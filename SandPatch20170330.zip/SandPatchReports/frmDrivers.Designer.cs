﻿namespace SandPatchReportsUI
{
    partial class frmDrivers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.ActiveDriversReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SandPatchReportsRowsets = new SandPatchReportsUI.SandPatchReportsRowsets();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmbDriverStatus = new System.Windows.Forms.ComboBox();
            this.lblDriverStatus = new System.Windows.Forms.Label();
            this.cmdPrint = new System.Windows.Forms.Button();
            this.reportViewerDrivers = new Microsoft.Reporting.WinForms.ReportViewer();
            this.ActiveDriversReportTableAdapter = new SandPatchReportsUI.SandPatchReportsRowsetsTableAdapters.ActiveDriversReportTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.ActiveDriversReportBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).BeginInit();
            this.SuspendLayout();
            // 
            // ActiveDriversReportBindingSource
            // 
            this.ActiveDriversReportBindingSource.DataMember = "ActiveDriversReport";
            this.ActiveDriversReportBindingSource.DataSource = this.SandPatchReportsRowsets;
            // 
            // SandPatchReportsRowsets
            // 
            this.SandPatchReportsRowsets.DataSetName = "SandPatchReportsRowsets";
            this.SandPatchReportsRowsets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(586, 30);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(124, 37);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Drivers";
            // 
            // cmbDriverStatus
            // 
            this.cmbDriverStatus.FormattingEnabled = true;
            this.cmbDriverStatus.Location = new System.Drawing.Point(621, 85);
            this.cmbDriverStatus.Name = "cmbDriverStatus";
            this.cmbDriverStatus.Size = new System.Drawing.Size(147, 24);
            this.cmbDriverStatus.TabIndex = 2;
            // 
            // lblDriverStatus
            // 
            this.lblDriverStatus.AutoSize = true;
            this.lblDriverStatus.Location = new System.Drawing.Point(528, 88);
            this.lblDriverStatus.Name = "lblDriverStatus";
            this.lblDriverStatus.Size = new System.Drawing.Size(87, 16);
            this.lblDriverStatus.TabIndex = 3;
            this.lblDriverStatus.Text = "Driver Status:";
            // 
            // cmdPrint
            // 
            this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPrint.Location = new System.Drawing.Point(597, 744);
            this.cmdPrint.Name = "cmdPrint";
            this.cmdPrint.Size = new System.Drawing.Size(103, 38);
            this.cmdPrint.TabIndex = 4;
            this.cmdPrint.Text = "Print";
            this.cmdPrint.UseVisualStyleBackColor = true;
            this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
            // 
            // reportViewerDrivers
            // 
            this.reportViewerDrivers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "ActiveDriversDataSet";
            reportDataSource1.Value = this.ActiveDriversReportBindingSource;
            this.reportViewerDrivers.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerDrivers.LocalReport.ReportEmbeddedResource = "SandPatchReportsUI.Reports.rptDrivers.rdlc";
            this.reportViewerDrivers.Location = new System.Drawing.Point(12, 131);
            this.reportViewerDrivers.Name = "reportViewerDrivers";
            this.reportViewerDrivers.Size = new System.Drawing.Size(1273, 597);
            this.reportViewerDrivers.TabIndex = 5;
            // 
            // ActiveDriversReportTableAdapter
            // 
            this.ActiveDriversReportTableAdapter.ClearBeforeFill = true;
            // 
            // frmDrivers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1297, 819);
            this.Controls.Add(this.reportViewerDrivers);
            this.Controls.Add(this.cmdPrint);
            this.Controls.Add(this.lblDriverStatus);
            this.Controls.Add(this.cmbDriverStatus);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDrivers";
            this.Text = "Drivers";
            this.Load += new System.EventHandler(this.frmDrivers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ActiveDriversReportBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cmbDriverStatus;
        private System.Windows.Forms.Label lblDriverStatus;
        private System.Windows.Forms.Button cmdPrint;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerDrivers;
        private System.Windows.Forms.BindingSource ActiveDriversReportBindingSource;
        private SandPatchReportsRowsets SandPatchReportsRowsets;
        private SandPatchReportsRowsetsTableAdapters.ActiveDriversReportTableAdapter ActiveDriversReportTableAdapter;
    }
}