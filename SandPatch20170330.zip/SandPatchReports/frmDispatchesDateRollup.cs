﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmDispatchesDateRollup : Form
    {
        private byte _includeNullDates = 1;

        public frmDispatchesDateRollup()
        {
            InitializeComponent();
        }

        private void frmDispatchesDateRollup_Load(object sender, EventArgs e)
        {
            ttDateNotification.SetToolTip(dtpFromDate, "Either or both dates can be cleared");
            ttDateNotification.SetToolTip(dtpToDate, "Either or both dates can be cleared");
        }

        private void dtp_Enter(object sender, EventArgs e)
        {
            ((DateTimePicker)sender).Format = DateTimePickerFormat.Custom;
            ((DateTimePicker)sender).CustomFormat = "MM/dd/yyyy";
        }

        private void contextNoDate_Click(object sender, EventArgs e)
        {
            if (dtpFromDate.Focused)
            {
                dtpFromDate.MinDate = DateTime.MinValue;
                dtpFromDate.Format = DateTimePickerFormat.Custom;
                dtpFromDate.CustomFormat = " ";
                dtpFromDate.Value = dtpFromDate.MinDate;
            }
            if (dtpToDate.Focused)
            {
                dtpToDate.MinDate = DateTime.MinValue;
                dtpToDate.Format = DateTimePickerFormat.Custom;
                dtpToDate.CustomFormat = " ";
                dtpToDate.Value = dtpToDate.MinDate;
            }
        }

        private void cmdPrint_Click(object sender, EventArgs e)
        {
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportDispatchDateRollup", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;

            if (dtpFromDate.Value != dtpFromDate.MinDate)
            {
                preprocess.Parameters.Add(new SqlParameter("@ReportDateStart", (object)dtpFromDate.Value));
            }

            if (dtpToDate.Value != dtpToDate.MinDate)
            {
                preprocess.Parameters.Add(new SqlParameter("@ReportDateStop", (object)dtpToDate.Value));
            }

            _includeNullDates = 1;
            if (chkIncludeNullDates.Checked == false) _includeNullDates = 0;
            preprocess.Parameters.Add(new SqlParameter("@IncludeNullDates", (object)_includeNullDates));

            preprocess.ExecuteNonQuery();

            Application.DoEvents();

            this.DispatchDateRollupReportTableAdapter.Connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();

            this.DispatchDateRollupReportTableAdapter.Fill(this.SandPatchReportsRowsets.DispatchDateRollupReport);

            reportViewerDispatchesDateRollup.RefreshReport();
       }

    }
}
