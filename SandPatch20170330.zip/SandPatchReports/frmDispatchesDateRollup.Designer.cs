﻿namespace SandPatchReportsUI
{
    partial class frmDispatchesDateRollup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.SandPatchReportsRowsets = new SandPatchReportsUI.SandPatchReportsRowsets();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmdPrint = new System.Windows.Forms.Button();
            this.reportViewerDispatchesDateRollup = new Microsoft.Reporting.WinForms.ReportViewer();
            this.lblFromDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.cmNoDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextNoDate = new System.Windows.Forms.ToolStripMenuItem();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.chkIncludeNullDates = new System.Windows.Forms.CheckBox();
            this.ttDateNotification = new System.Windows.Forms.ToolTip(this.components);
            this.DispatchDateRollupReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DispatchDateRollupReportTableAdapter = new SandPatchReportsUI.SandPatchReportsRowsetsTableAdapters.DispatchDateRollupReportTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).BeginInit();
            this.cmNoDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DispatchDateRollupReportBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SandPatchReportsRowsets
            // 
            this.SandPatchReportsRowsets.DataSetName = "SandPatchReportsRowsets";
            this.SandPatchReportsRowsets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(462, 30);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(372, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Dispatches Date Rollup";
            // 
            // cmdPrint
            // 
            this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPrint.Location = new System.Drawing.Point(597, 744);
            this.cmdPrint.Name = "cmdPrint";
            this.cmdPrint.Size = new System.Drawing.Size(103, 38);
            this.cmdPrint.TabIndex = 8;
            this.cmdPrint.Text = "Print";
            this.cmdPrint.UseVisualStyleBackColor = true;
            this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
            // 
            // reportViewerDispatchesDateRollup
            // 
            this.reportViewerDispatchesDateRollup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "DispatchDateRollupDataSet";
            reportDataSource1.Value = this.DispatchDateRollupReportBindingSource;
            this.reportViewerDispatchesDateRollup.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerDispatchesDateRollup.LocalReport.ReportEmbeddedResource = "SandPatchReportsUI.Reports.rptDispatchDateRollup.rdlc";
            this.reportViewerDispatchesDateRollup.Location = new System.Drawing.Point(12, 158);
            this.reportViewerDispatchesDateRollup.Name = "reportViewerDispatchesDateRollup";
            this.reportViewerDispatchesDateRollup.Size = new System.Drawing.Size(1273, 570);
            this.reportViewerDispatchesDateRollup.TabIndex = 7;
            // 
            // lblFromDate
            // 
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.Location = new System.Drawing.Point(357, 89);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Size = new System.Drawing.Size(42, 16);
            this.lblFromDate.TabIndex = 3;
            this.lblFromDate.Text = "From:";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.ContextMenuStrip = this.cmNoDate;
            this.dtpFromDate.Location = new System.Drawing.Point(405, 84);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(238, 22);
            this.dtpFromDate.TabIndex = 4;
            this.dtpFromDate.Enter += new System.EventHandler(this.dtp_Enter);
            // 
            // cmNoDate
            // 
            this.cmNoDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmNoDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contextNoDate});
            this.cmNoDate.Name = "cmNoDate";
            this.cmNoDate.Size = new System.Drawing.Size(138, 26);
            // 
            // contextNoDate
            // 
            this.contextNoDate.Name = "contextNoDate";
            this.contextNoDate.Size = new System.Drawing.Size(137, 22);
            this.contextNoDate.Text = "Clear Date";
            this.contextNoDate.Click += new System.EventHandler(this.contextNoDate_Click);
            // 
            // dtpToDate
            // 
            this.dtpToDate.ContextMenuStrip = this.cmNoDate;
            this.dtpToDate.Location = new System.Drawing.Point(701, 84);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(238, 22);
            this.dtpToDate.TabIndex = 6;
            this.dtpToDate.Enter += new System.EventHandler(this.dtp_Enter);
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Location = new System.Drawing.Point(664, 89);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(28, 16);
            this.lblToDate.TabIndex = 5;
            this.lblToDate.Text = "To:";
            // 
            // chkIncludeNullDates
            // 
            this.chkIncludeNullDates.AutoSize = true;
            this.chkIncludeNullDates.Checked = true;
            this.chkIncludeNullDates.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncludeNullDates.Location = new System.Drawing.Point(550, 117);
            this.chkIncludeNullDates.Name = "chkIncludeNullDates";
            this.chkIncludeNullDates.Size = new System.Drawing.Size(197, 20);
            this.chkIncludeNullDates.TabIndex = 16;
            this.chkIncludeNullDates.Text = "Include records with null date";
            this.chkIncludeNullDates.UseVisualStyleBackColor = true;
            // 
            // ttDateNotification
            // 
            this.ttDateNotification.ToolTipTitle = "Either or Both Dates Can Be Cleared";
            // 
            // DispatchDateRollupReportBindingSource
            // 
            this.DispatchDateRollupReportBindingSource.DataMember = "DispatchDateRollupReport";
            this.DispatchDateRollupReportBindingSource.DataSource = this.SandPatchReportsRowsets;
            // 
            // DispatchDateRollupReportTableAdapter
            // 
            this.DispatchDateRollupReportTableAdapter.ClearBeforeFill = true;
            // 
            // frmDispatchesDateRollup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1297, 819);
            this.Controls.Add(this.chkIncludeNullDates);
            this.Controls.Add(this.dtpToDate);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.dtpFromDate);
            this.Controls.Add(this.lblFromDate);
            this.Controls.Add(this.reportViewerDispatchesDateRollup);
            this.Controls.Add(this.cmdPrint);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDispatchesDateRollup";
            this.Text = "Dispatches Date Rollup";
            this.Load += new System.EventHandler(this.frmDispatchesDateRollup_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).EndInit();
            this.cmNoDate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DispatchDateRollupReportBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button cmdPrint;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerDispatchesDateRollup;
        private SandPatchReportsRowsets SandPatchReportsRowsets;
        private System.Windows.Forms.Label lblFromDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.ContextMenuStrip cmNoDate;
        private System.Windows.Forms.ToolStripMenuItem contextNoDate;
        private System.Windows.Forms.CheckBox chkIncludeNullDates;
        private System.Windows.Forms.ToolTip ttDateNotification;
        private System.Windows.Forms.BindingSource DispatchDateRollupReportBindingSource;
        private SandPatchReportsRowsetsTableAdapters.DispatchDateRollupReportTableAdapter DispatchDateRollupReportTableAdapter;
    }
}