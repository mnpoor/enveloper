﻿namespace SandPatchReportsUI
{
    partial class frmDispatchesJobRollup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.DispatchJobRollupReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SandPatchReportsRowsets = new SandPatchReportsUI.SandPatchReportsRowsets();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmbJobNumber = new System.Windows.Forms.ComboBox();
            this.lblJobNumber = new System.Windows.Forms.Label();
            this.cmdPrint = new System.Windows.Forms.Button();
            this.reportViewerDispatchesJobRollup = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DispatchJobRollupReportTableAdapter = new SandPatchReportsUI.SandPatchReportsRowsetsTableAdapters.DispatchJobRollupReportTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.DispatchJobRollupReportBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).BeginInit();
            this.SuspendLayout();
            // 
            // DispatchJobRollupReportBindingSource
            // 
            this.DispatchJobRollupReportBindingSource.DataMember = "DispatchJobRollupReport";
            this.DispatchJobRollupReportBindingSource.DataSource = this.SandPatchReportsRowsets;
            // 
            // SandPatchReportsRowsets
            // 
            this.SandPatchReportsRowsets.DataSetName = "SandPatchReportsRowsets";
            this.SandPatchReportsRowsets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(470, 30);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(356, 37);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Dispatches Job Rollup";
            // 
            // cmbJobNumber
            // 
            this.cmbJobNumber.FormattingEnabled = true;
            this.cmbJobNumber.Location = new System.Drawing.Point(592, 85);
            this.cmbJobNumber.Name = "cmbJobNumber";
            this.cmbJobNumber.Size = new System.Drawing.Size(205, 24);
            this.cmbJobNumber.TabIndex = 2;
            // 
            // lblJobNumber
            // 
            this.lblJobNumber.AutoSize = true;
            this.lblJobNumber.Location = new System.Drawing.Point(499, 88);
            this.lblJobNumber.Name = "lblJobNumber";
            this.lblJobNumber.Size = new System.Drawing.Size(85, 16);
            this.lblJobNumber.TabIndex = 3;
            this.lblJobNumber.Text = "Job Number:";
            // 
            // cmdPrint
            // 
            this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPrint.Location = new System.Drawing.Point(597, 744);
            this.cmdPrint.Name = "cmdPrint";
            this.cmdPrint.Size = new System.Drawing.Size(103, 38);
            this.cmdPrint.TabIndex = 4;
            this.cmdPrint.Text = "Print";
            this.cmdPrint.UseVisualStyleBackColor = true;
            this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
            // 
            // reportViewerDispatchesJobRollup
            // 
            this.reportViewerDispatchesJobRollup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "DispatchJobRollupDataSet";
            reportDataSource1.Value = this.DispatchJobRollupReportBindingSource;
            this.reportViewerDispatchesJobRollup.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerDispatchesJobRollup.LocalReport.ReportEmbeddedResource = "SandPatchReportsUI.Reports.rptDispatchJobNumberRollup.rdlc";
            this.reportViewerDispatchesJobRollup.Location = new System.Drawing.Point(12, 131);
            this.reportViewerDispatchesJobRollup.Name = "reportViewerDispatchesJobRollup";
            this.reportViewerDispatchesJobRollup.Size = new System.Drawing.Size(1273, 597);
            this.reportViewerDispatchesJobRollup.TabIndex = 5;
            // 
            // DispatchJobRollupReportTableAdapter
            // 
            this.DispatchJobRollupReportTableAdapter.ClearBeforeFill = true;
            // 
            // frmDispatchesJobRollup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1297, 819);
            this.Controls.Add(this.reportViewerDispatchesJobRollup);
            this.Controls.Add(this.cmdPrint);
            this.Controls.Add(this.lblJobNumber);
            this.Controls.Add(this.cmbJobNumber);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDispatchesJobRollup";
            this.Text = "Dispatches Job Rollup";
            this.Load += new System.EventHandler(this.frmDispatchesJobRollup_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DispatchJobRollupReportBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cmbJobNumber;
        private System.Windows.Forms.Label lblJobNumber;
        private System.Windows.Forms.Button cmdPrint;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerDispatchesJobRollup;
        private SandPatchReportsRowsets SandPatchReportsRowsets;
        private System.Windows.Forms.BindingSource DispatchJobRollupReportBindingSource;
        private SandPatchReportsRowsetsTableAdapters.DispatchJobRollupReportTableAdapter DispatchJobRollupReportTableAdapter;
    }
}