using SandPatchCL;
using SandPatchCL.DataServices;
using SandPatchReportsUI.WinControls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmDispatchesWeeklyRecap : Form
    {
        private PaySchedule _paySchedule;
        private Collection<PaySchedule> _paySchedules;

        private Shipper _shipper;

        private Customer _customer;

        private Dispatch _dispatch;
        private Collection<Dispatch> _dispatches;

        private Invoice _invoice;

        private LoadingTerminal _loadingTerminal;

        private JobSite _jobSite;

        #region Private Members
        
        private const int FIELD_SEQUENCENUMBER                     = 0;
        private const int FIELD_PAYPERIODSTARTDATE                 = 1;
        private const int FIELD_PAYPERIODENDDATE                   = 2;
        private const int FIELD_DISPATCHID                         = 3;
        private const int FIELD_CUSTOMERID                         = 4;
        private const int FIELD_JOBNUMBERID                        = 5;
        private const int FIELD_PURCHASEORDERID                    = 6;
        private const int FIELD_DISPATCHACCEPTANCENUMBER           = 7;
        private const int FIELD_DISPATCHACCEPTANCEDATE             = 8;
        private const int FIELD_CARRIERID                          = 9;
        private const int FIELD_DRIVERID                           = 10;
        private const int FIELD_TRUCKNUMBER                        = 11;
        private const int FIELD_PURCHASEORDERNUMBER                = 12;
        private const int FIELD_DISPATCHSTATUSID                   = 13;
        private const int FIELD_FREIGHTID                          = 14;
        private const int FIELD_FREIGHTNAME                        = 15;
        private const int FIELD_LOADINGTERMINALID                  = 16;
        private const int FIELD_LOADINGTERMINALNAME                = 17;
        private const int FIELD_LOADINGTERMINALAPPOINTMENTDATETIME = 18;
        private const int FIELD_ACTUALLOADINGTERMINALARRIVALTIME   = 19;
        private const int FIELD_ACTUALLOADINGTERMINALDEPARTURETIME = 20;
        private const int FIELD_BILLOFLADINGID                     = 21;
        private const int FIELD_BILLOFLADINGNUMBER                 = 22;
        private const int FIELD_SHIPMENTWEIGHT                     = 23;
        private const int FIELD_TICKETNUMBER                       = 24;
        private const int FIELD_JOBSITEID                          = 25;
        private const int FIELD_JOBSITENAME                        = 26;
        private const int FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME = 27;
        private const int FIELD_JOBSITEACTUALARRIVALTIME           = 28;
        private const int FIELD_JOBSITEACTUALDEPARTURETIME         = 29;
        private const int FIELD_DISPATCHMILES                      = 30;
        private const int FIELD_DISPATCHTOTALHOURS                 = 31;
        private const int FIELD_ADDEDBY                            = 32;
        private const int FIELD_UPDATEDBY                          = 33;
        
        #endregion

        private string[][] _rowSet;

        private string _column1;
        private string _column2;
        private string _column3;
        private string _column4;
        private string _column5;
        private string _column6;
        private string _column7;
        private string _column8;
        private string _column9;
        private string _column10;
        private string _column11;
        private string _column12;
        private string _column13;
        private string _column14;
        private string _column15;
        private string _column16;
        private string _column17;

        private Size _textSize;

        private System.Drawing.Printing.PrintDocument _dispatchReportDocument = new System.Drawing.Printing.PrintDocument();

        internal PrintPreviewDialog _previewDialog;

        private System.Drawing.Printing.PrinterSettings.PaperSizeCollection _paperSizes;
        private System.Drawing.Printing.PaperSize _paperSize;
        //private System.Drawing.Rectangle _pageDrawingArea = new Rectangle(new Point(125, 125), new Size(1950, 3200));
        //private System.Drawing.Rectangle _pageSize = new Rectangle(new Point(0, 0), new Size(2050, 3300));
        private System.Drawing.Printing.PrinterSettings _printerSettings = new System.Drawing.Printing.PrinterSettings();
        //private System.Drawing.Printing.PageSettings _pageSettings = new System.Drawing.Printing.PageSettings(new System.Drawing.Printing.PrinterSettings());

        private FontFamily[] _allFonts;
        private FontFamily _arialFontFamily;
        private FontFamily _calibriFontFamily;
        private FontFamily _timesRomanFontFamily;
        private Font _reportEndDateFont;
        private Font _pageHeaderFont;
        private Font _groupHeaderFont;
        private Font _columnHeaderFont;
        private Font _lineItemFont;

        private Rectangle _lowerTitleBar = new Rectangle(50, 180, 750, 16);

        private Rectangle _chargeCodeBox;
        private Rectangle _lineItemBox;
        private Rectangle _totalBox;

        private int _lastJobSiteId = 0;
        private DateTime _lastAcceptanceDate;

        private int i = 0;
        private int _rowNumber = 0;
        private int _pageNumber = 0;
        private int x = 0;
        private int y = 0;
        private int _topRowY = 0;

        public frmDispatchesWeeklyRecap()
        {
            InitializeComponent();
        }

        private void frmDispatchesWeeklyRecap_Load(object sender, EventArgs e)
        {
            _paySchedules = DataServicePaySchedules.PayScheduleSqlGetAll();
            Application.DoEvents();
            cmbWeekYear.DataSource = _paySchedules;
            cmbWeekYear.DisplayMember = "PayPeriodEndDate";
            cmbWeekYear.ValueMember = "PayScheduleId";
        }

        private void cmdPreviewPrint_Click(object sender, EventArgs e)
        {
            _paySchedule = (PaySchedule)cmbWeekYear.SelectedItem;

            string sqlStatement = "ReportDispatchesInPayPeriod";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PayScheduleId", (object)_paySchedule.PayScheduleId));

            IDataReader dataReader;

            dataReader = command.ExecuteReader();

            _rowSet = new string[dataReader.RecordsAffected][];

            i = 0;

            while (dataReader.Read())
            {
                string[] reportRow = new string[34];
                reportRow[0] = dataReader.IsDBNull(FIELD_SEQUENCENUMBER) ? string.Empty : dataReader.GetInt32(FIELD_SEQUENCENUMBER).ToString("###");
                reportRow[1] = dataReader.IsDBNull(FIELD_PAYPERIODSTARTDATE) ? string.Empty : dataReader.GetDateTime(FIELD_PAYPERIODSTARTDATE).ToString("MM/dd/yyyy");
                reportRow[2] = dataReader.IsDBNull(FIELD_PAYPERIODENDDATE) ? string.Empty : dataReader.GetDateTime(FIELD_PAYPERIODENDDATE).ToString("MM/dd/yyyy");
                reportRow[3] = dataReader.IsDBNull(FIELD_DISPATCHID) ? string.Empty : dataReader.GetInt32(FIELD_DISPATCHID).ToString();
                reportRow[4] = dataReader.IsDBNull(FIELD_CUSTOMERID) ? string.Empty : dataReader.GetInt32(FIELD_CUSTOMERID).ToString();
                reportRow[5] = dataReader.IsDBNull(FIELD_JOBNUMBERID) ? string.Empty : dataReader.GetInt32(FIELD_JOBNUMBERID).ToString();
                reportRow[6] = dataReader.IsDBNull(FIELD_PURCHASEORDERID) ? string.Empty : dataReader.GetInt32(FIELD_PURCHASEORDERID).ToString();
                reportRow[7] = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCENUMBER) ? string.Empty : dataReader.GetString(FIELD_DISPATCHACCEPTANCENUMBER);
                reportRow[8] = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCEDATE) ? string.Empty : dataReader.GetDateTime(FIELD_DISPATCHACCEPTANCEDATE).ToString("MM/dd/yyyy");
                reportRow[9] = dataReader.IsDBNull(FIELD_CARRIERID) ? string.Empty : dataReader.GetInt32(FIELD_CARRIERID).ToString();
                reportRow[10] = dataReader.IsDBNull(FIELD_DRIVERID) ? string.Empty : dataReader.GetInt32(FIELD_DRIVERID).ToString();
                reportRow[11] = dataReader.IsDBNull(FIELD_TRUCKNUMBER) ? string.Empty : dataReader.GetInt32(FIELD_TRUCKNUMBER).ToString();
                reportRow[12] = dataReader.IsDBNull(FIELD_PURCHASEORDERNUMBER) ? string.Empty : dataReader.GetString(FIELD_PURCHASEORDERNUMBER);
                reportRow[13] = dataReader.IsDBNull(FIELD_DISPATCHSTATUSID) ? string.Empty : dataReader.GetInt32(FIELD_DISPATCHSTATUSID).ToString();
                reportRow[14] = dataReader.IsDBNull(FIELD_FREIGHTID) ? string.Empty : dataReader.GetInt32(FIELD_FREIGHTID).ToString();
                reportRow[15] = dataReader.IsDBNull(FIELD_FREIGHTNAME) ? string.Empty : dataReader.GetString(FIELD_FREIGHTNAME);
                reportRow[16] = dataReader.IsDBNull(FIELD_LOADINGTERMINALID) ? string.Empty : dataReader.GetInt32(FIELD_LOADINGTERMINALID).ToString();
                reportRow[17] = dataReader.IsDBNull(FIELD_LOADINGTERMINALNAME) ? string.Empty : dataReader.GetString(FIELD_LOADINGTERMINALNAME);
                reportRow[18] = dataReader.IsDBNull(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME) ? string.Empty : dataReader.GetDateTime(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME).ToString("MM/dd/yy hh:mm");
                reportRow[19] = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALARRIVALTIME) ? string.Empty : dataReader.GetDateTime(FIELD_ACTUALLOADINGTERMINALARRIVALTIME).ToString("MM/dd/yy hh:mm");
                reportRow[20] = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME) ? string.Empty : dataReader.GetDateTime(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME).ToString("MM/dd/yy hh:mm");
                reportRow[21] = dataReader.IsDBNull(FIELD_BILLOFLADINGID) ? string.Empty : dataReader.GetInt32(FIELD_BILLOFLADINGID).ToString();
                reportRow[22] = dataReader.IsDBNull(FIELD_BILLOFLADINGNUMBER) ? string.Empty : dataReader.GetString(FIELD_BILLOFLADINGNUMBER);
                reportRow[23] = dataReader.IsDBNull(FIELD_SHIPMENTWEIGHT) ? string.Empty : dataReader.GetDecimal(FIELD_SHIPMENTWEIGHT).ToString("##,###");
                reportRow[24] = dataReader.IsDBNull(FIELD_TICKETNUMBER) ? string.Empty : dataReader.GetString(FIELD_TICKETNUMBER);
                reportRow[25] = dataReader.IsDBNull(FIELD_JOBSITEID) ? string.Empty : dataReader.GetInt32(FIELD_JOBSITEID).ToString();
                reportRow[26] = dataReader.IsDBNull(FIELD_JOBSITENAME) ? string.Empty : dataReader.GetString(FIELD_JOBSITENAME);
                reportRow[27] = dataReader.IsDBNull(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME) ? string.Empty : dataReader.GetDateTime(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME).ToString("MM/dd/yy hh:mm");
                reportRow[28] = dataReader.IsDBNull(FIELD_JOBSITEACTUALARRIVALTIME) ? string.Empty : dataReader.GetDateTime(FIELD_JOBSITEACTUALARRIVALTIME).ToString("MM/dd/yy hh:mm");
                reportRow[29] = dataReader.IsDBNull(FIELD_JOBSITEACTUALDEPARTURETIME) ? string.Empty : dataReader.GetDateTime(FIELD_JOBSITEACTUALDEPARTURETIME).ToString("MM/dd/yy hh:mm");
                reportRow[30] = dataReader.IsDBNull(FIELD_DISPATCHMILES) ? string.Empty : dataReader.GetInt32(FIELD_DISPATCHMILES).ToString();
                reportRow[31] = dataReader.IsDBNull(FIELD_DISPATCHTOTALHOURS) ? string.Empty : dataReader.GetValue(FIELD_DISPATCHTOTALHOURS).ToString();
                reportRow[32] = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty : dataReader.GetString(FIELD_ADDEDBY);
                reportRow[33] = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty : dataReader.GetString(FIELD_UPDATEDBY);
                _rowSet[i++] = reportRow;
            }

            command.Connection.Close();

            _previewDialog = new PrintPreviewDialog();
            _previewDialog.Document = _dispatchReportDocument;
            _previewDialog.ClientSize = new System.Drawing.Size(775, 1000);
            _previewDialog.Location = new System.Drawing.Point(120, 32);
            _previewDialog.Name = "Print Dispatch Weekly Recap";

            //_pageSettings = new System.Drawing.Printing.PageSettings(_printerSettings);
            _printerSettings.FromPage = 1;
            _printerSettings.ToPage = 1;
            _printerSettings.Copies = 1;
            _paperSizes = _printerSettings.PaperSizes;
            foreach (System.Drawing.Printing.PaperSize paperSize in _paperSizes)
            {
                if (paperSize.PaperName == "Legal") _paperSize = paperSize;
            }
            
            _dispatchReportDocument.DefaultPageSettings = new System.Drawing.Printing.PageSettings(_printerSettings);
            _dispatchReportDocument.DefaultPageSettings.PaperSize = _paperSize;
            _dispatchReportDocument.DefaultPageSettings.Landscape = true;
            _dispatchReportDocument.BeginPrint += new System.Drawing.Printing.PrintEventHandler(DispatchReportDocument_BeginPrint);
            _dispatchReportDocument.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(DispatchReportDocument_QueryPageSettings);
            _dispatchReportDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(DispatchReportDocument_PrintPage);

            _previewDialog.MinimumSize = new System.Drawing.Size(375, 250);
            _previewDialog.UseAntiAlias = true;

            _allFonts = FontFamily.Families;
            foreach (FontFamily item in _allFonts)
            {
                if (item.Name == "Arial") _arialFontFamily = item;
                if (item.Name == "Calibri") _calibriFontFamily = item;
                if (item.Name == "Times New Roman") _timesRomanFontFamily = item;
            }
            _reportEndDateFont = new Font(_arialFontFamily, 20f, FontStyle.Bold, GraphicsUnit.Point);
            _pageHeaderFont = new Font(_calibriFontFamily, 12f, FontStyle.Bold, GraphicsUnit.Point);
            _groupHeaderFont = new Font(_arialFontFamily, 12f, FontStyle.Regular, GraphicsUnit.Point);
            _columnHeaderFont = new Font(_timesRomanFontFamily, 9f, FontStyle.Regular, GraphicsUnit.Point);
            _lineItemFont = new Font(_calibriFontFamily, 10f, FontStyle.Regular, GraphicsUnit.Point);

            DialogResult response = _previewDialog.ShowDialog();
        }

        public void DispatchReportDocument_BeginPrint(Object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            _pageNumber = 1;
            _lastJobSiteId = 0;
        }

        public void DispatchReportDocument_QueryPageSettings(Object sender, System.Drawing.Printing.PrintEventArgs e)
        {
        }

        private void DispatchReportDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            y = 25;

            _column1 = _rowSet[0][2];     // end date
            e.Graphics.DrawString(_column1, _reportEndDateFont, Brushes.Black, 1100, y);

            _column1 = _pageNumber++.ToString();     // page number
            e.Graphics.DrawString(_column1, _reportEndDateFont, Brushes.Black, 1300, y);

            y += 30;

            _column1 = "Weekly Spreadsheet for " + _rowSet[0][1] + " to " + _rowSet[0][2];     // start date to end date
            _textSize = TextRenderer.MeasureText(_column1, _pageHeaderFont);
            e.Graphics.DrawString(_column1, _pageHeaderFont, Brushes.Black, 700 - (_textSize.Width / 2), y);

            y += 18;

            _topRowY = y;

            while (y < 800)
            {
                if (_rowSet[_rowNumber] == null)
                {
                    e.HasMorePages = false;
                    return;
                }

                string[] lineItem = _rowSet[_rowNumber++];

                int jobSiteId = Convert.ToInt32(lineItem[25]);
                DateTime currentAcceptanceDate = Convert.ToDateTime(lineItem[8]);

                if (_lastJobSiteId != jobSiteId)
                {
                    _column1 = lineItem[26];
                    _textSize = TextRenderer.MeasureText(_column1, _groupHeaderFont);
                    e.Graphics.DrawString(_column1, _groupHeaderFont, Brushes.Black, 700 - (_textSize.Width / 2), y);

                    y += 15;

                    DrawColumnHeaders(e);

                    _lastJobSiteId = jobSiteId;
                    _lastAcceptanceDate = currentAcceptanceDate;
                }
                else
                {
                    if (_topRowY == y)
                    {
                        DrawColumnHeaders(e);
                    }
                }

                if (_lastAcceptanceDate != currentAcceptanceDate)
                {
                    _lastAcceptanceDate = currentAcceptanceDate;
                    y += 15;
                }

                _column1 = lineItem[0];     // sequence
                _textSize = TextRenderer.MeasureText(_column1, _lineItemFont); // compute right justification
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 55 - _textSize.Width, y);

                _column1 = lineItem[11];    // truck number
                _textSize = TextRenderer.MeasureText(_column1, _lineItemFont); // compute right justification
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 120 - _textSize.Width, y);

                _column1 = lineItem[7];    // dispatch acceptance number
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 130, y);

                _column1 = lineItem[8];    // dispatch acceptance date
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 210, y);

                _column1 = lineItem[12];    // purchase order number
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 300, y);

                _column1 = lineItem[15];    // freight name
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 400, y);

                _column1 = lineItem[18];    // loading terminal appointment date time
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 475, y);

                _column1 = lineItem[27];    // job site appointment date time
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 585, y);

                _column1 = lineItem[22];    // bill of lading
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 695, y);

                _column1 = lineItem[23];    // shipment weight
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 765, y);

                _column1 = lineItem[24];    // ticket number
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 845, y);

                _column1 = lineItem[19];    // actual loading arrival time
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 925, y);

                _column1 = lineItem[20];    // actual loading departure time
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 1035, y);

                _column1 = lineItem[28];    // actual job site arrival time
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 1145, y);

                _column1 = lineItem[29];    // actual job site departure time
                e.Graphics.DrawString(_column1, _lineItemFont, Brushes.Black, 1255, y);

                y += 15;
            }

            e.HasMorePages = true;
        }

        private void DrawColumnHeaders(System.Drawing.Printing.PrintPageEventArgs e)
        {
            _column1 = "Unit Number";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(60f, (float)y, 60f, 40f));

            _column1 = "Dispatch Acceptance Number";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(130f, (float)y, 100f, 40f));

            _column1 = "Dispatch Acceptance Date";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(210f, (float)y, 90f, 40f));

            _column1 = "Purchase Order Number";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(300f, (float)y, 80f, 40f));

            _column1 = "Freight Name";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(400f, (float)y, 60f, 40f));

            _column1 = "Loading Appointment Date Time";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(475f, (float)y, 115f, 40f));

            _column1 = "Job Site Delivery Appointment Date Time";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(585f, (float)y, 115f, 40f));

            _column1 = "Bill Of Lading Number";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(695f, (float)y, 70f, 40f));

            _column1 = "Shipment Weight";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(765f, (float)y, 70f, 40f));

            _column1 = "Ticket Number";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(845f, (float)y, 70f, 40f));

            _column1 = "Loading Arrival Time";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(925f, (float)y, 100f, 40f));

            _column1 = "Loading Departure Time";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(1035f, (float)y, 100f, 40f));

            _column1 = "Job Site Arrival Time";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(1145f, (float)y, 100f, 40f));

            _column1 = "Job Site Departure Time";
            e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(1255f, (float)y, 100f, 40f));

            //_column1 = "Dispatch Total Hours";
            //e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(210f, (float)y, 120f, 40f));

            //_column1 = "Dispatch Miles";
            //e.Graphics.DrawString(_column1, _columnHeaderFont, Brushes.Black, new RectangleF(210f, (float)y, 120f, 40f));

            y += 45;
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
