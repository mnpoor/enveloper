﻿namespace SandPatchReportsUI
{
    partial class frmJobNumbersRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.SandPatchReportsRowsets = new SandPatchReportsUI.SandPatchReportsRowsets();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmbJobNumberStatus = new System.Windows.Forms.ComboBox();
            this.lblJobNumberStatus = new System.Windows.Forms.Label();
            this.cmdPrint = new System.Windows.Forms.Button();
            this.reportViewerJobNumbers = new Microsoft.Reporting.WinForms.ReportViewer();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.cmbCustomers = new System.Windows.Forms.ComboBox();
            this.JobNumbersReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.JobNumbersReportTableAdapter = new SandPatchReportsUI.SandPatchReportsRowsetsTableAdapters.JobNumbersReportTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.JobNumbersReportBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SandPatchReportsRowsets
            // 
            this.SandPatchReportsRowsets.DataSetName = "SandPatchReportsRowsets";
            this.SandPatchReportsRowsets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(538, 30);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(220, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Job Numbers";
            // 
            // cmbJobNumberStatus
            // 
            this.cmbJobNumberStatus.FormattingEnabled = true;
            this.cmbJobNumberStatus.Location = new System.Drawing.Point(650, 119);
            this.cmbJobNumberStatus.Name = "cmbJobNumberStatus";
            this.cmbJobNumberStatus.Size = new System.Drawing.Size(147, 24);
            this.cmbJobNumberStatus.TabIndex = 4;
            // 
            // lblJobNumberStatus
            // 
            this.lblJobNumberStatus.AutoSize = true;
            this.lblJobNumberStatus.Location = new System.Drawing.Point(499, 122);
            this.lblJobNumberStatus.Name = "lblJobNumberStatus";
            this.lblJobNumberStatus.Size = new System.Drawing.Size(125, 16);
            this.lblJobNumberStatus.TabIndex = 3;
            this.lblJobNumberStatus.Text = "Job Number Status:";
            // 
            // cmdPrint
            // 
            this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPrint.Location = new System.Drawing.Point(597, 744);
            this.cmdPrint.Name = "cmdPrint";
            this.cmdPrint.Size = new System.Drawing.Size(103, 38);
            this.cmdPrint.TabIndex = 6;
            this.cmdPrint.Text = "Print";
            this.cmdPrint.UseVisualStyleBackColor = true;
            this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
            // 
            // reportViewerJobNumbers
            // 
            this.reportViewerJobNumbers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "JobNumbersDataSet";
            reportDataSource1.Value = this.JobNumbersReportBindingSource;
            this.reportViewerJobNumbers.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerJobNumbers.LocalReport.ReportEmbeddedResource = "SandPatchReportsUI.Reports.rptJobNumbersRegister.rdlc";
            this.reportViewerJobNumbers.Location = new System.Drawing.Point(12, 168);
            this.reportViewerJobNumbers.Name = "reportViewerJobNumbers";
            this.reportViewerJobNumbers.Size = new System.Drawing.Size(1273, 560);
            this.reportViewerJobNumbers.TabIndex = 5;
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(499, 82);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(68, 16);
            this.lblCustomer.TabIndex = 1;
            this.lblCustomer.Text = "Customer:";
            // 
            // cmbCustomers
            // 
            this.cmbCustomers.FormattingEnabled = true;
            this.cmbCustomers.Location = new System.Drawing.Point(650, 79);
            this.cmbCustomers.Name = "cmbCustomers";
            this.cmbCustomers.Size = new System.Drawing.Size(147, 24);
            this.cmbCustomers.TabIndex = 2;
            // 
            // JobNumbersReportBindingSource
            // 
            this.JobNumbersReportBindingSource.DataMember = "JobNumbersReport";
            this.JobNumbersReportBindingSource.DataSource = this.SandPatchReportsRowsets;
            // 
            // JobNumbersReportTableAdapter
            // 
            this.JobNumbersReportTableAdapter.ClearBeforeFill = true;
            // 
            // frmJobNumbersRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1297, 819);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.cmbCustomers);
            this.Controls.Add(this.reportViewerJobNumbers);
            this.Controls.Add(this.cmdPrint);
            this.Controls.Add(this.lblJobNumberStatus);
            this.Controls.Add(this.cmbJobNumberStatus);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmJobNumbersRegister";
            this.Text = "Job Numbers Report";
            this.Load += new System.EventHandler(this.frmJobNumbersRegister_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.JobNumbersReportBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cmbJobNumberStatus;
        private System.Windows.Forms.Label lblJobNumberStatus;
        private System.Windows.Forms.Button cmdPrint;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerJobNumbers;
        private SandPatchReportsRowsets SandPatchReportsRowsets;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.ComboBox cmbCustomers;
        private System.Windows.Forms.BindingSource JobNumbersReportBindingSource;
        private SandPatchReportsRowsetsTableAdapters.JobNumbersReportTableAdapter JobNumbersReportTableAdapter;
    }
}