﻿namespace SandPatchReportsUI
{
    partial class frmSandPatchReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuSandPatchReports = new System.Windows.Forms.MenuStrip();
            this.menuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTransaction = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTransactionInvoices = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReports = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDrivers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDriversStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDispatches = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDispatchesJobRollup = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDispatchesDriverActivity = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDispatchesDateRollup = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsJobNumbers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsPurchaseOrders = new System.Windows.Forms.ToolStripMenuItem();
            this.menuValidation = new System.Windows.Forms.ToolStripMenuItem();
            this.menuValidationPaymentDueTerms = new System.Windows.Forms.ToolStripMenuItem();
            this.menuValidationInvoiceDetailPrototype = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReportsDispachesWeeklyRecap = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSandPatchReports.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuSandPatchReports
            // 
            this.menuSandPatchReports.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFile,
            this.menuMaster,
            this.menuTransaction,
            this.menuReports,
            this.menuValidation});
            this.menuSandPatchReports.Location = new System.Drawing.Point(0, 0);
            this.menuSandPatchReports.Name = "menuSandPatchReports";
            this.menuSandPatchReports.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuSandPatchReports.Size = new System.Drawing.Size(1276, 24);
            this.menuSandPatchReports.TabIndex = 2;
            this.menuSandPatchReports.Text = "menuStrip1";
            // 
            // menuFile
            // 
            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFileConnection,
            this.menuFileSeparator1,
            this.menuFileExit});
            this.menuFile.Name = "menuFile";
            this.menuFile.Size = new System.Drawing.Size(37, 20);
            this.menuFile.Text = "File";
            // 
            // menuFileConnection
            // 
            this.menuFileConnection.Name = "menuFileConnection";
            this.menuFileConnection.Size = new System.Drawing.Size(136, 22);
            this.menuFileConnection.Text = "Connection";
            this.menuFileConnection.Click += new System.EventHandler(this.menuFileConnection_Click);
            // 
            // menuFileSeparator1
            // 
            this.menuFileSeparator1.Name = "menuFileSeparator1";
            this.menuFileSeparator1.Size = new System.Drawing.Size(133, 6);
            // 
            // menuFileExit
            // 
            this.menuFileExit.Name = "menuFileExit";
            this.menuFileExit.Size = new System.Drawing.Size(136, 22);
            this.menuFileExit.Text = "Exit";
            this.menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
            // 
            // menuMaster
            // 
            this.menuMaster.Name = "menuMaster";
            this.menuMaster.Size = new System.Drawing.Size(55, 20);
            this.menuMaster.Text = "Master";
            // 
            // menuTransaction
            // 
            this.menuTransaction.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuTransactionInvoices});
            this.menuTransaction.Name = "menuTransaction";
            this.menuTransaction.Size = new System.Drawing.Size(81, 20);
            this.menuTransaction.Text = "Transaction";
            // 
            // menuTransactionInvoices
            // 
            this.menuTransactionInvoices.Name = "menuTransactionInvoices";
            this.menuTransactionInvoices.Size = new System.Drawing.Size(117, 22);
            this.menuTransactionInvoices.Text = "Invoices";
            this.menuTransactionInvoices.Click += new System.EventHandler(this.menuTransactionInvoices_Click);
            // 
            // menuReports
            // 
            this.menuReports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuReportsDrivers,
            this.menuReportsDispatches,
            this.menuReportsJobNumbers,
            this.menuReportsPurchaseOrders});
            this.menuReports.Name = "menuReports";
            this.menuReports.Size = new System.Drawing.Size(59, 20);
            this.menuReports.Text = "Reports";
            // 
            // menuReportsDrivers
            // 
            this.menuReportsDrivers.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuReportsDriversStatus});
            this.menuReportsDrivers.Name = "menuReportsDrivers";
            this.menuReportsDrivers.Size = new System.Drawing.Size(160, 22);
            this.menuReportsDrivers.Text = "Drivers";
            // 
            // menuReportsDriversStatus
            // 
            this.menuReportsDriversStatus.Name = "menuReportsDriversStatus";
            this.menuReportsDriversStatus.Size = new System.Drawing.Size(106, 22);
            this.menuReportsDriversStatus.Text = "Status";
            this.menuReportsDriversStatus.Click += new System.EventHandler(this.menuReportsDriversStatus_Click);
            // 
            // menuReportsDispatches
            // 
            this.menuReportsDispatches.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuReportsDispatchesJobRollup,
            this.menuReportsDispatchesDriverActivity,
            this.menuReportsDispatchesDateRollup,
            this.menuReportsDispachesWeeklyRecap});
            this.menuReportsDispatches.Name = "menuReportsDispatches";
            this.menuReportsDispatches.Size = new System.Drawing.Size(160, 22);
            this.menuReportsDispatches.Text = "Dispatches";
            // 
            // menuReportsDispatchesJobRollup
            // 
            this.menuReportsDispatchesJobRollup.Name = "menuReportsDispatchesJobRollup";
            this.menuReportsDispatchesJobRollup.Size = new System.Drawing.Size(152, 22);
            this.menuReportsDispatchesJobRollup.Text = "Job Rollup";
            this.menuReportsDispatchesJobRollup.Click += new System.EventHandler(this.menuReportsDispatchesJobRollup_Click);
            // 
            // menuReportsDispatchesDriverActivity
            // 
            this.menuReportsDispatchesDriverActivity.Name = "menuReportsDispatchesDriverActivity";
            this.menuReportsDispatchesDriverActivity.Size = new System.Drawing.Size(152, 22);
            this.menuReportsDispatchesDriverActivity.Text = "Driver Activity";
            this.menuReportsDispatchesDriverActivity.Click += new System.EventHandler(this.menuReportsDispatchesDriverActivity_Click);
            // 
            // menuReportsDispatchesDateRollup
            // 
            this.menuReportsDispatchesDateRollup.Name = "menuReportsDispatchesDateRollup";
            this.menuReportsDispatchesDateRollup.Size = new System.Drawing.Size(152, 22);
            this.menuReportsDispatchesDateRollup.Text = "Date Rollup";
            this.menuReportsDispatchesDateRollup.Click += new System.EventHandler(this.menuReportsDispatchesDateRollup_Click);
            // 
            // menuReportsJobNumbers
            // 
            this.menuReportsJobNumbers.Name = "menuReportsJobNumbers";
            this.menuReportsJobNumbers.Size = new System.Drawing.Size(160, 22);
            this.menuReportsJobNumbers.Text = "Job Numbers";
            this.menuReportsJobNumbers.Click += new System.EventHandler(this.menuReportsJobNumbers_Click);
            // 
            // menuReportsPurchaseOrders
            // 
            this.menuReportsPurchaseOrders.Name = "menuReportsPurchaseOrders";
            this.menuReportsPurchaseOrders.Size = new System.Drawing.Size(160, 22);
            this.menuReportsPurchaseOrders.Text = "Purchase Orders";
            this.menuReportsPurchaseOrders.Click += new System.EventHandler(this.menuReportsPurchaseOrders_Click);
            // 
            // menuValidation
            // 
            this.menuValidation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuValidationPaymentDueTerms,
            this.menuValidationInvoiceDetailPrototype});
            this.menuValidation.Name = "menuValidation";
            this.menuValidation.Size = new System.Drawing.Size(72, 20);
            this.menuValidation.Text = "Validation";
            // 
            // menuValidationPaymentDueTerms
            // 
            this.menuValidationPaymentDueTerms.Name = "menuValidationPaymentDueTerms";
            this.menuValidationPaymentDueTerms.Size = new System.Drawing.Size(200, 22);
            this.menuValidationPaymentDueTerms.Text = "Payment Due Terms";
            this.menuValidationPaymentDueTerms.Click += new System.EventHandler(this.menuValidationPaymentDueTerms_Click);
            // 
            // menuValidationInvoiceDetailPrototype
            // 
            this.menuValidationInvoiceDetailPrototype.Name = "menuValidationInvoiceDetailPrototype";
            this.menuValidationInvoiceDetailPrototype.Size = new System.Drawing.Size(200, 22);
            this.menuValidationInvoiceDetailPrototype.Text = "Invoice Detail Prototype";
            this.menuValidationInvoiceDetailPrototype.Click += new System.EventHandler(this.menuValidationInvoiceDetailPrototype_Click);
            // 
            // menuReportsDispachesWeeklyRecap
            // 
            this.menuReportsDispachesWeeklyRecap.Name = "menuReportsDispachesWeeklyRecap";
            this.menuReportsDispachesWeeklyRecap.Size = new System.Drawing.Size(152, 22);
            this.menuReportsDispachesWeeklyRecap.Text = "Weekly Recap";
            this.menuReportsDispachesWeeklyRecap.Click += new System.EventHandler(this.menuReportsDispachesWeeklyRecap_Click);
            // 
            // frmSandPatchReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1276, 849);
            this.Controls.Add(this.menuSandPatchReports);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmSandPatchReports";
            this.Text = "SandPatch Reports";
            this.menuSandPatchReports.ResumeLayout(false);
            this.menuSandPatchReports.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuSandPatchReports;
        private System.Windows.Forms.ToolStripMenuItem menuFile;
        private System.Windows.Forms.ToolStripMenuItem menuFileConnection;
        private System.Windows.Forms.ToolStripSeparator menuFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem menuFileExit;
        private System.Windows.Forms.ToolStripMenuItem menuReports;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDrivers;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDriversStatus;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDispatches;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDispatchesJobRollup;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDispatchesDriverActivity;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDispatchesDateRollup;
        private System.Windows.Forms.ToolStripMenuItem menuReportsPurchaseOrders;
        private System.Windows.Forms.ToolStripMenuItem menuReportsJobNumbers;
        private System.Windows.Forms.ToolStripMenuItem menuValidation;
        private System.Windows.Forms.ToolStripMenuItem menuValidationPaymentDueTerms;
        private System.Windows.Forms.ToolStripMenuItem menuMaster;
        private System.Windows.Forms.ToolStripMenuItem menuTransaction;
        private System.Windows.Forms.ToolStripMenuItem menuTransactionInvoices;
        private System.Windows.Forms.ToolStripMenuItem menuValidationInvoiceDetailPrototype;
        private System.Windows.Forms.ToolStripMenuItem menuReportsDispachesWeeklyRecap;
    }
}

