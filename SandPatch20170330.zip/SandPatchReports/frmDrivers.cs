﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmDrivers : Form
    {
        private Collection<DriverStatus> _driverStatuses;

        public frmDrivers()
        {
            InitializeComponent();
        }

        private void frmDrivers_Load(object sender, EventArgs e)
        {
            _driverStatuses = SandPatchCL.DataServices.DataServiceDriverStatuses.DriverStatusSqlGetAll();
            cmbDriverStatus.DataSource = null;
            Application.DoEvents();
            _driverStatuses.Insert(0, new DriverStatus());
            _driverStatuses[0].DriverStatusDescription = "All";
            cmbDriverStatus.DataSource = _driverStatuses;
            cmbDriverStatus.DisplayMember = "DriverStatusDescription";
            cmbDriverStatus.ValueMember = "DriverStatusId";
        }

        private void cmdPrint_Click(object sender, EventArgs e)
        {
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportActiveDrivers", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;

            int driverStatusId = ((DriverStatus)cmbDriverStatus.SelectedItem).DriverStatusId;

            if (driverStatusId > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@DriverStatusId", (object)driverStatusId));
            }

            preprocess.ExecuteNonQuery();

            Application.DoEvents();

            this.ActiveDriversReportTableAdapter.Connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();

            this.ActiveDriversReportTableAdapter.Fill(this.SandPatchReportsRowsets.ActiveDriversReport);

            reportViewerDrivers.RefreshReport();
       }
    }
}
