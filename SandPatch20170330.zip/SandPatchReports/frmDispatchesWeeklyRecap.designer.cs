namespace SandPatchReportsUI
{
    partial class frmDispatchesWeeklyRecap
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdExit = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblDriverStatus = new System.Windows.Forms.Label();
            this.cmbWeekYear = new System.Windows.Forms.ComboBox();
            this.cmdPreviewPrint = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdExit
            // 
            this.cmdExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExit.Location = new System.Drawing.Point(748, 387);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(86, 41);
            this.cmdExit.TabIndex = 0;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = true;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(267, 33);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(327, 37);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Weekly Spreadsheet";
            // 
            // lblDriverStatus
            // 
            this.lblDriverStatus.AutoSize = true;
            this.lblDriverStatus.Location = new System.Drawing.Point(289, 92);
            this.lblDriverStatus.Name = "lblDriverStatus";
            this.lblDriverStatus.Size = new System.Drawing.Size(80, 16);
            this.lblDriverStatus.TabIndex = 5;
            this.lblDriverStatus.Text = "Week/Year:";
            // 
            // cmbWeekYear
            // 
            this.cmbWeekYear.FormattingEnabled = true;
            this.cmbWeekYear.Location = new System.Drawing.Point(382, 89);
            this.cmbWeekYear.Name = "cmbWeekYear";
            this.cmbWeekYear.Size = new System.Drawing.Size(190, 24);
            this.cmbWeekYear.TabIndex = 4;
            // 
            // cmdPreviewPrint
            // 
            this.cmdPreviewPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPreviewPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPreviewPrint.Location = new System.Drawing.Point(24, 387);
            this.cmdPreviewPrint.Name = "cmdPreviewPrint";
            this.cmdPreviewPrint.Size = new System.Drawing.Size(148, 41);
            this.cmdPreviewPrint.TabIndex = 36;
            this.cmdPreviewPrint.Text = "Preview/Print";
            this.cmdPreviewPrint.UseVisualStyleBackColor = true;
            this.cmdPreviewPrint.Click += new System.EventHandler(this.cmdPreviewPrint_Click);
            // 
            // frmDispatchesWeeklyRecap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 459);
            this.Controls.Add(this.cmdPreviewPrint);
            this.Controls.Add(this.lblDriverStatus);
            this.Controls.Add(this.cmbWeekYear);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.cmdExit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDispatchesWeeklyRecap";
            this.Text = "Weekly Spreadsheet";
            this.Load += new System.EventHandler(this.frmDispatchesWeeklyRecap_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblDriverStatus;
        private System.Windows.Forms.ComboBox cmbWeekYear;
        private System.Windows.Forms.Button cmdPreviewPrint;

    }

}
