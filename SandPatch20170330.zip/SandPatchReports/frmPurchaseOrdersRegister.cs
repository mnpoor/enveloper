﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmPurchaseOrdersRegister : Form
    {
        private Collection<Customer> _customers;
        private Collection<JobNumber> _jobNumbers;
        private Collection<PurchaseOrderStatus> _purchaseOrderStatuses;

        public frmPurchaseOrdersRegister()
        {
            InitializeComponent();
        }

        private void frmPurchaseOrdersRegister_Load(object sender, EventArgs e)
        {
            _customers = SandPatchCL.DataServices.DataServiceCustomers.CustomerSqlGetAll();
            cmbCustomers.DataSource = null;
            Application.DoEvents();
            _customers.Insert(0, new Customer());
            _customers[0].CustomerName = "All";
            cmbCustomers.DataSource = _customers;
            cmbCustomers.DisplayMember = "CustomerName";
            cmbCustomers.ValueMember = "CustomerId";

            _jobNumbers = SandPatchCL.DataServices.DataServiceJobNumbers.JobNumberSqlGetAll();
            cmbJobNumbers.DataSource = null;
            Application.DoEvents();
            _jobNumbers.Insert(0, new JobNumber());
            _jobNumbers[0].JobNumberAssignment = 0;
            cmbJobNumbers.DataSource = _jobNumbers;
            cmbJobNumbers.DisplayMember = "JobNumberAssignment";
            cmbJobNumbers.ValueMember = "JobNumberId";

            _purchaseOrderStatuses = SandPatchCL.DataServices.DataServicePurchaseOrderStatuses.PurchaseOrderStatusSqlGetAll();
            cmbPurchaseOrderStatus.DataSource = null;
            Application.DoEvents();
            _purchaseOrderStatuses.Insert(0, new PurchaseOrderStatus());
            _purchaseOrderStatuses[0].PurchaseOrderStatusDescription = "All";
            cmbPurchaseOrderStatus.DataSource = _purchaseOrderStatuses;
            cmbPurchaseOrderStatus.DisplayMember = "PurchaseOrderStatusDescription";
            cmbPurchaseOrderStatus.ValueMember = "PurchaseOrderStatusId";
        }

        private void cmdPrint_Click(object sender, EventArgs e)
        {
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportPurchaseOrders", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;


            int customerId = ((Customer)cmbCustomers.SelectedItem).CustomerId;
            if (customerId > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@CustomerId", (object)customerId));
            }

            int jobNumberId = ((JobNumber)cmbJobNumbers.SelectedItem).JobNumberId;
            if (jobNumberId > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@JobNumberId", (object)jobNumberId));
            }

            int purchaseOrderStatusId = ((PurchaseOrderStatus)cmbPurchaseOrderStatus.SelectedItem).PurchaseOrderStatusId;
            if (purchaseOrderStatusId > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@PurchaseOrderStatusId", (object)purchaseOrderStatusId));
            }

            preprocess.ExecuteNonQuery();

            Application.DoEvents();

            this.PurchaseOrdersReportTableAdapter.Connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();

            this.PurchaseOrdersReportTableAdapter.Fill(this.SandPatchReportsRowsets.PurchaseOrdersReport);

            reportViewerPurchaseOrders.RefreshReport();
       }
    }
}
