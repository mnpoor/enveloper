﻿namespace SandPatchReportsUI
{
    partial class frmPurchaseOrdersRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.PurchaseOrdersReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SandPatchReportsRowsets = new SandPatchReportsUI.SandPatchReportsRowsets();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmbPurchaseOrderStatus = new System.Windows.Forms.ComboBox();
            this.lblPurchaseOrderStatus = new System.Windows.Forms.Label();
            this.cmdPrint = new System.Windows.Forms.Button();
            this.reportViewerPurchaseOrders = new Microsoft.Reporting.WinForms.ReportViewer();
            this.PurchaseOrdersReportTableAdapter = new SandPatchReportsUI.SandPatchReportsRowsetsTableAdapters.PurchaseOrdersReportTableAdapter();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.cmbCustomers = new System.Windows.Forms.ComboBox();
            this.lblJobNumber = new System.Windows.Forms.Label();
            this.cmbJobNumbers = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.PurchaseOrdersReportBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).BeginInit();
            this.SuspendLayout();
            // 
            // PurchaseOrdersReportBindingSource
            // 
            this.PurchaseOrdersReportBindingSource.DataMember = "PurchaseOrdersReport";
            this.PurchaseOrdersReportBindingSource.DataSource = this.SandPatchReportsRowsets;
            // 
            // SandPatchReportsRowsets
            // 
            this.SandPatchReportsRowsets.DataSetName = "SandPatchReportsRowsets";
            this.SandPatchReportsRowsets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(511, 30);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(274, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Purchase Orders";
            // 
            // cmbPurchaseOrderStatus
            // 
            this.cmbPurchaseOrderStatus.FormattingEnabled = true;
            this.cmbPurchaseOrderStatus.Location = new System.Drawing.Point(650, 143);
            this.cmbPurchaseOrderStatus.Name = "cmbPurchaseOrderStatus";
            this.cmbPurchaseOrderStatus.Size = new System.Drawing.Size(147, 24);
            this.cmbPurchaseOrderStatus.TabIndex = 6;
            // 
            // lblPurchaseOrderStatus
            // 
            this.lblPurchaseOrderStatus.AutoSize = true;
            this.lblPurchaseOrderStatus.Location = new System.Drawing.Point(499, 146);
            this.lblPurchaseOrderStatus.Name = "lblPurchaseOrderStatus";
            this.lblPurchaseOrderStatus.Size = new System.Drawing.Size(145, 16);
            this.lblPurchaseOrderStatus.TabIndex = 5;
            this.lblPurchaseOrderStatus.Text = "Purchase Order Status:";
            // 
            // cmdPrint
            // 
            this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPrint.Location = new System.Drawing.Point(597, 744);
            this.cmdPrint.Name = "cmdPrint";
            this.cmdPrint.Size = new System.Drawing.Size(103, 38);
            this.cmdPrint.TabIndex = 8;
            this.cmdPrint.Text = "Print";
            this.cmdPrint.UseVisualStyleBackColor = true;
            this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
            // 
            // reportViewerPurchaseOrders
            // 
            this.reportViewerPurchaseOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "PurchaseOrderReportDataSet";
            reportDataSource1.Value = this.PurchaseOrdersReportBindingSource;
            this.reportViewerPurchaseOrders.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerPurchaseOrders.LocalReport.ReportEmbeddedResource = "SandPatchReportsUI.Reports.rptPurchaseOrderRegister.rdlc";
            this.reportViewerPurchaseOrders.Location = new System.Drawing.Point(12, 186);
            this.reportViewerPurchaseOrders.Name = "reportViewerPurchaseOrders";
            this.reportViewerPurchaseOrders.Size = new System.Drawing.Size(1273, 542);
            this.reportViewerPurchaseOrders.TabIndex = 7;
            // 
            // PurchaseOrdersReportTableAdapter
            // 
            this.PurchaseOrdersReportTableAdapter.ClearBeforeFill = true;
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(499, 82);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(68, 16);
            this.lblCustomer.TabIndex = 1;
            this.lblCustomer.Text = "Customer:";
            // 
            // cmbCustomers
            // 
            this.cmbCustomers.FormattingEnabled = true;
            this.cmbCustomers.Location = new System.Drawing.Point(650, 79);
            this.cmbCustomers.Name = "cmbCustomers";
            this.cmbCustomers.Size = new System.Drawing.Size(147, 24);
            this.cmbCustomers.TabIndex = 2;
            // 
            // lblJobNumber
            // 
            this.lblJobNumber.AutoSize = true;
            this.lblJobNumber.Location = new System.Drawing.Point(499, 114);
            this.lblJobNumber.Name = "lblJobNumber";
            this.lblJobNumber.Size = new System.Drawing.Size(85, 16);
            this.lblJobNumber.TabIndex = 3;
            this.lblJobNumber.Text = "Job Number:";
            // 
            // cmbJobNumbers
            // 
            this.cmbJobNumbers.FormattingEnabled = true;
            this.cmbJobNumbers.Location = new System.Drawing.Point(650, 111);
            this.cmbJobNumbers.Name = "cmbJobNumbers";
            this.cmbJobNumbers.Size = new System.Drawing.Size(147, 24);
            this.cmbJobNumbers.TabIndex = 4;
            // 
            // frmPurchaseOrdersRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1297, 819);
            this.Controls.Add(this.lblJobNumber);
            this.Controls.Add(this.cmbJobNumbers);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.cmbCustomers);
            this.Controls.Add(this.reportViewerPurchaseOrders);
            this.Controls.Add(this.cmdPrint);
            this.Controls.Add(this.lblPurchaseOrderStatus);
            this.Controls.Add(this.cmbPurchaseOrderStatus);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmPurchaseOrdersRegister";
            this.Text = "Purchase Orders Report";
            this.Load += new System.EventHandler(this.frmPurchaseOrdersRegister_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PurchaseOrdersReportBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cmbPurchaseOrderStatus;
        private System.Windows.Forms.Label lblPurchaseOrderStatus;
        private System.Windows.Forms.Button cmdPrint;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerPurchaseOrders;
        private SandPatchReportsRowsets SandPatchReportsRowsets;
        private System.Windows.Forms.BindingSource PurchaseOrdersReportBindingSource;
        private SandPatchReportsRowsetsTableAdapters.PurchaseOrdersReportTableAdapter PurchaseOrdersReportTableAdapter;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.ComboBox cmbCustomers;
        private System.Windows.Forms.Label lblJobNumber;
        private System.Windows.Forms.ComboBox cmbJobNumbers;
    }
}