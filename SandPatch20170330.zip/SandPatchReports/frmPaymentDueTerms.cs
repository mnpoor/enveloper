using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmPaymentDueTerms : Form
    {

        private PaymentDueTerm _paymentDueTerm;
        private Collection<PaymentDueTerm> _paymentDueTerms;

        public frmPaymentDueTerms()
        {
            InitializeComponent();
        }

        private void frmPaymentDueTerms_Load(object sender, EventArgs e)
        {
            _paymentDueTerms = SandPatchCL.DataServices.DataServicePaymentDueTerms.PaymentDueTermSqlGetAll();
            ucPaymentDueTermsManager.PaymentDueTermFill(ref _paymentDueTerms);
        }

        private void ucPaymentDueTermsManager_PaymentDueTermRefreshEvent(object sender, SPEventArgs e)
        {
            _paymentDueTerms = SandPatchCL.DataServices.DataServicePaymentDueTerms.PaymentDueTermSqlGetAll();
            ucPaymentDueTermsManager.PaymentDueTermFill(ref _paymentDueTerms);
        }

        private void ucPaymentDueTermsManager_PaymentDueTermAddNewRecordEvent(object sender, SPEventArgs e)
        {
            _paymentDueTerm = (PaymentDueTerm)e.SPClass;
            SandPatchCL.DataServices.DataServicePaymentDueTerms.SqlSave(ref _paymentDueTerm);
            ucPaymentDueTermsManager.NewIdAssignment(_paymentDueTerm.PaymentDueTermId);
        }

        private void ucPaymentDueTermsManager_PaymentDueTermUpdateEvent(object sender, SPEventArgs e)
        {
            _paymentDueTerm = (PaymentDueTerm)e.SPClass;
            SandPatchCL.DataServices.DataServicePaymentDueTerms.SqlSave(ref _paymentDueTerm);
        }

        private void ucPaymentDueTermsManager_PaymentDueTermDeleteEvent(object sender, SPEventArgs e)
        {
            _paymentDueTerm = (PaymentDueTerm)e.SPClass;
            SandPatchCL.DataServices.DataServicePaymentDueTerms.SqlDelete(ref _paymentDueTerm);
        }

    }

}
