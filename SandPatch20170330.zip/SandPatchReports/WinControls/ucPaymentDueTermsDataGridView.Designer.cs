namespace SandPatchReportsUI.WinControls
{
    partial class ucPaymentDueTermsDataGridView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgPaymentDueTerms = new System.Windows.Forms.DataGridView();
            this.cmdRefresh = new System.Windows.Forms.Button();
            this.dgcPaymentDueTermId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcPaymentDueTermDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDateAdded = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcAddedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDateUpdated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcUpdatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgPaymentDueTerms)).BeginInit();
            this.SuspendLayout();
            // 
            // dgPaymentDueTerms
            // 
            this.dgPaymentDueTerms.AllowUserToOrderColumns = true;
            this.dgPaymentDueTerms.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgPaymentDueTerms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPaymentDueTerms.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgcPaymentDueTermId,
            this.dgcPaymentDueTermDescription,
            this.dgcDateAdded,
            this.dgcAddedBy,
            this.dgcDateUpdated,
            this.dgcUpdatedBy});
            this.dgPaymentDueTerms.Location = new System.Drawing.Point(16, 18);
            this.dgPaymentDueTerms.MultiSelect = false;
            this.dgPaymentDueTerms.Name = "dgPaymentDueTerms";
            this.dgPaymentDueTerms.Size = new System.Drawing.Size(496, 422);
            this.dgPaymentDueTerms.TabIndex = 0;
            this.dgPaymentDueTerms.RowLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPaymentDueTerms_RowLeave);
            this.dgPaymentDueTerms.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgPaymentDueTerms_UserAddedRow);
            this.dgPaymentDueTerms.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgPaymentDueTerms_UserDeletingRow);
            // 
            // cmdRefresh
            // 
            this.cmdRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdRefresh.Location = new System.Drawing.Point(229, 462);
            this.cmdRefresh.Name = "cmdRefresh";
            this.cmdRefresh.Size = new System.Drawing.Size(101, 32);
            this.cmdRefresh.TabIndex = 1;
            this.cmdRefresh.Text = "Refresh";
            this.cmdRefresh.UseVisualStyleBackColor = true;
            // 
            // dgcPaymentDueTermId
            // 
            this.dgcPaymentDueTermId.HeaderText = "Id";
            this.dgcPaymentDueTermId.Name = "dgcPaymentDueTermId";
            this.dgcPaymentDueTermId.ReadOnly = true;
            this.dgcPaymentDueTermId.Width = 50;
            // 
            // dgcPaymentDueTermDescription
            // 
            this.dgcPaymentDueTermDescription.HeaderText = "Description";
            this.dgcPaymentDueTermDescription.Name = "dgcPaymentDueTermDescription";
            this.dgcPaymentDueTermDescription.Width = 120;
            // 
            // dgcDateAdded
            // 
            this.dgcDateAdded.HeaderText = "Date Added";
            this.dgcDateAdded.Name = "dgcDateAdded";
            this.dgcDateAdded.ReadOnly = true;
            this.dgcDateAdded.Width = 70;
            // 
            // dgcAddedBy
            // 
            this.dgcAddedBy.HeaderText = "Added By";
            this.dgcAddedBy.Name = "dgcAddedBy";
            this.dgcAddedBy.ReadOnly = true;
            this.dgcAddedBy.Width = 70;
            // 
            // dgcDateUpdated
            // 
            this.dgcDateUpdated.HeaderText = "Date Updated";
            this.dgcDateUpdated.Name = "dgcDateUpdated";
            this.dgcDateUpdated.ReadOnly = true;
            this.dgcDateUpdated.Width = 70;
            // 
            // dgcUpdatedBy
            // 
            this.dgcUpdatedBy.HeaderText = "Updated By";
            this.dgcUpdatedBy.Name = "dgcUpdatedBy";
            this.dgcUpdatedBy.ReadOnly = true;
            this.dgcUpdatedBy.Width = 70;
            // 
            // ucPaymentDueTermsDataGridView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmdRefresh);
            this.Controls.Add(this.dgPaymentDueTerms);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ucPaymentDueTermsDataGridView";
            this.Size = new System.Drawing.Size(530, 511);
            ((System.ComponentModel.ISupportInitialize)(this.dgPaymentDueTerms)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgPaymentDueTerms;
        private System.Windows.Forms.Button cmdRefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcPaymentDueTermId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcPaymentDueTermDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDateAdded;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcAddedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDateUpdated;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcUpdatedBy;
    }
}
