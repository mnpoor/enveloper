namespace SandPatchReportsUI.WinControls
{
    partial class ucInvoiceLineItemPrototypesDataGridView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgInvoiceLineItemPrototypes = new System.Windows.Forms.DataGridView();
            this.cmdRefresh = new System.Windows.Forms.Button();
            this.dgcInvoiceLineItemPrototypeId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDefinitionDisplayOrder = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcTransactionDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcTransactionDefaultText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcTransactionValueSource = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcUnitsDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcRecordQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcRecordUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcRecordRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcMultiplyQuantityTimesRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcRecordAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDateAdded = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcAddedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDateUpdated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcUpdatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoiceLineItemPrototypes)).BeginInit();
            this.SuspendLayout();
            // 
            // dgInvoiceLineItemPrototypes
            // 
            this.dgInvoiceLineItemPrototypes.AllowUserToOrderColumns = true;
            this.dgInvoiceLineItemPrototypes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgInvoiceLineItemPrototypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgInvoiceLineItemPrototypes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgcInvoiceLineItemPrototypeId,
            this.dgcDefinitionDisplayOrder,
            this.dgcTransactionDescription,
            this.dgcTransactionDefaultText,
            this.dgcTransactionValueSource,
            this.dgcUnitsDescription,
            this.dgcRecordQuantity,
            this.dgcRecordUnits,
            this.dgcRecordRate,
            this.dgcMultiplyQuantityTimesRate,
            this.dgcRecordAmount,
            this.dgcDateAdded,
            this.dgcAddedBy,
            this.dgcDateUpdated,
            this.dgcUpdatedBy});
            this.dgInvoiceLineItemPrototypes.Location = new System.Drawing.Point(16, 18);
            this.dgInvoiceLineItemPrototypes.MultiSelect = false;
            this.dgInvoiceLineItemPrototypes.Name = "dgInvoiceLineItemPrototypes";
            this.dgInvoiceLineItemPrototypes.Size = new System.Drawing.Size(524, 351);
            this.dgInvoiceLineItemPrototypes.TabIndex = 0;
            this.dgInvoiceLineItemPrototypes.RowLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgInvoiceLineItemPrototypes_RowLeave);
            this.dgInvoiceLineItemPrototypes.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgInvoiceLineItemPrototypes_UserAddedRow);
            this.dgInvoiceLineItemPrototypes.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgInvoiceLineItemPrototypes_UserDeletingRow);
            // 
            // cmdRefresh
            // 
            this.cmdRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdRefresh.Location = new System.Drawing.Point(229, 391);
            this.cmdRefresh.Name = "cmdRefresh";
            this.cmdRefresh.Size = new System.Drawing.Size(101, 32);
            this.cmdRefresh.TabIndex = 1;
            this.cmdRefresh.Text = "Refresh";
            this.cmdRefresh.UseVisualStyleBackColor = true;
            // 
            // dgcInvoiceLineItemPrototypeId
            // 
            this.dgcInvoiceLineItemPrototypeId.HeaderText = "Id";
            this.dgcInvoiceLineItemPrototypeId.Name = "dgcInvoiceLineItemPrototypeId";
            // 
            // dgcDefinitionDisplayOrder
            // 
            this.dgcDefinitionDisplayOrder.HeaderText = "Display Order";
            this.dgcDefinitionDisplayOrder.Name = "dgcDefinitionDisplayOrder";
            // 
            // dgcTransactionDescription
            // 
            this.dgcTransactionDescription.HeaderText = "Transaction Description";
            this.dgcTransactionDescription.Name = "dgcTransactionDescription";
            // 
            // dgcTransactionDefaultText
            // 
            this.dgcTransactionDefaultText.HeaderText = "Transaction Default Text";
            this.dgcTransactionDefaultText.Name = "dgcTransactionDefaultText";
            // 
            // dgcTransactionValueSource
            // 
            this.dgcTransactionValueSource.HeaderText = "Transaction Value Source";
            this.dgcTransactionValueSource.Name = "dgcTransactionValueSource";
            // 
            // dgcUnitsDescription
            // 
            this.dgcUnitsDescription.HeaderText = "Units Description";
            this.dgcUnitsDescription.Name = "dgcUnitsDescription";
            // 
            // dgcRecordQuantity
            // 
            this.dgcRecordQuantity.HeaderText = "Record Quantity?";
            this.dgcRecordQuantity.Name = "dgcRecordQuantity";
            // 
            // dgcRecordUnits
            // 
            this.dgcRecordUnits.HeaderText = "Record Units?";
            this.dgcRecordUnits.Name = "dgcRecordUnits";
            // 
            // dgcRecordRate
            // 
            this.dgcRecordRate.HeaderText = "Record Rate?";
            this.dgcRecordRate.Name = "dgcRecordRate";
            // 
            // dgcMultiplyQuantityTimesRate
            // 
            this.dgcMultiplyQuantityTimesRate.HeaderText = "Multiply Quantity Times Rate?";
            this.dgcMultiplyQuantityTimesRate.Name = "dgcMultiplyQuantityTimesRate";
            // 
            // dgcRecordAmount
            // 
            this.dgcRecordAmount.HeaderText = "Record Amount?";
            this.dgcRecordAmount.Name = "dgcRecordAmount";
            // 
            // dgcDateAdded
            // 
            this.dgcDateAdded.HeaderText = "Date Added";
            this.dgcDateAdded.Name = "dgcDateAdded";
            this.dgcDateAdded.ReadOnly = true;
            this.dgcDateAdded.Width = 70;
            // 
            // dgcAddedBy
            // 
            this.dgcAddedBy.HeaderText = "Added By";
            this.dgcAddedBy.Name = "dgcAddedBy";
            this.dgcAddedBy.ReadOnly = true;
            this.dgcAddedBy.Width = 70;
            // 
            // dgcDateUpdated
            // 
            this.dgcDateUpdated.HeaderText = "Date Updated";
            this.dgcDateUpdated.Name = "dgcDateUpdated";
            this.dgcDateUpdated.ReadOnly = true;
            this.dgcDateUpdated.Width = 70;
            // 
            // dgcUpdatedBy
            // 
            this.dgcUpdatedBy.HeaderText = "Updated By";
            this.dgcUpdatedBy.Name = "dgcUpdatedBy";
            this.dgcUpdatedBy.ReadOnly = true;
            this.dgcUpdatedBy.Width = 70;
            // 
            // ucInvoiceLineItemPrototypesDataGridView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmdRefresh);
            this.Controls.Add(this.dgInvoiceLineItemPrototypes);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ucInvoiceLineItemPrototypesDataGridView";
            this.Size = new System.Drawing.Size(558, 440);
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoiceLineItemPrototypes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgInvoiceLineItemPrototypes;
        private System.Windows.Forms.Button cmdRefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcInvoiceLineItemPrototypeId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDefinitionDisplayOrder;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTransactionDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTransactionDefaultText;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTransactionValueSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcUnitsDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcRecordQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcRecordUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcRecordRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcMultiplyQuantityTimesRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcRecordAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDateAdded;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcAddedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDateUpdated;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcUpdatedBy;
    }
}
