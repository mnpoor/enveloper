namespace SandPatchReportsUI.WinControls
{
    partial class ucInvoice
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private System.Windows.Forms.Button cmdClear;
        private System.Windows.Forms.Button cmdAdd;
        private System.Windows.Forms.Button cmdUpdate;
        private System.Windows.Forms.Button cmdDelete;
        private System.Windows.Forms.Label lblInvoiceId;
        private System.Windows.Forms.TextBox txtInvoiceId;
        private System.Windows.Forms.Label lblInvoiceNumber;
        private System.Windows.Forms.TextBox txtInvoiceNumber;
        private System.Windows.Forms.Label lblInvoiceDate;
        private System.Windows.Forms.TextBox txtInvoiceDate;
        private System.Windows.Forms.Label lblShipperBillingId;
        private System.Windows.Forms.TextBox txtShipperBillingId;
        private System.Windows.Forms.Label lblBillToCustomerId;
        private System.Windows.Forms.TextBox txtBillToCustomerId;
        private System.Windows.Forms.Label lblOriginTypeId;
        private System.Windows.Forms.TextBox txtOriginTypeId;
        private System.Windows.Forms.Label lblOriginId;
        private System.Windows.Forms.TextBox txtOriginId;
        private System.Windows.Forms.Label lblDestinationTypeId;
        private System.Windows.Forms.TextBox txtDestinationTypeId;
        private System.Windows.Forms.Label lblDestinationId;
        private System.Windows.Forms.TextBox txtDestinationId;
        private System.Windows.Forms.Label lblChargeCode;
        private System.Windows.Forms.TextBox txtChargeCode;
        private System.Windows.Forms.Label lblPaymentTermsId;
        private System.Windows.Forms.TextBox txtPaymentTermsId;
        private System.Windows.Forms.Label lblBillOfLadingId;
        private System.Windows.Forms.TextBox txtBillOfLadingId;
        private System.Windows.Forms.Label lblDispatchId;
        private System.Windows.Forms.TextBox txtDispatchId;
        private System.Windows.Forms.Label lblInvoiceSubtotalAmount;
        private System.Windows.Forms.TextBox txtInvoiceSubtotalAmount;
        private System.Windows.Forms.Label lblInvoiceAdjustmentsAmount;
        private System.Windows.Forms.TextBox txtInvoiceAdjustmentsAmount;
        private System.Windows.Forms.Label lblInvoiceTotalAmount;
        private System.Windows.Forms.TextBox txtInvoiceTotalAmount;

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdClear = new System.Windows.Forms.Button();
            this.cmdAdd = new System.Windows.Forms.Button();
            this.cmdUpdate = new System.Windows.Forms.Button();
            this.cmdDelete = new System.Windows.Forms.Button();
            this.lblInvoiceId = new System.Windows.Forms.Label();
            this.txtInvoiceId = new System.Windows.Forms.TextBox();
            this.lblInvoiceNumber = new System.Windows.Forms.Label();
            this.txtInvoiceNumber = new System.Windows.Forms.TextBox();
            this.lblInvoiceDate = new System.Windows.Forms.Label();
            this.txtInvoiceDate = new System.Windows.Forms.TextBox();
            this.lblShipperBillingId = new System.Windows.Forms.Label();
            this.txtShipperBillingId = new System.Windows.Forms.TextBox();
            this.lblBillToCustomerId = new System.Windows.Forms.Label();
            this.txtBillToCustomerId = new System.Windows.Forms.TextBox();
            this.lblOriginTypeId = new System.Windows.Forms.Label();
            this.txtOriginTypeId = new System.Windows.Forms.TextBox();
            this.lblOriginId = new System.Windows.Forms.Label();
            this.txtOriginId = new System.Windows.Forms.TextBox();
            this.lblDestinationTypeId = new System.Windows.Forms.Label();
            this.txtDestinationTypeId = new System.Windows.Forms.TextBox();
            this.lblDestinationId = new System.Windows.Forms.Label();
            this.txtDestinationId = new System.Windows.Forms.TextBox();
            this.lblChargeCode = new System.Windows.Forms.Label();
            this.txtChargeCode = new System.Windows.Forms.TextBox();
            this.lblPaymentTermsId = new System.Windows.Forms.Label();
            this.txtPaymentTermsId = new System.Windows.Forms.TextBox();
            this.lblBillOfLadingId = new System.Windows.Forms.Label();
            this.txtBillOfLadingId = new System.Windows.Forms.TextBox();
            this.lblDispatchId = new System.Windows.Forms.Label();
            this.txtDispatchId = new System.Windows.Forms.TextBox();
            this.lblInvoiceSubtotalAmount = new System.Windows.Forms.Label();
            this.txtInvoiceSubtotalAmount = new System.Windows.Forms.TextBox();
            this.lblInvoiceAdjustmentsAmount = new System.Windows.Forms.Label();
            this.txtInvoiceAdjustmentsAmount = new System.Windows.Forms.TextBox();
            this.lblInvoiceTotalAmount = new System.Windows.Forms.Label();
            this.txtInvoiceTotalAmount = new System.Windows.Forms.TextBox();
            this.cmdPreviewPrintInvoice = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdClear
            // 
            this.cmdClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdClear.Location = new System.Drawing.Point(90, 593);
            this.cmdClear.Name = "cmdClear";
            this.cmdClear.Size = new System.Drawing.Size(86, 41);
            this.cmdClear.TabIndex = 22;
            this.cmdClear.Text = "Clear";
            this.cmdClear.UseVisualStyleBackColor = true;
            this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
            // 
            // cmdAdd
            // 
            this.cmdAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdAdd.Location = new System.Drawing.Point(204, 593);
            this.cmdAdd.Name = "cmdAdd";
            this.cmdAdd.Size = new System.Drawing.Size(86, 41);
            this.cmdAdd.TabIndex = 23;
            this.cmdAdd.Text = "Add";
            this.cmdAdd.UseVisualStyleBackColor = true;
            this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
            // 
            // cmdUpdate
            // 
            this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdUpdate.Location = new System.Drawing.Point(318, 593);
            this.cmdUpdate.Name = "cmdUpdate";
            this.cmdUpdate.Size = new System.Drawing.Size(86, 41);
            this.cmdUpdate.TabIndex = 24;
            this.cmdUpdate.Text = "Update";
            this.cmdUpdate.UseVisualStyleBackColor = true;
            this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
            // 
            // cmdDelete
            // 
            this.cmdDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdDelete.Location = new System.Drawing.Point(657, 593);
            this.cmdDelete.Name = "cmdDelete";
            this.cmdDelete.Size = new System.Drawing.Size(67, 30);
            this.cmdDelete.TabIndex = 26;
            this.cmdDelete.Text = "Delete";
            this.cmdDelete.UseVisualStyleBackColor = true;
            this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
            // 
            // lblInvoiceId
            // 
            this.lblInvoiceId.AutoSize = true;
            this.lblInvoiceId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceId.Location = new System.Drawing.Point(23, 23);
            this.lblInvoiceId.Name = "lblInvoiceId";
            this.lblInvoiceId.Size = new System.Drawing.Size(75, 16);
            this.lblInvoiceId.TabIndex = 3;
            this.lblInvoiceId.Text = "Invoice Id";
            // 
            // txtInvoiceId
            // 
            this.txtInvoiceId.BackColor = System.Drawing.SystemColors.Window;
            this.txtInvoiceId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvoiceId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceId.Location = new System.Drawing.Point(236, 21);
            this.txtInvoiceId.Name = "txtInvoiceId";
            this.txtInvoiceId.Size = new System.Drawing.Size(54, 22);
            this.txtInvoiceId.TabIndex = 4;
            // 
            // lblInvoiceNumber
            // 
            this.lblInvoiceNumber.AutoSize = true;
            this.lblInvoiceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceNumber.Location = new System.Drawing.Point(23, 49);
            this.lblInvoiceNumber.Name = "lblInvoiceNumber";
            this.lblInvoiceNumber.Size = new System.Drawing.Size(116, 16);
            this.lblInvoiceNumber.TabIndex = 5;
            this.lblInvoiceNumber.Text = "Invoice Number";
            // 
            // txtInvoiceNumber
            // 
            this.txtInvoiceNumber.BackColor = System.Drawing.SystemColors.Window;
            this.txtInvoiceNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvoiceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceNumber.Location = new System.Drawing.Point(236, 47);
            this.txtInvoiceNumber.Name = "txtInvoiceNumber";
            this.txtInvoiceNumber.Size = new System.Drawing.Size(114, 22);
            this.txtInvoiceNumber.TabIndex = 6;
            // 
            // lblInvoiceDate
            // 
            this.lblInvoiceDate.AutoSize = true;
            this.lblInvoiceDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceDate.Location = new System.Drawing.Point(413, 49);
            this.lblInvoiceDate.Name = "lblInvoiceDate";
            this.lblInvoiceDate.Size = new System.Drawing.Size(95, 16);
            this.lblInvoiceDate.TabIndex = 7;
            this.lblInvoiceDate.Text = "Invoice Date";
            // 
            // txtInvoiceDate
            // 
            this.txtInvoiceDate.BackColor = System.Drawing.SystemColors.Window;
            this.txtInvoiceDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvoiceDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceDate.Location = new System.Drawing.Point(626, 47);
            this.txtInvoiceDate.Name = "txtInvoiceDate";
            this.txtInvoiceDate.Size = new System.Drawing.Size(94, 22);
            this.txtInvoiceDate.TabIndex = 8;
            // 
            // lblShipperBillingId
            // 
            this.lblShipperBillingId.AutoSize = true;
            this.lblShipperBillingId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShipperBillingId.Location = new System.Drawing.Point(23, 77);
            this.lblShipperBillingId.Name = "lblShipperBillingId";
            this.lblShipperBillingId.Size = new System.Drawing.Size(141, 16);
            this.lblShipperBillingId.TabIndex = 9;
            this.lblShipperBillingId.Text = "Our Billing Address";
            // 
            // txtShipperBillingId
            // 
            this.txtShipperBillingId.BackColor = System.Drawing.SystemColors.Window;
            this.txtShipperBillingId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtShipperBillingId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShipperBillingId.Location = new System.Drawing.Point(236, 75);
            this.txtShipperBillingId.Name = "txtShipperBillingId";
            this.txtShipperBillingId.Size = new System.Drawing.Size(54, 22);
            this.txtShipperBillingId.TabIndex = 10;
            // 
            // lblBillToCustomerId
            // 
            this.lblBillToCustomerId.AutoSize = true;
            this.lblBillToCustomerId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillToCustomerId.Location = new System.Drawing.Point(23, 105);
            this.lblBillToCustomerId.Name = "lblBillToCustomerId";
            this.lblBillToCustomerId.Size = new System.Drawing.Size(122, 16);
            this.lblBillToCustomerId.TabIndex = 11;
            this.lblBillToCustomerId.Text = "Bill To Customer";
            // 
            // txtBillToCustomerId
            // 
            this.txtBillToCustomerId.BackColor = System.Drawing.SystemColors.Window;
            this.txtBillToCustomerId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBillToCustomerId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillToCustomerId.Location = new System.Drawing.Point(236, 103);
            this.txtBillToCustomerId.Name = "txtBillToCustomerId";
            this.txtBillToCustomerId.Size = new System.Drawing.Size(54, 22);
            this.txtBillToCustomerId.TabIndex = 12;
            // 
            // lblOriginTypeId
            // 
            this.lblOriginTypeId.AutoSize = true;
            this.lblOriginTypeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOriginTypeId.Location = new System.Drawing.Point(23, 133);
            this.lblOriginTypeId.Name = "lblOriginTypeId";
            this.lblOriginTypeId.Size = new System.Drawing.Size(89, 16);
            this.lblOriginTypeId.TabIndex = 13;
            this.lblOriginTypeId.Text = "Origin Type";
            // 
            // txtOriginTypeId
            // 
            this.txtOriginTypeId.BackColor = System.Drawing.SystemColors.Window;
            this.txtOriginTypeId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOriginTypeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOriginTypeId.Location = new System.Drawing.Point(236, 131);
            this.txtOriginTypeId.Name = "txtOriginTypeId";
            this.txtOriginTypeId.Size = new System.Drawing.Size(54, 22);
            this.txtOriginTypeId.TabIndex = 14;
            // 
            // lblOriginId
            // 
            this.lblOriginId.AutoSize = true;
            this.lblOriginId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOriginId.Location = new System.Drawing.Point(413, 129);
            this.lblOriginId.Name = "lblOriginId";
            this.lblOriginId.Size = new System.Drawing.Size(49, 16);
            this.lblOriginId.TabIndex = 15;
            this.lblOriginId.Text = "Origin";
            // 
            // txtOriginId
            // 
            this.txtOriginId.BackColor = System.Drawing.SystemColors.Window;
            this.txtOriginId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOriginId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOriginId.Location = new System.Drawing.Point(626, 127);
            this.txtOriginId.Name = "txtOriginId";
            this.txtOriginId.Size = new System.Drawing.Size(54, 22);
            this.txtOriginId.TabIndex = 16;
            // 
            // lblDestinationTypeId
            // 
            this.lblDestinationTypeId.AutoSize = true;
            this.lblDestinationTypeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestinationTypeId.Location = new System.Drawing.Point(23, 161);
            this.lblDestinationTypeId.Name = "lblDestinationTypeId";
            this.lblDestinationTypeId.Size = new System.Drawing.Size(126, 16);
            this.lblDestinationTypeId.TabIndex = 17;
            this.lblDestinationTypeId.Text = "Destination Type";
            // 
            // txtDestinationTypeId
            // 
            this.txtDestinationTypeId.BackColor = System.Drawing.SystemColors.Window;
            this.txtDestinationTypeId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDestinationTypeId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDestinationTypeId.Location = new System.Drawing.Point(236, 159);
            this.txtDestinationTypeId.Name = "txtDestinationTypeId";
            this.txtDestinationTypeId.Size = new System.Drawing.Size(54, 22);
            this.txtDestinationTypeId.TabIndex = 18;
            // 
            // lblDestinationId
            // 
            this.lblDestinationId.AutoSize = true;
            this.lblDestinationId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestinationId.Location = new System.Drawing.Point(413, 161);
            this.lblDestinationId.Name = "lblDestinationId";
            this.lblDestinationId.Size = new System.Drawing.Size(86, 16);
            this.lblDestinationId.TabIndex = 19;
            this.lblDestinationId.Text = "Destination";
            // 
            // txtDestinationId
            // 
            this.txtDestinationId.BackColor = System.Drawing.SystemColors.Window;
            this.txtDestinationId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDestinationId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDestinationId.Location = new System.Drawing.Point(626, 159);
            this.txtDestinationId.Name = "txtDestinationId";
            this.txtDestinationId.Size = new System.Drawing.Size(54, 22);
            this.txtDestinationId.TabIndex = 20;
            // 
            // lblChargeCode
            // 
            this.lblChargeCode.AutoSize = true;
            this.lblChargeCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChargeCode.Location = new System.Drawing.Point(23, 189);
            this.lblChargeCode.Name = "lblChargeCode";
            this.lblChargeCode.Size = new System.Drawing.Size(99, 16);
            this.lblChargeCode.TabIndex = 21;
            this.lblChargeCode.Text = "Charge Code";
            // 
            // txtChargeCode
            // 
            this.txtChargeCode.BackColor = System.Drawing.SystemColors.Window;
            this.txtChargeCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtChargeCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChargeCode.Location = new System.Drawing.Point(236, 187);
            this.txtChargeCode.Name = "txtChargeCode";
            this.txtChargeCode.Size = new System.Drawing.Size(114, 22);
            this.txtChargeCode.TabIndex = 22;
            // 
            // lblPaymentTermsId
            // 
            this.lblPaymentTermsId.AutoSize = true;
            this.lblPaymentTermsId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentTermsId.Location = new System.Drawing.Point(23, 217);
            this.lblPaymentTermsId.Name = "lblPaymentTermsId";
            this.lblPaymentTermsId.Size = new System.Drawing.Size(116, 16);
            this.lblPaymentTermsId.TabIndex = 23;
            this.lblPaymentTermsId.Text = "Payment Terms";
            // 
            // txtPaymentTermsId
            // 
            this.txtPaymentTermsId.BackColor = System.Drawing.SystemColors.Window;
            this.txtPaymentTermsId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPaymentTermsId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaymentTermsId.Location = new System.Drawing.Point(236, 215);
            this.txtPaymentTermsId.Name = "txtPaymentTermsId";
            this.txtPaymentTermsId.Size = new System.Drawing.Size(54, 22);
            this.txtPaymentTermsId.TabIndex = 24;
            // 
            // lblBillOfLadingId
            // 
            this.lblBillOfLadingId.AutoSize = true;
            this.lblBillOfLadingId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillOfLadingId.Location = new System.Drawing.Point(23, 245);
            this.lblBillOfLadingId.Name = "lblBillOfLadingId";
            this.lblBillOfLadingId.Size = new System.Drawing.Size(100, 16);
            this.lblBillOfLadingId.TabIndex = 25;
            this.lblBillOfLadingId.Text = "Bill Of Lading";
            // 
            // txtBillOfLadingId
            // 
            this.txtBillOfLadingId.BackColor = System.Drawing.SystemColors.Window;
            this.txtBillOfLadingId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBillOfLadingId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillOfLadingId.Location = new System.Drawing.Point(236, 243);
            this.txtBillOfLadingId.Name = "txtBillOfLadingId";
            this.txtBillOfLadingId.Size = new System.Drawing.Size(54, 22);
            this.txtBillOfLadingId.TabIndex = 26;
            // 
            // lblDispatchId
            // 
            this.lblDispatchId.AutoSize = true;
            this.lblDispatchId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDispatchId.Location = new System.Drawing.Point(23, 273);
            this.lblDispatchId.Name = "lblDispatchId";
            this.lblDispatchId.Size = new System.Drawing.Size(69, 16);
            this.lblDispatchId.TabIndex = 27;
            this.lblDispatchId.Text = "Dispatch";
            // 
            // txtDispatchId
            // 
            this.txtDispatchId.BackColor = System.Drawing.SystemColors.Window;
            this.txtDispatchId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDispatchId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDispatchId.Location = new System.Drawing.Point(236, 271);
            this.txtDispatchId.Name = "txtDispatchId";
            this.txtDispatchId.Size = new System.Drawing.Size(54, 22);
            this.txtDispatchId.TabIndex = 28;
            // 
            // lblInvoiceSubtotalAmount
            // 
            this.lblInvoiceSubtotalAmount.AutoSize = true;
            this.lblInvoiceSubtotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceSubtotalAmount.Location = new System.Drawing.Point(413, 217);
            this.lblInvoiceSubtotalAmount.Name = "lblInvoiceSubtotalAmount";
            this.lblInvoiceSubtotalAmount.Size = new System.Drawing.Size(120, 16);
            this.lblInvoiceSubtotalAmount.TabIndex = 29;
            this.lblInvoiceSubtotalAmount.Text = "Subtotal Amount";
            // 
            // txtInvoiceSubtotalAmount
            // 
            this.txtInvoiceSubtotalAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtInvoiceSubtotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvoiceSubtotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceSubtotalAmount.Location = new System.Drawing.Point(626, 215);
            this.txtInvoiceSubtotalAmount.Name = "txtInvoiceSubtotalAmount";
            this.txtInvoiceSubtotalAmount.Size = new System.Drawing.Size(94, 22);
            this.txtInvoiceSubtotalAmount.TabIndex = 30;
            // 
            // lblInvoiceAdjustmentsAmount
            // 
            this.lblInvoiceAdjustmentsAmount.AutoSize = true;
            this.lblInvoiceAdjustmentsAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceAdjustmentsAmount.Location = new System.Drawing.Point(413, 243);
            this.lblInvoiceAdjustmentsAmount.Name = "lblInvoiceAdjustmentsAmount";
            this.lblInvoiceAdjustmentsAmount.Size = new System.Drawing.Size(147, 16);
            this.lblInvoiceAdjustmentsAmount.TabIndex = 31;
            this.lblInvoiceAdjustmentsAmount.Text = "Adjustments Amount";
            // 
            // txtInvoiceAdjustmentsAmount
            // 
            this.txtInvoiceAdjustmentsAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtInvoiceAdjustmentsAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvoiceAdjustmentsAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceAdjustmentsAmount.Location = new System.Drawing.Point(626, 241);
            this.txtInvoiceAdjustmentsAmount.Name = "txtInvoiceAdjustmentsAmount";
            this.txtInvoiceAdjustmentsAmount.Size = new System.Drawing.Size(94, 22);
            this.txtInvoiceAdjustmentsAmount.TabIndex = 32;
            // 
            // lblInvoiceTotalAmount
            // 
            this.lblInvoiceTotalAmount.AutoSize = true;
            this.lblInvoiceTotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceTotalAmount.Location = new System.Drawing.Point(413, 269);
            this.lblInvoiceTotalAmount.Name = "lblInvoiceTotalAmount";
            this.lblInvoiceTotalAmount.Size = new System.Drawing.Size(99, 16);
            this.lblInvoiceTotalAmount.TabIndex = 33;
            this.lblInvoiceTotalAmount.Text = "Total Amount";
            // 
            // txtInvoiceTotalAmount
            // 
            this.txtInvoiceTotalAmount.BackColor = System.Drawing.SystemColors.Window;
            this.txtInvoiceTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvoiceTotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceTotalAmount.Location = new System.Drawing.Point(626, 267);
            this.txtInvoiceTotalAmount.Name = "txtInvoiceTotalAmount";
            this.txtInvoiceTotalAmount.Size = new System.Drawing.Size(94, 22);
            this.txtInvoiceTotalAmount.TabIndex = 34;
            // 
            // cmdPreviewPrintInvoice
            // 
            this.cmdPreviewPrintInvoice.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPreviewPrintInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPreviewPrintInvoice.Location = new System.Drawing.Point(432, 593);
            this.cmdPreviewPrintInvoice.Name = "cmdPreviewPrintInvoice";
            this.cmdPreviewPrintInvoice.Size = new System.Drawing.Size(196, 41);
            this.cmdPreviewPrintInvoice.TabIndex = 35;
            this.cmdPreviewPrintInvoice.Text = "Preview/Print Invoice";
            this.cmdPreviewPrintInvoice.UseVisualStyleBackColor = true;
            this.cmdPreviewPrintInvoice.Click += new System.EventHandler(this.cmdPreviewPrintInvoice_Click);
            // 
            // ucInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmdPreviewPrintInvoice);
            this.Controls.Add(this.cmdClear);
            this.Controls.Add(this.cmdAdd);
            this.Controls.Add(this.cmdUpdate);
            this.Controls.Add(this.cmdDelete);
            this.Controls.Add(this.lblInvoiceId);
            this.Controls.Add(this.txtInvoiceId);
            this.Controls.Add(this.lblInvoiceNumber);
            this.Controls.Add(this.txtInvoiceNumber);
            this.Controls.Add(this.lblInvoiceDate);
            this.Controls.Add(this.txtInvoiceDate);
            this.Controls.Add(this.lblShipperBillingId);
            this.Controls.Add(this.txtShipperBillingId);
            this.Controls.Add(this.lblBillToCustomerId);
            this.Controls.Add(this.txtBillToCustomerId);
            this.Controls.Add(this.lblOriginTypeId);
            this.Controls.Add(this.txtOriginTypeId);
            this.Controls.Add(this.lblOriginId);
            this.Controls.Add(this.txtOriginId);
            this.Controls.Add(this.lblDestinationTypeId);
            this.Controls.Add(this.txtDestinationTypeId);
            this.Controls.Add(this.lblDestinationId);
            this.Controls.Add(this.txtDestinationId);
            this.Controls.Add(this.lblChargeCode);
            this.Controls.Add(this.txtChargeCode);
            this.Controls.Add(this.lblPaymentTermsId);
            this.Controls.Add(this.txtPaymentTermsId);
            this.Controls.Add(this.lblBillOfLadingId);
            this.Controls.Add(this.txtBillOfLadingId);
            this.Controls.Add(this.lblDispatchId);
            this.Controls.Add(this.txtDispatchId);
            this.Controls.Add(this.lblInvoiceSubtotalAmount);
            this.Controls.Add(this.txtInvoiceSubtotalAmount);
            this.Controls.Add(this.lblInvoiceAdjustmentsAmount);
            this.Controls.Add(this.txtInvoiceAdjustmentsAmount);
            this.Controls.Add(this.lblInvoiceTotalAmount);
            this.Controls.Add(this.txtInvoiceTotalAmount);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucInvoice";
            this.Size = new System.Drawing.Size(824, 649);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdPreviewPrintInvoice;

    }

}
