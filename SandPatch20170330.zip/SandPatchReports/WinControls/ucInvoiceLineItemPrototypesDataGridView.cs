using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI.WinControls
{
    public partial class ucInvoiceLineItemPrototypesDataGridView : UserControl
    {
        public event SPEventHandler InvoiceLineItemPrototypeAddNewRecordEvent;
        public event SPEventHandler InvoiceLineItemPrototypeUpdateEvent;
        public event SPEventHandler InvoiceLineItemPrototypeRefreshEvent;
        public event SPEventHandler InvoiceLineItemPrototypeDeleteEvent;

        private bool _newRowInputStarted = false;
        private int _newlyInsertedRowNumber = 0;

        private InvoiceLineItemPrototype _invoiceLineItemPrototype = new InvoiceLineItemPrototype();

        public ucInvoiceLineItemPrototypesDataGridView()
        {
            InitializeComponent();
        }

        public void InvoiceLineItemPrototypeFill(ref Collection<InvoiceLineItemPrototype> itemCollection)
        {
            dgInvoiceLineItemPrototypes.Rows.Clear();

            foreach (InvoiceLineItemPrototype item in itemCollection)
            {
                object[] objectArray = new object[] { item.InvoiceLineItemPrototypeId.ToString(), item.DefinitionDisplayOrder.ToString(), item.TransactionDescription, item.TransactionDefaultText, item.TransactionValueSource.ToString(), item.UnitsDescription, item.RecordQuantity.ToString(), item.RecordUnits.ToString(), item.RecordRate.ToString(), item.MultiplyQuantityTimesRate.ToString(), item.RecordAmount.ToString(), item.DateAdded, item.AddedBy, item.DateUpdated, item.UpdatedBy };
                dgInvoiceLineItemPrototypes.Rows.Add(objectArray);
            }
        }

        private void dgInvoiceLineItemPrototypes_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            _newRowInputStarted = true;
        }

        private void dgInvoiceLineItemPrototypes_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            if (dgInvoiceLineItemPrototypes.IsCurrentRowDirty == true)
            {
                _invoiceLineItemPrototype = new InvoiceLineItemPrototype();
                 DataGridViewRow saveRow = new DataGridViewRow();
                 _newlyInsertedRowNumber = e.RowIndex;
                 saveRow = dgInvoiceLineItemPrototypes.Rows[e.RowIndex];
                 if (_newRowInputStarted)
                 {
                     _invoiceLineItemPrototype.InvoiceLineItemPrototypeId = 0;
                 }
                 else
                 {
                     _invoiceLineItemPrototype.InvoiceLineItemPrototypeId = Convert.ToInt32(saveRow.Cells["dgcInvoiceLineItemPrototypeId"].Value);
                 }
                 try
                 {
                     _invoiceLineItemPrototype.InvoiceLineItemPrototypeId = Convert.ToInt32(saveRow.Cells["dgcInvoiceLineItemPrototypeId"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.InvoiceLineItemPrototypeId = 0;
                 }
                 try
                 {
                     _invoiceLineItemPrototype.DefinitionDisplayOrder = Convert.ToInt32(saveRow.Cells["dgcDefinitionDisplayOrder"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.DefinitionDisplayOrder = 0;
                 }
                 _invoiceLineItemPrototype.TransactionDescription = saveRow.Cells["dgcTransactionDescription"].EditedFormattedValue.ToString();
                 _invoiceLineItemPrototype.TransactionDefaultText = saveRow.Cells["dgcTransactionDefaultText"].EditedFormattedValue.ToString();
                 try
                 {
                     _invoiceLineItemPrototype.TransactionValueSource = Convert.ToInt32(saveRow.Cells["dgcTransactionValueSource"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.TransactionValueSource = 0;
                 }
                 _invoiceLineItemPrototype.UnitsDescription = saveRow.Cells["dgcUnitsDescription"].EditedFormattedValue.ToString();
                 try
                 {
                     _invoiceLineItemPrototype.RecordQuantity = Convert.ToInt16(saveRow.Cells["dgcRecordQuantity"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.RecordQuantity = 0;
                 }
                 try
                 {
                     _invoiceLineItemPrototype.RecordUnits = Convert.ToInt16(saveRow.Cells["dgcRecordUnits"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.RecordUnits = 0;
                 }
                 try
                 {
                     _invoiceLineItemPrototype.RecordRate = Convert.ToInt16(saveRow.Cells["dgcRecordRate"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.RecordRate = 0;
                 }
                 try
                 {
                     _invoiceLineItemPrototype.MultiplyQuantityTimesRate = Convert.ToInt16(saveRow.Cells["dgcMultiplyQuantityTimesRate"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.MultiplyQuantityTimesRate = 0;
                 }
                 try
                 {
                     _invoiceLineItemPrototype.RecordAmount = Convert.ToInt16(saveRow.Cells["dgcRecordAmount"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _invoiceLineItemPrototype.RecordAmount = 0;
                 }
                 if (_newRowInputStarted)
                 {
                     _newRowInputStarted = false;
                     OnInvoiceLineItemPrototypeAddNewRecord();
                 }
                 else
                 {
                     OnInvoiceLineItemPrototypeUpdate();
                 }
             }
             else
             {
                 _newlyInsertedRowNumber = 0;
             }
         }

        private void OnInvoiceLineItemPrototypeAddNewRecord()
         {
             if (InvoiceLineItemPrototypeAddNewRecordEvent != null)
             {
                 InvoiceLineItemPrototypeAddNewRecordEvent(this, new SPEventArgs(_invoiceLineItemPrototype, SPObjectAction.add));
             }
         }

        private void OnInvoiceLineItemPrototypeUpdate()
        {
            if (InvoiceLineItemPrototypeUpdateEvent != null)
            {
                InvoiceLineItemPrototypeUpdateEvent(this, new SPEventArgs(_invoiceLineItemPrototype, SPObjectAction.update));
            }
        }

        public void NewIdAssignment(int id)
        {
            dgInvoiceLineItemPrototypes[0, _newlyInsertedRowNumber].Value = id.ToString();
        }

        private void dgInvoiceLineItemPrototypes_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            _invoiceLineItemPrototype = new InvoiceLineItemPrototype();
            DataGridViewRow saveRow = new DataGridViewRow();
            saveRow = e.Row;
            _invoiceLineItemPrototype.InvoiceLineItemPrototypeId = Convert.ToInt32(saveRow.Cells["dgcInvoiceLineItemPrototypeId"].Value);
            OnInvoiceLineItemPrototypeDelete();
        }

        private void OnInvoiceLineItemPrototypeDelete()
        {
            if (InvoiceLineItemPrototypeDeleteEvent != null)
            {
                InvoiceLineItemPrototypeDeleteEvent(this, new SPEventArgs(_invoiceLineItemPrototype, SPObjectAction.delete));
            }
        }

    }

}
