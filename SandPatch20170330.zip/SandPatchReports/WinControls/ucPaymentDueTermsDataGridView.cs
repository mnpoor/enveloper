using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI.WinControls
{
    public partial class ucPaymentDueTermsDataGridView : UserControl
    {
        public event SPEventHandler PaymentDueTermAddNewRecordEvent;
        public event SPEventHandler PaymentDueTermUpdateEvent;
        public event SPEventHandler PaymentDueTermRefreshEvent;
        public event SPEventHandler PaymentDueTermDeleteEvent;

        private bool _newRowInputStarted = false;
        private int _newlyInsertedRowNumber = 0;

        private PaymentDueTerm _paymentDueTerm = new PaymentDueTerm();

        public ucPaymentDueTermsDataGridView()
        {
            InitializeComponent();
        }

        public void PaymentDueTermFill(ref Collection<PaymentDueTerm> itemCollection)
        {
            dgPaymentDueTerms.Rows.Clear();

            foreach (PaymentDueTerm item in itemCollection)
            {
                object[] objectArray = new object[] { item.PaymentDueTermId.ToString(), item.PaymentDueTermDescription, item.DateAdded, item.AddedBy, item.DateUpdated, item.UpdatedBy };
                dgPaymentDueTerms.Rows.Add(objectArray);
            }
        }

        private void dgPaymentDueTerms_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            _newRowInputStarted = true;
        }

        private void dgPaymentDueTerms_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            if (dgPaymentDueTerms.IsCurrentRowDirty == true)
            {
                _paymentDueTerm = new PaymentDueTerm();
                 DataGridViewRow saveRow = new DataGridViewRow();
                 _newlyInsertedRowNumber = e.RowIndex;
                 saveRow = dgPaymentDueTerms.Rows[e.RowIndex];
                 if (_newRowInputStarted)
                 {
                     _paymentDueTerm.PaymentDueTermId = 0;
                 }
                 else
                 {
                     _paymentDueTerm.PaymentDueTermId = Convert.ToInt32(saveRow.Cells["dgcPaymentDueTermId"].Value);
                 }
                 try
                 {
                     _paymentDueTerm.PaymentDueTermId = Convert.ToInt32(saveRow.Cells["dgcPaymentDueTermId"].EditedFormattedValue.ToString());
                 }
                 catch
                 {
                     _paymentDueTerm.PaymentDueTermId = 0;
                 }
                 _paymentDueTerm.PaymentDueTermDescription = saveRow.Cells["dgcPaymentDueTermDescription"].EditedFormattedValue.ToString();
                 if (_newRowInputStarted)
                 {
                     _newRowInputStarted = false;
                     OnPaymentDueTermAddNewRecord();
                 }
                 else
                 {
                     OnPaymentDueTermUpdate();
                 }
             }
             else
             {
                 _newlyInsertedRowNumber = 0;
             }
         }

        private void OnPaymentDueTermAddNewRecord()
         {
             if (PaymentDueTermAddNewRecordEvent != null)
             {
                 PaymentDueTermAddNewRecordEvent(this, new SPEventArgs(_paymentDueTerm, SPObjectAction.add));
             }
         }

        private void OnPaymentDueTermUpdate()
        {
            if (PaymentDueTermUpdateEvent != null)
            {
                PaymentDueTermUpdateEvent(this, new SPEventArgs(_paymentDueTerm, SPObjectAction.update));
            }
        }

        public void NewIdAssignment(int id)
        {
            dgPaymentDueTerms[0, _newlyInsertedRowNumber].Value = id.ToString();
        }

        private void dgPaymentDueTerms_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            _paymentDueTerm = new PaymentDueTerm();
            DataGridViewRow saveRow = new DataGridViewRow();
            saveRow = e.Row;
            _paymentDueTerm.PaymentDueTermId = Convert.ToInt32(saveRow.Cells["dgcPaymentDueTermId"].Value);
            OnPaymentDueTermDelete();
        }

        private void OnPaymentDueTermDelete()
        {
            if (PaymentDueTermDeleteEvent != null)
            {
                PaymentDueTermDeleteEvent(this, new SPEventArgs(_paymentDueTerm, SPObjectAction.delete));
            }
        }

    }
}
