using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI.WinControls
{
    public partial class ucInvoice : UserControl
    {
        public event SPEventHandler InvoiceClearEvent;
        public event SPEventHandler InvoiceAddEvent;
        public event SPEventHandler InvoiceUpdateEvent;
        public event SPEventHandler InvoicePreviewPrintEvent;
        public event SPEventHandler InvoiceDeleteEvent;

        private Shipper _shipper;

        private Customer _customer;

        private Dispatch _dispatch;

        private Invoice _invoice;

        private LoadingTerminal _loadingTerminal;

        private JobSite _jobSite;

        string _column1;
        string _column2;
        string _column3;
        string _column4;
        string _column5;
        string _column6; 

        private System.Drawing.Printing.PrintDocument _invoiceDocument = new System.Drawing.Printing.PrintDocument();

        internal PrintPreviewDialog _previewDialog;

        private System.Drawing.Printing.PrinterSettings.PaperSizeCollection _paperSizes;
        private System.Drawing.Printing.PaperSize _paperSize;
        private System.Drawing.Rectangle _pageDrawingArea = new Rectangle(new Point(125, 125), new Size(1950, 3200));
        private System.Drawing.Rectangle _pageSize = new Rectangle(new Point(0, 0), new Size(2050, 3300));
        private System.Drawing.Printing.PrinterSettings _printerSettings = new System.Drawing.Printing.PrinterSettings();
        //private System.Drawing.Printing.PageSettings _pageSettings = new System.Drawing.Printing.PageSettings(new System.Drawing.Printing.PrinterSettings());

        private FontFamily[] _allFonts;
        private FontFamily _arialFontFamily;
        private FontFamily _calibriFontFamily;
        private FontFamily _goudyStoutFontFamily;
        private FontFamily _berlinSansFBFontFamily;
        private Font _companyNameFont;
        private Font _companyAddressFont;
        private Font _invoiceTitleFont;
        private Font _billToFont;
        private Font _lineItemFont;

        private Rectangle _lowerTitleBar = new Rectangle(50, 180, 750, 16);

        private Rectangle _chargeCodeBox;
        private Rectangle _lineItemBox;
        private Rectangle _totalBox;

        public ucInvoice()
        {
            InitializeComponent();
        }

        public void InvoiceClear()
        {
            _invoice = null;

            txtInvoiceId.Text = string.Empty;
            txtInvoiceNumber.Text = string.Empty;
            txtInvoiceDate.Text = string.Empty;
            txtShipperBillingId.Text = string.Empty;
            txtBillToCustomerId.Text = string.Empty;
            txtOriginTypeId.Text = string.Empty;
            txtOriginId.Text = string.Empty;
            txtDestinationTypeId.Text = string.Empty;
            txtDestinationId.Text = string.Empty;
            txtChargeCode.Text = string.Empty;
            txtPaymentTermsId.Text = string.Empty;
            txtBillOfLadingId.Text = string.Empty;
            txtDispatchId.Text = string.Empty;
            txtInvoiceSubtotalAmount.Text = string.Empty;
            txtInvoiceAdjustmentsAmount.Text = string.Empty;
            txtInvoiceTotalAmount.Text = string.Empty;
        }

        public void InvoiceShow(Invoice i)
        {
            _invoice = new Invoice(i);

            txtInvoiceId.Text = i.InvoiceId.ToString();
            txtInvoiceNumber.Text = i.InvoiceNumber;
            txtInvoiceDate.Text = i.InvoiceDate.ToString();
            txtShipperBillingId.Text = i.ShipperBillingId.ToString();
            txtBillToCustomerId.Text = i.BillToCustomerId.ToString();
            txtOriginTypeId.Text = i.OriginTypeId.ToString();
            txtOriginId.Text = i.OriginId.ToString();
            txtDestinationTypeId.Text = i.DestinationTypeId.ToString();
            txtDestinationId.Text = i.DestinationId.ToString();
            txtChargeCode.Text = i.ChargeCode;
            txtPaymentTermsId.Text = i.PaymentTermsId.ToString();
            txtBillOfLadingId.Text = i.BillOfLadingId.ToString();
            txtDispatchId.Text = i.DispatchId.ToString();
            txtInvoiceSubtotalAmount.Text = i.InvoiceSubtotalAmount.ToString();
            txtInvoiceAdjustmentsAmount.Text = i.InvoiceAdjustmentsAmount.ToString();
            txtInvoiceTotalAmount.Text = i.InvoiceTotalAmount.ToString();
        }

        public void InvoiceUpdate(ref Invoice i)
        {
            try
            {
                i.InvoiceId = Convert.ToInt32(txtInvoiceId.Text);
            }
            catch
            {
                i.InvoiceId = 0;
            }
            i.InvoiceNumber = txtInvoiceNumber.Text;
            try
            {
                i.InvoiceDate = Convert.ToDateTime(txtInvoiceDate.Text);
            }
            catch
            {
                i.InvoiceDate = new DateTime();
            }
            try
            {
                i.ShipperBillingId = Convert.ToInt32(txtShipperBillingId.Text);
            }
            catch
            {
                i.ShipperBillingId = 0;
            }
            try
            {
                i.BillToCustomerId = Convert.ToInt32(txtBillToCustomerId.Text);
            }
            catch
            {
                i.BillToCustomerId = 0;
            }
            try
            {
                i.OriginTypeId = Convert.ToInt32(txtOriginTypeId.Text);
            }
            catch
            {
                i.OriginTypeId = 0;
            }
            try
            {
                i.OriginId = Convert.ToInt32(txtOriginId.Text);
            }
            catch
            {
                i.OriginId = 0;
            }
            try
            {
                i.DestinationTypeId = Convert.ToInt32(txtDestinationTypeId.Text);
            }
            catch
            {
                i.DestinationTypeId = 0;
            }
            try
            {
                i.DestinationId = Convert.ToInt32(txtDestinationId.Text);
            }
            catch
            {
                i.DestinationId = 0;
            }
            i.ChargeCode = txtChargeCode.Text;
            try
            {
                i.PaymentTermsId = Convert.ToInt32(txtPaymentTermsId.Text);
            }
            catch
            {
                i.PaymentTermsId = 0;
            }
            try
            {
                i.BillOfLadingId = Convert.ToInt32(txtBillOfLadingId.Text);
            }
            catch
            {
                i.BillOfLadingId = 0;
            }
            try
            {
                i.DispatchId = Convert.ToInt32(txtDispatchId.Text);
            }
            catch
            {
                i.DispatchId = 0;
            }
            try
            {
                i.InvoiceSubtotalAmount = Convert.ToDecimal(txtInvoiceSubtotalAmount.Text);
            }
            catch
            {
                i.InvoiceSubtotalAmount = 0;
            }
            try
            {
                i.InvoiceAdjustmentsAmount = Convert.ToDecimal(txtInvoiceAdjustmentsAmount.Text);
            }
            catch
            {
                i.InvoiceAdjustmentsAmount = 0;
            }
            try
            {
                i.InvoiceTotalAmount = Convert.ToDecimal(txtInvoiceTotalAmount.Text);
            }
            catch
            {
                i.InvoiceTotalAmount = 0;
            }
        }

        public void InvoicePreviewPrint()
        {
            if (_invoice == null) return;
            
            _dispatch = SandPatchCL.DataServices.DataServiceDispatches.DispatchSqlGetById(_invoice.DispatchId);
            if (_dispatch == null) return;

            _shipper = SandPatchCL.DataServices.DataServiceShippers.ShipperSqlGetById(_invoice.ShipperBillingId);
            if (_shipper == null) return;

            _customer = SandPatchCL.DataServices.DataServiceCustomers.CustomerSqlGetById(_invoice.BillToCustomerId);
            if (_customer == null) return;

            _loadingTerminal = SandPatchCL.DataServices.DataServiceLoadingTerminals.LoadingTerminalSqlGetById(_invoice.OriginId);
            if (_loadingTerminal == null) return;

            _jobSite = SandPatchCL.DataServices.DataServiceJobSites.JobSiteSqlGetById(_invoice.DestinationId);
            if (_jobSite == null) return;

            _previewDialog = new PrintPreviewDialog();
            _previewDialog.Document = _invoiceDocument;
            _previewDialog.ClientSize = new System.Drawing.Size(775, 1000);
            _previewDialog.Location = new System.Drawing.Point(120, 32);
            _previewDialog.Name = "Print Invoice";

            //_pageSettings = new System.Drawing.Printing.PageSettings(_printerSettings);
            _printerSettings.FromPage = 1;
            _printerSettings.ToPage = 1;
            _printerSettings.Copies = 1;
            _paperSizes = _printerSettings.PaperSizes;
            foreach (System.Drawing.Printing.PaperSize paperSize in _paperSizes)
            {
                if (paperSize.PaperName == "Letter") _paperSize = paperSize;
            }

            _invoiceDocument.DefaultPageSettings = new System.Drawing.Printing.PageSettings(_printerSettings);
            _invoiceDocument.BeginPrint += new System.Drawing.Printing.PrintEventHandler(InvoiceDocument_BeginPrint);
            _invoiceDocument.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(InvoiceDocument_QueryPageSettings);
            _invoiceDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(InvoiceDocument_PrintPage);

            _previewDialog.MinimumSize = new System.Drawing.Size(375, 250);
            _previewDialog.UseAntiAlias = true;

            DialogResult response = _previewDialog.ShowDialog();
        }

        public void InvoiceDocument_BeginPrint(Object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            _allFonts = FontFamily.Families;
            foreach (FontFamily item in _allFonts)
            {
                if (item.Name == "Arial") _arialFontFamily = item;
                if (item.Name == "Calibri") _calibriFontFamily = item;
                if (item.Name == "Goudy Stout") _goudyStoutFontFamily = item;
                if (item.Name == "Berlin Sans FB") _berlinSansFBFontFamily = item;
            }
            _companyNameFont = new Font(_arialFontFamily, 18f, FontStyle.Bold, GraphicsUnit.Point);
            _companyAddressFont = new Font(_calibriFontFamily, 11f, FontStyle.Regular, GraphicsUnit.Point);
            _invoiceTitleFont = new Font(_goudyStoutFontFamily, 8f, FontStyle.Bold, GraphicsUnit.Point);
            _billToFont = new Font(_calibriFontFamily, 10f, FontStyle.Bold, GraphicsUnit.Point);
            _lineItemFont = new Font(FontFamily.GenericSerif, 10f, FontStyle.Regular, GraphicsUnit.Point);
        }

        public void InvoiceDocument_QueryPageSettings(Object sender, System.Drawing.Printing.PrintEventArgs e)
        {
        }

        private void InvoiceDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StaticLayout(e);

            _column1 = _invoice.InvoiceDate.ToShortDateString();
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 630, 58);

            _column1 = _invoice.InvoiceNumber;
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 651, 152);

            int y = 948;

            _column1 = _shipper.ShipperCompanyName.Trim();
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 140, y);
            y += 15;
            _column1 = _shipper.ShipperStreetAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 140, y);
                y += 15;
            }
            _column1 = _shipper.ShipperBoxAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 140, y);
                y += 15;
            }
            _column1 = _shipper.ShipperCity.Trim() + ", " + _shipper.ShipperState.Trim() + "  " + _shipper.ShipperPostalCode.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 140, y);
                y += 15;
            }
            _column1 = _shipper.ShipperPhoneNumber.Trim();
            if (_column1.Length > 0) e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 140, y);

            y = 200 + 15;

            _column1 = _customer.CustomerName.Trim();
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
            y += 15;
            _column1 = _customer.ContactName.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
                y += 15;
            }
            _column1 = _customer.StreetAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
                y += 15;
            }
            _column1 = _customer.BoxAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
                y += 15;
            }
            _column1 = _customer.City.Trim() + ", " + _customer.CustomerState.Trim() + "  " + _customer.PostalCode.Trim();
            if (_column1.Length > 0) e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);

            y = 300 + 15;

            _column1 = _loadingTerminal.LoadingTerminalName.Trim();
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
            y += 15;
            _column1 = _loadingTerminal.ContactName.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
                y += 15;
            }
            _column1 = _loadingTerminal.StreetAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
                y += 15;
            }
            _column1 = _loadingTerminal.BoxAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);
                y += 15;
            }
            _column1 = _loadingTerminal.City.Trim() + ", " + _loadingTerminal.LoadingTerminalState.Trim() + "  " + _loadingTerminal.PostalCode.Trim();
            if (_column1.Length > 0) e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 50, y);

            y = 300 + 15;

            _column1 = _jobSite.JobSiteName.Trim();
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 400, y);
            y += 15;
            _column1 = _jobSite.JobSiteContactName.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 400, y);
                y += 15;
            }
            _column1 = _jobSite.StreetAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 400, y);
                y += 15;
            }
            _column1 = _jobSite.BoxAddress.Trim();
            if (_column1.Length > 0)
            {
                e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 400, y);
                y += 15;
            }
            _column1 = _jobSite.City.Trim() + ", " + _jobSite.JobSiteState.Trim() + "  " + _jobSite.PostalCode.Trim() + "  " + _jobSite.CountryCode.Trim();
            if (_column1.Length > 0) e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 400, y);

            _column1 = _invoice.InvoiceSubtotalAmount.ToString();
            _column1 = _column1.Substring(0, _column1.Length - 2);
            Size textSize = TextRenderer.MeasureText(_column1, _companyAddressFont, new Size(96, 11));
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 798 - textSize.Width, 925);

            _column1 = _invoice.InvoiceTotalAmount.ToString();
            _column1 = _column1.Substring(0, _column1.Length - 2);
            textSize = TextRenderer.MeasureText(_column1, _companyAddressFont, new Size(96, 11));
            e.Graphics.DrawString(_column1, _companyAddressFont, Brushes.Black, 798 - textSize.Width, 968);

            e.HasMorePages = false;
        }

        private void StaticLayout(System.Drawing.Printing.PrintPageEventArgs e)
        {
            int y = 50;
            e.Graphics.DrawString("SIERRA COUNTRY ENERGY SERVICES", _companyNameFont, Brushes.Black, 50, y);
            y += 27;
            e.Graphics.DrawString("11810 Parliament", _companyAddressFont, Brushes.Black, 50, y);
            y += 15;
            e.Graphics.DrawString("San Antonio, Texas 78216", _companyAddressFont, Brushes.Black, 50, y);
            y += 15;
            e.Graphics.DrawString("210-348-8737 fax 210-348-8411", _companyAddressFont, Brushes.Black, 50, y);
            y += 30;
            e.Graphics.DrawLine(Pens.Black, 50, y, 800, y);
            y += 4;
            e.Graphics.DrawLine(Pens.Black, 50, y, 800, y);            
            e.Graphics.DrawString("INVOICE", _invoiceTitleFont, Brushes.Black, 500, 156);
            e.Graphics.DrawRectangle(Pens.Black, _lowerTitleBar);

            e.Graphics.DrawString("Bill To:", _billToFont, Brushes.Black, 50, 200);
            e.Graphics.DrawString("Origin:", _billToFont, Brushes.Black, 50, 300);
            e.Graphics.DrawString("Destination:", _billToFont, Brushes.Black, 400, 300);

            _chargeCodeBox = new Rectangle(600, 430, 200, 70);
            _lineItemBox = new Rectangle(50, 500, 750, 425);
            _totalBox = new Rectangle(700, 925, 100, 60);

            e.Graphics.DrawRectangle(Pens.Black, _chargeCodeBox);
            e.Graphics.DrawRectangle(Pens.Black, _lineItemBox);
            e.Graphics.DrawRectangle(Pens.Black, _totalBox);
            e.Graphics.DrawLine(Pens.Black, 300, 500, 300, 925);
            e.Graphics.DrawLine(Pens.Black, 600, 430, 600, 925);
            e.Graphics.DrawLine(Pens.Black, 700, 430, 700, 975);

            e.Graphics.DrawLine(Pens.Black, 375, 500, 375, 518);
            e.Graphics.DrawLine(Pens.Black, 450, 500, 450, 518);
            e.Graphics.DrawLine(Pens.Black, 50, 518, 800, 518);

            e.Graphics.DrawLine(Pens.Black, 600, 447, 800, 447);
            e.Graphics.DrawLine(Pens.Black, 600, 465, 800, 465);
            e.Graphics.DrawLine(Pens.Black, 600, 483, 800, 483);

            e.Graphics.DrawLine(Pens.Black, 700, 940, 800, 940);
            e.Graphics.DrawLine(Pens.Black, 700, 955, 800, 955);

            e.Graphics.DrawString("Description", _billToFont, Brushes.Black, 125, 501);
            e.Graphics.DrawString("Quantity", _billToFont, Brushes.Black, 305, 501);
            e.Graphics.DrawString("Units", _billToFont, Brushes.Black, 390, 501);
            e.Graphics.DrawString("Rate", _billToFont, Brushes.Black, 550, 501);
            e.Graphics.DrawString("Amount", _billToFont, Brushes.Black, 605, 501);

            e.Graphics.DrawString("Notes:", _billToFont, Brushes.Black, 50, 928);
            e.Graphics.DrawString("Please Remit Payment To:", _billToFont, Brushes.Black, 125, 928);

            e.Graphics.DrawString("Charge Code", _billToFont, Brushes.Black, 600, 432);
            e.Graphics.DrawString("Bill of Lading #", _billToFont, Brushes.Black, 600, 465);

            e.Graphics.DrawString("Subtotal", _companyAddressFont, Brushes.Black, 600, 928);
            e.Graphics.DrawString("Total", _billToFont, Brushes.Black, 625, 968);

            e.Graphics.DrawString("Terms", _billToFont, Brushes.Black, 700, 432);
            e.Graphics.DrawString("Driver Ticket #", _billToFont, Brushes.Black, 700, 465);

            e.Graphics.DrawString("WE APPRECIATE YOUR BUSINESS", _companyAddressFont, Brushes.Black, 125, 1025);
        }

        private void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.InvoiceClearEvent != null)
            {
                this.InvoiceClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        private void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.InvoiceAddEvent != null)
            {
                this.InvoiceAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        private void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.InvoiceUpdateEvent != null)
            {
                this.InvoiceUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        private void cmdPreviewPrintInvoice_Click(object sender, EventArgs e)
        {
            OnPreviewPrint();
        }

        private void OnPreviewPrint()
        {
            if (this.InvoicePreviewPrintEvent != null)
            {
                this.InvoicePreviewPrintEvent(this, new SPEventArgs(null, SPObjectAction.previewPrint));
            }
        }

        private void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.InvoiceDeleteEvent != null)
            {
                this.InvoiceDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
