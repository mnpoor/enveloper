namespace SandPatchReportsUI.WinControls
{
    partial class ucInvoicesSearchDataGridView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInvoiceNumber = new System.Windows.Forms.TextBox();
            this.txtInvoiceDate = new System.Windows.Forms.TextBox();
            this.cmdSearch = new System.Windows.Forms.Button();
            this.cmdClear = new System.Windows.Forms.Button();
            this.dgInvoices = new System.Windows.Forms.DataGridView();
            this.lblInvoiceDate = new System.Windows.Forms.Label();
            this.lblInvoiceNumber = new System.Windows.Forms.Label();
            this.dgcInvoiceId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcInvoiceNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcInvoiceDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcOriginId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDestinationId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoices)).BeginInit();
            this.SuspendLayout();
            // 
            // txtInvoiceNumber
            // 
            this.txtInvoiceNumber.Location = new System.Drawing.Point(187, 24);
            this.txtInvoiceNumber.Name = "txtInvoiceNumber";
            this.txtInvoiceNumber.Size = new System.Drawing.Size(156, 22);
            this.txtInvoiceNumber.TabIndex = 1;
            // 
            // txtInvoiceDate
            // 
            this.txtInvoiceDate.Location = new System.Drawing.Point(187, 52);
            this.txtInvoiceDate.Name = "txtInvoiceDate";
            this.txtInvoiceDate.Size = new System.Drawing.Size(156, 22);
            this.txtInvoiceDate.TabIndex = 3;
            // 
            // cmdSearch
            // 
            this.cmdSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdSearch.Location = new System.Drawing.Point(574, 101);
            this.cmdSearch.Name = "cmdSearch";
            this.cmdSearch.Size = new System.Drawing.Size(83, 28);
            this.cmdSearch.TabIndex = 5;
            this.cmdSearch.Text = "Search";
            this.cmdSearch.UseVisualStyleBackColor = true;
            this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
            // 
            // cmdClear
            // 
            this.cmdClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdClear.Location = new System.Drawing.Point(472, 101);
            this.cmdClear.Name = "cmdClear";
            this.cmdClear.Size = new System.Drawing.Size(83, 28);
            this.cmdClear.TabIndex = 4;
            this.cmdClear.Text = "Clear";
            this.cmdClear.UseVisualStyleBackColor = true;
            this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
            // 
            // dgInvoices
            // 
            this.dgInvoices.AllowUserToAddRows = false;
            this.dgInvoices.AllowUserToDeleteRows = false;
            this.dgInvoices.AllowUserToOrderColumns = true;
            this.dgInvoices.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgInvoices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgInvoices.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgcInvoiceId,
            this.dgcInvoiceNumber,
            this.dgcInvoiceDate,
            this.dgcOriginId,
            this.dgcDestinationId});
            this.dgInvoices.Location = new System.Drawing.Point(22, 144);
            this.dgInvoices.MultiSelect = false;
            this.dgInvoices.Name = "dgInvoices";
            this.dgInvoices.ReadOnly = true;
            this.dgInvoices.Size = new System.Drawing.Size(635, 192);
            this.dgInvoices.TabIndex = 6;
            this.dgInvoices.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgInvoices_RowEnter);
            // 
            // lblInvoiceDate
            // 
            this.lblInvoiceDate.AutoSize = true;
            this.lblInvoiceDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceDate.Location = new System.Drawing.Point(56, 52);
            this.lblInvoiceDate.Name = "lblInvoiceDate";
            this.lblInvoiceDate.Size = new System.Drawing.Size(106, 18);
            this.lblInvoiceDate.TabIndex = 2;
            this.lblInvoiceDate.Text = "Invoice Date:";
            // 
            // lblInvoiceNumber
            // 
            this.lblInvoiceNumber.AutoSize = true;
            this.lblInvoiceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceNumber.Location = new System.Drawing.Point(56, 24);
            this.lblInvoiceNumber.Name = "lblInvoiceNumber";
            this.lblInvoiceNumber.Size = new System.Drawing.Size(130, 18);
            this.lblInvoiceNumber.TabIndex = 0;
            this.lblInvoiceNumber.Text = "Invoice Number:";
            // 
            // dgcInvoiceId
            // 
            this.dgcInvoiceId.HeaderText = "Id";
            this.dgcInvoiceId.Name = "dgcInvoiceId";
            this.dgcInvoiceId.ReadOnly = true;
            this.dgcInvoiceId.Width = 50;
            // 
            // dgcInvoiceNumber
            // 
            this.dgcInvoiceNumber.HeaderText = "Invoice Number";
            this.dgcInvoiceNumber.Name = "dgcInvoiceNumber";
            this.dgcInvoiceNumber.ReadOnly = true;
            this.dgcInvoiceNumber.Width = 120;
            // 
            // dgcInvoiceDate
            // 
            this.dgcInvoiceDate.HeaderText = "Invoice Date";
            this.dgcInvoiceDate.Name = "dgcInvoiceDate";
            this.dgcInvoiceDate.ReadOnly = true;
            this.dgcInvoiceDate.Width = 120;
            // 
            // dgcOriginId
            // 
            this.dgcOriginId.HeaderText = "Origin";
            this.dgcOriginId.Name = "dgcOriginId";
            this.dgcOriginId.ReadOnly = true;
            this.dgcOriginId.Width = 150;
            // 
            // dgcDestinationId
            // 
            this.dgcDestinationId.HeaderText = "Destination";
            this.dgcDestinationId.Name = "dgcDestinationId";
            this.dgcDestinationId.ReadOnly = true;
            this.dgcDestinationId.Width = 150;
            // 
            // ucInvoicesSearchDataGridView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblInvoiceNumber);
            this.Controls.Add(this.txtInvoiceNumber);
            this.Controls.Add(this.lblInvoiceDate);
            this.Controls.Add(this.txtInvoiceDate);
            this.Controls.Add(this.cmdClear);
            this.Controls.Add(this.cmdSearch);
            this.Controls.Add(this.dgInvoices);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ucInvoicesSearchDataGridView";
            this.Size = new System.Drawing.Size(682, 364);
            ((System.ComponentModel.ISupportInitialize)(this.dgInvoices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInvoiceNumber;
        private System.Windows.Forms.TextBox txtInvoiceDate;
        private System.Windows.Forms.Button cmdSearch;
        private System.Windows.Forms.Button cmdClear;
        private System.Windows.Forms.DataGridView dgInvoices;
        private System.Windows.Forms.Label lblInvoiceDate;
        private System.Windows.Forms.Label lblInvoiceNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcInvoiceId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcInvoiceNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcInvoiceDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcOriginId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDestinationId;
    }
}
