using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI.WinControls
{
    public partial class ucInvoicesSearchDataGridView : UserControl
    {
        public event SPEventHandler InvoiceDataGridViewClearEvent;
        public event SPEventHandler InvoiceDataGridViewSearchEvent;
        public event SPEventHandler InvoiceDataGridViewRowSelectedEvent;

        public ucInvoicesSearchDataGridView()
        {
            InitializeComponent();
        }

        public void InvoiceDataGridViewClear()
        {
            txtInvoiceNumber.Text = string.Empty;
            txtInvoiceDate.Text = string.Empty;
            dgInvoices.Rows.Clear();
        }

        public string[] InvoiceDataGridViewWildcard()
        {
            txtInvoiceNumber.Text = ApplyWildcards(txtInvoiceNumber.Text);
            return new string[] { txtInvoiceNumber.Text, txtInvoiceDate.Text };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains(" % ")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void InvoiceDataGridViewSearch(Collection<Invoice> itemCollection)
        {

            dgInvoices.Rows.Clear();

            Application.DoEvents();

            foreach (Invoice item in itemCollection)
            {
                string[] textArray = new string[] { item.InvoiceId.ToString().Trim(), item.InvoiceNumber.ToString().Trim(), item.InvoiceDate.ToString().Trim(), item.ShipperBillingId.ToString().Trim(), item.BillToCustomerId.ToString().Trim(), item.OriginTypeId.ToString().Trim(), item.OriginId.ToString().Trim(), item.DestinationTypeId.ToString().Trim() };
                DataGridViewRow InvoiceRow = new DataGridViewRow();
                InvoiceRow.CreateCells(dgInvoices);
                InvoiceRow.SetValues(textArray);
                InvoiceRow.Tag = new Invoice(item);
                dgInvoices.Rows.Add(InvoiceRow);
            }
        }

        private void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.InvoiceDataGridViewClearEvent != null)
            {
                this.InvoiceDataGridViewClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        private void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.InvoiceDataGridViewSearchEvent != null)
            {
                this.InvoiceDataGridViewSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        private void dgInvoices_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (this.InvoiceDataGridViewRowSelectedEvent != null)
            {
                this.InvoiceDataGridViewRowSelectedEvent(this, new SPEventArgs((Invoice)dgInvoices.Rows[e.RowIndex].Tag, SPObjectAction.dataGridItemSelected));
            }
        }

    }

}
