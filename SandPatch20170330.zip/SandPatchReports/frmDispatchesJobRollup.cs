﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmDispatchesJobRollup : Form
    {
        private Collection<JobNumber> _jobNumbers;

        public frmDispatchesJobRollup()
        {
            InitializeComponent();
        }

        private void frmDispatchesJobRollup_Load(object sender, EventArgs e)
        {
            _jobNumbers = SandPatchCL.DataServices.DataServiceJobNumbers.JobNumberSqlGetAll();
            foreach (JobNumber item in _jobNumbers) item.JobNumberDescription = item.JobNumberAssignment.ToString() + " - " + item.JobNumberDescription;
            _jobNumbers.Insert(0, new JobNumber());
            _jobNumbers[0].JobNumberDescription = "All";
            cmbJobNumber.DataSource = null;
            Application.DoEvents();
            cmbJobNumber.DataSource = _jobNumbers;
            cmbJobNumber.DisplayMember = "JobNumberDescription";
            cmbJobNumber.ValueMember = "JobNumberAssignment";
        }

        private void cmdPrint_Click(object sender, EventArgs e)
        {
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportDispatchJobRollup", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;

            int jobNumberAssignment = ((JobNumber)cmbJobNumber.SelectedItem).JobNumberAssignment;

            if (jobNumberAssignment > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumberAssignment));
            }

            preprocess.ExecuteNonQuery();

            Application.DoEvents();

            this.DispatchJobRollupReportTableAdapter.Connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();

            this.DispatchJobRollupReportTableAdapter.Fill(this.SandPatchReportsRowsets.DispatchJobRollupReport);

            reportViewerDispatchesJobRollup.RefreshReport();
       }
    }
}
