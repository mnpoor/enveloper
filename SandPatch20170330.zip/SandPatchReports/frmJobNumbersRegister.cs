﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmJobNumbersRegister : Form
    {
        private Collection<Customer> _customers;
        private Collection<JobNumberStatus> _jobNumberStatuses;

        public frmJobNumbersRegister()
        {
            InitializeComponent();
        }

        private void frmJobNumbersRegister_Load(object sender, EventArgs e)
        {
            _customers = SandPatchCL.DataServices.DataServiceCustomers.CustomerSqlGetAll();
            cmbCustomers.DataSource = null;
            Application.DoEvents();
            _customers.Insert(0, new Customer());
            _customers[0].CustomerName = "All";
            cmbCustomers.DataSource = _customers;
            cmbCustomers.DisplayMember = "CustomerName";
            cmbCustomers.ValueMember = "CustomerId";

            _jobNumberStatuses = SandPatchCL.DataServices.DataServiceJobNumberStatuses.JobNumberStatusSqlGetAll();
            cmbJobNumberStatus.DataSource = null;
            Application.DoEvents();
            _jobNumberStatuses.Insert(0, new JobNumberStatus());
            _jobNumberStatuses[0].JobNumberStatusDescription = "All";
            cmbJobNumberStatus.DataSource = _jobNumberStatuses;
            cmbJobNumberStatus.DisplayMember = "JobNumberStatusDescription";
            cmbJobNumberStatus.ValueMember = "JobNumberStatusId";
        }

        private void cmdPrint_Click(object sender, EventArgs e)
        {
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportJobNumbers", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;


            int customerId = ((Customer)cmbCustomers.SelectedItem).CustomerId;
            if (customerId > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@CustomerId", (object)customerId));
            }

            int jobNumberStatusId = ((JobNumberStatus)cmbJobNumberStatus.SelectedItem).JobNumberStatusId;
            if (jobNumberStatusId > 0)
            {
                preprocess.Parameters.Add(new SqlParameter("@JobNumberStatusId", (object)jobNumberStatusId));
            }

            preprocess.ExecuteNonQuery();

            Application.DoEvents();

            this.JobNumbersReportTableAdapter.Connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();

            this.JobNumbersReportTableAdapter.Fill(this.SandPatchReportsRowsets.JobNumbersReport);

            reportViewerJobNumbers.RefreshReport();
       }
    }
}
