﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmInvoicePrint : Form
    {
        private System.Drawing.Printing.PrintDocument _invoiceDocument = new System.Drawing.Printing.PrintDocument();

        internal PrintPreviewDialog _previewDialog;

        private System.Drawing.Printing.PrinterSettings.PaperSizeCollection _paperSizes;
        private System.Drawing.Printing.PaperSize _paperSize;
        private System.Drawing.Rectangle _pageDrawingArea = new Rectangle(new Point(125, 125), new Size(1950, 3200));
        private System.Drawing.Rectangle _pageSize = new Rectangle(new Point(0, 0), new Size(2050, 3300));
        private System.Drawing.Printing.PrinterSettings _printerSettings = new System.Drawing.Printing.PrinterSettings();
        //private System.Drawing.Printing.PageSettings _pageSettings = new System.Drawing.Printing.PageSettings(new System.Drawing.Printing.PrinterSettings());

        private FontFamily[] _allFonts;
        private FontFamily _arialFontFamily;
        private FontFamily _calibriFontFamily;
        private FontFamily _goudyStoutFontFamily;
        private FontFamily _berlinSansFBFontFamily;
        private Font _companyNameFont;
        private Font _companyAddressFont;
        private Font _invoiceTitleFont;
        private Font _billToFont;
        private Font _lineItemFont;

        private Rectangle _lowerTitleBar = new Rectangle(50, 195, 750, 16);

        private Rectangle _chargeCodeBox;
        private Rectangle _lineItemBox;
        private Rectangle _totalBox;
        
        public frmInvoicePrint()
        {
            InitializeComponent();
        }

        private void cmdPreview_Click(object sender, EventArgs e)
        {
            _previewDialog = new PrintPreviewDialog();
            _previewDialog.Document = _invoiceDocument;
	        _previewDialog.ClientSize = new System.Drawing.Size(775, 1000);
	        _previewDialog.Location = new System.Drawing.Point(120, 32);
	        _previewDialog.Name = "Print Invoice";

            //_pageSettings = new System.Drawing.Printing.PageSettings(_printerSettings);
            _printerSettings.FromPage = 1;
            _printerSettings.ToPage = 1;
            _printerSettings.Copies = 1;
            _paperSizes = _printerSettings.PaperSizes;
            foreach (System.Drawing.Printing.PaperSize paperSize in _paperSizes)
            {
                if (paperSize.PaperName == "Letter") _paperSize = paperSize;
            }

            _invoiceDocument.DefaultPageSettings = new System.Drawing.Printing.PageSettings(_printerSettings);
            _invoiceDocument.BeginPrint += new System.Drawing.Printing.PrintEventHandler(InvoiceDocument_BeginPrint);
            _invoiceDocument.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(InvoiceDocument_QueryPageSettings);
	        _invoiceDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(InvoiceDocument_PrintPage);

	        _previewDialog.MinimumSize = new System.Drawing.Size(375, 250);
	        _previewDialog.UseAntiAlias = true;

            DialogResult response = _previewDialog.ShowDialog();
        }

        public void InvoiceDocument_BeginPrint(Object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            _allFonts = FontFamily.Families;
            foreach(FontFamily item in _allFonts)
            {
                if (item.Name == "Arial") _arialFontFamily = item;
                if (item.Name == "Calibri") _calibriFontFamily = item;
                if (item.Name == "Goudy Stout") _goudyStoutFontFamily = item;
                if (item.Name == "Berlin Sans FB") _berlinSansFBFontFamily = item;
            }
            _companyNameFont = new Font(_arialFontFamily, 18f, FontStyle.Bold, GraphicsUnit.Point);
            _companyAddressFont = new Font(_calibriFontFamily, 11f, FontStyle.Regular, GraphicsUnit.Point);
            _invoiceTitleFont = new Font(_goudyStoutFontFamily, 8f, FontStyle.Bold, GraphicsUnit.Point);
            _billToFont = new Font(_calibriFontFamily, 10f, FontStyle.Bold, GraphicsUnit.Point);
            _lineItemFont = new Font(FontFamily.GenericSerif, 10f, FontStyle.Regular, GraphicsUnit.Point);
        }

        public void InvoiceDocument_QueryPageSettings(Object sender, System.Drawing.Printing.PrintEventArgs e)
        {
        }

        private void InvoiceDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StaticLayout(e);

            e.HasMorePages = false;
        }

        private void StaticLayout(System.Drawing.Printing.PrintPageEventArgs e)
        {
            int y = 50 + 18;
            e.Graphics.DrawString("SIERRA COUNTRY ENERGY SERVICES", _companyNameFont, Brushes.Black, 50, y);
            y += 27;
            e.Graphics.DrawString("11810 Parliament", _companyAddressFont, Brushes.Black, 50, y);
            y += 21;
            e.Graphics.DrawString("San Antonio, Texas 78216", _companyAddressFont, Brushes.Black, 50, y);
            y += 21;
            e.Graphics.DrawString("210-348-8737 fax 210-348-8411", _companyAddressFont, Brushes.Black, 50, y);
            y += 21;
            e.Graphics.DrawLine(Pens.Black, 50, y, 800, y);
            y += 3;
            e.Graphics.DrawLine(Pens.Black, 50, y, 800, y);
            y += 12;
            e.Graphics.DrawString("INVOICE", _invoiceTitleFont, Brushes.Black, 500, y);
            e.Graphics.DrawRectangle(Pens.Black, _lowerTitleBar);
            y += 40;
            e.Graphics.DrawString("Bill To:", _billToFont, Brushes.Black, 50, y);
            e.Graphics.DrawString("Origin:", _billToFont, Brushes.Black, 50, 300);
            e.Graphics.DrawString("Destination:", _billToFont, Brushes.Black, 400, 300);

            _chargeCodeBox = new Rectangle(600, 430, 200, 70);
            _lineItemBox = new Rectangle(50, 500, 750, 425);
            _totalBox = new Rectangle(700, 925, 100, 60);

            e.Graphics.DrawRectangle(Pens.Black, _chargeCodeBox);
            e.Graphics.DrawRectangle(Pens.Black, _lineItemBox);
            e.Graphics.DrawRectangle(Pens.Black, _totalBox);
            e.Graphics.DrawLine(Pens.Black, 300, 500, 300, 925);
            e.Graphics.DrawLine(Pens.Black, 600, 430, 600, 925);
            e.Graphics.DrawLine(Pens.Black, 700, 430, 700, 975);

            e.Graphics.DrawLine(Pens.Black, 375, 500, 375, 518);
            e.Graphics.DrawLine(Pens.Black, 450, 500, 450, 518);
            e.Graphics.DrawLine(Pens.Black, 50, 518, 800, 518);

            e.Graphics.DrawLine(Pens.Black, 600, 447, 800, 447);
            e.Graphics.DrawLine(Pens.Black, 600, 465, 800, 465);
            e.Graphics.DrawLine(Pens.Black, 600, 483, 800, 483);

            e.Graphics.DrawLine(Pens.Black, 700, 940, 800, 940);
            e.Graphics.DrawLine(Pens.Black, 700, 955, 800, 955);

            e.Graphics.DrawString("Description", _billToFont, Brushes.Black, 125, 501);
            e.Graphics.DrawString("Quantity", _billToFont, Brushes.Black, 305, 501);
            e.Graphics.DrawString("Units", _billToFont, Brushes.Black, 390, 501);
            e.Graphics.DrawString("Rate", _billToFont, Brushes.Black, 550, 501);
            e.Graphics.DrawString("Amount", _billToFont, Brushes.Black, 605, 501);

            e.Graphics.DrawString("Notes:", _billToFont, Brushes.Black, 50, 928);
            e.Graphics.DrawString("Please Remit Payment To:", _billToFont, Brushes.Black, 125, 928);

            e.Graphics.DrawString("Charge Code", _billToFont, Brushes.Black, 600, 432);
            e.Graphics.DrawString("Bill of Lading #", _billToFont, Brushes.Black, 600, 465);

            e.Graphics.DrawString("Subtotal", _companyAddressFont, Brushes.Black, 600, 928);
            e.Graphics.DrawString("Total", _billToFont, Brushes.Black, 625, 968);

            e.Graphics.DrawString("Terms", _billToFont, Brushes.Black, 700, 432);
            e.Graphics.DrawString("Driver Ticket #", _billToFont, Brushes.Black, 700, 465);

            e.Graphics.DrawString("WE APPRECIATE YOUR BUSINESS", _companyAddressFont, Brushes.Black, 125, 1025);

        }

    }
}
