using SandPatchCL;
using SandPatchCL.DataServices;
using SandPatchReportsUI.WinControls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmInvoice : Form
    {

        private Invoice _invoice;
        private Collection<Invoice> _invoices;

        private string[] _searchTerms;

        public frmInvoice()
        {
            InitializeComponent();
        }

        private void frmInvoice_Load(object sender, EventArgs e)
        {
            _invoice = new Invoice();
            ucInvoicesSearch.InvoiceDataGridViewClear();
        }

        private void ucInvoicesSearch_InvoiceDataGridViewClearEvent(object sender, SPEventArgs e)
        {
            _invoices = new Collection<Invoice>();
            ucInvoicesSearch.InvoiceDataGridViewClear();
        }

        private void ucInvoicesSearch_InvoiceDataGridViewSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = ucInvoicesSearch.InvoiceDataGridViewWildcard();
            _invoices = DataServiceInvoices.InvoiceSqlGetBySearchTerms(_searchTerms);
            ucInvoicesSearch.InvoiceDataGridViewSearch(_invoices);
        }

        private void ucInvoicesSearch_InvoiceDataGridViewRowSelectedEvent(object sender, SPEventArgs e)
        {
            _invoice = (Invoice)e.SPClass;
            ucInvoiceEdit.InvoiceShow(_invoice);
        }

        private void ucInvoiceEdit_InvoiceClearEvent(object sender, SPEventArgs e)
        {
            _invoice = new Invoice();
            ucInvoiceEdit.InvoiceClear();
        }

        private void ucInvoiceEdit_InvoiceAddEvent(object sender, SPEventArgs e)
        {
            ucInvoiceEdit.InvoiceUpdate(ref _invoice);
            DataServiceInvoices.SqlSave(ref _invoice);
            ucInvoiceEdit.InvoiceShow(_invoice);
        }

        private void ucInvoiceEdit_InvoiceUpdateEvent(object sender, SPEventArgs e)
        {
            ucInvoiceEdit.InvoiceUpdate(ref _invoice);
            DataServiceInvoices.SqlSave(ref _invoice);
            ucInvoiceEdit.InvoiceShow(_invoice);
        }

        private void ucInvoiceEdit_InvoicePrintEvent(object sender, SPEventArgs e)
        {
            ucInvoiceEdit.InvoicePreviewPrint();
        }

        private void ucInvoiceEdit_InvoiceDeleteEvent(object sender, SPEventArgs e)
        {
            ucInvoiceEdit.InvoiceUpdate(ref _invoice);
            DataServiceInvoices.SqlDelete(ref _invoice);
            _invoice = new Invoice();
            ucInvoiceEdit.InvoiceClear();
            _invoices = DataServiceInvoices.InvoiceSqlGetBySearchTerms(_searchTerms);
            ucInvoicesSearch.InvoiceDataGridViewSearch(_invoices);
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }

}
