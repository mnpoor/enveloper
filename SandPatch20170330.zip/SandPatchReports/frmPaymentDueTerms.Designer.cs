namespace SandPatchReportsUI
{
    partial class frmPaymentDueTerms
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucPaymentDueTermsManager = new SandPatchReportsUI.WinControls.ucPaymentDueTermsDataGridView();
            this.SuspendLayout();
            // 
            // ucPaymentDueTermsManager
            // 
            this.ucPaymentDueTermsManager.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucPaymentDueTermsManager.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucPaymentDueTermsManager.Location = new System.Drawing.Point(12, 16);
            this.ucPaymentDueTermsManager.Name = "ucPaymentDueTermsManager";
            this.ucPaymentDueTermsManager.Size = new System.Drawing.Size(529, 553);
            this.ucPaymentDueTermsManager.TabIndex = 0;
            this.ucPaymentDueTermsManager.PaymentDueTermAddNewRecordEvent += new SandPatchCL.SPEventHandler(this.ucPaymentDueTermsManager_PaymentDueTermAddNewRecordEvent);
            this.ucPaymentDueTermsManager.PaymentDueTermUpdateEvent += new SandPatchCL.SPEventHandler(this.ucPaymentDueTermsManager_PaymentDueTermUpdateEvent);
            this.ucPaymentDueTermsManager.PaymentDueTermRefreshEvent += new SandPatchCL.SPEventHandler(this.ucPaymentDueTermsManager_PaymentDueTermRefreshEvent);
            this.ucPaymentDueTermsManager.PaymentDueTermDeleteEvent += new SandPatchCL.SPEventHandler(this.ucPaymentDueTermsManager_PaymentDueTermDeleteEvent);
            // 
            // frmPaymentDueTerms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 591);
            this.Controls.Add(this.ucPaymentDueTermsManager);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmPaymentDueTerms";
            this.Text = "PaymentDueTerms";
            this.Load += new System.EventHandler(this.frmPaymentDueTerms_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private SandPatchReportsUI.WinControls.ucPaymentDueTermsDataGridView ucPaymentDueTermsManager;

    }

}
