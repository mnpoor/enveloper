﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmSandPatchReports : Form
    {
        public frmSandPatchReports()
        {
            InitializeComponent();
        }

        private void menuFileConnection_Click(object sender, EventArgs e)
        {
            frmSQLServerConnectionBuilder sqlServerConnectionBuilderForm = new frmSQLServerConnectionBuilder();
            sqlServerConnectionBuilderForm.Show();
        }

        private void menuTransactionInvoices_Click(object sender, EventArgs e)
        {
            frmInvoice invoiceForm = new frmInvoice();
            invoiceForm.Show();
        }

        private void menuReportsDriversStatus_Click(object sender, EventArgs e)
        {
            frmDrivers driversReportForm = new frmDrivers();
            driversReportForm.Show();
        }

        private void menuReportsDispatchesJobRollup_Click(object sender, EventArgs e)
        {
            frmDispatchesJobRollup dispatchJobRollupReportForm = new frmDispatchesJobRollup();
            dispatchJobRollupReportForm.Show();
        }

        private void menuReportsDispatchesDriverActivity_Click(object sender, EventArgs e)
        {
            frmDispatchesDriverActivity dispatchDriverActivtyReportForm = new frmDispatchesDriverActivity();
            dispatchDriverActivtyReportForm.Show();
        }

        private void menuReportsDispatchesDateRollup_Click(object sender, EventArgs e)
        {
            frmDispatchesDateRollup dispatchDateRollupReportForm = new frmDispatchesDateRollup();
            dispatchDateRollupReportForm.Show();
        }

        private void menuReportsDispachesWeeklyRecap_Click(object sender, EventArgs e)
        {
            frmDispatchesWeeklyRecap dispachWeeklyRecapForm = new frmDispatchesWeeklyRecap();
            dispachWeeklyRecapForm.Show();
        }

        private void menuReportsJobNumbers_Click(object sender, EventArgs e)
        {
            frmJobNumbersRegister jobNumbersRegisterReportForm = new frmJobNumbersRegister();
            jobNumbersRegisterReportForm.Show();
        }

        private void menuReportsPurchaseOrders_Click(object sender, EventArgs e)
        {
            frmPurchaseOrdersRegister purchaseOrderRegisterReportForm = new frmPurchaseOrdersRegister();
            purchaseOrderRegisterReportForm.Show();
        }

        private void menuValidationPaymentDueTerms_Click(object sender, EventArgs e)
        {
            frmPaymentDueTerms paymentDueTermsForm = new frmPaymentDueTerms();
            paymentDueTermsForm.Show();
        }

        private void menuValidationInvoiceDetailPrototype_Click(object sender, EventArgs e)
        {
            frmInvoiceLineItemPrototypes invoiceLineItemPrototypeForm = new frmInvoiceLineItemPrototypes();
            invoiceLineItemPrototypeForm.Show();
        }

        private void menuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
