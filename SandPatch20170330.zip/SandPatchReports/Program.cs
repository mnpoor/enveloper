﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    static class Program
    {
        public const string DialogBoxCaption = "SandPatch Reports";
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                SPSingleton _oneAndOnly = SPSingleton.Instance;
            }
            catch
            {
                Application.Exit();
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmSandPatchReports());
        }
    }
}
