using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SandPatchReportsUI
{
    public partial class frmInvoiceLineItemPrototypes : Form
    {

        private InvoiceLineItemPrototype _invoiceLineItemPrototype;
        private Collection<InvoiceLineItemPrototype> _invoiceLineItemPrototypes;

        public frmInvoiceLineItemPrototypes()
        {
            InitializeComponent();
        }

        private void frmInvoiceLineItemPrototypes_Load(object sender, EventArgs e)
        {
            _invoiceLineItemPrototypes = SandPatchCL.DataServices.DataServiceInvoiceLineItemPrototypes.InvoiceLineItemPrototypeSqlGetAll();
            ucInvoiceLineItemPrototypesManager.InvoiceLineItemPrototypeFill(ref _invoiceLineItemPrototypes);
        }

        private void ucInvoiceLineItemPrototypesManager_InvoiceLineItemPrototypeRefreshEvent(object sender, SPEventArgs e)
        {
            _invoiceLineItemPrototypes = SandPatchCL.DataServices.DataServiceInvoiceLineItemPrototypes.InvoiceLineItemPrototypeSqlGetAll();
            ucInvoiceLineItemPrototypesManager.InvoiceLineItemPrototypeFill(ref _invoiceLineItemPrototypes);
        }

        private void ucInvoiceLineItemPrototypesManager_InvoiceLineItemPrototypeAddNewRecordEvent(object sender, SPEventArgs e)
        {
            _invoiceLineItemPrototype = (InvoiceLineItemPrototype)e.SPClass;
            SandPatchCL.DataServices.DataServiceInvoiceLineItemPrototypes.SqlSave(ref _invoiceLineItemPrototype);
            ucInvoiceLineItemPrototypesManager.NewIdAssignment(_invoiceLineItemPrototype.InvoiceLineItemPrototypeId);
        }

        private void ucInvoiceLineItemPrototypesManager_InvoiceLineItemPrototypeUpdateEvent(object sender, SPEventArgs e)
        {
            _invoiceLineItemPrototype = (InvoiceLineItemPrototype)e.SPClass;
            SandPatchCL.DataServices.DataServiceInvoiceLineItemPrototypes.SqlSave(ref _invoiceLineItemPrototype);
        }

        private void ucInvoiceLineItemPrototypesManager_InvoiceLineItemPrototypeDeleteEvent(object sender, SPEventArgs e)
        {
            _invoiceLineItemPrototype = (InvoiceLineItemPrototype)e.SPClass;
            SandPatchCL.DataServices.DataServiceInvoiceLineItemPrototypes.SqlDelete(ref _invoiceLineItemPrototype);
        }

    }

}
