﻿namespace SandPatchReportsUI
{
    partial class frmDispatchesDriverActivity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.DispatchDriverActivityReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SandPatchReportsRowsets = new SandPatchReportsUI.SandPatchReportsRowsets();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmbTruckNumberDriverName = new System.Windows.Forms.ComboBox();
            this.lblTruckNumberDriverName = new System.Windows.Forms.Label();
            this.cmdPrint = new System.Windows.Forms.Button();
            this.reportViewerDispatchesDriverActivity = new Microsoft.Reporting.WinForms.ReportViewer();
            this.lblFromDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.cmNoDate = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextNoDate = new System.Windows.Forms.ToolStripMenuItem();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.DispatchDriverActivityReportTableAdapter = new SandPatchReportsUI.SandPatchReportsRowsetsTableAdapters.DispatchDriverActivityReportTableAdapter();
            this.chkIncludeNullDates = new System.Windows.Forms.CheckBox();
            this.ttDateNotification = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.DispatchDriverActivityReportBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).BeginInit();
            this.cmNoDate.SuspendLayout();
            this.SuspendLayout();
            // 
            // DispatchDriverActivityReportBindingSource
            // 
            this.DispatchDriverActivityReportBindingSource.DataMember = "DispatchDriverActivityReport";
            this.DispatchDriverActivityReportBindingSource.DataSource = this.SandPatchReportsRowsets;
            // 
            // SandPatchReportsRowsets
            // 
            this.SandPatchReportsRowsets.DataSetName = "SandPatchReportsRowsets";
            this.SandPatchReportsRowsets.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(447, 30);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(403, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Dispatches Driver Activity";
            // 
            // cmbTruckNumberDriverName
            // 
            this.cmbTruckNumberDriverName.FormattingEnabled = true;
            this.cmbTruckNumberDriverName.Location = new System.Drawing.Point(613, 85);
            this.cmbTruckNumberDriverName.Name = "cmbTruckNumberDriverName";
            this.cmbTruckNumberDriverName.Size = new System.Drawing.Size(258, 24);
            this.cmbTruckNumberDriverName.TabIndex = 2;
            // 
            // lblTruckNumberDriverName
            // 
            this.lblTruckNumberDriverName.AutoSize = true;
            this.lblTruckNumberDriverName.Location = new System.Drawing.Point(425, 88);
            this.lblTruckNumberDriverName.Name = "lblTruckNumberDriverName";
            this.lblTruckNumberDriverName.Size = new System.Drawing.Size(182, 16);
            this.lblTruckNumberDriverName.TabIndex = 1;
            this.lblTruckNumberDriverName.Text = "Truck Number / Driver Name:";
            // 
            // cmdPrint
            // 
            this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPrint.Location = new System.Drawing.Point(597, 744);
            this.cmdPrint.Name = "cmdPrint";
            this.cmdPrint.Size = new System.Drawing.Size(103, 38);
            this.cmdPrint.TabIndex = 8;
            this.cmdPrint.Text = "Print";
            this.cmdPrint.UseVisualStyleBackColor = true;
            this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
            // 
            // reportViewerDispatchesDriverActivity
            // 
            this.reportViewerDispatchesDriverActivity.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            reportDataSource1.Name = "DispatchDriverActivityDataSet";
            reportDataSource1.Value = this.DispatchDriverActivityReportBindingSource;
            this.reportViewerDispatchesDriverActivity.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerDispatchesDriverActivity.LocalReport.ReportEmbeddedResource = "SandPatchReportsUI.Reports.rptDispatchDriverActivity.rdlc";
            this.reportViewerDispatchesDriverActivity.Location = new System.Drawing.Point(12, 189);
            this.reportViewerDispatchesDriverActivity.Name = "reportViewerDispatchesDriverActivity";
            this.reportViewerDispatchesDriverActivity.Size = new System.Drawing.Size(1273, 539);
            this.reportViewerDispatchesDriverActivity.TabIndex = 7;
            // 
            // lblFromDate
            // 
            this.lblFromDate.AutoSize = true;
            this.lblFromDate.Location = new System.Drawing.Point(357, 127);
            this.lblFromDate.Name = "lblFromDate";
            this.lblFromDate.Size = new System.Drawing.Size(42, 16);
            this.lblFromDate.TabIndex = 3;
            this.lblFromDate.Text = "From:";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.ContextMenuStrip = this.cmNoDate;
            this.dtpFromDate.Location = new System.Drawing.Point(405, 122);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(238, 22);
            this.dtpFromDate.TabIndex = 4;
            this.dtpFromDate.Enter += new System.EventHandler(this.dtp_Enter);
            // 
            // cmNoDate
            // 
            this.cmNoDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmNoDate.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contextNoDate});
            this.cmNoDate.Name = "cmNoDate";
            this.cmNoDate.Size = new System.Drawing.Size(138, 26);
            // 
            // contextNoDate
            // 
            this.contextNoDate.Name = "contextNoDate";
            this.contextNoDate.Size = new System.Drawing.Size(137, 22);
            this.contextNoDate.Text = "Clear Date";
            this.contextNoDate.Click += new System.EventHandler(this.contextNoDate_Click);
            // 
            // dtpToDate
            // 
            this.dtpToDate.ContextMenuStrip = this.cmNoDate;
            this.dtpToDate.Location = new System.Drawing.Point(701, 122);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(238, 22);
            this.dtpToDate.TabIndex = 6;
            this.dtpToDate.Enter += new System.EventHandler(this.dtp_Enter);
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Location = new System.Drawing.Point(664, 127);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(28, 16);
            this.lblToDate.TabIndex = 5;
            this.lblToDate.Text = "To:";
            // 
            // DispatchDriverActivityReportTableAdapter
            // 
            this.DispatchDriverActivityReportTableAdapter.ClearBeforeFill = true;
            // 
            // chkIncludeNullDates
            // 
            this.chkIncludeNullDates.AutoSize = true;
            this.chkIncludeNullDates.Checked = true;
            this.chkIncludeNullDates.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncludeNullDates.Location = new System.Drawing.Point(550, 155);
            this.chkIncludeNullDates.Name = "chkIncludeNullDates";
            this.chkIncludeNullDates.Size = new System.Drawing.Size(197, 20);
            this.chkIncludeNullDates.TabIndex = 16;
            this.chkIncludeNullDates.Text = "Include records with null date";
            this.chkIncludeNullDates.UseVisualStyleBackColor = true;
            // 
            // ttDateNotification
            // 
            this.ttDateNotification.ToolTipTitle = "Either or Both Dates Can Be Cleared";
            // 
            // frmDispatchesDriverActivity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1297, 819);
            this.Controls.Add(this.chkIncludeNullDates);
            this.Controls.Add(this.dtpToDate);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.dtpFromDate);
            this.Controls.Add(this.lblFromDate);
            this.Controls.Add(this.reportViewerDispatchesDriverActivity);
            this.Controls.Add(this.cmdPrint);
            this.Controls.Add(this.lblTruckNumberDriverName);
            this.Controls.Add(this.cmbTruckNumberDriverName);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmDispatchesDriverActivity";
            this.Text = "Dispatches Driver Activity";
            this.Load += new System.EventHandler(this.frmDispatchesDriverActivity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DispatchDriverActivityReportBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SandPatchReportsRowsets)).EndInit();
            this.cmNoDate.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cmbTruckNumberDriverName;
        private System.Windows.Forms.Label lblTruckNumberDriverName;
        private System.Windows.Forms.Button cmdPrint;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerDispatchesDriverActivity;
        private SandPatchReportsRowsets SandPatchReportsRowsets;
        private System.Windows.Forms.Label lblFromDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.BindingSource DispatchDriverActivityReportBindingSource;
        private SandPatchReportsRowsetsTableAdapters.DispatchDriverActivityReportTableAdapter DispatchDriverActivityReportTableAdapter;
        private System.Windows.Forms.ContextMenuStrip cmNoDate;
        private System.Windows.Forms.ToolStripMenuItem contextNoDate;
        private System.Windows.Forms.CheckBox chkIncludeNullDates;
        private System.Windows.Forms.ToolTip ttDateNotification;
    }
}