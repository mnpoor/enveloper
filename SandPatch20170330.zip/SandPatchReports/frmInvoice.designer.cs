namespace SandPatchReportsUI
{
    partial class frmInvoice
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdExit = new System.Windows.Forms.Button();
            this.cmdRefresh = new System.Windows.Forms.Button();
            this.splitterInvoice = new System.Windows.Forms.SplitContainer();
            this.ucInvoicesSearch = new SandPatchReportsUI.WinControls.ucInvoicesSearchDataGridView();
            this.ucInvoiceEdit = new SandPatchReportsUI.WinControls.ucInvoice();
            this.lblInvoiceTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitterInvoice)).BeginInit();
            this.splitterInvoice.Panel1.SuspendLayout();
            this.splitterInvoice.Panel2.SuspendLayout();
            this.splitterInvoice.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdExit
            // 
            this.cmdExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExit.Location = new System.Drawing.Point(1158, 776);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(86, 41);
            this.cmdExit.TabIndex = 0;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = true;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // cmdRefresh
            // 
            this.cmdRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdRefresh.Location = new System.Drawing.Point(38, 776);
            this.cmdRefresh.Name = "cmdRefresh";
            this.cmdRefresh.Size = new System.Drawing.Size(86, 41);
            this.cmdRefresh.TabIndex = 1;
            this.cmdRefresh.Text = "Refresh";
            this.cmdRefresh.UseVisualStyleBackColor = true;
            // 
            // splitterInvoice
            // 
            this.splitterInvoice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitterInvoice.Location = new System.Drawing.Point(7, 63);
            this.splitterInvoice.Name = "splitterInvoice";
            // 
            // splitterInvoice.Panel1
            // 
            this.splitterInvoice.Panel1.Controls.Add(this.ucInvoicesSearch);
            // 
            // splitterInvoice.Panel2
            // 
            this.splitterInvoice.Panel2.Controls.Add(this.ucInvoiceEdit);
            this.splitterInvoice.Size = new System.Drawing.Size(1242, 695);
            this.splitterInvoice.SplitterDistance = 574;
            this.splitterInvoice.TabIndex = 22;
            // 
            // ucInvoicesSearch
            // 
            this.ucInvoicesSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucInvoicesSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucInvoicesSearch.Location = new System.Drawing.Point(0, 0);
            this.ucInvoicesSearch.Name = "ucInvoicesSearch";
            this.ucInvoicesSearch.Size = new System.Drawing.Size(574, 695);
            this.ucInvoicesSearch.TabIndex = 0;
            this.ucInvoicesSearch.InvoiceDataGridViewClearEvent += new SandPatchCL.SPEventHandler(this.ucInvoicesSearch_InvoiceDataGridViewClearEvent);
            this.ucInvoicesSearch.InvoiceDataGridViewSearchEvent += new SandPatchCL.SPEventHandler(this.ucInvoicesSearch_InvoiceDataGridViewSearchEvent);
            this.ucInvoicesSearch.InvoiceDataGridViewRowSelectedEvent += new SandPatchCL.SPEventHandler(this.ucInvoicesSearch_InvoiceDataGridViewRowSelectedEvent);
            // 
            // ucInvoiceEdit
            // 
            this.ucInvoiceEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucInvoiceEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucInvoiceEdit.Location = new System.Drawing.Point(0, 0);
            this.ucInvoiceEdit.Margin = new System.Windows.Forms.Padding(4);
            this.ucInvoiceEdit.Name = "ucInvoiceEdit";
            this.ucInvoiceEdit.Size = new System.Drawing.Size(664, 695);
            this.ucInvoiceEdit.TabIndex = 0;
            this.ucInvoiceEdit.InvoiceClearEvent += new SandPatchCL.SPEventHandler(this.ucInvoiceEdit_InvoiceClearEvent);
            this.ucInvoiceEdit.InvoiceAddEvent += new SandPatchCL.SPEventHandler(this.ucInvoiceEdit_InvoiceAddEvent);
            this.ucInvoiceEdit.InvoiceUpdateEvent += new SandPatchCL.SPEventHandler(this.ucInvoiceEdit_InvoiceUpdateEvent);
            this.ucInvoiceEdit.InvoicePreviewPrintEvent += new SandPatchCL.SPEventHandler(this.ucInvoiceEdit_InvoicePrintEvent);
            this.ucInvoiceEdit.InvoiceDeleteEvent += new SandPatchCL.SPEventHandler(this.ucInvoiceEdit_InvoiceDeleteEvent);
            // 
            // lblInvoiceTitle
            // 
            this.lblInvoiceTitle.AutoSize = true;
            this.lblInvoiceTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoiceTitle.Location = new System.Drawing.Point(422, 12);
            this.lblInvoiceTitle.Name = "lblInvoiceTitle";
            this.lblInvoiceTitle.Size = new System.Drawing.Size(115, 33);
            this.lblInvoiceTitle.TabIndex = 29;
            this.lblInvoiceTitle.Text = "Invoice";
            // 
            // frmInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 848);
            this.Controls.Add(this.lblInvoiceTitle);
            this.Controls.Add(this.splitterInvoice);
            this.Controls.Add(this.cmdRefresh);
            this.Controls.Add(this.cmdExit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmInvoice";
            this.Text = "Invoice";
            this.Load += new System.EventHandler(this.frmInvoice_Load);
            this.splitterInvoice.Panel1.ResumeLayout(false);
            this.splitterInvoice.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitterInvoice)).EndInit();
            this.splitterInvoice.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.Button cmdRefresh;
        private System.Windows.Forms.SplitContainer splitterInvoice;
        private SandPatchReportsUI.WinControls.ucInvoicesSearchDataGridView ucInvoicesSearch;
        private SandPatchReportsUI.WinControls.ucInvoice ucInvoiceEdit;
        private System.Windows.Forms.Label lblInvoiceTitle;

    }

}
