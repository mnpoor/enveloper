using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormShipper : System.Web.UI.Page
    {
        private Shipper _shipper;
        private Collection<Shipper> _shippers;

        protected void Page_Load(object sender, EventArgs e)
        {
                _shipper = new Shipper();
                wcShipperSearch.ShipperDataGridClearEvent += new SPEventHandler(wcShipperSearch_ShipperDataGridClearEvent);
                wcShipperSearch.ShipperDataGridSearchEvent += new SPEventHandler(wcShipperSearch_ShipperDataGridSearchEvent);
                wcShipperSearch.ShipperDataGridRowSelectedEvent += new SPEventHandler(wcShipperSearch_ShipperDataGridRowSelectedEvent);
                wcShipperEdit.ShipperClearEvent += new SPEventHandler(wcShipperEdit_ShipperClearEvent);
                wcShipperEdit.ShipperAddEvent += new SPEventHandler(wcShipperEdit_ShipperAddEvent);
                wcShipperEdit.ShipperUpdateEvent += new SPEventHandler(wcShipperEdit_ShipperUpdateEvent);
                wcShipperEdit.ShipperDeleteEvent += new SPEventHandler(wcShipperEdit_ShipperDeleteEvent);
                if (!Page.IsPostBack)
                {
                    wcShipperSearch.ShipperDataGridClear();
            }
        }

        public void wcShipperSearch_ShipperDataGridClearEvent(object sender, SPEventArgs e)
        {
            _shippers = new Collection<Shipper>();
            wcShipperSearch.ShipperDataGridClear();
        }

        public void wcShipperSearch_ShipperDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcShipperSearch.ShipperDataGridSearch();
        }

        public void wcShipperSearch_ShipperDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _shipper = SandPatchCL.DataServices.DataServiceShippers.ShipperSqlGetById(e.Index);
            wcShipperEdit.ShipperShow(_shipper);
        }

        public void wcShipperEdit_ShipperClearEvent(object sender, SPEventArgs e)
        {
            _shipper = new Shipper();
            wcShipperEdit.ShipperClear();
        }

        public void wcShipperEdit_ShipperAddEvent(object sender, SPEventArgs e)
        {
            wcShipperEdit.ShipperUpdate(ref _shipper);
            DataServiceShippers.SqlSave(ref _shipper);
            wcShipperEdit.ShipperShow(_shipper);
        }

        public void wcShipperEdit_ShipperUpdateEvent(object sender, SPEventArgs e)
        {
            wcShipperEdit.ShipperUpdate(ref _shipper);
            DataServiceShippers.SqlSave(ref _shipper);
            wcShipperEdit.ShipperShow(_shipper);
        }

        public void wcShipperEdit_ShipperDeleteEvent(object sender, SPEventArgs e)
        {
            wcShipperEdit.ShipperUpdate(ref _shipper);
            DataServiceShippers.SqlDelete(ref _shipper);
            _shipper = new Shipper();
            wcShipperEdit.ShipperClear();
            wcShipperSearch.ShipperDataGridSearch();
        }

    }
}
