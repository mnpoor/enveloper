using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormCustomerStatus : System.Web.UI.Page
    {
        private CustomerStatus _customerStatus;
        private Collection<CustomerStatus> _customerStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _customerStatus = new CustomerStatus();
            wcCustomerStatusesSearch.CustomerStatusDataGridClearEvent += new SPEventHandler(wcCustomerStatusesSearch_CustomerStatusDataGridClearEvent);
            wcCustomerStatusesSearch.CustomerStatusDataGridSearchEvent += new SPEventHandler(wcCustomerStatusesSearch_CustomerStatusDataGridSearchEvent);
            wcCustomerStatusesSearch.CustomerStatusDataGridRowSelectedEvent += new SPEventHandler(wcCustomerStatusesSearch_CustomerStatusDataGridRowSelectedEvent);
            wcCustomerStatusEdit.CustomerStatusClearEvent += new SPEventHandler(wcCustomerStatusEdit_CustomerStatusClearEvent);
            wcCustomerStatusEdit.CustomerStatusAddEvent += new SPEventHandler(wcCustomerStatusEdit_CustomerStatusAddEvent);
            wcCustomerStatusEdit.CustomerStatusUpdateEvent += new SPEventHandler(wcCustomerStatusEdit_CustomerStatusUpdateEvent);
            wcCustomerStatusEdit.CustomerStatusDeleteEvent += new SPEventHandler(wcCustomerStatusEdit_CustomerStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcCustomerStatusesSearch.CustomerStatusDataGridClear();
            }
        }

        public void wcCustomerStatusesSearch_CustomerStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _customerStatuss = new Collection<CustomerStatus>();
            wcCustomerStatusesSearch.CustomerStatusDataGridClear();
        }

        public void wcCustomerStatusesSearch_CustomerStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcCustomerStatusesSearch.CustomerStatusDataGridSearch();
        }

        public void wcCustomerStatusesSearch_CustomerStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _customerStatus = SandPatchCL.DataServices.DataServiceCustomerStatuses.CustomerStatusSqlGetById(e.Index);
            wcCustomerStatusEdit.CustomerStatusShow(_customerStatus);
        }

        public void wcCustomerStatusEdit_CustomerStatusClearEvent(object sender, SPEventArgs e)
        {
            _customerStatus = new CustomerStatus();
            wcCustomerStatusEdit.CustomerStatusClear();
        }

        public void wcCustomerStatusEdit_CustomerStatusAddEvent(object sender, SPEventArgs e)
        {
            wcCustomerStatusEdit.CustomerStatusUpdate(ref _customerStatus);
            DataServiceCustomerStatuses.SqlSave(ref _customerStatus);
            wcCustomerStatusEdit.CustomerStatusShow(_customerStatus);
        }

        public void wcCustomerStatusEdit_CustomerStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcCustomerStatusEdit.CustomerStatusUpdate(ref _customerStatus);
            DataServiceCustomerStatuses.SqlSave(ref _customerStatus);
            wcCustomerStatusEdit.CustomerStatusShow(_customerStatus);
        }

        public void wcCustomerStatusEdit_CustomerStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcCustomerStatusEdit.CustomerStatusUpdate(ref _customerStatus);
            DataServiceCustomerStatuses.SqlDelete(ref _customerStatus);
            _customerStatus = new CustomerStatus();
            wcCustomerStatusEdit.CustomerStatusClear();
            wcCustomerStatusesSearch.CustomerStatusDataGridSearch();
        }

    }
}
