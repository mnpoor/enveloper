using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormAvailabilityStatuses : System.Web.UI.Page
    {
        private AvailabilityStatus _availabilityStatus;
        private Collection<AvailabilityStatus> _availabilityStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _availabilityStatus = new AvailabilityStatus();
            wcAvailabilityStatusesSearch.AvailabilityStatusDataGridClearEvent += new SPEventHandler(wcAvailabilityStatusesSearch_AvailabilityStatusDataGridClearEvent);
            wcAvailabilityStatusesSearch.AvailabilityStatusDataGridSearchEvent += new SPEventHandler(wcAvailabilityStatusesSearch_AvailabilityStatusDataGridSearchEvent);
            wcAvailabilityStatusesSearch.AvailabilityStatusDataGridRowSelectedEvent += new SPEventHandler(wcAvailabilityStatusesSearch_AvailabilityStatusDataGridRowSelectedEvent);
            wcAvailabilityStatusesManager.AvailabilityStatusClearEvent += new SPEventHandler(wcAvailabilityStatusesManager_AvailabilityStatusClearEvent);
            wcAvailabilityStatusesManager.AvailabilityStatusAddEvent += new SPEventHandler(wcAvailabilityStatusesManager_AvailabilityStatusAddEvent);
            wcAvailabilityStatusesManager.AvailabilityStatusUpdateEvent += new SPEventHandler(wcAvailabilityStatusesManager_AvailabilityStatusUpdateEvent);
            wcAvailabilityStatusesManager.AvailabilityStatusDeleteEvent += new SPEventHandler(wcAvailabilityStatusesManager_AvailabilityStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcAvailabilityStatusesSearch.AvailabilityStatusDataGridClear();
            }
        }

        public void wcAvailabilityStatusesSearch_AvailabilityStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _availabilityStatuss = new Collection<AvailabilityStatus>();
            wcAvailabilityStatusesManager.AvailabilityStatusClear();
            wcAvailabilityStatusesSearch.AvailabilityStatusDataGridClear();
        }

        public void wcAvailabilityStatusesSearch_AvailabilityStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcAvailabilityStatusesSearch.AvailabilityStatusDataGridSearch();
        }

        public void wcAvailabilityStatusesSearch_AvailabilityStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _availabilityStatus = SandPatchCL.DataServices.DataServiceAvailabilityStatuses.AvailabilityStatusSqlGetById(e.Index);
            wcAvailabilityStatusesManager.AvailabilityStatusShow(_availabilityStatus);
        }

        public void wcAvailabilityStatusesManager_AvailabilityStatusClearEvent(object sender, SPEventArgs e)
        {
            _availabilityStatus = new AvailabilityStatus();
            wcAvailabilityStatusesManager.AvailabilityStatusClear();
        }

        public void wcAvailabilityStatusesManager_AvailabilityStatusAddEvent(object sender, SPEventArgs e)
        {
            wcAvailabilityStatusesManager.AvailabilityStatusUpdate(ref _availabilityStatus);
            DataServiceAvailabilityStatuses.SqlSave(ref _availabilityStatus);
            wcAvailabilityStatusesManager.AvailabilityStatusShow(_availabilityStatus);
        }

        public void wcAvailabilityStatusesManager_AvailabilityStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcAvailabilityStatusesManager.AvailabilityStatusUpdate(ref _availabilityStatus);
            DataServiceAvailabilityStatuses.SqlSave(ref _availabilityStatus);
            wcAvailabilityStatusesManager.AvailabilityStatusShow(_availabilityStatus);
        }

        public void wcAvailabilityStatusesManager_AvailabilityStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcAvailabilityStatusesManager.AvailabilityStatusUpdate(ref _availabilityStatus);
            DataServiceAvailabilityStatuses.SqlDelete(ref _availabilityStatus);
            _availabilityStatus = new AvailabilityStatus();
            wcAvailabilityStatusesManager.AvailabilityStatusClear();
            wcAvailabilityStatusesSearch.AvailabilityStatusDataGridSearch();
        }

    }
}
