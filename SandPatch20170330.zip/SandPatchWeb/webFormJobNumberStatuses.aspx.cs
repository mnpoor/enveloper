using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormJobNumberStatuses : System.Web.UI.Page
    {
        private JobNumberStatus _jobNumberStatus;
        private Collection<JobNumberStatus> _jobNumberStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _jobNumberStatus = new JobNumberStatus();
            wcJobNumberStatusesSearch.JobNumberStatusDataGridClearEvent += new SPEventHandler(wcJobNumberStatusesSearch_JobNumberStatusDataGridClearEvent);
            wcJobNumberStatusesSearch.JobNumberStatusDataGridSearchEvent += new SPEventHandler(wcJobNumberStatusesSearch_JobNumberStatusDataGridSearchEvent);
            wcJobNumberStatusesSearch.JobNumberStatusDataGridRowSelectedEvent += new SPEventHandler(wcJobNumberStatusesSearch_JobNumberStatusDataGridRowSelectedEvent);
            wcJobNumberStatusesManager.JobNumberStatusClearEvent += new SPEventHandler(wcJobNumberStatusesManager_JobNumberStatusClearEvent);
            wcJobNumberStatusesManager.JobNumberStatusAddEvent += new SPEventHandler(wcJobNumberStatusesManager_JobNumberStatusAddEvent);
            wcJobNumberStatusesManager.JobNumberStatusUpdateEvent += new SPEventHandler(wcJobNumberStatusesManager_JobNumberStatusUpdateEvent);
            wcJobNumberStatusesManager.JobNumberStatusDeleteEvent += new SPEventHandler(wcJobNumberStatusesManager_JobNumberStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcJobNumberStatusesSearch.JobNumberStatusDataGridClear();
            }
        }

        public void wcJobNumberStatusesSearch_JobNumberStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _jobNumberStatuses = new Collection<JobNumberStatus>();
            wcJobNumberStatusesSearch.JobNumberStatusDataGridClear();
        }

        public void wcJobNumberStatusesSearch_JobNumberStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcJobNumberStatusesSearch.JobNumberStatusDataGridSearch();
        }

        public void wcJobNumberStatusesSearch_JobNumberStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _jobNumberStatus = SandPatchCL.DataServices.DataServiceJobNumberStatuses.JobNumberStatusSqlGetById(e.Index);
            wcJobNumberStatusesManager.JobNumberStatusShow(_jobNumberStatus);
        }

        public void wcJobNumberStatusesManager_JobNumberStatusClearEvent(object sender, SPEventArgs e)
        {
            _jobNumberStatus = new JobNumberStatus();
            wcJobNumberStatusesManager.JobNumberStatusClear();
        }

        public void wcJobNumberStatusesManager_JobNumberStatusAddEvent(object sender, SPEventArgs e)
        {
            wcJobNumberStatusesManager.JobNumberStatusUpdate(ref _jobNumberStatus);
            DataServiceJobNumberStatuses.SqlSave(ref _jobNumberStatus);
            wcJobNumberStatusesManager.JobNumberStatusShow(_jobNumberStatus);
        }

        public void wcJobNumberStatusesManager_JobNumberStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcJobNumberStatusesManager.JobNumberStatusUpdate(ref _jobNumberStatus);
            DataServiceJobNumberStatuses.SqlSave(ref _jobNumberStatus);
            wcJobNumberStatusesManager.JobNumberStatusShow(_jobNumberStatus);
        }

        public void wcJobNumberStatusesManager_JobNumberStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcJobNumberStatusesManager.JobNumberStatusUpdate(ref _jobNumberStatus);
            DataServiceJobNumberStatuses.SqlDelete(ref _jobNumberStatus);
            _jobNumberStatus = new JobNumberStatus();
            wcJobNumberStatusesManager.JobNumberStatusClear();
            wcJobNumberStatusesSearch.JobNumberStatusDataGridSearch();
        }

    }
}
