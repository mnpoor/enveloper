using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormJobSiteStatus : System.Web.UI.Page
    {
        private JobSiteStatus _jobSiteStatus;
        private Collection<JobSiteStatus> _jobSiteStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _jobSiteStatus = new JobSiteStatus();
            wcJobSiteStatusesSearch.JobSiteStatusDataGridClearEvent += new SPEventHandler(wcJobSiteStatusesSearch_JobSiteStatusDataGridClearEvent);
            wcJobSiteStatusesSearch.JobSiteStatusDataGridSearchEvent += new SPEventHandler(wcJobSiteStatusesSearch_JobSiteStatusDataGridSearchEvent);
            wcJobSiteStatusesSearch.JobSiteStatusDataGridRowSelectedEvent += new SPEventHandler(wcJobSiteStatusesSearch_JobSiteStatusDataGridRowSelectedEvent);
            wcJobSiteStatusEdit.JobSiteStatusClearEvent += new SPEventHandler(wcJobSiteStatusEdit_JobSiteStatusClearEvent);
            wcJobSiteStatusEdit.JobSiteStatusAddEvent += new SPEventHandler(wcJobSiteStatusEdit_JobSiteStatusAddEvent);
            wcJobSiteStatusEdit.JobSiteStatusUpdateEvent += new SPEventHandler(wcJobSiteStatusEdit_JobSiteStatusUpdateEvent);
            wcJobSiteStatusEdit.JobSiteStatusDeleteEvent += new SPEventHandler(wcJobSiteStatusEdit_JobSiteStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcJobSiteStatusesSearch.JobSiteStatusDataGridClear();
            }
        }

        public void wcJobSiteStatusesSearch_JobSiteStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _jobSiteStatuss = new Collection<JobSiteStatus>();
            wcJobSiteStatusesSearch.JobSiteStatusDataGridClear();
        }

        public void wcJobSiteStatusesSearch_JobSiteStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcJobSiteStatusesSearch.JobSiteStatusDataGridSearch();
        }

        public void wcJobSiteStatusesSearch_JobSiteStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _jobSiteStatus = SandPatchCL.DataServices.DataServiceJobSiteStatuses.JobSiteStatusSqlGetById(e.Index);
            wcJobSiteStatusEdit.JobSiteStatusShow(_jobSiteStatus);
        }

        public void wcJobSiteStatusEdit_JobSiteStatusClearEvent(object sender, SPEventArgs e)
        {
            _jobSiteStatus = new JobSiteStatus();
            wcJobSiteStatusEdit.JobSiteStatusClear();
        }

        public void wcJobSiteStatusEdit_JobSiteStatusAddEvent(object sender, SPEventArgs e)
        {
            wcJobSiteStatusEdit.JobSiteStatusUpdate(ref _jobSiteStatus);
            DataServiceJobSiteStatuses.SqlSave(ref _jobSiteStatus);
            wcJobSiteStatusEdit.JobSiteStatusShow(_jobSiteStatus);
        }

        public void wcJobSiteStatusEdit_JobSiteStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcJobSiteStatusEdit.JobSiteStatusUpdate(ref _jobSiteStatus);
            DataServiceJobSiteStatuses.SqlSave(ref _jobSiteStatus);
            wcJobSiteStatusEdit.JobSiteStatusShow(_jobSiteStatus);
        }

        public void wcJobSiteStatusEdit_JobSiteStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcJobSiteStatusEdit.JobSiteStatusUpdate(ref _jobSiteStatus);
            DataServiceJobSiteStatuses.SqlDelete(ref _jobSiteStatus);
            _jobSiteStatus = new JobSiteStatus();
            wcJobSiteStatusEdit.JobSiteStatusClear();
            wcJobSiteStatusesSearch.JobSiteStatusDataGridSearch();
        }

    }
}
