﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace SandPatchWeb.GridViewTemplates
{
    public class templateItemHiddenFieldBuilder : ControlBuilder 
    {
        public override bool AllowWhitespaceLiterals()
        {
            return false;
        }
    }

    //[ControlBuilderAttribute(typeof(NoWhiteSpaceControlBuilder))]
    //public class NoWhiteSpaceControl : Control
    //{ }

    //public class WhiteSpaceControl : Control
    //{ }

    [ControlBuilder(typeof(templateItemHiddenFieldBuilder))]
    public class ItemHiddenField : Control
    {

    }
}