using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormJobSite : System.Web.UI.Page
    {
        private JobSite _jobSite;
        private Collection<JobSite> _jobSites;

        private Collection<JobSiteStatus> _jobSiteStatuses;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _jobSite = new JobSite();
            wcJobSiteSearch.JobSiteDataGridClearEvent += new SPEventHandler(wcJobSiteSearch_JobSiteDataGridClearEvent);
            wcJobSiteSearch.JobSiteDataGridSearchEvent += new SPEventHandler(wcJobSiteSearch_JobSiteDataGridSearchEvent);
            wcJobSiteSearch.JobSiteDataGridPageIndexChangingEvent += new SPEventHandler(wcJobSiteSearch_JobSiteDataGridPageIndexChangingEvent);
            wcJobSiteSearch.JobSiteDataGridRowSelectedEvent += new SPEventHandler(wcJobSiteSearch_JobSiteDataGridRowSelectedEvent);
            wcJobSiteEdit.JobSiteClearEvent += new SPEventHandler(wcJobSiteEdit_JobSiteClearEvent);
            wcJobSiteEdit.JobSiteAddEvent += new SPEventHandler(wcJobSiteEdit_JobSiteAddEvent);
            wcJobSiteEdit.JobSiteUpdateEvent += new SPEventHandler(wcJobSiteEdit_JobSiteUpdateEvent);
            wcJobSiteEdit.JobSiteDeleteEvent += new SPEventHandler(wcJobSiteEdit_JobSiteDeleteEvent);
            if (wcJobSiteEdit.JobSiteStatusesCount < 1)
            {
                _jobSiteStatuses = DataServiceJobSiteStatuses.JobSiteStatusSqlGetAll();
                _jobSiteStatuses.Insert(0, new JobSiteStatus());
                _jobSiteStatuses[0].JobSiteStatusDescription = "* Unassigned *";
                wcJobSiteEdit.JobSiteStatusesFill(_jobSiteStatuses);
            }
            if (!Page.IsPostBack)
            {
                wcJobSiteSearch.JobSiteDataGridClear();
            }
        }

        public void wcJobSiteSearch_JobSiteDataGridClearEvent(object sender, SPEventArgs e)
        {
            _jobSites = new Collection<JobSite>();
            wcJobSiteSearch.JobSiteDataGridClear();
        }

        public void wcJobSiteSearch_JobSiteDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcJobSiteSearch.JobSiteDataGridWildcard();
            _jobSites = SandPatchCL.DataServices.DataServiceJobSites.JobSiteSqlGetBySearchTerms(_searchTerms);
            wcJobSiteSearch.JobSiteDataGridSearch(_jobSites, 0);
            //wcJobSiteSearch.JobSiteDataGridSearch();
        }

        public void wcJobSiteSearch_JobSiteDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcJobSiteSearch.JobSiteDataGridWildcard();
            _jobSites = SandPatchCL.DataServices.DataServiceJobSites.JobSiteSqlGetBySearchTerms(_searchTerms);
            wcJobSiteSearch.JobSiteDataGridSearch(_jobSites, e.Index);
        }

        public void wcJobSiteSearch_JobSiteDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _jobSite = SandPatchCL.DataServices.DataServiceJobSites.JobSiteSqlGetById(e.Index);
            wcJobSiteEdit.JobSiteShow(_jobSite);
        }

        public void wcJobSiteEdit_JobSiteClearEvent(object sender, SPEventArgs e)
        {
            _jobSite = new JobSite();
            wcJobSiteEdit.JobSiteClear();
        }

        public void wcJobSiteEdit_JobSiteAddEvent(object sender, SPEventArgs e)
        {
            wcJobSiteEdit.JobSiteUpdate(ref _jobSite);
            DataServiceJobSites.SqlSave(ref _jobSite);
            wcJobSiteEdit.JobSiteShow(_jobSite);
        }

        public void wcJobSiteEdit_JobSiteUpdateEvent(object sender, SPEventArgs e)
        {
            wcJobSiteEdit.JobSiteUpdate(ref _jobSite);
            DataServiceJobSites.SqlSave(ref _jobSite);
            wcJobSiteEdit.JobSiteShow(_jobSite);
        }

        public void wcJobSiteEdit_JobSiteDeleteEvent(object sender, SPEventArgs e)
        {
            wcJobSiteEdit.JobSiteUpdate(ref _jobSite);
            DataServiceJobSites.SqlDelete(ref _jobSite);
            _jobSite = new JobSite();
            wcJobSiteEdit.JobSiteClear();
            _searchTerms = wcJobSiteSearch.JobSiteDataGridWildcard();
            _jobSites = SandPatchCL.DataServices.DataServiceJobSites.JobSiteSqlGetBySearchTerms(_searchTerms);
            wcJobSiteSearch.JobSiteDataGridSearch(_jobSites, 0);
            //wcJobSiteSearch.JobSiteDataGridSearch();
        }

    }
}
