using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormBillOfLading : System.Web.UI.Page
    {
        private Collection<Customer> _customers;
        private Collection<JobNumber> _jobNumbers;
        private Collection<PurchaseOrder> _purchaseOrders;
        private Collection<Carrier> _carriers;
        private Collection<Driver> _drivers;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<Freight> _freights;
        private Collection<JobSite> _jobSites;
        private Collection<BillOfLadingStatus> _billOfLadingStatuses;

        private BillOfLading _billOfLading;
        private Collection<BillOfLading> _billOfLadings;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _billOfLading = new BillOfLading();
            wcBillOfLadingSearch.BillOfLadingDataGridClearEvent += new SPEventHandler(wcBillOfLadingSearch_BillOfLadingDataGridClearEvent);
            wcBillOfLadingSearch.BillOfLadingDataGridSearchEvent += new SPEventHandler(wcBillOfLadingSearch_BillOfLadingDataGridSearchEvent);
            wcBillOfLadingSearch.BillOfLadingDataGridPageIndexChangingEvent += new SPEventHandler(wcBillOfLadingSearch_BillOfLadingDataGridPageIndexChangingEvent);
            wcBillOfLadingSearch.BillOfLadingDataGridRowSelectedEvent += new SPEventHandler(wcBillOfLadingSearch_BillOfLadingDataGridRowSelectedEvent);
            wcBillOfLadingEdit.BillOfLadingClearEvent += new SPEventHandler(wcBillOfLadingEdit_BillOfLadingClearEvent);
            wcBillOfLadingEdit.BillOfLadingAddEvent += new SPEventHandler(wcBillOfLadingEdit_BillOfLadingAddEvent);
            wcBillOfLadingEdit.BillOfLadingUpdateEvent += new SPEventHandler(wcBillOfLadingEdit_BillOfLadingUpdateEvent);
            wcBillOfLadingEdit.BillOfLadingDeleteEvent += new SPEventHandler(wcBillOfLadingEdit_BillOfLadingDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcBillOfLadingSearch.BillOfLadingDataGridClear();
            }

            if (wcBillOfLadingEdit.CustomerCount < 1)
            {
                _customers = DataServiceCustomers.CustomerSqlGetAll();
                _customers.Insert(0, new Customer());
                _customers[0].CustomerName = "* Unassigned *";
                wcBillOfLadingEdit.CustomersFill(_customers);
            }

            if (wcBillOfLadingEdit.JobNumberCount < 1)
            {
                _jobNumbers = DataServiceJobNumbers.JobNumberSqlGetAll();
                _jobNumbers.Insert(0, new JobNumber());
                _jobNumbers[0].JobNumberAssignment = 0;
                wcBillOfLadingEdit.JobNumbersFill(_jobNumbers);
            }

            if (wcBillOfLadingEdit.PurchaseOrderCount < 1)
            {
                _purchaseOrders = DataServicePurchaseOrders.PurchaseOrderSqlGetAll();
                _purchaseOrders.Insert(0, new PurchaseOrder());
                _purchaseOrders[0].PurchaseOrderNumber = "* Unassigned *";
                wcBillOfLadingEdit.PurchaseOrdersFill(_purchaseOrders);
            }

            if (wcBillOfLadingEdit.CarrierCount < 1)
            {
                _carriers = DataServiceCarriers.CarrierSqlGetAll();
                _carriers.Insert(0, new Carrier());
                _carriers[0].CarrierCompanyName = "* Unassigned *";
                wcBillOfLadingEdit.CarriersFill(_carriers);
            }

            if (wcBillOfLadingEdit.DriverCount < 1)
            {
                _drivers = DataServiceDrivers.DriverSqlGetAll();
                _drivers.Insert(0, new Driver());
                _drivers[0].DriverName = "* Unassigned *";
                wcBillOfLadingEdit.DriversFill(_drivers);
            }

            if (wcBillOfLadingEdit.LoadingTerminalCount < 1)
            {
                _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                _loadingTerminals.Insert(0, new LoadingTerminal());
                _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
                wcBillOfLadingEdit.LoadingTerminalsFill(_loadingTerminals);
            }

            if (wcBillOfLadingEdit.FreightCount < 1)
            {
                _freights = DataServiceFreights.FreightSqlGetAll();
                _freights.Insert(0, new Freight());
                _freights[0].FreightName = "* Unassigned *";
                wcBillOfLadingEdit.FreightsFill(_freights);
            }

            if (wcBillOfLadingEdit.JobSiteCount < 1)
            {
                _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                _jobSites.Insert(0, new JobSite());
                _jobSites[0].JobSiteName = "* Unassigned *";
                wcBillOfLadingEdit.JobSitesFill(_jobSites);
            }

            if (wcBillOfLadingEdit.BillOfLadingStatusCount < 1)
            {
                _billOfLadingStatuses = DataServiceBillOfLadingStatuses.BillOfLadingStatusSqlGetAll();
                _billOfLadingStatuses.Insert(0, new BillOfLadingStatus());
                _billOfLadingStatuses[0].BillOfLadingStatusDescription = "* Unassigned *";
                wcBillOfLadingEdit.BillOfLadingStatusesFill(_billOfLadingStatuses);
            }
        }

        public void wcBillOfLadingSearch_BillOfLadingDataGridClearEvent(object sender, SPEventArgs e)
        {
            _billOfLadings = new Collection<BillOfLading>();
            wcBillOfLadingSearch.BillOfLadingDataGridClear();
        }

        public void wcBillOfLadingSearch_BillOfLadingDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcBillOfLadingSearch.BillOfLadingDataGridWildcard();
            _billOfLadings = SandPatchCL.DataServices.DataServiceBillsOfLading.BillOfLadingSqlGetBySearchTerms(_searchTerms);
            wcBillOfLadingSearch.BillOfLadingDataGridSearch(_billOfLadings, 0);
        }

        public void wcBillOfLadingSearch_BillOfLadingDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcBillOfLadingSearch.BillOfLadingDataGridWildcard();
            _billOfLadings = SandPatchCL.DataServices.DataServiceBillsOfLading.BillOfLadingSqlGetBySearchTerms(_searchTerms);
            wcBillOfLadingSearch.BillOfLadingDataGridSearch(_billOfLadings, e.Index);
        }

        public void wcBillOfLadingSearch_BillOfLadingDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _billOfLading = SandPatchCL.DataServices.DataServiceBillsOfLading.BillOfLadingSqlGetById(e.Index);
            wcBillOfLadingEdit.BillOfLadingShow(_billOfLading);
        }

        public void wcBillOfLadingEdit_BillOfLadingClearEvent(object sender, SPEventArgs e)
        {
            _billOfLading = new BillOfLading();
            wcBillOfLadingEdit.BillOfLadingClear();
        }

        public void wcBillOfLadingEdit_BillOfLadingAddEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingEdit.BillOfLadingUpdate(ref _billOfLading);
            DataServiceBillsOfLading.SqlSave(ref _billOfLading);
            wcBillOfLadingEdit.BillOfLadingShow(_billOfLading);
        }

        public void wcBillOfLadingEdit_BillOfLadingUpdateEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingEdit.BillOfLadingUpdate(ref _billOfLading);
            DataServiceBillsOfLading.SqlSave(ref _billOfLading);
            wcBillOfLadingEdit.BillOfLadingShow(_billOfLading);
        }

        public void wcBillOfLadingEdit_BillOfLadingDeleteEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingEdit.BillOfLadingUpdate(ref _billOfLading);
            DataServiceBillsOfLading.SqlDelete(ref _billOfLading);
            _billOfLading = new BillOfLading();
            wcBillOfLadingEdit.BillOfLadingClear();
            _searchTerms = wcBillOfLadingSearch.BillOfLadingDataGridWildcard();
            _billOfLadings = SandPatchCL.DataServices.DataServiceBillsOfLading.BillOfLadingSqlGetBySearchTerms(_searchTerms);
            wcBillOfLadingSearch.BillOfLadingDataGridSearch(_billOfLadings, 0);
        }

    }
}
