using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDriverStatus : System.Web.UI.Page
    {
        private DriverStatus _driverStatus;
        private Collection<DriverStatus> _driverStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _driverStatus = new DriverStatus();
            wcDriverStatusesSearch.DriverStatusDataGridClearEvent += new SPEventHandler(wcDriverStatusesSearch_DriverStatusDataGridClearEvent);
            wcDriverStatusesSearch.DriverStatusDataGridSearchEvent += new SPEventHandler(wcDriverStatusesSearch_DriverStatusDataGridSearchEvent);
            wcDriverStatusesSearch.DriverStatusDataGridRowSelectedEvent += new SPEventHandler(wcDriverStatusesSearch_DriverStatusDataGridRowSelectedEvent);
            wcDriverStatusEdit.DriverStatusClearEvent += new SPEventHandler(wcDriverStatusEdit_DriverStatusClearEvent);
            wcDriverStatusEdit.DriverStatusAddEvent += new SPEventHandler(wcDriverStatusEdit_DriverStatusAddEvent);
            wcDriverStatusEdit.DriverStatusUpdateEvent += new SPEventHandler(wcDriverStatusEdit_DriverStatusUpdateEvent);
            wcDriverStatusEdit.DriverStatusDeleteEvent += new SPEventHandler(wcDriverStatusEdit_DriverStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcDriverStatusesSearch.DriverStatusDataGridClear();
            }
        }

        public void wcDriverStatusesSearch_DriverStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _driverStatuss = new Collection<DriverStatus>();
            wcDriverStatusesSearch.DriverStatusDataGridClear();
        }

        public void wcDriverStatusesSearch_DriverStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcDriverStatusesSearch.DriverStatusDataGridSearch();
        }

        public void wcDriverStatusesSearch_DriverStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _driverStatus = SandPatchCL.DataServices.DataServiceDriverStatuses.DriverStatusSqlGetById(e.Index);
            wcDriverStatusEdit.DriverStatusShow(_driverStatus);
        }

        public void wcDriverStatusEdit_DriverStatusClearEvent(object sender, SPEventArgs e)
        {
            _driverStatus = new DriverStatus();
            wcDriverStatusEdit.DriverStatusClear();
        }

        public void wcDriverStatusEdit_DriverStatusAddEvent(object sender, SPEventArgs e)
        {
            wcDriverStatusEdit.DriverStatusUpdate(ref _driverStatus);
            DataServiceDriverStatuses.SqlSave(ref _driverStatus);
            wcDriverStatusEdit.DriverStatusShow(_driverStatus);
        }

        public void wcDriverStatusEdit_DriverStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcDriverStatusEdit.DriverStatusUpdate(ref _driverStatus);
            DataServiceDriverStatuses.SqlSave(ref _driverStatus);
            wcDriverStatusEdit.DriverStatusShow(_driverStatus);
        }

        public void wcDriverStatusEdit_DriverStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcDriverStatusEdit.DriverStatusUpdate(ref _driverStatus);
            DataServiceDriverStatuses.SqlDelete(ref _driverStatus);
            _driverStatus = new DriverStatus();
            wcDriverStatusEdit.DriverStatusClear();
            wcDriverStatusesSearch.DriverStatusDataGridSearch();
        }

    }
}
