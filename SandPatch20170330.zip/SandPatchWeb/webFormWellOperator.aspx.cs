using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormWellOperator : System.Web.UI.Page
    {
        private WellOperator _wellOperator;
        private Collection<WellOperator> _wellOperators;

        protected void Page_Load(object sender, EventArgs e)
        {
            _wellOperator = new WellOperator();
            wcWellOperatorSearch.WellOperatorDataGridClearEvent += new SPEventHandler(wcWellOperatorSearch_WellOperatorDataGridClearEvent);
            wcWellOperatorSearch.WellOperatorDataGridSearchEvent += new SPEventHandler(wcWellOperatorSearch_WellOperatorDataGridSearchEvent);
            wcWellOperatorSearch.WellOperatorDataGridRowSelectedEvent += new SPEventHandler(wcWellOperatorSearch_WellOperatorDataGridRowSelectedEvent);
            wcWellOperatorEdit.WellOperatorClearEvent += new SPEventHandler(wcWellOperatorEdit_WellOperatorClearEvent);
            wcWellOperatorEdit.WellOperatorAddEvent += new SPEventHandler(wcWellOperatorEdit_WellOperatorAddEvent);
            wcWellOperatorEdit.WellOperatorUpdateEvent += new SPEventHandler(wcWellOperatorEdit_WellOperatorUpdateEvent);
            wcWellOperatorEdit.WellOperatorDeleteEvent += new SPEventHandler(wcWellOperatorEdit_WellOperatorDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcWellOperatorSearch.WellOperatorDataGridClear();
            }
        }

        public void wcWellOperatorSearch_WellOperatorDataGridClearEvent(object sender, SPEventArgs e)
        {
            _wellOperators = new Collection<WellOperator>();
            wcWellOperatorSearch.WellOperatorDataGridClear();
        }

        public void wcWellOperatorSearch_WellOperatorDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorSearch.WellOperatorDataGridSearch();
        }

        public void wcWellOperatorSearch_WellOperatorDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _wellOperator = SandPatchCL.DataServices.DataServiceWellOperators.WellOperatorSqlGetById(e.Index);
            wcWellOperatorEdit.WellOperatorShow(_wellOperator);
        }

        public void wcWellOperatorEdit_WellOperatorClearEvent(object sender, SPEventArgs e)
        {
            _wellOperator = new WellOperator();
            wcWellOperatorEdit.WellOperatorClear();
        }

        public void wcWellOperatorEdit_WellOperatorAddEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorEdit.WellOperatorUpdate(ref _wellOperator);
            DataServiceWellOperators.SqlSave(ref _wellOperator);
            wcWellOperatorEdit.WellOperatorShow(_wellOperator);
        }

        public void wcWellOperatorEdit_WellOperatorUpdateEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorEdit.WellOperatorUpdate(ref _wellOperator);
            DataServiceWellOperators.SqlSave(ref _wellOperator);
            wcWellOperatorEdit.WellOperatorShow(_wellOperator);
        }

        public void wcWellOperatorEdit_WellOperatorDeleteEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorEdit.WellOperatorUpdate(ref _wellOperator);
            DataServiceWellOperators.SqlDelete(ref _wellOperator);
            _wellOperator = new WellOperator();
            wcWellOperatorEdit.WellOperatorClear();
            wcWellOperatorSearch.WellOperatorDataGridSearch();
        }

    }
}
