using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcBillOfLadingStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler BillOfLadingStatusDataGridClearEvent;
        public event SPEventHandler BillOfLadingStatusDataGridSearchEvent;
        public event SPEventHandler BillOfLadingStatusDataGridRowSelectedEvent;

        private Collection<BillOfLadingStatus> _billOfLadingStatuses = new Collection<BillOfLadingStatus>();

        private DataTable _billOfLadingStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void BillOfLadingStatusDataGridClear()
        {
            txtBillOfLadingStatusIdSearch.Text = string.Empty;
            txtBillOfLadingStatusDescriptionSearch.Text = string.Empty;
           //gvBillOfLadingStatuss.; // clears data grid - not implemented
        }

        public void BillOfLadingStatusDataGridSearch()
        {
            Collection<BillOfLadingStatus> itemCollection = new Collection<BillOfLadingStatus>();

            txtBillOfLadingStatusIdSearch.Text = ApplyWildcards(txtBillOfLadingStatusIdSearch.Text);
            txtBillOfLadingStatusDescriptionSearch.Text = ApplyWildcards(txtBillOfLadingStatusDescriptionSearch.Text);

            _billOfLadingStatuses = DataServiceBillOfLadingStatuses.BillOfLadingStatusSqlGetAll();

            _billOfLadingStatusDataTable = new DataTable("BillOfLadingStatus");
            _billOfLadingStatusDataTable.Columns.Add(new DataColumn("BillOfLadingStatusId", _billOfLadingStatuses[0].BillOfLadingStatusId.GetType()));
            _billOfLadingStatusDataTable.Columns[0].Caption = "BillOfLadingStatusId ";
            _billOfLadingStatusDataTable.Columns[0].ReadOnly = true;
            _billOfLadingStatusDataTable.Columns.Add(new DataColumn("BillOfLadingStatusDescription", _billOfLadingStatuses[0].BillOfLadingStatusDescription.GetType()));
            _billOfLadingStatusDataTable.Columns[1].Caption = "BillOfLadingStatusDescription ";
            _billOfLadingStatusDataTable.Columns[1].ReadOnly = true;
            foreach (BillOfLadingStatus item in _billOfLadingStatuses)
            {
                object[] gridItems = new object[2] { item.BillOfLadingStatusId, item.BillOfLadingStatusDescription };
                _billOfLadingStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvBillOfLadingStatuss.DataSource = _billOfLadingStatusDataTable;
            gvBillOfLadingStatuss.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.BillOfLadingStatusDataGridClearEvent != null)
            {
                this.BillOfLadingStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.BillOfLadingStatusDataGridSearchEvent != null)
            {
                this.BillOfLadingStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvBillOfLadingStatuss_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvBillOfLadingStatuss.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.BillOfLadingStatusDataGridRowSelectedEvent != null)
            {
                this.BillOfLadingStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
