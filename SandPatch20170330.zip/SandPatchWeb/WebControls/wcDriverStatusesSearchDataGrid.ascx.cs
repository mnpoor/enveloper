using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDriverStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DriverStatusDataGridClearEvent;
        public event SPEventHandler DriverStatusDataGridSearchEvent;
        public event SPEventHandler DriverStatusDataGridRowSelectedEvent;

        private Collection<DriverStatus> _driverStatuses = new Collection<DriverStatus>();

        private DataTable _driverStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void DriverStatusDataGridClear()
        {
        }

        public void DriverStatusDataGridSearch()
        {
            Collection<DriverStatus> itemCollection = new Collection<DriverStatus>();

            _driverStatuses = DataServiceDriverStatuses.DriverStatusSqlGetAll();

            _driverStatusDataTable = new DataTable("DriverStatus");
            _driverStatusDataTable.Columns.Add(new DataColumn("DriverStatusId", _driverStatuses[0].DriverStatusId.GetType()));
            _driverStatusDataTable.Columns[0].Caption = "DriverStatusId ";
            _driverStatusDataTable.Columns[0].ReadOnly = true;
            _driverStatusDataTable.Columns.Add(new DataColumn("DriverStatusDescription", _driverStatuses[0].DriverStatusDescription.GetType()));
            _driverStatusDataTable.Columns[1].Caption = "DriverStatusDescription ";
            _driverStatusDataTable.Columns[1].ReadOnly = true;
            foreach (DriverStatus item in _driverStatuses)
            {
                object[] gridItems = new object[2] { item.DriverStatusId, item.DriverStatusDescription };
                _driverStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvDriverStatuses.DataSource = _driverStatusDataTable;
            gvDriverStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DriverStatusDataGridClearEvent != null)
            {
                this.DriverStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.DriverStatusDataGridSearchEvent != null)
            {
                this.DriverStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvDriverStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvDriverStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.DriverStatusDataGridRowSelectedEvent != null)
            {
                this.DriverStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
