using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcLoadingTerminalSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler LoadingTerminalDataGridClearEvent;
        public event SPEventHandler LoadingTerminalDataGridSearchEvent;
        public event SPEventHandler LoadingTerminalDataGridPageIndexChangingEvent;
        public event SPEventHandler LoadingTerminalDataGridRowSelectedEvent;

        private Collection<LoadingTerminal> _loadingTerminals = new Collection<LoadingTerminal>();

        private DataTable _loadingTerminalDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void LoadingTerminalDataGridClear()
        {
            txtLoadingTerminalNameSearch.Text = string.Empty;
            txtContactNameSearch.Text = string.Empty;
            txtCitySearch.Text = string.Empty;
            _loadingTerminalDataTable = new DataTable("LoadingTerminal");
            gvLoadingTerminals.DataSource = _loadingTerminalDataTable;
            gvLoadingTerminals.DataBind();
        }

        public string[] LoadingTerminalDataGridWildcard()
        {
            txtLoadingTerminalNameSearch.Text = ApplyWildcards(txtLoadingTerminalNameSearch.Text);
            txtContactNameSearch.Text = ApplyWildcards(txtContactNameSearch.Text);
            txtCitySearch.Text = ApplyWildcards(txtCitySearch.Text);
            return new string[] { txtLoadingTerminalNameSearch.Text.Trim(), txtContactNameSearch.Text.Trim(), txtCitySearch.Text.Trim() };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void LoadingTerminalDataGridSearch(Collection<LoadingTerminal> itemCollection, int pageIndex)
        {
            _loadingTerminals = new Collection<LoadingTerminal>(itemCollection);
            GridViewFill(pageIndex);
        }

        public void GridViewFill(int pageIndex)
        {
            //_loadingTerminalDataTable = new DataTable("LoadingTerminal");
            //_loadingTerminalDataTable.Columns.Add(new DataColumn("LoadingTerminalId", _loadingTerminals[0].LoadingTerminalId.GetType()));
            //_loadingTerminalDataTable.Columns[0].Caption = "LoadingTerminalId ";
            //_loadingTerminalDataTable.Columns[0].ReadOnly = true;
            //_loadingTerminalDataTable.Columns.Add(new DataColumn("LoadingTerminalName", _loadingTerminals[0].LoadingTerminalName.GetType()));
            //_loadingTerminalDataTable.Columns[1].Caption = "LoadingTerminalName ";
            //_loadingTerminalDataTable.Columns[1].ReadOnly = true;
            //_loadingTerminalDataTable.Columns.Add(new DataColumn("ContactName", _loadingTerminals[0].ContactName.GetType()));
            //_loadingTerminalDataTable.Columns[2].Caption = "ContactName ";
            //_loadingTerminalDataTable.Columns[2].ReadOnly = true;
            //_loadingTerminalDataTable.Columns.Add(new DataColumn("StreetAddress", _loadingTerminals[0].StreetAddress.GetType()));
            //_loadingTerminalDataTable.Columns[3].Caption = "StreetAddress ";
            //_loadingTerminalDataTable.Columns[3].ReadOnly = true;
            //_loadingTerminalDataTable.Columns.Add(new DataColumn("BoxAddress", _loadingTerminals[0].BoxAddress.GetType()));
            //_loadingTerminalDataTable.Columns[4].Caption = "BoxAddress ";
            //_loadingTerminalDataTable.Columns[4].ReadOnly = true;
            //foreach (LoadingTerminal item in _loadingTerminals)
            //{
            //    object[] gridItems = new object[5] { item.LoadingTerminalId, item.LoadingTerminalName, item.ContactName, item.StreetAddress, item.BoxAddress };
            //    _loadingTerminalDataTable.LoadDataRow(gridItems, true);
            //}
            //Console.WriteLine(itemCollection.Count.ToString());

            _loadingTerminalDataTable = new DataTable("LoadingTerminal");
            _loadingTerminalDataTable.Columns.Add(new DataColumn("LoadingTerminalId", typeof(string)));
            _loadingTerminalDataTable.Columns[0].Caption = " Id ";
            _loadingTerminalDataTable.Columns[0].ReadOnly = true;
            _loadingTerminalDataTable.Columns.Add(new DataColumn("LoadingTerminalName", typeof(string)));
            _loadingTerminalDataTable.Columns[1].Caption = " Loading Terminal Name ";
            _loadingTerminalDataTable.Columns[1].ReadOnly = true;
            _loadingTerminalDataTable.Columns.Add(new DataColumn("ContactName", typeof(string)));
            _loadingTerminalDataTable.Columns[2].Caption = " Contact Name ";
            _loadingTerminalDataTable.Columns[2].ReadOnly = true;
            _loadingTerminalDataTable.Columns.Add(new DataColumn("StreetAddress", typeof(string)));
            _loadingTerminalDataTable.Columns[3].Caption = " Street Address ";
            _loadingTerminalDataTable.Columns[3].ReadOnly = true;
            _loadingTerminalDataTable.Columns.Add(new DataColumn("City", typeof(string)));
            _loadingTerminalDataTable.Columns[4].Caption = " City ";
            _loadingTerminalDataTable.Columns[4].ReadOnly = true;
            foreach (LoadingTerminal item in _loadingTerminals)
            {
                object[] gridItems = new object[5] { item.LoadingTerminalId.ToString(), item.LoadingTerminalName, item.ContactName, item.StreetAddress, item.City };
                _loadingTerminalDataTable.LoadDataRow(gridItems, true);
            }

            gvLoadingTerminals.Columns.Clear();
            BoundField column0 = new BoundField();
            column0.HeaderText = "Id";
            column0.DataField = "LoadingTerminalId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            gvLoadingTerminals.Columns.Add(column0);

            BoundField column1 = new BoundField();
            column1.HeaderText = "Loading Terminal Name";
            column1.DataField = "LoadingTerminalName";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;
            gvLoadingTerminals.Columns.Add(column1);

            BoundField column2 = new BoundField();
            column2.HeaderText = "Contact Name";
            column2.DataField = "ContactName";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;
            gvLoadingTerminals.Columns.Add(column2);

            BoundField column3 = new BoundField();
            column3.HeaderText = "Street Address";
            column3.DataField = "StreetAddress";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;
            gvLoadingTerminals.Columns.Add(column3);

            BoundField column4 = new BoundField();
            column4.HeaderText = "City";
            column4.DataField = "City";
            column4.DataFormatString = "{0}";
            column4.ReadOnly = true;
            gvLoadingTerminals.Columns.Add(column4);

            gvLoadingTerminals.DataSource = _loadingTerminalDataTable;
            gvLoadingTerminals.PageIndex = pageIndex;
            gvLoadingTerminals.DataBind();
            gvLoadingTerminals.Width = new Unit((int)700);
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.LoadingTerminalDataGridClearEvent != null)
            {
                this.LoadingTerminalDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.LoadingTerminalDataGridSearchEvent != null)
            {
                this.LoadingTerminalDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvLoadingTerminals_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.LoadingTerminalDataGridPageIndexChangingEvent != null)
            {
                this.LoadingTerminalDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvLoadingTerminals_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvLoadingTerminals.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.LoadingTerminalDataGridRowSelectedEvent != null)
            {
                this.LoadingTerminalDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
