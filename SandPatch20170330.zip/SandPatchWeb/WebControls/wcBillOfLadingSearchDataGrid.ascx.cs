using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcBillOfLadingSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler BillOfLadingDataGridClearEvent;
        public event SPEventHandler BillOfLadingDataGridSearchEvent;
        public event SPEventHandler BillOfLadingDataGridPageIndexChangingEvent;
        public event SPEventHandler BillOfLadingDataGridRowSelectedEvent;

        private Customer _foundCustomer = null;
        private Driver _foundDriver = null;
        private JobNumber _foundJobNumber = null;
        private PurchaseOrder _foundPurchaseOrder = null;

        private Collection<BillOfLading> _billsOfLading = new Collection<BillOfLading>();

        private DataTable _billOfLadingDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void BillOfLadingDataGridClear()
        {
            txtTruckNumberSearch.Text = string.Empty;
            txtBillOfLadingNumberSearch.Text = string.Empty;
            txtCustomerNameSearch.Text = string.Empty;
            txtJobNumberSearch.Text = string.Empty;
            txtPurchaseOrderNumberSearch.Text = string.Empty;
            txtBillOfLadingFromDateSearch.Text = string.Empty;
            txtBillOfLadingToDateSearch.Text = string.Empty;
            _billOfLadingDataTable = new DataTable("BillOfLading");
            gvBillsOfLading.DataSource = _billOfLadingDataTable;
            gvBillsOfLading.DataBind();
        }

        public string[] BillOfLadingDataGridWildcard()
        {
            txtCustomerNameSearch.Text = ApplyWildcards(txtCustomerNameSearch.Text);
            txtPurchaseOrderNumberSearch.Text = ApplyWildcards(txtPurchaseOrderNumberSearch.Text);
            txtBillOfLadingNumberSearch.Text = ApplyWildcards(txtBillOfLadingNumberSearch.Text);
            return new string[] { txtTruckNumberSearch.Text.Trim(), txtBillOfLadingNumberSearch.Text.Trim(), txtCustomerNameSearch.Text.Trim(), txtJobNumberSearch.Text.Trim(), txtPurchaseOrderNumberSearch.Text.Trim(), txtBillOfLadingFromDateSearch.Text.Trim(), txtBillOfLadingToDateSearch.Text.Trim() };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void BillOfLadingDataGridSearch(Collection<BillOfLading> itemCollection, int pageIndex)
        {
            _billsOfLading = new Collection<BillOfLading>(itemCollection);
            GridViewFill(pageIndex);
        }

        //public void BillOfLadingDataGridSearch()
        //{
        //    Collection<BillOfLading> itemCollection = new Collection<BillOfLading>();

        //    txtBillOfLadingNumberSearch.Text = ApplyWildcards(txtBillOfLadingNumberSearch.Text);
        //    txtCustomerNameSearch.Text = ApplyWildcards(txtCustomerNameSearch.Text);
        //    txtPurchaseOrderNumberSearch.Text = ApplyWildcards(txtPurchaseOrderNumberSearch.Text);

        //    _billOfLadings = DataServiceBillsOfLading.BillOfLadingSqlGetBySearchTerms(txtTruckNumberSearch.Text.Trim(), txtBillOfLadingNumberSearch.Text.Trim(), txtCustomerNameSearch.Text.Trim(), txtJobNumberSearch.Text.Trim(), txtPurchaseOrderNumberSearch.Text.Trim(), txtBillOfLadingFromDateSearch.Text.Trim(), txtBillOfLadingToDateSearch.Text.Trim());

        //    GridViewFill(0);
        //}

        //protected void gvBillsOfLading_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    _billsOfLading = DataServiceBillsOfLading.BillOfLadingSqlGetBySearchTerms(txtTruckNumberSearch.Text.Trim(), txtBillOfLadingNumberSearch.Text.Trim(), txtCustomerNameSearch.Text.Trim(), txtJobNumberSearch.Text.Trim(), txtPurchaseOrderNumberSearch.Text.Trim(), txtBillOfLadingFromDateSearch.Text.Trim(), txtBillOfLadingToDateSearch.Text.Trim());

        //    GridViewFill(e.NewPageIndex);
        //}

        protected void GridViewFill(int pageIndex)
        {
            _billOfLadingDataTable = new DataTable("BillOfLading");
            _billOfLadingDataTable.Columns.Add(new DataColumn("BillOfLadingId", typeof(string)));
            _billOfLadingDataTable.Columns[0].Caption = " Id ";
            _billOfLadingDataTable.Columns[0].ReadOnly = true;
            _billOfLadingDataTable.Columns.Add(new DataColumn("BillOfLadingNumber", typeof(string)));
            _billOfLadingDataTable.Columns[1].Caption = " Bill Of Lading ";
            _billOfLadingDataTable.Columns[1].ReadOnly = true;
            _billOfLadingDataTable.Columns.Add(new DataColumn("TruckNumber", typeof(string)));
            _billOfLadingDataTable.Columns[2].Caption = " Truck Number ";
            _billOfLadingDataTable.Columns[2].ReadOnly = true;
            _billOfLadingDataTable.Columns.Add(new DataColumn("DriverName", typeof(string)));
            _billOfLadingDataTable.Columns[3].Caption = " Truck Driver Name ";
            _billOfLadingDataTable.Columns[3].ReadOnly = true;
            _billOfLadingDataTable.Columns.Add(new DataColumn("CustomerName", typeof(string)));
            _billOfLadingDataTable.Columns[4].Caption = " Customer Name ";
            _billOfLadingDataTable.Columns[4].ReadOnly = true;
            _billOfLadingDataTable.Columns.Add(new DataColumn("JobNumberAssignment", typeof(string)));
            _billOfLadingDataTable.Columns[5].Caption = " Job Number ";
            _billOfLadingDataTable.Columns[5].ReadOnly = true;
            _billOfLadingDataTable.Columns.Add(new DataColumn("PurchaseOrderNumber", typeof(string)));
            _billOfLadingDataTable.Columns[6].Caption = " Purchase Order ";
            _billOfLadingDataTable.Columns[6].ReadOnly = true;
            foreach (BillOfLading item in _billsOfLading)
            {
                _foundCustomer = DataServiceCustomers.CustomerSqlGetById(item.CustomerId);
                _foundDriver = DataServiceDrivers.DriverSqlGetById(item.DriverId);
                _foundJobNumber = DataServiceJobNumbers.JobNumberSqlGetById(item.JobNumberId);
                _foundPurchaseOrder = DataServicePurchaseOrders.PurchaseOrderSqlGetById(item.PurchaseOrderId);
                object[] gridItems = new object[7] { item.BillOfLadingId, item.BillOfLadingNumber,
                    (_foundDriver == null ? "* Unassigned *" : _foundDriver.TruckNumber.ToString()),
                    (_foundDriver == null ? string.Empty : _foundDriver.DriverName),
                    (_foundCustomer == null ? "* Missing *" : _foundCustomer.CustomerName),
                    (_foundJobNumber == null ? "* Missing *" : _foundJobNumber.JobNumberAssignment.ToString()),
                    (_foundPurchaseOrder == null ? "* Missing *" : _foundPurchaseOrder.PurchaseOrderNumber) };
                _billOfLadingDataTable.LoadDataRow(gridItems, true);
            }

            BoundField column0 = new BoundField();
            column0.HeaderText = "Id ";
            column0.DataField = "BillOfLadingId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;

            BoundField column1 = new BoundField();
            column1.HeaderText = "Bill Of Lading Number";
            column1.DataField = "BillOfLadingNumber";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;

            BoundField column2 = new BoundField();
            column2.HeaderText = "Truck Number";
            column2.DataField = "TruckNumber";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;

            BoundField column3 = new BoundField();
            column3.HeaderText = "Driver Name";
            column3.DataField = "DriverName";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;

            BoundField column4 = new BoundField();
            column4.HeaderText = "Customer Name";
            column4.DataField = "CustomerName";
            column4.DataFormatString = "{0}";
            column4.ReadOnly = true;

            BoundField column5 = new BoundField();
            column5.HeaderText = "Job Number";
            column5.DataField = "JobNumberAssignment";
            column5.DataFormatString = "{0}";
            column5.ReadOnly = true;

            BoundField column6 = new BoundField();
            column6.HeaderText = "Purchase Order Number";
            column6.DataField = "PurchaseOrderNumber";
            column6.DataFormatString = "{0}";
            column6.ReadOnly = true;

            gvBillsOfLading.Columns.Clear();
            gvBillsOfLading.Columns.Add(column0);
            gvBillsOfLading.Columns.Add(column1);
            gvBillsOfLading.Columns.Add(column2);
            gvBillsOfLading.Columns.Add(column3);
            gvBillsOfLading.Columns.Add(column4);
            gvBillsOfLading.Columns.Add(column5);
            gvBillsOfLading.Columns.Add(column6);

            gvBillsOfLading.DataSource = _billOfLadingDataTable;
            gvBillsOfLading.PageIndex = pageIndex;
            gvBillsOfLading.DataBind();
            gvBillsOfLading.Width = new Unit((int)750);

            _billOfLadingDataTable = new DataTable("BillOfLading");     // empty out data table
            _billsOfLading = new Collection<BillOfLading>();           // empty out collection
            GC.Collect();                                       // consolidate heap space
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.BillOfLadingDataGridClearEvent != null)
            {
                this.BillOfLadingDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.BillOfLadingDataGridSearchEvent != null)
            {
                this.BillOfLadingDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvBillsOfLading_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.BillOfLadingDataGridPageIndexChangingEvent != null)
            {
                this.BillOfLadingDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvBillsOfLading_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvBillsOfLading.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.BillOfLadingDataGridRowSelectedEvent != null)
            {
                this.BillOfLadingDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
