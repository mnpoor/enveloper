using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDispatchStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DispatchStatusDataGridClearEvent;
        public event SPEventHandler DispatchStatusDataGridSearchEvent;
        public event SPEventHandler DispatchStatusDataGridRowSelectedEvent;

        private Collection<DispatchStatus> _dispatchStatuses = new Collection<DispatchStatus>();

        private DataTable _dispatchStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void DispatchStatusDataGridClear()
        {
            _dispatchStatusDataTable = new DataTable("DispatchStatus");
            gvDispatchStatuses.DataSource = _dispatchStatusDataTable;
            gvDispatchStatuses.DataBind();
        }

        public void DispatchStatusDataGridSearch()
        {
            Collection<DispatchStatus> itemCollection = new Collection<DispatchStatus>();

            _dispatchStatuses = DataServiceDispatchStatuses.DispatchStatusSqlGetAll();

            _dispatchStatusDataTable = new DataTable("DispatchStatus");
            _dispatchStatusDataTable.Columns.Add(new DataColumn("Dispatch Status Id ", typeof(string)));
            _dispatchStatusDataTable.Columns[0].Caption = "Dispatch Status Id ";
            _dispatchStatusDataTable.Columns[0].ReadOnly = true;
            _dispatchStatusDataTable.Columns.Add(new DataColumn(" Status Description ", typeof(string)));
            _dispatchStatusDataTable.Columns[1].Caption = " Status Description ";
            _dispatchStatusDataTable.Columns[1].ReadOnly = true;
            _dispatchStatusDataTable.Columns.Add(new DataColumn(" Include In Open Dispatches ", typeof(string)));
            _dispatchStatusDataTable.Columns[2].Caption = " Include In Open Dispatches ";
            _dispatchStatusDataTable.Columns[2].ReadOnly = true;
            foreach (DispatchStatus item in _dispatchStatuses)
            {
                object[] gridItems = new object[3] { item.DispatchStatusId, item.DispatchStatusDescription, item.DispatchIncludeInOpenDispatches };
                _dispatchStatusDataTable.LoadDataRow(gridItems, true);
            }

            gvDispatchStatuses.DataSource = _dispatchStatusDataTable;
            gvDispatchStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DispatchStatusDataGridClearEvent != null)
            {
                this.DispatchStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.DispatchStatusDataGridSearchEvent != null)
            {
                this.DispatchStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvDispatchStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvDispatchStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.DispatchStatusDataGridRowSelectedEvent != null)
            {
                this.DispatchStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
