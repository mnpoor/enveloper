using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobNumber : System.Web.UI.UserControl
    {
        public event SPEventHandler JobNumberClearEvent;
        public event SPEventHandler JobNumberOriginTypeChangedEvent;
        public event SPEventHandler JobNumberDestinationTypeChangedEvent;
        public event SPEventHandler JobNumberAddEvent;
        public event SPEventHandler JobNumberUpdateEvent;
        public event SPEventHandler JobNumberDeleteEvent;

        private Collection<Customer> _customers;
        private Collection<OriginType> _originTypes;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<DestinationType> _destinationTypes;
        private Collection<JobSite> _jobSites;
        private Collection<JobNumberStatus> _jobNumberStatuses;

        private JobNumber _jobNumber;
        private Collection<JobNumber> _jobNumbers;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CustomerCount
        {
            get
            {
                return cmbCustomers.Items.Count;
            }
        }

        public int OriginTypeCount
        {
            get
            {
                return cmbOriginTypes.Items.Count;
            }
        }

        public int OriginTypeIdSelected
        {
            get
            {
                return Convert.ToInt32(cmbOriginTypes.SelectedValue);
            }
        }

        public int PointOfOriginCount
        {
            get
            {
                return cmbPointsOfOrigin.Items.Count;
            }
        }

        public int DestinationTypeCount
        {
            get
            {
                return cmbDestinationTypes.Items.Count;
            }
        }

        public int DestinationTypeIdSelected
        {
            get
            {
                return Convert.ToInt32(cmbDestinationTypes.SelectedValue);
            }
        }

        public int DestinationCount
        {
            get
            {
                return cmbDestinations.Items.Count;
            }
        }

        public int JobNumberStatusCount
        {
            get
            {
                return cmbJobNumberStatuses.Items.Count;
            }
        }

        public void CustomersFill(Collection<Customer> customers)
        {
            if (cmbCustomers.Items.Count < 1)
            {
                _customers = new Collection<Customer>(customers);
                foreach (Customer item in _customers)
                {
                    cmbCustomers.Items.Add(new ListItem(item.CustomerName.ToString(), item.CustomerId.ToString()));
                }
                cmbCustomers.DataBind();
            }
        }

        public void OriginTypesFill(Collection<OriginType> originTypes)
        {
            if (cmbOriginTypes.Items.Count < 1)
            {
                _originTypes = new Collection<OriginType>(originTypes);
                foreach (OriginType item in _originTypes)
                {
                    cmbOriginTypes.Items.Add(new ListItem(item.OriginTypeDescription.ToString(), item.OriginTypeId.ToString()));
                }
                //cmbOriginTypes.DataBind();
            }
        }

        public void LoadingTerminalsFill(Collection<LoadingTerminal> loadingTerminals)
        {
            if (loadingTerminals == null) return; // sometimes this is called before the collection is populated, just skip it.
            _loadingTerminals = new Collection<LoadingTerminal>(loadingTerminals);
        }

        public void JobSitesFill(Collection<JobSite> jobSites)
        {
            if (jobSites == null) return;       // sometimes this is called before the collection is populated, just skip it.
            _jobSites = new Collection<JobSite>(jobSites);
        }

        public void LoadingTerminalsPopulateOriginDropdown()
        {
            cmbPointsOfOrigin.Items.Clear();
            foreach (LoadingTerminal item in _loadingTerminals)
            {
                cmbPointsOfOrigin.Items.Add(new ListItem(item.LoadingTerminalName.ToString(), item.LoadingTerminalId.ToString()));
            }
            //cmbPointsOfOrigin.DataBind();
        }

        public void EnrouteClearOriginDropdown()
        {
            cmbPointsOfOrigin.Items.Clear();
        }

        public void JobSitesPopulateOriginDropdown()
        {
            cmbPointsOfOrigin.Items.Clear();
            foreach (JobSite item in _jobSites)
            {
                cmbPointsOfOrigin.Items.Add(new ListItem(item.JobSiteName.ToString(), item.JobSiteId.ToString()));
            }
            //cmbPointsOfOrigin.DataBind();
        }

        public void DestinationTypesFill(Collection<DestinationType> destinationTypes)
        {
            if (cmbDestinationTypes.Items.Count < 1)
            {
                _destinationTypes = new Collection<DestinationType>(destinationTypes);
                foreach (DestinationType item in _destinationTypes)
                {
                    cmbDestinationTypes.Items.Add(new ListItem(item.DestinationTypeDescription.ToString(), item.DestinationTypeId.ToString()));
                }
                //cmbDestinationTypes.DataBind();
            }
        }

        public void JobNumberStatusesFill(Collection<JobNumberStatus> jobNumberStatuses)
        {
            if (cmbJobNumberStatuses.Items.Count < 1)
            {
                _jobNumberStatuses = new Collection<JobNumberStatus>(jobNumberStatuses);
                foreach (JobNumberStatus item in _jobNumberStatuses)
                {
                    cmbJobNumberStatuses.Items.Add(new ListItem(item.JobNumberStatusDescription.ToString(), item.JobNumberStatusId.ToString()));
                }
                //cmbOriginTypes .DataBind();
            }
        }

        public void LoadingTerminalsPopulateDestinationDropdown()
        {
            if (_loadingTerminals == null) return;
            cmbDestinations.Items.Clear();
            foreach (LoadingTerminal item in _loadingTerminals)
            {
                cmbDestinations.Items.Add(new ListItem(item.LoadingTerminalName.ToString(), item.LoadingTerminalId.ToString()));
            }
            //cmbDestinations.DataBind();
        }

        public void JobSitesPopulateDestinationDropdown()
        {
            if (_jobSites == null) return;
            cmbDestinations.Items.Clear();
            foreach (JobSite item in _jobSites)
            {
                cmbDestinations.Items.Add(new ListItem(item.JobSiteName.ToString(), item.JobSiteId.ToString()));
            }
            //cmbDestinations.DataBind();
        }

        public void JobNumberClear()
        {
            _jobNumber = null;

            txtJobNumberId.Text = string.Empty;
            txtJobNumberAssignment.Text = string.Empty;
            txtCustomerId.Text = string.Empty;
            cmbCustomers.SelectedValue = "0";
            txtJobNumberDate.Text = string.Empty;
            txtStartTime.Text = string.Empty;
            txtEndTime.Text = string.Empty;
            txtOriginTypeId.Text = string.Empty;
            cmbOriginTypes.SelectedValue = "0";
            txtOriginId.Text = string.Empty;
            cmbPointsOfOrigin.Items.Clear();
            txtDestinationTypeId.Text = string.Empty;
            cmbDestinationTypes.SelectedValue = "0";
            txtDestinationId.Text = string.Empty;
            cmbDestinations.Items.Clear();
            txtJobNumberStatusId.Text = string.Empty;
            cmbJobNumberStatuses.SelectedValue = "0";
            txtJobNumberDescription.Text = string.Empty;
        }

        public void JobNumberShow(JobNumber j)
        {
            _jobNumber = new JobNumber(j);

            txtJobNumberId.Text = j.JobNumberId.ToString();
            txtJobNumberAssignment.Text = j.JobNumberAssignment.ToString();
            txtCustomerId.Text = j.CustomerId.ToString();
            try
            {
                cmbCustomers.SelectedValue = j.CustomerId.ToString();
            }
            catch
            {
                cmbCustomers.SelectedValue = "0";
            }
            txtJobNumberDate.Text = j.JobNumberDate.ToShortDateString();
            txtStartTime.Text = j.StartTime.ToShortTimeString();
            txtEndTime.Text = j.EndTime.ToShortTimeString();
            txtOriginTypeId.Text = j.OriginTypeId.ToString();
            try
            {
                cmbOriginTypes.SelectedValue = j.OriginTypeId.ToString();
                OnOriginTypeChanged();      // triggers 'round trip' to populate the 'points of origin' dropdown
            }
            catch
            {
                cmbOriginTypes.SelectedValue = "0";
                //cmbPointsOfOrigin.Items.Clear();
            }
            txtOriginId.Text = j.OriginId.ToString();
            cmbPointsOfOrigin.SelectedValue = j.OriginId.ToString();
            txtDestinationTypeId.Text = j.DestinationTypeId.ToString();
            try
            {
                cmbDestinationTypes.SelectedValue = j.DestinationTypeId.ToString();
                OnDestinationTypeChanged();      // triggers 'round trip' to populate the 'points of origin' dropdown
            }
            catch
            {
                cmbDestinationTypes.SelectedValue = "0";
                //cmbDestination.Items.Clear();
            }
            txtDestinationId.Text = j.DestinationId.ToString();
            cmbDestinations.SelectedValue = j.DestinationId.ToString();
            txtJobNumberStatusId.Text = j.JobNumberStatusId.ToString();
            try
            {
                cmbJobNumberStatuses.SelectedValue = j.JobNumberStatusId.ToString();
            }
            catch
            {
                cmbJobNumberStatuses.SelectedValue = "0";
            }
            txtJobNumberDescription.Text = j.JobNumberDescription;
        }

        protected void cmbCustomers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCustomers.Items.Count > 0)
            {
                txtCustomerId.Text = cmbCustomers.SelectedValue;
            }
        }

        protected void cmbOriginTypes_TextChanged(object sender, EventArgs e)
        {
            if (cmbOriginTypes.Items.Count > 0)
            {
                txtOriginTypeId.Text = cmbOriginTypes.SelectedValue;
                cmbPointsOfOrigin.Items.Clear();
                OnOriginTypeChanged();
            }
        }

        private void OnOriginTypeChanged()
        {
            if (this.JobNumberOriginTypeChangedEvent != null)
            {
                this.JobNumberOriginTypeChangedEvent(this, new SPEventArgs(null, SPObjectAction.listItemSelected));
            }
        }

        protected void cmbPointsOfOrigin_TextChanged(object sender, EventArgs e)
        {
            if (cmbPointsOfOrigin.Items.Count > 0)
            {
                txtOriginId.Text = cmbPointsOfOrigin.SelectedValue;
            }
        }

        protected void cmbDestinationTypes_TextChanged(object sender, EventArgs e)
        {
            if (cmbDestinationTypes.Items.Count > 0)
            {
                txtDestinationTypeId.Text = cmbDestinationTypes.SelectedValue;
                cmbDestinations.Items.Clear();
                OnDestinationTypeChanged();
            }
        }

        private void OnDestinationTypeChanged()
        {
            if (this.JobNumberDestinationTypeChangedEvent != null)
            {
                this.JobNumberDestinationTypeChangedEvent(this, new SPEventArgs(null, SPObjectAction.listItemSelected));
            }
        }

        protected void cmbDestinations_TextChanged(object sender, EventArgs e)
        {
            if (cmbDestinations.Items.Count > 0)
            {
                txtDestinationId.Text = cmbDestinations.SelectedValue;
            }
        }

        protected void cmbJobNumberStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobNumberStatuses.Items.Count > 0)
            {
                txtJobNumberStatusId.Text = cmbJobNumberStatuses.SelectedValue;
            }
        }

        public void JobNumberUpdate(ref JobNumber j)
        {
            try
            {
                j.JobNumberId = Convert.ToInt32(txtJobNumberId.Text);
            }
            catch
            {
                j.JobNumberId = 0;
            }
            try
            {
                j.JobNumberAssignment = Convert.ToInt32(txtJobNumberAssignment.Text);
            }
            catch
            {
                j.JobNumberAssignment = 0;
            }
            try
            {
                j.CustomerId = Convert.ToInt32(txtCustomerId.Text);
            }
            catch
            {
                j.CustomerId = 0;
            }
            try
            {
                j.JobNumberDate = Convert.ToDateTime(txtJobNumberDate.Text);
            }
            catch
            {
                j.JobNumberDate = new DateTime();
            }
            try
            {
                j.StartTime = Convert.ToDateTime(txtStartTime.Text);
            }
            catch
            {
                j.StartTime = new DateTime();
            }
            try
            {
                j.EndTime = Convert.ToDateTime(txtEndTime.Text);
            }
            catch
            {
                j.EndTime = new DateTime();
            }
            try
            {
                j.OriginTypeId = Convert.ToInt32(txtOriginTypeId.Text);
            }
            catch
            {
                j.OriginTypeId = 0;
            }
            try
            {
                j.OriginId = Convert.ToInt32(txtOriginId.Text);
            }
            catch
            {
                j.OriginId = 0;
            }
            try
            {
                j.DestinationTypeId = Convert.ToInt32(txtDestinationTypeId.Text);
            }
            catch
            {
                j.DestinationTypeId = 0;
            }
            try
            {
                j.DestinationId = Convert.ToInt32(txtDestinationId.Text);
            }
            catch
            {
                j.DestinationId = 0;
            }
            try
            {
                j.JobNumberStatusId = Convert.ToInt32(txtJobNumberStatusId.Text);
            }
            catch
            {
                j.JobNumberStatusId = 0;
            }
            j.JobNumberDescription = txtJobNumberDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobNumberClearEvent != null)
            {
                this.JobNumberClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.JobNumberAddEvent != null)
            {
                this.JobNumberAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.JobNumberUpdateEvent != null)
            {
                this.JobNumberUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.JobNumberDeleteEvent != null)
            {
                this.JobNumberDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
