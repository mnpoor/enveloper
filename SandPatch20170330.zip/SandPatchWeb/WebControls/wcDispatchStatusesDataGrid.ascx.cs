using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDispatchStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DispatchStatusClearEvent;
        public event SPEventHandler DispatchStatusAddEvent;
        public event SPEventHandler DispatchStatusUpdateEvent;
        public event SPEventHandler DispatchStatusDeleteEvent;

        private DispatchStatus _dispatchStatus;
        private Collection<DispatchStatus> _dispatchStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void DispatchStatusClear()
        {
            _dispatchStatus = null;

            txtDispatchStatusId.Text = string.Empty;
            txtDispatchStatusDescription.Text = string.Empty;
            txtDispatchIncludeInOpenDispatches.Text = string.Empty;
        }

        public void DispatchStatusShow(DispatchStatus d)
        {
            _dispatchStatus = new DispatchStatus(d);

            txtDispatchStatusId.Text = d.DispatchStatusId.ToString();
            txtDispatchStatusDescription.Text = d.DispatchStatusDescription;
            txtDispatchIncludeInOpenDispatches.Text = d.DispatchIncludeInOpenDispatches.ToString();
        }

        public void DispatchStatusUpdate(ref DispatchStatus d)
        {
            try
            {
                d.DispatchStatusId = Convert.ToInt32(txtDispatchStatusId.Text);
            }
            catch
            {
                d.DispatchStatusId = 0;
            }
            d.DispatchStatusDescription = txtDispatchStatusDescription.Text;
            try
            {
                d.DispatchIncludeInOpenDispatches = Convert.ToInt16(txtDispatchIncludeInOpenDispatches.Text);
            }
            catch
            {
                d.DispatchIncludeInOpenDispatches = 0;
            }
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DispatchStatusClearEvent != null)
            {
                this.DispatchStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.DispatchStatusAddEvent != null)
            {
                this.DispatchStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.DispatchStatusUpdateEvent != null)
            {
                this.DispatchStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.DispatchStatusDeleteEvent != null)
            {
                this.DispatchStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
