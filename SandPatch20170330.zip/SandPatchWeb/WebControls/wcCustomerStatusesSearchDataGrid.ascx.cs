using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCustomerStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler CustomerStatusDataGridClearEvent;
        public event SPEventHandler CustomerStatusDataGridSearchEvent;
        public event SPEventHandler CustomerStatusDataGridRowSelectedEvent;

        private Collection<CustomerStatus> _customerStatuses = new Collection<CustomerStatus>();

        private DataTable _customerStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void CustomerStatusDataGridClear()
        {
        }

        public void CustomerStatusDataGridSearch()
        {
            Collection<CustomerStatus> itemCollection = new Collection<CustomerStatus>();

            _customerStatuses = DataServiceCustomerStatuses.CustomerStatusSqlGetAll();

            _customerStatusDataTable = new DataTable("CustomerStatus");
            _customerStatusDataTable.Columns.Add(new DataColumn("CustomerStatusId", _customerStatuses[0].CustomerStatusId.GetType()));
            _customerStatusDataTable.Columns[0].Caption = "CustomerStatusId ";
            _customerStatusDataTable.Columns[0].ReadOnly = true;
            _customerStatusDataTable.Columns.Add(new DataColumn("CustomerStatusDescription", _customerStatuses[0].CustomerStatusDescription.GetType()));
            _customerStatusDataTable.Columns[1].Caption = "CustomerStatusDescription ";
            _customerStatusDataTable.Columns[1].ReadOnly = true;
            foreach (CustomerStatus item in _customerStatuses)
            {
                object[] gridItems = new object[2] { item.CustomerStatusId, item.CustomerStatusDescription };
                _customerStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvCustomerStatuses.DataSource = _customerStatusDataTable;
            gvCustomerStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CustomerStatusDataGridClearEvent != null)
            {
                this.CustomerStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.CustomerStatusDataGridSearchEvent != null)
            {
                this.CustomerStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvCustomerStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvCustomerStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.CustomerStatusDataGridRowSelectedEvent != null)
            {
                this.CustomerStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
