using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobSiteStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler JobSiteStatusDataGridClearEvent;
        public event SPEventHandler JobSiteStatusDataGridSearchEvent;
        public event SPEventHandler JobSiteStatusDataGridRowSelectedEvent;

        private Collection<JobSiteStatus> _jobSiteStatuses = new Collection<JobSiteStatus>();

        private DataTable _jobSiteStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void JobSiteStatusDataGridClear()
        {
        }

        public void JobSiteStatusDataGridSearch()
        {
            Collection<JobSiteStatus> itemCollection = new Collection<JobSiteStatus>();

            _jobSiteStatuses = DataServiceJobSiteStatuses.JobSiteStatusSqlGetAll();

            _jobSiteStatusDataTable = new DataTable("JobSiteStatus");
            _jobSiteStatusDataTable.Columns.Add(new DataColumn("JobSiteStatusId", _jobSiteStatuses[0].JobSiteStatusId.GetType()));
            _jobSiteStatusDataTable.Columns[0].Caption = "JobSiteStatusId ";
            _jobSiteStatusDataTable.Columns[0].ReadOnly = true;
            _jobSiteStatusDataTable.Columns.Add(new DataColumn("JobSiteStatusDescription", _jobSiteStatuses[0].JobSiteStatusDescription.GetType()));
            _jobSiteStatusDataTable.Columns[1].Caption = "JobSiteStatusDescription ";
            _jobSiteStatusDataTable.Columns[1].ReadOnly = true;
            foreach (JobSiteStatus item in _jobSiteStatuses)
            {
                object[] gridItems = new object[2] { item.JobSiteStatusId, item.JobSiteStatusDescription };
                _jobSiteStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvJobSiteStatuses.DataSource = _jobSiteStatusDataTable;
            gvJobSiteStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobSiteStatusDataGridClearEvent != null)
            {
                this.JobSiteStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.JobSiteStatusDataGridSearchEvent != null)
            {
                this.JobSiteStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvJobSiteStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvJobSiteStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.JobSiteStatusDataGridRowSelectedEvent != null)
            {
                this.JobSiteStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
