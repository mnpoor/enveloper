using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcFreight : System.Web.UI.UserControl
    {
        public event SPEventHandler FreightClearEvent;
        public event SPEventHandler FreightAddEvent;
        public event SPEventHandler FreightUpdateEvent;
        public event SPEventHandler FreightDeleteEvent;

        private Freight _freight;
        private Collection<Freight> _freights;

        private Collection<FreightStatus> _freightStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int FreightStatusesCount
        {
            get
            {
                return cmbFreightStatus.Items.Count;
            }
        }

        public void FreightStatusesFill(Collection<FreightStatus> freightStatuses)
        {
            if (cmbFreightStatus.Items.Count < 1)
            {
                _freightStatuses = new Collection<FreightStatus>(freightStatuses);
                foreach (FreightStatus item in _freightStatuses)
                {
                    cmbFreightStatus.Items.Add(new ListItem(item.FreightStatusDescription, item.FreightStatusId.ToString()));
                }
                cmbFreightStatus.DataBind();
            }
        }

        public void FreightClear()
        {
            _freight = null;

            txtFreightId.Text = string.Empty;
            txtFreightName.Text = string.Empty;
            txtFreightDescription.Text = string.Empty;
            txtFreightUnitOfMeasure.Text = string.Empty;
            txtFreightStatusId.Text = string.Empty;
            cmbFreightStatus.SelectedValue = "0";
        }

        public void FreightShow(Freight f)
        {
            _freight = new Freight(f);

            txtFreightId.Text = f.FreightId.ToString();
            txtFreightName.Text = f.FreightName;
            txtFreightDescription.Text = f.FreightDescription;
            txtFreightUnitOfMeasure.Text = f.FreightUnitOfMeasure;
            txtFreightStatusId.Text = f.FreightStatusId.ToString();
            try
            {
                cmbFreightStatus.SelectedValue = f.FreightStatusId.ToString();
            }
            catch
            {
                cmbFreightStatus.SelectedValue = "0";
            }
        }

        protected void cmbFreightStatus_TextChanged(object sender, EventArgs e)
        {
            if (cmbFreightStatus.Items.Count > 0)
            {
                txtFreightStatusId.Text = cmbFreightStatus.SelectedValue;
            }
        }

        public void FreightUpdate(ref Freight f)
        {
            try
            {
                f.FreightId = Convert.ToInt32(txtFreightId.Text);
            }
            catch
            {
                f.FreightId = 0;
            }
            f.FreightName = txtFreightName.Text;
            f.FreightDescription = txtFreightDescription.Text;
            f.FreightUnitOfMeasure = txtFreightUnitOfMeasure.Text;
            try
            {
                f.FreightStatusId = Convert.ToInt32(txtFreightStatusId.Text);
            }
            catch
            {
                f.FreightStatusId = 0;
            }
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.FreightClearEvent != null)
            {
                this.FreightClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.FreightAddEvent != null)
            {
                this.FreightAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.FreightUpdateEvent != null)
            {
                this.FreightUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.FreightDeleteEvent != null)
            {
                this.FreightDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
