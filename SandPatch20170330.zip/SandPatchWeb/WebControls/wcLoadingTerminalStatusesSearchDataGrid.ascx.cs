using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcLoadingTerminalStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler LoadingTerminalStatusDataGridClearEvent;
        public event SPEventHandler LoadingTerminalStatusDataGridSearchEvent;
        public event SPEventHandler LoadingTerminalStatusDataGridRowSelectedEvent;

        private Collection<LoadingTerminalStatus> _loadingTerminalStatuses = new Collection<LoadingTerminalStatus>();

        private DataTable _loadingTerminalStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void LoadingTerminalStatusDataGridClear()
        {
        }

        public void LoadingTerminalStatusDataGridSearch()
        {
            Collection<LoadingTerminalStatus> itemCollection = new Collection<LoadingTerminalStatus>();

            _loadingTerminalStatuses = DataServiceLoadingTerminalStatuses.LoadingTerminalStatusSqlGetAll();

            _loadingTerminalStatusDataTable = new DataTable("LoadingTerminalStatus");
            _loadingTerminalStatusDataTable.Columns.Add(new DataColumn("LoadingTerminalStatusId", _loadingTerminalStatuses[0].LoadingTerminalStatusId.GetType()));
            _loadingTerminalStatusDataTable.Columns[0].Caption = "LoadingTerminalStatusId ";
            _loadingTerminalStatusDataTable.Columns[0].ReadOnly = true;
            _loadingTerminalStatusDataTable.Columns.Add(new DataColumn("LoadingTerminalStatusDescription", _loadingTerminalStatuses[0].LoadingTerminalStatusDescription.GetType()));
            _loadingTerminalStatusDataTable.Columns[1].Caption = "LoadingTerminalStatusDescription ";
            _loadingTerminalStatusDataTable.Columns[1].ReadOnly = true;
            foreach (LoadingTerminalStatus item in _loadingTerminalStatuses)
            {
                object[] gridItems = new object[2] { item.LoadingTerminalStatusId, item.LoadingTerminalStatusDescription };
                _loadingTerminalStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvLoadingTerminalStatuses.DataSource = _loadingTerminalStatusDataTable;
            gvLoadingTerminalStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.LoadingTerminalStatusDataGridClearEvent != null)
            {
                this.LoadingTerminalStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.LoadingTerminalStatusDataGridSearchEvent != null)
            {
                this.LoadingTerminalStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvLoadingTerminalStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvLoadingTerminalStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.LoadingTerminalStatusDataGridRowSelectedEvent != null)
            {
                this.LoadingTerminalStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
