using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcShipper : System.Web.UI.UserControl
    {
        public event SPEventHandler ShipperClearEvent;
        public event SPEventHandler ShipperAddEvent;
        public event SPEventHandler ShipperUpdateEvent;
        public event SPEventHandler ShipperDeleteEvent;

        private Shipper _shipper;
        private Collection<Shipper> _shippers;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void ShipperClear()
        {
            _shipper = null;

            txtShipperId.Text = string.Empty;
            txtShipperCompanyName.Text = string.Empty;
            txtShipperStreetAddress.Text = string.Empty;
            txtShipperBoxAddress.Text = string.Empty;
            txtShipperCity.Text = string.Empty;
            txtShipperState.Text = string.Empty;
            txtShipperPostalCode.Text = string.Empty;
            txtShipperStatusId.Text = string.Empty;
            txtShipperPhoneNumber.Text = string.Empty;
            txtShipperFaxNumber.Text = string.Empty;
            txtShipperContactName.Text = string.Empty;
            txtShipperContactEmail.Text = string.Empty;
            txtShipperContactMobileNumber.Text = string.Empty;
            txtShipperActivationDate.Text = string.Empty;
            txtShipperSeveranceDate.Text = string.Empty;
            txtShipperNotes.Text = string.Empty;
        }

        public void ShipperShow(Shipper s)
        {
            _shipper = new Shipper(s);

            txtShipperId.Text = s.ShipperId.ToString();
            txtShipperCompanyName.Text = s.ShipperCompanyName;
            txtShipperStreetAddress.Text = s.ShipperStreetAddress;
            txtShipperBoxAddress.Text = s.ShipperBoxAddress;
            txtShipperCity.Text = s.ShipperCity;
            txtShipperState.Text = s.ShipperState;
            txtShipperPostalCode.Text = s.ShipperPostalCode;
            txtShipperStatusId.Text = s.ShipperStatusId.ToString();
            txtShipperPhoneNumber.Text = s.ShipperPhoneNumber;
            txtShipperFaxNumber.Text = s.ShipperFaxNumber;
            txtShipperContactName.Text = s.ShipperContactName;
            txtShipperContactEmail.Text = s.ShipperContactEmail;
            txtShipperContactMobileNumber.Text = s.ShipperContactMobileNumber;
            if (s.ShipperActivationDate == new DateTime()) txtShipperActivationDate.Text = string.Empty;
                else txtShipperActivationDate.Text = s.ShipperActivationDate.ToShortDateString();
            if (s.ShipperSeveranceDate == new DateTime()) txtShipperSeveranceDate.Text = string.Empty;
                else txtShipperSeveranceDate.Text = s.ShipperSeveranceDate.ToShortDateString();
            txtShipperNotes.Text = s.ShipperNotes;
        }

        public void ShipperUpdate(ref Shipper s)
        {
            try
            {
                s.ShipperId = Convert.ToInt32(txtShipperId.Text);
            }
            catch
            {
                s.ShipperId = 0;
            }
            s.ShipperCompanyName = txtShipperCompanyName.Text;
            s.ShipperStreetAddress = txtShipperStreetAddress.Text;
            s.ShipperBoxAddress = txtShipperBoxAddress.Text;
            s.ShipperCity = txtShipperCity.Text;
            s.ShipperState = txtShipperState.Text;
            s.ShipperPostalCode = txtShipperPostalCode.Text;
            try
            {
                s.ShipperStatusId = Convert.ToInt32(txtShipperStatusId.Text);
            }
            catch
            {
                s.ShipperStatusId = 0;
            }
            s.ShipperPhoneNumber = txtShipperPhoneNumber.Text;
            s.ShipperFaxNumber = txtShipperFaxNumber.Text;
            s.ShipperContactName = txtShipperContactName.Text;
            s.ShipperContactEmail = txtShipperContactEmail.Text;
            s.ShipperContactMobileNumber = txtShipperContactMobileNumber.Text;
            try
            {
                s.ShipperActivationDate = Convert.ToDateTime(txtShipperActivationDate.Text);
            }
            catch
            {
                s.ShipperActivationDate = new DateTime();
            }
            try
            {
                s.ShipperSeveranceDate = Convert.ToDateTime(txtShipperSeveranceDate.Text);
            }
            catch
            {
                s.ShipperSeveranceDate = new DateTime();
            }
            s.ShipperNotes = txtShipperNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.ShipperClearEvent != null)
            {
                this.ShipperClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.ShipperAddEvent != null)
            {
                this.ShipperAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.ShipperUpdateEvent != null)
            {
                this.ShipperUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.ShipperDeleteEvent != null)
            {
                this.ShipperDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
