using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCustomerSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler CustomerDataGridClearEvent;
        public event SPEventHandler CustomerDataGridSearchEvent;
        public event SPEventHandler CustomerDataGridRowSelectedEvent;

        private Collection<Customer> _customers = new Collection<Customer>();

        private DataTable _customerDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void CustomerDataGridViewClear()
        {
            txtCustomerNameSearch.Text = string.Empty;
            txtContactNameSearch.Text = string.Empty;
           //gvCustomers.; // clears data grid - not implemented
        }

        public void CustomerDataGridSearch()
        {
            Collection<Customer> itemCollection = new Collection<Customer>();

            txtCustomerNameSearch.Text = ApplyWildcards(txtCustomerNameSearch.Text);
            txtContactNameSearch.Text = ApplyWildcards(txtContactNameSearch.Text);

            _customers = DataServiceCustomers.CustomerSqlGetBySearchTerms(txtCustomerNameSearch.Text.Trim(), txtContactNameSearch.Text.Trim());

            _customerDataTable = new DataTable("Customers");
            _customerDataTable.Columns.Add(new DataColumn("Customer Id", _customers[0].CustomerId.GetType()));
            _customerDataTable.Columns[0].Caption = "Customer Id ";
            _customerDataTable.Columns.Add(new DataColumn("Customer Name", _customers[0].CustomerName.GetType()));
            _customerDataTable.Columns[1].Caption = "Customer Name ";
            _customerDataTable.Columns.Add(new DataColumn("Contact Name", _customers[0].ContactName.GetType()));
            _customerDataTable.Columns[2].Caption = "Contact Name";
            _customerDataTable.Columns.Add(new DataColumn("Phone Number", _customers[0].PhoneNumber.GetType()));
            _customerDataTable.Columns[3].Caption = "Phone Number ";
            _customerDataTable.Columns.Add(new DataColumn("Contact Email Address", _customers[0].ContactEmailAddress.GetType()));
            _customerDataTable.Columns[4].Caption = "Contact Email Address ";
            foreach (Customer item in _customers)
            {
                object[] gridItems = new object[5] { item.CustomerId, item.CustomerName, item.ContactName, item.PhoneNumber, item.ContactEmailAddress };
                _customerDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvCustomers.DataSource = _customerDataTable;
            gvCustomers.DataBind();
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains(" % ")) return searchTerm.Trim();
            return " % " + searchTerm.Trim() + " % ";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CustomerDataGridClearEvent != null)
            {
                this.CustomerDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.CustomerDataGridSearchEvent != null)
            {
                this.CustomerDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvCustomers.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.CustomerDataGridRowSelectedEvent != null)
            {
                this.CustomerDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
