using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcShipperStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler ShipperStatusClearEvent;
        public event SPEventHandler ShipperStatusAddEvent;
        public event SPEventHandler ShipperStatusUpdateEvent;
        public event SPEventHandler ShipperStatusDeleteEvent;

        private ShipperStatus _shipperStatus;
        private Collection<ShipperStatus> _shipperStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void ShipperStatusClear()
        {
            _shipperStatus = null;

            txtShipperStatusId.Text = string.Empty;
            txtShipperStatusDescription.Text = string.Empty;
        }

        public void ShipperStatusShow(ShipperStatus s)
        {
            _shipperStatus = new ShipperStatus(s);

            txtShipperStatusId.Text = s.ShipperStatusId.ToString();
            txtShipperStatusDescription.Text = s.ShipperStatusDescription;
        }

        public void ShipperStatusUpdate(ref ShipperStatus s)
        {
            try
            {
                s.ShipperStatusId = Convert.ToInt32(txtShipperStatusId.Text);
            }
            catch
            {
                s.ShipperStatusId = 0;
            }
            try
            {
                s.ShipperStatusId = Convert.ToInt32(txtShipperStatusId.Text);
            }
            catch
            {
                s.ShipperStatusId = 0;
            }
            s.ShipperStatusDescription = txtShipperStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.ShipperStatusClearEvent != null)
            {
                this.ShipperStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.ShipperStatusAddEvent != null)
            {
                this.ShipperStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.ShipperStatusUpdateEvent != null)
            {
                this.ShipperStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.ShipperStatusDeleteEvent != null)
            {
                this.ShipperStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
