using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcWellOperatorStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler WellOperatorStatusClearEvent;
        public event SPEventHandler WellOperatorStatusAddEvent;
        public event SPEventHandler WellOperatorStatusUpdateEvent;
        public event SPEventHandler WellOperatorStatusDeleteEvent;

        private WellOperatorStatus _wellOperatorStatus;
        private Collection<WellOperatorStatus> _wellOperatorStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void WellOperatorStatusClear()
        {
            _wellOperatorStatus = null;

            txtWellOperatorStatusId.Text = string.Empty;
            txtWellOperatorStatusDescription.Text = string.Empty;
        }

        public void WellOperatorStatusShow(WellOperatorStatus w)
        {
            _wellOperatorStatus = new WellOperatorStatus(w);

            txtWellOperatorStatusId.Text = w.WellOperatorStatusId.ToString();
            txtWellOperatorStatusDescription.Text = w.WellOperatorStatusDescription;
        }

        public void WellOperatorStatusUpdate(ref WellOperatorStatus w)
        {
            try
            {
                w.WellOperatorStatusId = Convert.ToInt32(txtWellOperatorStatusId.Text);
            }
            catch
            {
                w.WellOperatorStatusId = 0;
            }
            try
            {
                w.WellOperatorStatusId = Convert.ToInt32(txtWellOperatorStatusId.Text);
            }
            catch
            {
                w.WellOperatorStatusId = 0;
            }
            w.WellOperatorStatusDescription = txtWellOperatorStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.WellOperatorStatusClearEvent != null)
            {
                this.WellOperatorStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.WellOperatorStatusAddEvent != null)
            {
                this.WellOperatorStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.WellOperatorStatusUpdateEvent != null)
            {
                this.WellOperatorStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.WellOperatorStatusDeleteEvent != null)
            {
                this.WellOperatorStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
