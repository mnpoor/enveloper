using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcFuelCardStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler FuelCardStatusDataGridClearEvent;
        public event SPEventHandler FuelCardStatusDataGridSearchEvent;
        public event SPEventHandler FuelCardStatusDataGridRowSelectedEvent;

        private Collection<FuelCardStatus> _fuelCardStatuses = new Collection<FuelCardStatus>();

        private DataTable _fuelCardStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void FuelCardStatusDataGridClear()
        {
        }

        public void FuelCardStatusDataGridSearch()
        {
            Collection<FuelCardStatus> itemCollection = new Collection<FuelCardStatus>();

            _fuelCardStatuses = DataServiceFuelCardStatuses.FuelCardStatusSqlGetAll();

            _fuelCardStatusDataTable = new DataTable("FuelCardStatus");
            _fuelCardStatusDataTable.Columns.Add(new DataColumn("FuelCardStatusId", _fuelCardStatuses[0].FuelCardStatusId.GetType()));
            _fuelCardStatusDataTable.Columns[0].Caption = "FuelCardStatusId ";
            _fuelCardStatusDataTable.Columns[0].ReadOnly = true;
            _fuelCardStatusDataTable.Columns.Add(new DataColumn("FuelCardStatusDescription", _fuelCardStatuses[0].FuelCardStatusDescription.GetType()));
            _fuelCardStatusDataTable.Columns[1].Caption = "FuelCardStatusDescription ";
            _fuelCardStatusDataTable.Columns[1].ReadOnly = true;
            foreach (FuelCardStatus item in _fuelCardStatuses)
            {
                object[] gridItems = new object[2] { item.FuelCardStatusId, item.FuelCardStatusDescription };
                _fuelCardStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvFuelCardStatuses.DataSource = _fuelCardStatusDataTable;
            gvFuelCardStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.FuelCardStatusDataGridClearEvent != null)
            {
                this.FuelCardStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.FuelCardStatusDataGridSearchEvent != null)
            {
                this.FuelCardStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvFuelCardStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvFuelCardStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.FuelCardStatusDataGridRowSelectedEvent != null)
            {
                this.FuelCardStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
