using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcWithholdingAccountSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler WithholdingAccountDataGridClearEvent;
        public event SPEventHandler WithholdingAccountDataGridSearchEvent;
        public event SPEventHandler WithholdingAccountDataGridPageIndexChangingEvent;
        public event SPEventHandler WithholdingAccountDataGridRowSelectedEvent;

        private Collection<WithholdingAccount> _withholdingAccounts = new Collection<WithholdingAccount>();

        private DataTable _withholdingAccountDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void WithholdingAccountDataGridClear()
        {
            _withholdingAccountDataTable = new DataTable("WithholdingAccount");
            gvWithholdingAccounts.DataSource = _withholdingAccountDataTable;
            gvWithholdingAccounts.DataBind();
        }

        //public string[] WithholdingAccountDataGridWildcard()
        //{
        //    return new string[] { txtWithholdingIdSearch.Text.Trim(), txtWithholdingAccountNameSearch.Text.Trim(), txtWithholdingSummaryAccountNumberSearch.Text.Trim() };
        //}

        //private string ApplyWildcards(string searchTerm)
        //{
        //    if (searchTerm == string.Empty) return string.Empty;
        //    if (searchTerm.Contains("%")) return searchTerm.Trim();
        //    return "%" + searchTerm.Trim() + "%";
        //}

        public void WithholdingAccountDataGridSearch(Collection<WithholdingAccount> itemCollection, int pageIndex)
        {
            _withholdingAccounts = new Collection<WithholdingAccount>(itemCollection);
            GridViewFill(pageIndex);
        }


        public void GridViewFill(int pageIndex)
        {
            _withholdingAccountDataTable = new DataTable("WithholdingAccount");
            _withholdingAccountDataTable.Columns.Add(new DataColumn("WithholdingId", _withholdingAccounts[0].WithholdingId.GetType()));
            _withholdingAccountDataTable.Columns[0].Caption = "WithholdingId ";
            _withholdingAccountDataTable.Columns[0].ReadOnly = true;
            _withholdingAccountDataTable.Columns.Add(new DataColumn("WithholdingAccountName", _withholdingAccounts[0].WithholdingAccountName.GetType()));
            _withholdingAccountDataTable.Columns[1].Caption = "WithholdingAccountName ";
            _withholdingAccountDataTable.Columns[1].ReadOnly = true;
            _withholdingAccountDataTable.Columns.Add(new DataColumn("WithholdingSummaryAccountNumber", _withholdingAccounts[0].WithholdingSummaryAccountNumber.GetType()));
            _withholdingAccountDataTable.Columns[2].Caption = "WithholdingSummaryAccountNumber ";
            _withholdingAccountDataTable.Columns[2].ReadOnly = true;
            foreach (WithholdingAccount item in _withholdingAccounts)
            {
                object[] gridItems = new object[3] { item.WithholdingId, item.WithholdingAccountName, item.WithholdingSummaryAccountNumber };
                _withholdingAccountDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvWithholdingAccounts.Columns.Clear();
            BoundField column0 = new BoundField();
            column0.HeaderText = "Id";
            column0.DataField = "WithholdingId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            gvWithholdingAccounts.Columns.Add(column0);

            BoundField column1 = new BoundField();
            column1.HeaderText = "Account Name";
            column1.DataField = "WithholdingAccountName";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;
            gvWithholdingAccounts.Columns.Add(column1);

            BoundField column2 = new BoundField();
            column2.HeaderText = "Summary Account Number";
            column2.DataField = "WithholdingSummaryAccountNumber";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;
            gvWithholdingAccounts.Columns.Add(column2);

            gvWithholdingAccounts.DataSource = _withholdingAccountDataTable;
            gvWithholdingAccounts.PageIndex = pageIndex;
            gvWithholdingAccounts.DataBind();
            gvWithholdingAccounts.Width = new Unit((int)700);
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.WithholdingAccountDataGridClearEvent != null)
            {
                this.WithholdingAccountDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.WithholdingAccountDataGridSearchEvent != null)
            {
                this.WithholdingAccountDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvWithholdingAccounts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.WithholdingAccountDataGridPageIndexChangingEvent != null)
            {
                this.WithholdingAccountDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvWithholdingAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvWithholdingAccounts.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.WithholdingAccountDataGridRowSelectedEvent != null)
            {
                this.WithholdingAccountDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
