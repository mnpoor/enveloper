using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDriver : System.Web.UI.UserControl
    {
        public event SPEventHandler DriverClearEvent;
        public event SPEventHandler DriverAddEvent;
        public event SPEventHandler DriverUpdateEvent;
        public event SPEventHandler DriverDeleteEvent;

        private Collection<Carrier> _carriers;
        private Collection<DriverStatus> _driverStatuses;
        private Collection<FuelCardStatus> _fuelCardStatuses;
        private Collection<LicensePlateStatus> _licensePlateStatuses;

        private Driver _driver;
        private Collection<Driver> _drivers;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CarriersCount
        {
            get
            {
                return cmbCarriers.Items.Count;
            }
        }

        public int DriverStatusesCount
        {
            get
            {
                return cmbDriverStatuses.Items.Count;
            }
        }

        public int FuelCardStatusesCount
        {
            get
            {
                return cmbFuelCardStatuses.Items.Count;
            }
        }

        public int LicensePlateStatusesCount
        {
            get
            {
                return cmbLicensePlateStatuses.Items.Count;
            }
        }

        public void CarriersFill(Collection<Carrier> carriers)
        {
            if (cmbCarriers.Items.Count < 1)
            {
                _carriers = new Collection<Carrier>(carriers);
                foreach (Carrier item in _carriers)
                {
                    cmbCarriers.Items.Add(new ListItem(item.CarrierCompanyName, item.CarrierId.ToString()));
                }
                cmbCarriers.DataBind();
            }
        }

        public void DriverStatusesFill(Collection<DriverStatus> driverStatuses)
        {
            if (cmbDriverStatuses.Items.Count < 1)
            {
                _driverStatuses = new Collection<DriverStatus>(driverStatuses);
                foreach (DriverStatus item in _driverStatuses)
                {
                    cmbDriverStatuses.Items.Add(new ListItem(item.DriverStatusDescription, item.DriverStatusId.ToString()));
                }
                cmbDriverStatuses.DataBind();
            }
        }

        public void FuelCardStatusesFill(Collection<FuelCardStatus> fuelCardStatuses)
        {
            if (cmbFuelCardStatuses.Items.Count < 1)
            {
                _fuelCardStatuses = new Collection<FuelCardStatus>(fuelCardStatuses);
                foreach (FuelCardStatus item in _fuelCardStatuses)
                {
                    cmbFuelCardStatuses.Items.Add(new ListItem(item.FuelCardStatusDescription, item.FuelCardStatusId.ToString()));
                }
                cmbFuelCardStatuses.DataBind();
            }
        }

        public void LicensePlateStatusesFill(Collection<LicensePlateStatus> licensePlateStatuses)
        {
            if (cmbLicensePlateStatuses.Items.Count < 1)
            {
                _licensePlateStatuses = new Collection<LicensePlateStatus>(licensePlateStatuses);
                foreach (LicensePlateStatus item in _licensePlateStatuses)
                {
                    cmbLicensePlateStatuses.Items.Add(new ListItem(item.LicensePlateStatusDescription, item.LicensePlateStatusId.ToString()));
                }
                cmbLicensePlateStatuses.DataBind();
            }
        }

        public void DriverClear()
        {
            _driver = null;

            txtDriverId.Text = string.Empty;
            txtTruckNumber.Text = string.Empty;
            txtCarrierId.Text = string.Empty;
            cmbCarriers.SelectedValue = "0";
            txtDriverName.Text = string.Empty;
            txtDriverStreetAddress.Text = string.Empty;
            txtDriverBoxAddress.Text = string.Empty;
            txtDriverCity.Text = string.Empty;
            txtDriverState.Text = string.Empty;
            txtDriverPostalCode.Text = string.Empty;
            txtDriverTelephoneNumber.Text = string.Empty;
            txtDriverEmail.Text = string.Empty;
            txtDriverStatusId.Text = string.Empty;
            cmbDriverStatuses.SelectedValue = "0";
            txtDriverStartDate.Text = string.Empty;
            txtDriverSeveranceDate.Text = string.Empty;
            txtFuelCardStatusId.Text = string.Empty;
            cmbFuelCardStatuses.SelectedValue = "0";
            txtLicensePlateStatusId.Text = string.Empty;
            cmbLicensePlateStatuses.SelectedValue = "0";
            txtDriverNotes.Text = string.Empty;
        }

        public void DriverShow(Driver d)
        {
            _driver = new Driver(d);

            txtDriverId.Text = d.DriverId.ToString();
            txtTruckNumber.Text = d.TruckNumber.ToString();
            txtCarrierId.Text = d.CarrierId.ToString();
            try
            {
                cmbCarriers.SelectedValue = d.CarrierId.ToString();
            }
            catch
            {
                cmbCarriers.SelectedValue = "0";
            }
            txtDriverName.Text = d.DriverName;
            txtDriverStreetAddress.Text = d.DriverStreetAddress;
            txtDriverBoxAddress.Text = d.DriverBoxAddress;
            txtDriverCity.Text = d.DriverCity;
            txtDriverState.Text = d.DriverState;
            txtDriverPostalCode.Text = d.DriverPostalCode;
            txtDriverTelephoneNumber.Text = d.DriverTelephoneNumber;
            txtDriverEmail.Text = d.DriverEmail;
            txtDriverStatusId.Text = d.DriverStatusId.ToString();
            try
            {
                cmbDriverStatuses.SelectedValue = d.DriverStatusId.ToString();
            }
            catch
            {
                cmbDriverStatuses.SelectedValue = "0";
            }
            if (d.DriverStartDate == new DateTime()) txtDriverStartDate.Text = string.Empty;
                else txtDriverStartDate.Text = d.DriverStartDate.ToShortDateString();
            if (d.DriverSeveranceDate == new DateTime()) txtDriverSeveranceDate.Text = string.Empty;
                else txtDriverSeveranceDate.Text = d.DriverSeveranceDate.ToShortDateString();
            txtFuelCardStatusId.Text = d.FuelCardStatusId.ToString();
            try
            {
                cmbFuelCardStatuses.SelectedValue = d.FuelCardStatusId.ToString();
            }
            catch
            {
                cmbFuelCardStatuses.SelectedValue = "0";
            }
            txtLicensePlateStatusId.Text = d.LicensePlateStatusId.ToString();
            try
            {
                cmbLicensePlateStatuses.SelectedValue = d.LicensePlateStatusId.ToString();
            }
            catch
            {
                cmbLicensePlateStatuses.SelectedValue = "0";
            }
            txtDriverNotes.Text = d.DriverNotes;
        }

        protected void cmbCarriers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCarriers.Items.Count > 0)
            {
                txtCarrierId.Text = cmbCarriers.SelectedValue;
            }
        }

        protected void cmbDriverStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbDriverStatuses.Items.Count > 0)
            {
                txtDriverStatusId.Text = cmbDriverStatuses.SelectedValue;
            }
        }

        protected void cmbFuelCardStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbFuelCardStatuses.Items.Count > 0)
            {
                txtFuelCardStatusId.Text = cmbFuelCardStatuses.SelectedValue;
            }
        }

        protected void cmbLicensePlateStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbLicensePlateStatuses.Items.Count > 0)
            {
                txtLicensePlateStatusId.Text = cmbLicensePlateStatuses.SelectedValue;
            }
        }

        public void DriverUpdate(ref Driver d)
        {
            try
            {
                d.DriverId = Convert.ToInt32(txtDriverId.Text);
            }
            catch
            {
                d.DriverId = 0;
            }
            try
            {
                d.TruckNumber = Convert.ToInt32(txtTruckNumber.Text);
            }
            catch
            {
                d.TruckNumber = 0;
            }
            try
            {
                d.CarrierId = Convert.ToInt32(txtCarrierId.Text);
            }
            catch
            {
                d.CarrierId = 0;
            }
            d.DriverName = txtDriverName.Text;
            d.DriverStreetAddress = txtDriverStreetAddress.Text;
            d.DriverBoxAddress = txtDriverBoxAddress.Text;
            d.DriverCity = txtDriverCity.Text;
            d.DriverState = txtDriverState.Text;
            d.DriverPostalCode = txtDriverPostalCode.Text;
            d.DriverTelephoneNumber = txtDriverTelephoneNumber.Text;
            d.DriverEmail = txtDriverEmail.Text;
            try
            {
                d.DriverStatusId = Convert.ToInt32(txtDriverStatusId.Text);
            }
            catch
            {
                d.DriverStatusId = 0;
            }
            try
            {
                d.DriverStartDate = Convert.ToDateTime(txtDriverStartDate.Text);
            }
            catch
            {
                d.DriverStartDate = new DateTime();
            }
            try
            {
                d.DriverSeveranceDate = Convert.ToDateTime(txtDriverSeveranceDate.Text);
            }
            catch
            {
                d.DriverSeveranceDate = new DateTime();
            }
            try
            {
                d.FuelCardStatusId = Convert.ToInt32(txtFuelCardStatusId.Text);
            }
            catch
            {
                d.FuelCardStatusId = 0;
            }
            try
            {
                d.LicensePlateStatusId = Convert.ToInt32(txtLicensePlateStatusId.Text);
            }
            catch
            {
                d.LicensePlateStatusId = 0;
            }
            d.DriverNotes = txtDriverNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DriverClearEvent != null)
            {
                this.DriverClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.DriverAddEvent != null)
            {
                this.DriverAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.DriverUpdateEvent != null)
            {
                this.DriverUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.DriverDeleteEvent != null)
            {
                this.DriverDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
