using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcFuelCardStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler FuelCardStatusClearEvent;
        public event SPEventHandler FuelCardStatusAddEvent;
        public event SPEventHandler FuelCardStatusUpdateEvent;
        public event SPEventHandler FuelCardStatusDeleteEvent;

        private FuelCardStatus _fuelCardStatus;
        private Collection<FuelCardStatus> _fuelCardStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void FuelCardStatusClear()
        {
            _fuelCardStatus = null;

            txtFuelCardStatusId.Text = string.Empty;
            txtFuelCardStatusDescription.Text = string.Empty;
        }

        public void FuelCardStatusShow(FuelCardStatus f)
        {
            _fuelCardStatus = new FuelCardStatus(f);

            txtFuelCardStatusId.Text = f.FuelCardStatusId.ToString();
            txtFuelCardStatusDescription.Text = f.FuelCardStatusDescription;
        }

        public void FuelCardStatusUpdate(ref FuelCardStatus f)
        {
            try
            {
                f.FuelCardStatusId = Convert.ToInt32(txtFuelCardStatusId.Text);
            }
            catch
            {
                f.FuelCardStatusId = 0;
            }
            try
            {
                f.FuelCardStatusId = Convert.ToInt32(txtFuelCardStatusId.Text);
            }
            catch
            {
                f.FuelCardStatusId = 0;
            }
            f.FuelCardStatusDescription = txtFuelCardStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.FuelCardStatusClearEvent != null)
            {
                this.FuelCardStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.FuelCardStatusAddEvent != null)
            {
                this.FuelCardStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.FuelCardStatusUpdateEvent != null)
            {
                this.FuelCardStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.FuelCardStatusDeleteEvent != null)
            {
                this.FuelCardStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
