using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcOriginTypeDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler OriginTypeClearEvent;
        public event SPEventHandler OriginTypeAddEvent;
        public event SPEventHandler OriginTypeUpdateEvent;
        public event SPEventHandler OriginTypeDeleteEvent;

        private OriginType _originType;
        private Collection<OriginType> _originTypes;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void OriginTypeClear()
        {
            _originType = null;

            txtOriginTypeId.Text = string.Empty;
            txtOriginTypeDescription.Text = string.Empty;
        }

        public void OriginTypeShow(OriginType o)
        {
            _originType = new OriginType(o);

            txtOriginTypeId.Text = o.OriginTypeId.ToString();
            txtOriginTypeDescription.Text = o.OriginTypeDescription;
        }

        public void OriginTypeUpdate(ref OriginType o)
        {
            try
            {
                o.OriginTypeId = Convert.ToInt32(txtOriginTypeId.Text);
            }
            catch
            {
                o.OriginTypeId = 0;
            }
            try
            {
                o.OriginTypeId = Convert.ToInt32(txtOriginTypeId.Text);
            }
            catch
            {
                o.OriginTypeId = 0;
            }
            o.OriginTypeDescription = txtOriginTypeDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.OriginTypeClearEvent != null)
            {
                this.OriginTypeClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.OriginTypeAddEvent != null)
            {
                this.OriginTypeAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.OriginTypeUpdateEvent != null)
            {
                this.OriginTypeUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.OriginTypeDeleteEvent != null)
            {
                this.OriginTypeDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
