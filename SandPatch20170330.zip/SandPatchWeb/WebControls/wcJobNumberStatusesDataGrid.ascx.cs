using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobNumberStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler JobNumberStatusClearEvent;
        public event SPEventHandler JobNumberStatusAddEvent;
        public event SPEventHandler JobNumberStatusUpdateEvent;
        public event SPEventHandler JobNumberStatusDeleteEvent;

        private JobNumberStatus _jobNumberStatus;
        private Collection<JobNumberStatus> _jobNumberStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void JobNumberStatusClear()
        {
            _jobNumberStatus = null;

            txtJobNumberStatusId.Text = string.Empty;
            txtJobNumberStatusDescription.Text = string.Empty;
        }

        public void JobNumberStatusShow(JobNumberStatus j)
        {
            _jobNumberStatus = new JobNumberStatus(j);

            txtJobNumberStatusId.Text = j.JobNumberStatusId.ToString();
            txtJobNumberStatusDescription.Text = j.JobNumberStatusDescription;
        }

        public void JobNumberStatusUpdate(ref JobNumberStatus j)
        {
            try
            {
                j.JobNumberStatusId = Convert.ToInt32(txtJobNumberStatusId.Text);
            }
            catch
            {
                j.JobNumberStatusId = 0;
            }
            try
            {
                j.JobNumberStatusId = Convert.ToInt32(txtJobNumberStatusId.Text);
            }
            catch
            {
                j.JobNumberStatusId = 0;
            }
            j.JobNumberStatusDescription = txtJobNumberStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobNumberStatusClearEvent != null)
            {
                this.JobNumberStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.JobNumberStatusAddEvent != null)
            {
                this.JobNumberStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.JobNumberStatusUpdateEvent != null)
            {
                this.JobNumberStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.JobNumberStatusDeleteEvent != null)
            {
                this.JobNumberStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
