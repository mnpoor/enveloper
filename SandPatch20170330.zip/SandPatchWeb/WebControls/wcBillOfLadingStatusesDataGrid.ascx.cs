using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcBillOfLadingStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler BillOfLadingStatusClearEvent;
        public event SPEventHandler BillOfLadingStatusAddEvent;
        public event SPEventHandler BillOfLadingStatusUpdateEvent;
        public event SPEventHandler BillOfLadingStatusDeleteEvent;

        private BillOfLadingStatus _billOfLadingStatus;
        private Collection<BillOfLadingStatus> _billOfLadingStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void BillOfLadingStatusClear()
        {
            _billOfLadingStatus = null;

            txtBillOfLadingStatusId.Text = string.Empty;
            txtBillOfLadingStatusDescription.Text = string.Empty;
        }

        public void BillOfLadingStatusShow(BillOfLadingStatus b)
        {
            _billOfLadingStatus = new BillOfLadingStatus(b);

            txtBillOfLadingStatusId.Text = b.BillOfLadingStatusId.ToString();
            txtBillOfLadingStatusDescription.Text = b.BillOfLadingStatusDescription;
        }

        public void BillOfLadingStatusUpdate(ref BillOfLadingStatus b)
        {
            try
            {
                b.BillOfLadingStatusId = Convert.ToInt32(txtBillOfLadingStatusId.Text);
            }
            catch
            {
                b.BillOfLadingStatusId = 0;
            }
            try
            {
                b.BillOfLadingStatusId = Convert.ToInt32(txtBillOfLadingStatusId.Text);
            }
            catch
            {
                b.BillOfLadingStatusId = 0;
            }
            b.BillOfLadingStatusDescription = txtBillOfLadingStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.BillOfLadingStatusClearEvent != null)
            {
                this.BillOfLadingStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.BillOfLadingStatusAddEvent != null)
            {
                this.BillOfLadingStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.BillOfLadingStatusUpdateEvent != null)
            {
                this.BillOfLadingStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.BillOfLadingStatusDeleteEvent != null)
            {
                this.BillOfLadingStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
