using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcWellOperatorSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler WellOperatorDataGridClearEvent;
        public event SPEventHandler WellOperatorDataGridSearchEvent;
        public event SPEventHandler WellOperatorDataGridRowSelectedEvent;

        private Collection<WellOperator> _wellOperators = new Collection<WellOperator>();

        private DataTable _wellOperatorDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void WellOperatorDataGridClear()
        {
            txtWellOperatorCompanyNameSearch.Text = string.Empty;
            txtWellOperatorContactNameSearch.Text = string.Empty;
            txtWellOperatorCitySearch.Text = string.Empty;
           //gvWellOperators.; // clears data grid - not implemented
        }

        public void WellOperatorDataGridSearch()
        {
            Collection<WellOperator> itemCollection = new Collection<WellOperator>();

            txtWellOperatorCompanyNameSearch.Text = ApplyWildcards(txtWellOperatorCompanyNameSearch.Text);
            txtWellOperatorContactNameSearch.Text = ApplyWildcards(txtWellOperatorContactNameSearch.Text);
            txtWellOperatorCitySearch.Text = ApplyWildcards(txtWellOperatorCitySearch.Text);

            _wellOperators = DataServiceWellOperators.WellOperatorSqlGetBySearchTerms(txtWellOperatorCompanyNameSearch.Text.Trim(), txtWellOperatorContactNameSearch.Text.Trim(), txtWellOperatorCitySearch.Text.Trim());

            _wellOperatorDataTable = new DataTable("WellOperator");
            _wellOperatorDataTable.Columns.Add(new DataColumn("WellOperatorId", _wellOperators[0].WellOperatorId.GetType()));
            _wellOperatorDataTable.Columns[0].Caption = "Well Operator Id ";
            _wellOperatorDataTable.Columns[0].ReadOnly = true;
            _wellOperatorDataTable.Columns.Add(new DataColumn("WellOperatorCompanyName", _wellOperators[0].WellOperatorCompanyName.GetType()));
            _wellOperatorDataTable.Columns[1].Caption = "Well Operator Company Name ";
            _wellOperatorDataTable.Columns[1].ReadOnly = true;
            _wellOperatorDataTable.Columns.Add(new DataColumn("WellOperatorStreetAddress", _wellOperators[0].WellOperatorStreetAddress.GetType()));
            _wellOperatorDataTable.Columns[2].Caption = "Well Operator Street Address ";
            _wellOperatorDataTable.Columns[2].ReadOnly = true;
            _wellOperatorDataTable.Columns.Add(new DataColumn("WellOperatorBoxAddress", _wellOperators[0].WellOperatorBoxAddress.GetType()));
            _wellOperatorDataTable.Columns[3].Caption = "Well Operator Box Address ";
            _wellOperatorDataTable.Columns[3].ReadOnly = true;
            _wellOperatorDataTable.Columns.Add(new DataColumn("WellOperatorCity", _wellOperators[0].WellOperatorCity.GetType()));
            _wellOperatorDataTable.Columns[4].Caption = "Well Operator City ";
            _wellOperatorDataTable.Columns[4].ReadOnly = true;
            _wellOperatorDataTable.Columns.Add(new DataColumn("WellOperatorContactName", _wellOperators[0].WellOperatorContactName.GetType()));
            _wellOperatorDataTable.Columns[4].Caption = "Well Operator Contact Name ";
            _wellOperatorDataTable.Columns[4].ReadOnly = true;
            foreach (WellOperator item in _wellOperators)
            {
                object[] gridItems = new object[6] { item.WellOperatorId, item.WellOperatorCompanyName, item.WellOperatorStreetAddress, item.WellOperatorBoxAddress, item.WellOperatorCity, item.WellOperatorContactName };
                _wellOperatorDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvWellOperators.DataSource = _wellOperatorDataTable;
            gvWellOperators.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains(" % ")) return searchTerm.Trim();
            return " % " + searchTerm.Trim() + " % ";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.WellOperatorDataGridClearEvent != null)
            {
                this.WellOperatorDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.WellOperatorDataGridSearchEvent != null)
            {
                this.WellOperatorDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvWellOperators_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvWellOperators.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.WellOperatorDataGridRowSelectedEvent != null)
            {
                this.WellOperatorDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
