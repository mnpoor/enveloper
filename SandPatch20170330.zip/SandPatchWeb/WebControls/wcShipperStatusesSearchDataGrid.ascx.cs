using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcShipperStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler ShipperStatusDataGridClearEvent;
        public event SPEventHandler ShipperStatusDataGridSearchEvent;
        public event SPEventHandler ShipperStatusDataGridRowSelectedEvent;

        private Collection<ShipperStatus> _shipperStatuses = new Collection<ShipperStatus>();

        private DataTable _shipperStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void ShipperStatusDataGridClear()
        {
        }

        public void ShipperStatusDataGridSearch()
        {
            Collection<ShipperStatus> itemCollection = new Collection<ShipperStatus>();

            _shipperStatuses = DataServiceShipperStatuses.ShipperStatusSqlGetAll();

            _shipperStatusDataTable = new DataTable("ShipperStatus");
            _shipperStatusDataTable.Columns.Add(new DataColumn("ShipperStatusId", _shipperStatuses[0].ShipperStatusId.GetType()));
            _shipperStatusDataTable.Columns[0].Caption = "ShipperStatusId ";
            _shipperStatusDataTable.Columns[0].ReadOnly = true;
            _shipperStatusDataTable.Columns.Add(new DataColumn("ShipperStatusDescription", _shipperStatuses[0].ShipperStatusDescription.GetType()));
            _shipperStatusDataTable.Columns[1].Caption = "ShipperStatusDescription ";
            _shipperStatusDataTable.Columns[1].ReadOnly = true;
            foreach (ShipperStatus item in _shipperStatuses)
            {
                object[] gridItems = new object[2] { item.ShipperStatusId, item.ShipperStatusDescription };
                _shipperStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvShipperStatuses.DataSource = _shipperStatusDataTable;
            gvShipperStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.ShipperStatusDataGridClearEvent != null)
            {
                this.ShipperStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.ShipperStatusDataGridSearchEvent != null)
            {
                this.ShipperStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvShipperStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvShipperStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.ShipperStatusDataGridRowSelectedEvent != null)
            {
                this.ShipperStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
