using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDriverWithholding : System.Web.UI.UserControl
    {
        public event SPEventHandler DriverWithholdingClearEvent;
        public event SPEventHandler DriverWithholdingAddEvent;
        public event SPEventHandler DriverWithholdingUpdateEvent;
        public event SPEventHandler DriverWithholdingDeleteEvent;

        private DriverWithholding _driverWithholding;
        private Collection<DriverWithholding> _driverWithholdings;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void DriverWithholdingClear()
        {
            _driverWithholding = null;

            txtDriverWitholdingId.Text = string.Empty;
            txtCarrierId.Text = string.Empty;
            txtDriverId.Text = string.Empty;
            txtWithholdingAccountId.Text = string.Empty;
            txtDriverWitholdingLedgerAccountName.Text = string.Empty;
            txtDriverWitholdingLedgerAccountNumber.Text = string.Empty;
            txtWithholdingAmount.Text = string.Empty;
            txtWithholdingPercentage.Text = string.Empty;
            txtLicencePlateMonth.Text = string.Empty;
            txtFirstTransactionDate.Text = string.Empty;
            txtLastTransactionDate.Text = string.Empty;
        }

        public void DriverWithholdingShow(DriverWithholding d)
        {
            _driverWithholding = new DriverWithholding(d);

            txtDriverWitholdingId.Text = d.DriverWitholdingId.ToString();
            txtCarrierId.Text = d.CarrierId.ToString();
            txtDriverId.Text = d.DriverId.ToString();
            txtWithholdingAccountId.Text = d.WithholdingAccountId.ToString();
            txtDriverWitholdingLedgerAccountName.Text = d.DriverWitholdingLedgerAccountName;
            txtDriverWitholdingLedgerAccountNumber.Text = d.DriverWitholdingLedgerAccountNumber;
            txtWithholdingAmount.Text = d.WithholdingAmount.ToString();
            txtWithholdingPercentage.Text = d.WithholdingPercentage.ToString();
            txtLicencePlateMonth.Text = d.LicencePlateMonth.ToString();
            txtFirstTransactionDate.Text = d.FirstTransactionDate.ToShortDateString();
            txtLastTransactionDate.Text = d.LastTransactionDate.ToShortDateString();
        }

        public void DriverWithholdingUpdate(ref DriverWithholding d)
        {
            try
            {
                d.DriverWitholdingId = Convert.ToInt32(txtDriverWitholdingId.Text);
            }
            catch
            {
                d.DriverWitholdingId = 0;
            }
            try
            {
                d.CarrierId = Convert.ToInt32(txtCarrierId.Text);
            }
            catch
            {
                d.CarrierId = 0;
            }
            try
            {
                d.DriverId = Convert.ToInt32(txtDriverId.Text);
            }
            catch
            {
                d.DriverId = 0;
            }
            try
            {
                d.WithholdingAccountId = Convert.ToInt32(txtWithholdingAccountId.Text);
            }
            catch
            {
                d.WithholdingAccountId = 0;
            }
            d.DriverWitholdingLedgerAccountName = txtDriverWitholdingLedgerAccountName.Text;
            d.DriverWitholdingLedgerAccountNumber = txtDriverWitholdingLedgerAccountNumber.Text;
            try
            {
                d.WithholdingAmount = Convert.ToDecimal(txtWithholdingAmount.Text);
            }
            catch
            {
                d.WithholdingAmount = 0;
            }
            try
            {
                d.WithholdingPercentage = Convert.ToDecimal(txtWithholdingPercentage.Text);
            }
            catch
            {
                d.WithholdingPercentage = 0;
            }
            try
            {
                d.LicencePlateMonth = Convert.ToInt32(txtLicencePlateMonth.Text);
            }
            catch
            {
                d.LicencePlateMonth = 0;
            }
            try
            {
                d.FirstTransactionDate = Convert.ToDateTime(txtFirstTransactionDate.Text);
            }
            catch
            {
                d.FirstTransactionDate = new DateTime();
            }
            try
            {
                d.LastTransactionDate = Convert.ToDateTime(txtLastTransactionDate.Text);
            }
            catch
            {
                d.LastTransactionDate = new DateTime();
            }
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DriverWithholdingClearEvent != null)
            {
                this.DriverWithholdingClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.DriverWithholdingAddEvent != null)
            {
                this.DriverWithholdingAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.DriverWithholdingUpdateEvent != null)
            {
                this.DriverWithholdingUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.DriverWithholdingDeleteEvent != null)
            {
                this.DriverWithholdingDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
