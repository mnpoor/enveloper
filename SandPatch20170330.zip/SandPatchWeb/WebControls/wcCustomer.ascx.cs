using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCustomer : System.Web.UI.UserControl
    {
        public event SPEventHandler CustomerClearEvent;
        public event SPEventHandler CustomerAddEvent;
        public event SPEventHandler CustomerUpdateEvent;
        public event SPEventHandler CustomerDeleteEvent;

        private Customer _customer;
        private Collection<Customer> _customers;

        private Collection<CustomerStatus> _customerStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CustomerStatusesCount
        {
            get
            {
                return cmbCustomerStatus.Items.Count;
            }
        }

        public void CustomerStatusesFill(Collection<CustomerStatus> customerStatuses)
        {
            if (cmbCustomerStatus.Items.Count < 1)
            {
                _customerStatuses = new Collection<CustomerStatus>(customerStatuses);
                foreach (CustomerStatus item in _customerStatuses)
                {
                    cmbCustomerStatus.Items.Add(new ListItem(item.CustomerStatusDescription, item.CustomerStatusId.ToString()));
                }
                cmbCustomerStatus.DataBind();
            }
        }

        public void CustomerClear()
        {
            _customer = null;

            txtCustomerId.Text = string.Empty;
            txtCustomerName.Text = string.Empty;
            txtContactName.Text = string.Empty;
            txtStreetAddress.Text = string.Empty;
            txtBoxAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtCustomerState.Text = string.Empty;
            txtPostalCode.Text = string.Empty;
            txtCustomerStatusId.Text = string.Empty;
            txtPhoneNumber.Text = string.Empty;
            txtFaxNumber.Text = string.Empty;
            txtMobileNumber.Text = string.Empty;
            txtCustomerWebURL.Text = string.Empty;
            txtContactEmailAddress.Text = string.Empty;
            txtCustomerNotes.Text = string.Empty;
        }

        public void CustomerShow(Customer c)
        {
            _customer = new Customer(c);

            txtCustomerId.Text = c.CustomerId.ToString();
            txtCustomerName.Text = c.CustomerName;
            txtContactName.Text = c.ContactName;
            txtStreetAddress.Text = c.StreetAddress;
            txtBoxAddress.Text = c.BoxAddress;
            txtCity.Text = c.City;
            txtCustomerState.Text = c.CustomerState;
            txtPostalCode.Text = c.PostalCode;
            txtCustomerStatusId.Text = c.CustomerStatusId.ToString();
            try
            {
                cmbCustomerStatus.SelectedValue = c.CustomerStatusId.ToString();
            }
            catch
            {
                cmbCustomerStatus.SelectedValue = "0";
            }
            txtPhoneNumber.Text = c.PhoneNumber;
            txtFaxNumber.Text = c.FaxNumber;
            txtMobileNumber.Text = c.MobileNumber;
            txtCustomerWebURL.Text = c.CustomerWebURL;
            txtContactEmailAddress.Text = c.ContactEmailAddress;
            txtCustomerNotes.Text = c.CustomerNotes;
        }

        protected void cmbCustomerStatus_TextChanged(object sender, EventArgs e)
        {
            if (cmbCustomerStatus.Items.Count > 0)
            {
                txtCustomerStatusId.Text = cmbCustomerStatus.SelectedValue;
            }
        }

        public void CustomerUpdate(ref Customer c)
        {
            try
            {
                c.CustomerId = Convert.ToInt32(txtCustomerId.Text);
            }
            catch
            {
                c.CustomerId = 0;
            }
            c.CustomerName = txtCustomerName.Text;
            c.ContactName = txtContactName.Text;
            c.StreetAddress = txtStreetAddress.Text;
            c.BoxAddress = txtBoxAddress.Text;
            c.City = txtCity.Text;
            c.CustomerState = txtCustomerState.Text;
            c.PostalCode = txtPostalCode.Text;
            c.CustomerStatusId = Convert.ToInt32(txtCustomerStatusId.Text);
            c.PhoneNumber = txtPhoneNumber.Text;
            c.FaxNumber = txtFaxNumber.Text;
            c.MobileNumber = txtMobileNumber.Text;
            c.CustomerWebURL = txtCustomerWebURL.Text;
            c.ContactEmailAddress = txtContactEmailAddress.Text;
            c.CustomerNotes = txtCustomerNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CustomerClearEvent != null)
            {
                this.CustomerClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.CustomerAddEvent != null)
            {
                this.CustomerAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.CustomerUpdateEvent != null)
            {
                this.CustomerUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.CustomerDeleteEvent != null)
            {
                this.CustomerDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
