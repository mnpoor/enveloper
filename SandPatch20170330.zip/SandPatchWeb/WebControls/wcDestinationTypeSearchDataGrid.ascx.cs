using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDestinationTypeSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DestinationTypeDataGridClearEvent;
        public event SPEventHandler DestinationTypeDataGridSearchEvent;
        public event SPEventHandler DestinationTypeDataGridRowSelectedEvent;

        private Collection<DestinationType> _destinationTypes = new Collection<DestinationType>();

        private DataTable _destinationTypeDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void DestinationTypeDataGridClear()
        {
            txtDestinationTypeIdSearch.Text = string.Empty;
            txtDestinationTypeDescriptionSearch.Text = string.Empty;
           //gvDestinationTypes.; // clears data grid - not implemented
        }

        public void DestinationTypeDataGridSearch()
        {
            Collection<DestinationType> itemCollection = new Collection<DestinationType>();

            txtDestinationTypeIdSearch.Text = ApplyWildcards(txtDestinationTypeIdSearch.Text);
            txtDestinationTypeDescriptionSearch.Text = ApplyWildcards(txtDestinationTypeDescriptionSearch.Text);

            _destinationTypes = DataServiceDestinationTypes.DestinationTypeSqlGetAll();

            _destinationTypeDataTable = new DataTable("DestinationType");
            _destinationTypeDataTable.Columns.Add(new DataColumn("DestinationTypeId", _destinationTypes[0].DestinationTypeId.GetType()));
            _destinationTypeDataTable.Columns[0].Caption = "DestinationTypeId ";
            _destinationTypeDataTable.Columns[0].ReadOnly = true;
            _destinationTypeDataTable.Columns.Add(new DataColumn("DestinationTypeDescription", _destinationTypes[0].DestinationTypeDescription.GetType()));
            _destinationTypeDataTable.Columns[1].Caption = "DestinationTypeDescription ";
            _destinationTypeDataTable.Columns[1].ReadOnly = true;
            foreach (DestinationType item in _destinationTypes)
            {
                object[] gridItems = new object[2] { item.DestinationTypeId, item.DestinationTypeDescription };
                _destinationTypeDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvDestinationTypes.DataSource = _destinationTypeDataTable;
            gvDestinationTypes.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DestinationTypeDataGridClearEvent != null)
            {
                this.DestinationTypeDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.DestinationTypeDataGridSearchEvent != null)
            {
                this.DestinationTypeDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvDestinationTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvDestinationTypes.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.DestinationTypeDataGridRowSelectedEvent != null)
            {
                this.DestinationTypeDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
