using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCarrierStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler CarrierStatusDataGridClearEvent;
        public event SPEventHandler CarrierStatusDataGridSearchEvent;
        public event SPEventHandler CarrierStatusDataGridRowSelectedEvent;

        private Collection<CarrierStatus> _carrierStatuses = new Collection<CarrierStatus>();

        private DataTable _carrierStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void CarrierStatusDataGridClear()
        {
           //gvCarrierStatuss.; // clears data grid - not implemented
        }

        public void CarrierStatusDataGridSearch()
        {
            Collection<CarrierStatus> itemCollection = new Collection<CarrierStatus>();

            _carrierStatuses = DataServiceCarrierStatuses.CarrierStatusSqlGetAll();

            _carrierStatusDataTable = new DataTable("CarrierStatus");
            _carrierStatusDataTable.Columns.Add(new DataColumn("CarrierStatusId", _carrierStatuses[0].CarrierStatusId.GetType()));
            _carrierStatusDataTable.Columns[0].Caption = "CarrierStatusId ";
            _carrierStatusDataTable.Columns[0].ReadOnly = true;
            _carrierStatusDataTable.Columns.Add(new DataColumn("CarrierStatusDescription", _carrierStatuses[0].CarrierStatusDescription.GetType()));
            _carrierStatusDataTable.Columns[1].Caption = "CarrierStatusDescription ";
            _carrierStatusDataTable.Columns[1].ReadOnly = true;
            foreach (CarrierStatus item in _carrierStatuses)
            {
                object[] gridItems = new object[2] { item.CarrierStatusId, item.CarrierStatusDescription };
                _carrierStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvCarrierStatuss.DataSource = _carrierStatusDataTable;
            gvCarrierStatuss.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains(" % ")) return searchTerm.Trim();
            return " % " + searchTerm.Trim() + " % ";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CarrierStatusDataGridClearEvent != null)
            {
                this.CarrierStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.CarrierStatusDataGridSearchEvent != null)
            {
                this.CarrierStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvCarrierStatuss_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvCarrierStatuss.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.CarrierStatusDataGridRowSelectedEvent != null)
            {
                this.CarrierStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
