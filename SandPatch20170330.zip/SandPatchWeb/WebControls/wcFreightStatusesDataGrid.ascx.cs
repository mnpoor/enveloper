using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcFreightStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler FreightStatusClearEvent;
        public event SPEventHandler FreightStatusAddEvent;
        public event SPEventHandler FreightStatusUpdateEvent;
        public event SPEventHandler FreightStatusDeleteEvent;

        private FreightStatus _freightStatus;
        private Collection<FreightStatus> _freightStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void FreightStatusClear()
        {
            _freightStatus = null;

            txtFreightStatusId.Text = string.Empty;
            txtFreightStatusDescription.Text = string.Empty;
        }

        public void FreightStatusShow(FreightStatus f)
        {
            _freightStatus = new FreightStatus(f);

            txtFreightStatusId.Text = f.FreightStatusId.ToString();
            txtFreightStatusDescription.Text = f.FreightStatusDescription;
        }

        public void FreightStatusUpdate(ref FreightStatus f)
        {
            try
            {
                f.FreightStatusId = Convert.ToInt32(txtFreightStatusId.Text);
            }
            catch
            {
                f.FreightStatusId = 0;
            }
            try
            {
                f.FreightStatusId = Convert.ToInt32(txtFreightStatusId.Text);
            }
            catch
            {
                f.FreightStatusId = 0;
            }
            f.FreightStatusDescription = txtFreightStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.FreightStatusClearEvent != null)
            {
                this.FreightStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.FreightStatusAddEvent != null)
            {
                this.FreightStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.FreightStatusUpdateEvent != null)
            {
                this.FreightStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.FreightStatusDeleteEvent != null)
            {
                this.FreightStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
