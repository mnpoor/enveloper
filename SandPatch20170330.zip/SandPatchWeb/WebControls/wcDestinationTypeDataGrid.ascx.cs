using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDestinationTypeDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DestinationTypeClearEvent;
        public event SPEventHandler DestinationTypeAddEvent;
        public event SPEventHandler DestinationTypeUpdateEvent;
        public event SPEventHandler DestinationTypeDeleteEvent;

        private DestinationType _destinationType;
        private Collection<DestinationType> _destinationTypes;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void DestinationTypeClear()
        {
            _destinationType = null;

            txtDestinationTypeId.Text = string.Empty;
            txtDestinationTypeDescription.Text = string.Empty;
        }

        public void DestinationTypeShow(DestinationType d)
        {
            _destinationType = new DestinationType(d);

            txtDestinationTypeId.Text = d.DestinationTypeId.ToString();
            txtDestinationTypeDescription.Text = d.DestinationTypeDescription;
        }

        public void DestinationTypeUpdate(ref DestinationType d)
        {
            try
            {
                d.DestinationTypeId = Convert.ToInt32(txtDestinationTypeId.Text);
            }
            catch
            {
                d.DestinationTypeId = 0;
            }
            try
            {
                d.DestinationTypeId = Convert.ToInt32(txtDestinationTypeId.Text);
            }
            catch
            {
                d.DestinationTypeId = 0;
            }
            d.DestinationTypeDescription = txtDestinationTypeDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DestinationTypeClearEvent != null)
            {
                this.DestinationTypeClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.DestinationTypeAddEvent != null)
            {
                this.DestinationTypeAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.DestinationTypeUpdateEvent != null)
            {
                this.DestinationTypeUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.DestinationTypeDeleteEvent != null)
            {
                this.DestinationTypeDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
