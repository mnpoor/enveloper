using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobSite : System.Web.UI.UserControl
    {
        public event SPEventHandler JobSiteClearEvent;
        public event SPEventHandler JobSiteAddEvent;
        public event SPEventHandler JobSiteUpdateEvent;
        public event SPEventHandler JobSiteDeleteEvent;

        private JobSite _jobSite;
        private Collection<JobSite> _jobSites;

        private Collection<JobSiteStatus> _jobSiteStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int JobSiteStatusesCount
        {
            get
            {
                return cmbJobSiteStatus.Items.Count;
            }
        }

        public void JobSiteStatusesFill(Collection<JobSiteStatus> jobSiteStatuses)
        {
            if (cmbJobSiteStatus.Items.Count < 1)
            {
                _jobSiteStatuses = new Collection<JobSiteStatus>(jobSiteStatuses);
                foreach (JobSiteStatus item in _jobSiteStatuses)
                {
                    cmbJobSiteStatus.Items.Add(new ListItem(item.JobSiteStatusDescription, item.JobSiteStatusId.ToString()));
                }
                cmbJobSiteStatus.DataBind();
            }
        }

        public void JobSiteClear()
        {
            _jobSite = null;

            txtJobSiteId.Text = string.Empty;
            txtJobSiteName.Text = string.Empty;
            txtWellOperatorId.Text = string.Empty;
            txtJobSiteContactName.Text = string.Empty;
            txtStreetAddress.Text = string.Empty;
            txtBoxAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtJobSiteState.Text = string.Empty;
            txtPostalCode.Text = string.Empty;
            txtCountryCode.Text = string.Empty;
            txtJobSiteStatusId.Text = string.Empty;
            cmbJobSiteStatus.SelectedValue = "0";
            txtJobSitePhoneNumber.Text = string.Empty;
            txtJobSiteFaxNumber.Text = string.Empty;
            txtJobSiteContactEmail.Text = string.Empty;
            txtJobSiteContactMobileNumber.Text = string.Empty;
            txtJobSiteLatitude.Text = string.Empty;
            txtJobSiteLongitude.Text = string.Empty;
            txtJobSiteDrivingDirections.Text = string.Empty;
            txtJobSiteNotes.Text = string.Empty;
        }

        public void JobSiteShow(JobSite j)
        {
            _jobSite = new JobSite(j);

            txtJobSiteId.Text = j.JobSiteId.ToString();
            txtJobSiteName.Text = j.JobSiteName;
            txtWellOperatorId.Text = j.WellOperatorId.ToString();
            txtJobSiteContactName.Text = j.JobSiteContactName;
            txtStreetAddress.Text = j.StreetAddress;
            txtBoxAddress.Text = j.BoxAddress;
            txtCity.Text = j.City;
            txtJobSiteState.Text = j.JobSiteState;
            txtPostalCode.Text = j.PostalCode;
            txtCountryCode.Text = j.CountryCode;
            txtJobSiteStatusId.Text = j.JobSiteStatusId.ToString();
            try
            {
                cmbJobSiteStatus.SelectedValue = j.JobSiteStatusId.ToString();
            }
            catch
            {
                cmbJobSiteStatus.SelectedValue = "0";
            }
            txtJobSitePhoneNumber.Text = j.JobSitePhoneNumber;
            txtJobSiteFaxNumber.Text = j.JobSiteFaxNumber;
            txtJobSiteContactEmail.Text = j.JobSiteContactEmail;
            txtJobSiteContactMobileNumber.Text = j.JobSiteContactMobileNumber;
            txtJobSiteLatitude.Text = j.JobSiteLatitude;
            txtJobSiteLongitude.Text = j.JobSiteLongitude;
            txtJobSiteDrivingDirections.Text = j.JobSiteDrivingDirections;
            txtJobSiteNotes.Text = j.JobSiteNotes;
        }

        protected void cmbJobSiteStatus_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobSiteStatus.Items.Count > 0)
            {
                txtJobSiteStatusId.Text = cmbJobSiteStatus.SelectedValue;
            }
        }

        public void JobSiteUpdate(ref JobSite j)
        {
            try
            {
                j.JobSiteId = Convert.ToInt32(txtJobSiteId.Text);
            }
            catch
            {
                j.JobSiteId = 0;
            }
            j.JobSiteName = txtJobSiteName.Text;
            try
            {
                j.WellOperatorId = Convert.ToInt32(txtWellOperatorId.Text);
            }
            catch
            {
                j.WellOperatorId = 0;
            }
            j.JobSiteContactName = txtJobSiteContactName.Text;
            j.StreetAddress = txtStreetAddress.Text;
            j.BoxAddress = txtBoxAddress.Text;
            j.City = txtCity.Text;
            j.JobSiteState = txtJobSiteState.Text;
            j.PostalCode = txtPostalCode.Text;
            j.CountryCode = txtCountryCode.Text;
            try
            {
                j.JobSiteStatusId = Convert.ToInt32(txtJobSiteStatusId.Text);
            }
            catch
            {
                j.JobSiteStatusId = 0;
            }
            j.JobSitePhoneNumber = txtJobSitePhoneNumber.Text;
            j.JobSiteFaxNumber = txtJobSiteFaxNumber.Text;
            j.JobSiteContactEmail = txtJobSiteContactEmail.Text;
            j.JobSiteContactMobileNumber = txtJobSiteContactMobileNumber.Text;
            j.JobSiteLatitude = txtJobSiteLatitude.Text;
            j.JobSiteLongitude = txtJobSiteLongitude.Text;
            j.JobSiteDrivingDirections = txtJobSiteDrivingDirections.Text;
            j.JobSiteNotes = txtJobSiteNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobSiteClearEvent != null)
            {
                this.JobSiteClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.JobSiteAddEvent != null)
            {
                this.JobSiteAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.JobSiteUpdateEvent != null)
            {
                this.JobSiteUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.JobSiteDeleteEvent != null)
            {
                this.JobSiteDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
