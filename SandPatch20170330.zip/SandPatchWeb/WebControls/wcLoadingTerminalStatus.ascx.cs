using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcLoadingTerminalStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler LoadingTerminalStatusClearEvent;
        public event SPEventHandler LoadingTerminalStatusAddEvent;
        public event SPEventHandler LoadingTerminalStatusUpdateEvent;
        public event SPEventHandler LoadingTerminalStatusDeleteEvent;

        private LoadingTerminalStatus _loadingTerminalStatus;
        private Collection<LoadingTerminalStatus> _loadingTerminalStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void LoadingTerminalStatusClear()
        {
            _loadingTerminalStatus = null;

            txtLoadingTerminalStatusId.Text = string.Empty;
            txtLoadingTerminalStatusDescription.Text = string.Empty;
        }

        public void LoadingTerminalStatusShow(LoadingTerminalStatus l)
        {
            _loadingTerminalStatus = new LoadingTerminalStatus(l);

            txtLoadingTerminalStatusId.Text = l.LoadingTerminalStatusId.ToString();
            txtLoadingTerminalStatusDescription.Text = l.LoadingTerminalStatusDescription;
        }

        public void LoadingTerminalStatusUpdate(ref LoadingTerminalStatus l)
        {
            try
            {
                l.LoadingTerminalStatusId = Convert.ToInt32(txtLoadingTerminalStatusId.Text);
            }
            catch
            {
                l.LoadingTerminalStatusId = 0;
            }
            try
            {
                l.LoadingTerminalStatusId = Convert.ToInt32(txtLoadingTerminalStatusId.Text);
            }
            catch
            {
                l.LoadingTerminalStatusId = 0;
            }
            l.LoadingTerminalStatusDescription = txtLoadingTerminalStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.LoadingTerminalStatusClearEvent != null)
            {
                this.LoadingTerminalStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.LoadingTerminalStatusAddEvent != null)
            {
                this.LoadingTerminalStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.LoadingTerminalStatusUpdateEvent != null)
            {
                this.LoadingTerminalStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.LoadingTerminalStatusDeleteEvent != null)
            {
                this.LoadingTerminalStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
