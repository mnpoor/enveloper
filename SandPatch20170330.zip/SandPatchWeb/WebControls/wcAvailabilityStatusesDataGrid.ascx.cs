using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcAvailabilityStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler AvailabilityStatusClearEvent;
        public event SPEventHandler AvailabilityStatusAddEvent;
        public event SPEventHandler AvailabilityStatusUpdateEvent;
        public event SPEventHandler AvailabilityStatusDeleteEvent;

        private AvailabilityStatus _availabilityStatus;
        private Collection<AvailabilityStatus> _availabilityStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void AvailabilityStatusClear()
        {
            _availabilityStatus = null;

            txtAvailabilityStatusId.Text = string.Empty;
            txtAvailabilityStatusDescription.Text = string.Empty;
            txtAvailabilityColorCode.Text = string.Empty;
        }

        public void AvailabilityStatusShow(AvailabilityStatus a)
        {
            _availabilityStatus = new AvailabilityStatus(a);

            txtAvailabilityStatusId.Text = a.AvailabilityStatusId.ToString();
            txtAvailabilityStatusDescription.Text = a.AvailabilityStatusDescription;
            txtAvailabilityColorCode.Text = a.AvailabilityColorCode;
        }

        public void AvailabilityStatusUpdate(ref AvailabilityStatus a)
        {
            try
            {
                a.AvailabilityStatusId = Convert.ToInt32(txtAvailabilityStatusId.Text);
            }
            catch
            {
                a.AvailabilityStatusId = 0;
            }
            a.AvailabilityStatusDescription = txtAvailabilityStatusDescription.Text;
            a.AvailabilityColorCode = txtAvailabilityColorCode.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.AvailabilityStatusClearEvent != null)
            {
                this.AvailabilityStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.AvailabilityStatusAddEvent != null)
            {
                this.AvailabilityStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.AvailabilityStatusUpdateEvent != null)
            {
                this.AvailabilityStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.AvailabilityStatusDeleteEvent != null)
            {
                this.AvailabilityStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
