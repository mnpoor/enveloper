using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobSiteSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler JobSiteDataGridClearEvent;
        public event SPEventHandler JobSiteDataGridSearchEvent;
        public event SPEventHandler JobSiteDataGridPageIndexChangingEvent;
        public event SPEventHandler JobSiteDataGridRowSelectedEvent;

        private JobSiteStatus _foundJobSiteStatus;

        private Collection<JobSite> _jobSites = new Collection<JobSite>();

        private DataTable _jobSiteDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void JobSiteDataGridClear()
        {
            txtCustomerNameSearch.Text = string.Empty;
            txtJobSiteNameSearch.Text = string.Empty;
            _jobSiteDataTable = new DataTable("JobSite");
            gvJobSites.DataSource = _jobSiteDataTable;
            gvJobSites.DataBind();
        }

        public string[] JobSiteDataGridWildcard()
        {
            txtCustomerNameSearch.Text = ApplyWildcards(txtCustomerNameSearch.Text);
            txtJobSiteNameSearch.Text = ApplyWildcards(txtJobSiteNameSearch.Text);
            return new string[] { txtCustomerNameSearch.Text.Trim(), txtJobSiteNameSearch.Text.Trim() };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void JobSiteDataGridSearch(Collection<JobSite> itemCollection, int pageIndex)
        {
            _jobSites = new Collection<JobSite>(itemCollection);
            GridViewFill(pageIndex);
        }

        public void GridViewFill(int pageIndex)
        {
            _jobSiteDataTable = new DataTable("JobSite");
            _jobSiteDataTable.Columns.Add(new DataColumn("JobSiteId", typeof(string)));
            _jobSiteDataTable.Columns[0].Caption = "JobSiteId";
            _jobSiteDataTable.Columns[0].ReadOnly = true;
            _jobSiteDataTable.Columns.Add(new DataColumn("JobSiteName", typeof(string)));
            _jobSiteDataTable.Columns[1].Caption = "JobSiteName";
            _jobSiteDataTable.Columns[1].ReadOnly = true;
            _jobSiteDataTable.Columns.Add(new DataColumn("JobSiteStatus", typeof(string)));
            _jobSiteDataTable.Columns[2].Caption = "JobSiteStatus";
            _jobSiteDataTable.Columns[2].ReadOnly = true;
            _jobSiteDataTable.Columns.Add(new DataColumn("JobSitePhoneNumber", typeof(string)));
            _jobSiteDataTable.Columns[3].Caption = "JobSitePhoneNumber";
            _jobSiteDataTable.Columns[3].ReadOnly = true;

            foreach (JobSite item in _jobSites)
            {
                object[] gridItems = new object[4] { item.JobSiteId.ToString(), item.JobSiteName, (_foundJobSiteStatus == null ? "* Unassigned *" : _foundJobSiteStatus.JobSiteStatusDescription),
                        item.JobSitePhoneNumber };
                _jobSiteDataTable.LoadDataRow(gridItems, true);
            }
            
            gvJobSites.Columns.Clear();
            BoundField column0 = new BoundField();
            column0.HeaderText = "Id";
            column0.DataField = "JobSiteId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            gvJobSites.Columns.Add(column0);

            BoundField column1 = new BoundField();
            column1.HeaderText = "Name";
            column1.DataField = "JobSiteName";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;
            gvJobSites.Columns.Add(column1);

            BoundField column2 = new BoundField();
            column2.HeaderText = "Status";
            column2.DataField = "JobSiteStatus";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;
            gvJobSites.Columns.Add(column2);

            BoundField column3 = new BoundField();
            column3.HeaderText = "Phone Number";
            column3.DataField = "JobSitePhoneNumber";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;
            gvJobSites.Columns.Add(column3);

            gvJobSites.DataSource = _jobSiteDataTable;
            gvJobSites.PageIndex = pageIndex;
            gvJobSites.DataBind();
            gvJobSites.Width = new Unit((int)700);

            _jobSiteDataTable = new DataTable("JobSite");     // empty out data table
            _jobSites = new Collection<JobSite>();           // empty out collection
            GC.Collect();                                       // consolidate heap space
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobSiteDataGridClearEvent != null)
            {
                this.JobSiteDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.JobSiteDataGridSearchEvent != null)
            {
                this.JobSiteDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvJobSites_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.JobSiteDataGridPageIndexChangingEvent != null)
            {
                this.JobSiteDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvJobSites_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvJobSites.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.JobSiteDataGridRowSelectedEvent != null)
            {
                this.JobSiteDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
