using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCarrierSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler CarrierDataGridClearEvent;
        public event SPEventHandler CarrierDataGridSearchEvent;
        public event SPEventHandler CarrierDataGridRowSelectedEvent;

        private Collection<Carrier> _carriers = new Collection<Carrier>();

        private DataTable _carrierDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click +=new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void CarrierDataGridClear()
        {
            txtCarrierCompanyNameSearch.Text = string.Empty;
            txtCarrierContactNameSearch.Text = string.Empty;
            txtCarrierCitySearch.Text = string.Empty;
            _carrierDataTable = new DataTable("Carrier");
            gvCarriers.DataSource = _carrierDataTable;
            gvCarriers.DataBind();
        }

        public void CarrierDataGridSearch()
        {
            int rowCount = 0;
            Collection<Carrier> itemCollection = new Collection<Carrier>();

            txtCarrierCompanyNameSearch.Text = ApplyWildcards(txtCarrierCompanyNameSearch.Text);
            txtCarrierContactNameSearch.Text = ApplyWildcards(txtCarrierContactNameSearch.Text);
            txtCarrierCitySearch.Text = ApplyWildcards(txtCarrierCitySearch.Text);

            _carriers = DataServiceCarriers.CarrierSqlGetBySearchTerms(txtCarrierCompanyNameSearch.Text.Trim(), txtCarrierContactNameSearch.Text.Trim(), txtCarrierCitySearch.Text.Trim());

            _carrierDataTable = new DataTable("Carrier");
            _carrierDataTable.Columns.Add(new DataColumn("CarrierId", typeof(string)));
            _carrierDataTable.Columns[0].Caption = " Id ";
            _carrierDataTable.Columns[0].ReadOnly = true;
            _carrierDataTable.Columns.Add(new DataColumn("CompanyName", typeof(string)));
            _carrierDataTable.Columns[1].Caption = " Company Name ";
            _carrierDataTable.Columns[1].ReadOnly = true;
            _carrierDataTable.Columns.Add(new DataColumn("StreetAddress", typeof(string)));
            _carrierDataTable.Columns[2].Caption = " Street Address ";
            _carrierDataTable.Columns[2].ReadOnly = true;
            _carrierDataTable.Columns.Add(new DataColumn("BoxAddress", typeof(string)));
            _carrierDataTable.Columns[3].Caption = " Box Address ";
            _carrierDataTable.Columns[3].ReadOnly = true;
            _carrierDataTable.Columns.Add(new DataColumn("City", typeof(string)));
            _carrierDataTable.Columns[4].Caption = " City ";
            _carrierDataTable.Columns[4].ReadOnly = true;
            _carrierDataTable.Columns.Add(new DataColumn("ContactName", typeof(string)));
            _carrierDataTable.Columns[5].Caption = " Contact Name ";
            _carrierDataTable.Columns[5].ReadOnly = true;
            foreach (Carrier item in _carriers)
            {
                object[] gridItems = new object[6] { item.CarrierId.ToString(), item.CarrierCompanyName, item.CarrierStreetAddress, item.CarrierBoxAddress, item.CarrierCity, item.CarrierContactName };
                _carrierDataTable.LoadDataRow(gridItems, true);
                rowCount++;
                if (rowCount > 35) break;
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            BoundField column0 = new BoundField();
            column0.HeaderText = "Id";
            column0.DataField = "CarrierId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            //column0.Visible = false;

            //column0.ButtonType = ButtonType.Link;
            //column0.SelectText = "Select";
            //column0.ShowSelectButton = true;
            //column0.ShowHeader = true;

            //HiddenField column1h = new HiddenField();
            //column1h.ID = "CarrierId";

            //TemplateBuilder hiddenColumnTemplateBuilder = new TemplateBuilder();
            //ControlBuilder hiddenControlBuilder = new ControlBuilder();
            
            //TemplateField column1 = new TemplateField();

            //column1 = (TemplateField)hiddenColumnTemplateBuilder.BuildObject();
            //column1.ItemTemplate = new TemplateBuilder();
            //column0.ValidateSupportsCallback();
            //column0.DataNavigateUrlFields = new string[] { "CarrierId" };
            //column0.DataNavigateUrlFormatString = "~/webFormCarrier.aspx?id={0}";
            //column0.DataTextField = "CarrierId";
            //column0.DataTextFormatString = "{0}";            
            //column0.Target = "_blank";

            BoundField column2 = new BoundField();
            column2.HeaderText = "Company Name";
            column2.DataField = "CompanyName";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;

            BoundField column3 = new BoundField();
            column3.HeaderText = "Street Address";
            column3.DataField = "StreetAddress";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;

            BoundField column4 = new BoundField();
            column4.HeaderText = "Box Address";
            column4.DataField = "BoxAddress";
            column4.DataFormatString = "{0}";
            column4.ReadOnly = true;

            BoundField column5 = new BoundField();
            column5.HeaderText = "City";
            column5.DataField = "City";
            column5.DataFormatString = "{0}";
            column5.ReadOnly = true;

            BoundField column6 = new BoundField();
            column6.HeaderText = "Contact Name";
            column6.DataField = "ContactName";
            column6.DataFormatString = "{0}";
            column6.ReadOnly = true;

            gvCarriers.Columns.Clear();
            gvCarriers.Columns.Add(column0);
            //gvCarriers.Columns.Add(column1);
            gvCarriers.Columns.Add(column2);
            gvCarriers.Columns.Add(column3);
            gvCarriers.Columns.Add(column4);
            gvCarriers.Columns.Add(column5);
            gvCarriers.Columns.Add(column6);

            /*
            //if ((string)gridItems[0] != string.Empty) _dispatchPanelDataTable.LoadDataRow(gridItems, true);

            HyperLinkField column0 = new HyperLinkField();
            column0.HeaderText = "CarrierId";
            column0.DataNavigateUrlFields = new string[] {"CarrierId"};
            column0.DataNavigateUrlFormatString = "~/webFormDispatchEdit.aspx?id={0}";
            column0.DataTextField = "CarrierId";
            column0.DataTextFormatString = "{0}";            
            column0.Target = "_blank";

            //BoundField column1 = new BoundField();
            //column1.HeaderText = "Job Number";
            //column1.DataField = "JobNumber1";
            //column1.DataFormatString = "{0}";
            //column1.ReadOnly = true;

            //BoundField column2 = new BoundField();
            //column2.HeaderText = "Job Site Name";
            //column2.DataField = "JobSiteName1";
            //column2.DataFormatString = "{0}";
            //column2.ReadOnly = true;

            //BoundField column3 = new BoundField();
            //column3.HeaderText = "Status";
            //column3.DataField = "Status1";
            //column3.DataFormatString = "{0}";
            //column3.ReadOnly = true;

            //DropDownList availabilityStatus1 = new DropDownList();
            //foreach (AvailabilityStatus item in _availabilityStatuses)
            //{
            //    ListItem statusItem = new ListItem(item.AvailabilityStatusDescription, item.AvailabilityStatusId.ToString());
            //    availabilityStatus1.Items.Add(statusItem);
            //}
            //TemplateField column3a = new TemplateField();
            ////column3a.ItemTemplate.InstantiateIn()

            //TemplateField column4 = new TemplateField();
            //column4.HeaderText = " ";
            
            //HyperLinkField column5 = new HyperLinkField();
            //column5.HeaderText = "Truck";
            //column5.DataNavigateUrlFields = new string[] { "TruckNumber2" };
            //column5.DataNavigateUrlFormatString = "~/webFormDispatchEdit.aspx?id={0}";
            //column5.DataTextField = "TruckNumber2";
            //column5.DataTextFormatString = "{0}";
            //column5.Target = "_blank";

            //BoundField column6 = new BoundField();
            //column6.HeaderText = "Job Number";
            //column6.DataField = "JobNumber2";
            //column6.DataFormatString = "{0}";
            //column6.ReadOnly = true;

            //BoundField column7 = new BoundField();
            //column7.HeaderText = "Job Site Name";
            //column7.DataField = "JobSiteName2";
            //column7.DataFormatString = "{0}";
            //column7.ReadOnly = true;

            //BoundField column8 = new BoundField();
            //column8.HeaderText = "Status";
            //column8.DataField = "Status2";
            //column8.DataFormatString = "{0}";
            //column8.ReadOnly = true;

            //TemplateField column9 = new TemplateField();
            //column9.HeaderText = " ";
            
            //HyperLinkField column10 = new HyperLinkField();
            //column10.HeaderText = "Truck";
            //column10.DataNavigateUrlFields = new string[] { "TruckNumber3" };
            //column10.DataNavigateUrlFormatString = "~/webFormDispatchEdit.aspx?id={0}";
            //column10.DataTextField = "TruckNumber3";
            //column10.DataTextFormatString = "{0}";
            //column10.Target = "_blank";

            //BoundField column11 = new BoundField();
            //column11.HeaderText = "Job Number";
            //column11.DataField = "JobNumber3";
            //column11.DataFormatString = "{0}";
            //column11.ReadOnly = true;

            //BoundField column12 = new BoundField();
            //column12.HeaderText = "Job Site Name";
            //column12.DataField = "JobSiteName3";
            //column12.DataFormatString = "{0}";
            //column12.ReadOnly = true;

            //BoundField column13 = new BoundField();
            //column13.HeaderText = "Status";
            //column13.DataField = "Status3";
            //column13.DataFormatString = "{0}";
            //column13.ReadOnly = true;

            //gvDispatchPanel.Columns.Clear();
            //gvDispatchPanel.Columns.Add(column0);
            //gvDispatchPanel.Columns.Add(column1);
            //gvDispatchPanel.Columns.Add(column2);
            //gvDispatchPanel.Columns.Add(column3);
            //gvDispatchPanel.Columns.Add(column4);
            //gvDispatchPanel.Columns.Add(column5);
            //gvDispatchPanel.Columns.Add(column6);
            //gvDispatchPanel.Columns.Add(column7);
            //gvDispatchPanel.Columns.Add(column8);
            //gvDispatchPanel.Columns.Add(column9);
            //gvDispatchPanel.Columns.Add(column10);
            //gvDispatchPanel.Columns.Add(column11);
            //gvDispatchPanel.Columns.Add(column12);
            //gvDispatchPanel.Columns.Add(column13);
            gvDispatchPanel.DataSource = _dispatchPanelDataTable;
            gvDispatchPanel.DataBind();
             */

            gvCarriers.DataSource = _carrierDataTable;
            gvCarriers.DataBind();
            gvCarriers.Width = new Unit((int)750);
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CarrierDataGridClearEvent != null)
            {
                this.CarrierDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.CarrierDataGridSearchEvent != null)
            {
                this.CarrierDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvCarriers_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvCarriers.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.CarrierDataGridRowSelectedEvent != null)
            {
                this.CarrierDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
