using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPayScheduleStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler PayScheduleStatusClearEvent;
        public event SPEventHandler PayScheduleStatusAddEvent;
        public event SPEventHandler PayScheduleStatusUpdateEvent;
        public event SPEventHandler PayScheduleStatusDeleteEvent;

        private PayScheduleStatus _payScheduleStatus;
        private Collection<PayScheduleStatus> _payScheduleStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void PayScheduleStatusClear()
        {
            _payScheduleStatus = null;

            txtPayScheduleStatusId.Text = string.Empty;
            txtPayScheduleStatusDescription.Text = string.Empty;
        }

        public void PayScheduleStatusShow(PayScheduleStatus p)
        {
            _payScheduleStatus = new PayScheduleStatus(p);

            txtPayScheduleStatusId.Text = p.PayScheduleStatusId.ToString();
            txtPayScheduleStatusDescription.Text = p.PayScheduleStatusDescription;
        }

        public void PayScheduleStatusUpdate(ref PayScheduleStatus p)
        {
            try
            {
                p.PayScheduleStatusId = Convert.ToInt32(txtPayScheduleStatusId.Text);
            }
            catch
            {
                p.PayScheduleStatusId = 0;
            }
            try
            {
                p.PayScheduleStatusId = Convert.ToInt32(txtPayScheduleStatusId.Text);
            }
            catch
            {
                p.PayScheduleStatusId = 0;
            }
            p.PayScheduleStatusDescription = txtPayScheduleStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PayScheduleStatusClearEvent != null)
            {
                this.PayScheduleStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.PayScheduleStatusAddEvent != null)
            {
                this.PayScheduleStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.PayScheduleStatusUpdateEvent != null)
            {
                this.PayScheduleStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.PayScheduleStatusDeleteEvent != null)
            {
                this.PayScheduleStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
