using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDriverSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DriverDataGridClearEvent;
        public event SPEventHandler DriverDataGridSearchEvent;
        public event SPEventHandler DriverDataGridRowSelectedEvent;

        private Carrier _foundCarrier = null;

        private Collection<Driver> _drivers = new Collection<Driver>();

        private DataTable _driverDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void DriverDataGridClear()
        {
            txtTruckNumberSearch.Text = string.Empty;
            txtCarrierCompanyNameSearch.Text = string.Empty;
            txtCarrierContactNameSearch.Text = string.Empty;
            txtDriverNameSearch.Text = string.Empty;
            _driverDataTable = new DataTable("Driver");
            gvDrivers.DataSource = _driverDataTable;
            gvDrivers.DataBind();
        }

        public void DriverDataGridSearch()
        {
            //int rowCount = 0;
            Collection<Driver> itemCollection = new Collection<Driver>();

            try
            {
                int truckNumber = Convert.ToInt32(txtTruckNumberSearch.Text);
            }
            catch
            {
                txtTruckNumberSearch.Text = string.Empty;
            }
            txtCarrierCompanyNameSearch.Text = ApplyWildcards(txtCarrierCompanyNameSearch.Text);
            txtCarrierContactNameSearch.Text = ApplyWildcards(txtCarrierContactNameSearch.Text);
            txtDriverNameSearch.Text = ApplyWildcards(txtDriverNameSearch.Text);

            _drivers = DataServiceDrivers.DriverSqlGetBySearchTerms(0, 0, txtTruckNumberSearch.Text.Trim(), txtCarrierCompanyNameSearch.Text.Trim(), txtCarrierContactNameSearch.Text.Trim(), txtDriverNameSearch.Text.Trim());

            GridViewFill(0);
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        protected void gvDrivers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            _drivers = DataServiceDrivers.DriverSqlGetBySearchTerms(0, 0, txtTruckNumberSearch.Text.Trim(), txtCarrierCompanyNameSearch.Text.Trim(), txtCarrierContactNameSearch.Text.Trim(), txtDriverNameSearch.Text.Trim());

            GridViewFill(e.NewPageIndex);
        }

        protected void GridViewFill(int pageIndex)
        {
            _driverDataTable = new DataTable("Driver");
            _driverDataTable.Columns.Add(new DataColumn(" Id ", typeof(string)));
            _driverDataTable.Columns[0].Caption = " Id ";
            _driverDataTable.Columns[0].ReadOnly = true;
            _driverDataTable.Columns.Add(new DataColumn(" Truck Number ", typeof(string)));
            _driverDataTable.Columns[1].Caption = " Truck Number ";
            _driverDataTable.Columns[1].ReadOnly = true;
            _driverDataTable.Columns.Add(new DataColumn(" Carrier Name ", typeof(string)));
            _driverDataTable.Columns[2].Caption = "Carrier Name ";
            _driverDataTable.Columns[2].ReadOnly = true;
            _driverDataTable.Columns.Add(new DataColumn(" Driver Name ", typeof(string)));
            _driverDataTable.Columns[3].Caption = " Driver Name ";
            _driverDataTable.Columns[3].ReadOnly = true;
            _driverDataTable.Columns.Add(new DataColumn(" Driver Telephone Number ", typeof(string)));
            _driverDataTable.Columns[4].Caption = " Driver Telephone Number ";
            _driverDataTable.Columns[4].ReadOnly = true;
            foreach (Driver item in _drivers)
            {
                _foundCarrier = DataServiceCarriers.CarrierSqlGetById(item.CarrierId);
                object[] gridItems = new object[5] { item.DriverId.ToString(), item.TruckNumber.ToString(),
                    (_foundCarrier == null ? "* Missing *" : _foundCarrier.CarrierCompanyName), item.DriverName, item.DriverTelephoneNumber };
                _driverDataTable.LoadDataRow(gridItems, true);
                //rowCount++;
                //if (rowCount > 35) break;
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvDrivers.DataSource = _driverDataTable;
            gvDrivers.PageIndex = pageIndex;
            gvDrivers.DataBind();
            gvDrivers.Width = new Unit((int)750);
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DriverDataGridClearEvent != null)
            {
                this.DriverDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.DriverDataGridSearchEvent != null)
            {
                this.DriverDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvDrivers_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvDrivers.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.DriverDataGridRowSelectedEvent != null)
            {
                this.DriverDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
