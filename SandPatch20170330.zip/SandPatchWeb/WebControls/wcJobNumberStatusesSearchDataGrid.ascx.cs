using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobNumberStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler JobNumberStatusDataGridClearEvent;
        public event SPEventHandler JobNumberStatusDataGridSearchEvent;
        public event SPEventHandler JobNumberStatusDataGridRowSelectedEvent;

        private Collection<JobNumberStatus> _jobNumberStatuses = new Collection<JobNumberStatus>();

        private DataTable _jobNumberStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void JobNumberStatusDataGridClear()
        {
            txtJobNumberStatusIdSearch.Text = string.Empty;
            txtJobNumberStatusDescriptionSearch.Text = string.Empty;
           //gvJobNumberStatuss.; // clears data grid - not implemented
        }

        public void JobNumberStatusDataGridSearch()
        {
            Collection<JobNumberStatus> itemCollection = new Collection<JobNumberStatus>();

            txtJobNumberStatusIdSearch.Text = ApplyWildcards(txtJobNumberStatusIdSearch.Text);
            txtJobNumberStatusDescriptionSearch.Text = ApplyWildcards(txtJobNumberStatusDescriptionSearch.Text);

            _jobNumberStatuses = DataServiceJobNumberStatuses.JobNumberStatusSqlGetAll();

            _jobNumberStatusDataTable = new DataTable("JobNumberStatus");
            _jobNumberStatusDataTable.Columns.Add(new DataColumn("JobNumber Status Id ", _jobNumberStatuses[0].JobNumberStatusId.GetType()));
            _jobNumberStatusDataTable.Columns[0].Caption = "Job Number Status Id ";
            _jobNumberStatusDataTable.Columns[0].ReadOnly = true;
            _jobNumberStatusDataTable.Columns.Add(new DataColumn("Job Number Status Description ", _jobNumberStatuses[0].JobNumberStatusDescription.GetType()));
            _jobNumberStatusDataTable.Columns[1].Caption = "Job Number Status Description ";
            _jobNumberStatusDataTable.Columns[1].ReadOnly = true;
            foreach (JobNumberStatus item in _jobNumberStatuses)
            {
                object[] gridItems = new object[2] { item.JobNumberStatusId, item.JobNumberStatusDescription };
                _jobNumberStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvJobNumberStatuss.DataSource = _jobNumberStatusDataTable;
            gvJobNumberStatuss.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobNumberStatusDataGridClearEvent != null)
            {
                this.JobNumberStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.JobNumberStatusDataGridSearchEvent != null)
            {
                this.JobNumberStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvJobNumberStatuss_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvJobNumberStatuss.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.JobNumberStatusDataGridRowSelectedEvent != null)
            {
                this.JobNumberStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
