using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPurchaseOrderStatusesDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler PurchaseOrderStatusClearEvent;
        public event SPEventHandler PurchaseOrderStatusAddEvent;
        public event SPEventHandler PurchaseOrderStatusUpdateEvent;
        public event SPEventHandler PurchaseOrderStatusDeleteEvent;

        private PurchaseOrderStatus _purchaseOrderStatus;
        private Collection<PurchaseOrderStatus> _purchaseOrderStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void PurchaseOrderStatusClear()
        {
            _purchaseOrderStatus = null;

            txtPurchaseOrderStatusId.Text = string.Empty;
            txtPurchaseOrderStatusDescription.Text = string.Empty;
        }

        public void PurchaseOrderStatusShow(PurchaseOrderStatus p)
        {
            _purchaseOrderStatus = new PurchaseOrderStatus(p);

            txtPurchaseOrderStatusId.Text = p.PurchaseOrderStatusId.ToString();
            txtPurchaseOrderStatusDescription.Text = p.PurchaseOrderStatusDescription;
        }

        public void PurchaseOrderStatusUpdate(ref PurchaseOrderStatus p)
        {
            try
            {
                p.PurchaseOrderStatusId = Convert.ToInt32(txtPurchaseOrderStatusId.Text);
            }
            catch
            {
                p.PurchaseOrderStatusId = 0;
            }
            try
            {
                p.PurchaseOrderStatusId = Convert.ToInt32(txtPurchaseOrderStatusId.Text);
            }
            catch
            {
                p.PurchaseOrderStatusId = 0;
            }
            p.PurchaseOrderStatusDescription = txtPurchaseOrderStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PurchaseOrderStatusClearEvent != null)
            {
                this.PurchaseOrderStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.PurchaseOrderStatusAddEvent != null)
            {
                this.PurchaseOrderStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.PurchaseOrderStatusUpdateEvent != null)
            {
                this.PurchaseOrderStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.PurchaseOrderStatusDeleteEvent != null)
            {
                this.PurchaseOrderStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
