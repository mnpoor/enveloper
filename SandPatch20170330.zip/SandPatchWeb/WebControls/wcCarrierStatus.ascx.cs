using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCarrierStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler CarrierStatusClearEvent;
        public event SPEventHandler CarrierStatusAddEvent;
        public event SPEventHandler CarrierStatusUpdateEvent;
        public event SPEventHandler CarrierStatusDeleteEvent;

        private CarrierStatus _carrierStatus;
        private Collection<CarrierStatus> _carrierStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void CarrierStatusClear()
        {
            _carrierStatus = null;

            txtCarrierStatusId.Text = string.Empty;
            txtCarrierStatusDescription.Text = string.Empty;
        }

        public void CarrierStatusShow(CarrierStatus c)
        {
            _carrierStatus = new CarrierStatus(c);

            txtCarrierStatusId.Text = c.CarrierStatusId.ToString();
            txtCarrierStatusDescription.Text = c.CarrierStatusDescription;
        }

        public void CarrierStatusUpdate(ref CarrierStatus c)
        {
            try
            {
                c.CarrierStatusId = Convert.ToInt32(txtCarrierStatusId.Text);
            }
            catch
            {
                c.CarrierStatusId = 0;
            }
            c.CarrierStatusDescription = txtCarrierStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CarrierStatusClearEvent != null)
            {
                this.CarrierStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.CarrierStatusAddEvent != null)
            {
                this.CarrierStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.CarrierStatusUpdateEvent != null)
            {
                this.CarrierStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.CarrierStatusDeleteEvent != null)
            {
                this.CarrierStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
