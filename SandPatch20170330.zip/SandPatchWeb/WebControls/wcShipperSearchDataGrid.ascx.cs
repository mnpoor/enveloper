using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcShipperSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler ShipperDataGridClearEvent;
        public event SPEventHandler ShipperDataGridSearchEvent;
        public event SPEventHandler ShipperDataGridRowSelectedEvent;

        private Collection<Shipper> _shippers = new Collection<Shipper>();

        private DataTable _shipperDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void ShipperDataGridClear()
        {
            txtShipperCompanyNameSearch.Text = string.Empty;
            txtShipperContactNameSearch.Text = string.Empty;
           //gvShippers.; // clears data grid - not implemented
        }

        public void ShipperDataGridSearch()
        {
            Collection<Shipper> itemCollection = new Collection<Shipper>();

            txtShipperCompanyNameSearch.Text = ApplyWildcards(txtShipperCompanyNameSearch.Text);
            txtShipperContactNameSearch.Text = ApplyWildcards(txtShipperCompanyNameSearch.Text);

            _shippers = DataServiceShippers.ShipperSqlGetBySearchTerms(txtShipperCompanyNameSearch.Text.Trim(), txtShipperContactNameSearch.Text.Trim());

            _shipperDataTable = new DataTable("Shipper");
            _shipperDataTable.Columns.Add(new DataColumn("ShipperId", _shippers[0].ShipperId.GetType()));
            _shipperDataTable.Columns[0].Caption = "Shipper Id ";
            _shipperDataTable.Columns[0].ReadOnly = true;
            _shipperDataTable.Columns.Add(new DataColumn("ShipperCompanyName", _shippers[0].ShipperCompanyName.GetType()));
            _shipperDataTable.Columns[1].Caption = "Shipper Company Name ";
            _shipperDataTable.Columns[1].ReadOnly = true;
            _shipperDataTable.Columns.Add(new DataColumn("ShipperCity", _shippers[0].ShipperCity.GetType()));
            _shipperDataTable.Columns[2].Caption = "Shipper City ";
            _shipperDataTable.Columns[2].ReadOnly = true;
            _shipperDataTable.Columns.Add(new DataColumn("ShipperContactName", _shippers[0].ShipperContactName.GetType()));
            _shipperDataTable.Columns[3].Caption = "Shipper Contact Name ";
            _shipperDataTable.Columns[3].ReadOnly = true;
            _shipperDataTable.Columns.Add(new DataColumn("ShipperPhoneNumber", _shippers[0].ShipperPhoneNumber.GetType()));
            _shipperDataTable.Columns[4].Caption = "Shipper Phone Number ";
            _shipperDataTable.Columns[4].ReadOnly = true;
            foreach (Shipper item in _shippers)
            {
                object[] gridItems = new object[5] { item.ShipperId, item.ShipperCompanyName, item.ShipperCity, item.ShipperContactName, item.ShipperPhoneNumber };
                _shipperDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvShippers.DataSource = _shipperDataTable;
            gvShippers.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.ShipperDataGridClearEvent != null)
            {
                this.ShipperDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.ShipperDataGridSearchEvent != null)
            {
                this.ShipperDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvShippers_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvShippers.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.ShipperDataGridRowSelectedEvent != null)
            {
                this.ShipperDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
