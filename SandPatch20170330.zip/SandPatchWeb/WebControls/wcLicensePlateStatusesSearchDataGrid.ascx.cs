using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcLicensePlateStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler LicensePlateStatusDataGridClearEvent;
        public event SPEventHandler LicensePlateStatusDataGridSearchEvent;
        public event SPEventHandler LicensePlateStatusDataGridRowSelectedEvent;

        private Collection<LicensePlateStatus> _licensePlateStatuses = new Collection<LicensePlateStatus>();

        private DataTable _licensePlateStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void LicensePlateStatusDataGridClear()
        {
        }

        public void LicensePlateStatusDataGridSearch()
        {
            Collection<LicensePlateStatus> itemCollection = new Collection<LicensePlateStatus>();

            _licensePlateStatuses = DataServiceLicensePlateStatuses.LicensePlateStatusSqlGetAll();

            _licensePlateStatusDataTable = new DataTable("LicensePlateStatus");
            _licensePlateStatusDataTable.Columns.Add(new DataColumn("LicensePlateStatusId", _licensePlateStatuses[0].LicensePlateStatusId.GetType()));
            _licensePlateStatusDataTable.Columns[0].Caption = "LicensePlateStatusId ";
            _licensePlateStatusDataTable.Columns[0].ReadOnly = true;
            _licensePlateStatusDataTable.Columns.Add(new DataColumn("LicensePlateStatusDescription", _licensePlateStatuses[0].LicensePlateStatusDescription.GetType()));
            _licensePlateStatusDataTable.Columns[1].Caption = "LicensePlateStatusDescription ";
            _licensePlateStatusDataTable.Columns[1].ReadOnly = true;
            foreach (LicensePlateStatus item in _licensePlateStatuses)
            {
                object[] gridItems = new object[2] { item.LicensePlateStatusId, item.LicensePlateStatusDescription };
                _licensePlateStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvLicensePlateStatuses.DataSource = _licensePlateStatusDataTable;
            gvLicensePlateStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.LicensePlateStatusDataGridClearEvent != null)
            {
                this.LicensePlateStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.LicensePlateStatusDataGridSearchEvent != null)
            {
                this.LicensePlateStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvLicensePlateStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvLicensePlateStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.LicensePlateStatusDataGridRowSelectedEvent != null)
            {
                this.LicensePlateStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
