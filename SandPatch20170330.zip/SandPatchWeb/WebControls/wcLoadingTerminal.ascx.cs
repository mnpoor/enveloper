using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcLoadingTerminal : System.Web.UI.UserControl
    {
        public event SPEventHandler LoadingTerminalClearEvent;
        public event SPEventHandler LoadingTerminalAddEvent;
        public event SPEventHandler LoadingTerminalUpdateEvent;
        public event SPEventHandler LoadingTerminalDeleteEvent;

        private LoadingTerminal _loadingTerminal;
        private Collection<LoadingTerminal> _loadingTerminals;

        private Collection<LoadingTerminalStatus> _loadingTerminalStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int LoadingTerminalStatusesCount
        {
            get
            {
                return cmbLoadingTerminalStatus.Items.Count;
            }
        }

        public void LoadingTerminalStatusesFill(Collection<LoadingTerminalStatus> loadingTerminalStatuses)
        {
            if (cmbLoadingTerminalStatus.Items.Count < 1)
            {
                _loadingTerminalStatuses = new Collection<LoadingTerminalStatus>(loadingTerminalStatuses);
                foreach (LoadingTerminalStatus item in _loadingTerminalStatuses)
                {
                    cmbLoadingTerminalStatus.Items.Add(new ListItem(item.LoadingTerminalStatusDescription, item.LoadingTerminalStatusId.ToString()));
                }
                cmbLoadingTerminalStatus.DataBind();
            }
        }

        public void LoadingTerminalClear()
        {
            _loadingTerminal = null;

            txtLoadingTerminalId.Text = string.Empty;
            txtLoadingTerminalName.Text = string.Empty;
            txtContactName.Text = string.Empty;
            txtStreetAddress.Text = string.Empty;
            txtBoxAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtLoadingTerminalState.Text = string.Empty;
            txtPostalCode.Text = string.Empty;
            txtLoadingTerminalStatusId.Text = string.Empty;
            cmbLoadingTerminalStatus.SelectedValue = "0";
            txtPhoneNumber.Text = string.Empty;
            txtFaxNumber.Text = string.Empty;
            txtMobileNumber.Text = string.Empty;
            txtLoadingTerminalWebURL.Text = string.Empty;
            txtContactEmailAddress.Text = string.Empty;
            txtLoadingTerminalNotes.Text = string.Empty;
        }

        public void LoadingTerminalShow(LoadingTerminal l)
        {
            _loadingTerminal = new LoadingTerminal(l);

            txtLoadingTerminalId.Text = l.LoadingTerminalId.ToString();
            txtLoadingTerminalName.Text = l.LoadingTerminalName;
            txtContactName.Text = l.ContactName;
            txtStreetAddress.Text = l.StreetAddress;
            txtBoxAddress.Text = l.BoxAddress;
            txtCity.Text = l.City;
            txtLoadingTerminalState.Text = l.LoadingTerminalState;
            txtPostalCode.Text = l.PostalCode;
            txtLoadingTerminalStatusId.Text = l.LoadingTerminalStatusId.ToString();
            try
            {
                cmbLoadingTerminalStatus.SelectedValue = l.LoadingTerminalStatusId.ToString();
            }
            catch
            {
                cmbLoadingTerminalStatus.SelectedValue = "0";
            }
            txtPhoneNumber.Text = l.PhoneNumber;
            txtFaxNumber.Text = l.FaxNumber;
            txtMobileNumber.Text = l.MobileNumber;
            txtLoadingTerminalWebURL.Text = l.LoadingTerminalWebURL;
            txtContactEmailAddress.Text = l.ContactEmailAddress;
            txtLoadingTerminalNotes.Text = l.LoadingTerminalNotes;
        }

        protected void cmbLoadingTerminalStatus_TextChanged(object sender, EventArgs e)
        {
            if (cmbLoadingTerminalStatus.Items.Count > 0)
            {
                txtLoadingTerminalStatusId.Text = cmbLoadingTerminalStatus.SelectedValue;
            }
        }

        public void LoadingTerminalUpdate(ref LoadingTerminal l)
        {
            try
            {
                l.LoadingTerminalId = Convert.ToInt32(txtLoadingTerminalId.Text);
            }
            catch
            {
                l.LoadingTerminalId = 0;
            }
            try
            {
                l.LoadingTerminalId = Convert.ToInt32(txtLoadingTerminalId.Text);
            }
            catch
            {
                l.LoadingTerminalId = 0;
            }
            l.LoadingTerminalName = txtLoadingTerminalName.Text;
            l.ContactName = txtContactName.Text;
            l.StreetAddress = txtStreetAddress.Text;
            l.BoxAddress = txtBoxAddress.Text;
            l.City = txtCity.Text;
            l.LoadingTerminalState = txtLoadingTerminalState.Text;
            l.PostalCode = txtPostalCode.Text;
            try
            {
                l.LoadingTerminalStatusId = Convert.ToInt32(txtLoadingTerminalStatusId.Text);
            }
            catch
            {
                l.LoadingTerminalStatusId = 0;
            }
            l.PhoneNumber = txtPhoneNumber.Text;
            l.FaxNumber = txtFaxNumber.Text;
            l.MobileNumber = txtMobileNumber.Text;
            l.LoadingTerminalWebURL = txtLoadingTerminalWebURL.Text;
            l.ContactEmailAddress = txtContactEmailAddress.Text;
            l.LoadingTerminalNotes = txtLoadingTerminalNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.LoadingTerminalClearEvent != null)
            {
                this.LoadingTerminalClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.LoadingTerminalAddEvent != null)
            {
                this.LoadingTerminalAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.LoadingTerminalUpdateEvent != null)
            {
                this.LoadingTerminalUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.LoadingTerminalDeleteEvent != null)
            {
                this.LoadingTerminalDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
