using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPayScheduleStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler PayScheduleStatusDataGridClearEvent;
        public event SPEventHandler PayScheduleStatusDataGridSearchEvent;
        public event SPEventHandler PayScheduleStatusDataGridRowSelectedEvent;

        private Collection<PayScheduleStatus> _payScheduleStatuses = new Collection<PayScheduleStatus>();

        private DataTable _payScheduleStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void PayScheduleStatusDataGridClear()
        {
            _payScheduleStatusDataTable = new DataTable("PayScheduleStatus");
            gvPayScheduleStatuses.DataSource = _payScheduleStatusDataTable;
            gvPayScheduleStatuses.DataBind();
        }

        public void PayScheduleStatusDataGridSearch()
        {
            Collection<PayScheduleStatus> itemCollection = new Collection<PayScheduleStatus>();

            _payScheduleStatuses = DataServicePayScheduleStatuses.PayScheduleStatusSqlGetAll();

            _payScheduleStatusDataTable = new DataTable("PayScheduleStatus ");
            _payScheduleStatusDataTable.Columns.Add(new DataColumn("Pay Schedule Status Id ", typeof(string)));
            _payScheduleStatusDataTable.Columns[0].Caption = "Pay ScheduleStatus Id ";
            _payScheduleStatusDataTable.Columns[0].ReadOnly = true;
            _payScheduleStatusDataTable.Columns.Add(new DataColumn("Pay Schedule Status Description ", typeof(string)));
            _payScheduleStatusDataTable.Columns[1].Caption = "Pay Schedule Status Description ";
            _payScheduleStatusDataTable.Columns[1].ReadOnly = true;
            foreach (PayScheduleStatus item in _payScheduleStatuses)
            {
                object[] gridItems = new object[2] { item.PayScheduleStatusId, item.PayScheduleStatusDescription };
                _payScheduleStatusDataTable.LoadDataRow(gridItems, true);
            }
            gvPayScheduleStatuses.DataSource = _payScheduleStatusDataTable;
            gvPayScheduleStatuses.DataBind();
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PayScheduleStatusDataGridClearEvent != null)
            {
                this.PayScheduleStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.PayScheduleStatusDataGridSearchEvent != null)
            {
                this.PayScheduleStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvPayScheduleStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvPayScheduleStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.PayScheduleStatusDataGridRowSelectedEvent != null)
            {
                this.PayScheduleStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
