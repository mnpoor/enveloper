using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobNumberSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler JobNumberDataGridClearEvent;
        public event SPEventHandler JobNumberDataGridSearchEvent;
        public event SPEventHandler JobNumberDataGridPageIndexChangingEvent;
        public event SPEventHandler JobNumberDataGridRowSelectedEvent;

        private LoadingTerminal _loadingTerminal;
        private JobSite _jobSite;

        private Collection<JobNumber> _jobNumbers = new Collection<JobNumber>();

        private DataTable _jobNumberDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void JobNumberDataGridClear()
        {
            txtJobNumberAssignmentSearch.Text = string.Empty;
            txtJobDateFromSearch.Text = string.Empty;
            txtJobDateToSearch.Text = string.Empty;
            _jobNumberDataTable = new DataTable("JobNumber");
            gvJobNumbers.DataSource = _jobNumberDataTable;
            gvJobNumbers.DataBind();
        }

        public string[] JobNumberDataGridWildcard()
        {
            return new string[] { txtJobNumberAssignmentSearch.Text.Trim(), txtJobDateFromSearch.Text.Trim(), txtJobDateToSearch.Text.Trim() };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void JobNumberDataGridSearch(Collection<JobNumber> itemCollection, int pageIndex)
        {
            _jobNumbers = new Collection<JobNumber>(itemCollection);
            GridViewFill(pageIndex);
        }

        protected void GridViewFill(int pageIndex)
        {
            _jobNumberDataTable = new DataTable("JobNumber");
            _jobNumberDataTable.Columns.Add(new DataColumn("JobNumberId", typeof(string)));
            _jobNumberDataTable.Columns[0].Caption = " Id ";
            _jobNumberDataTable.Columns[0].ReadOnly = true;
            _jobNumberDataTable.Columns.Add(new DataColumn("JobNumberAssignment", typeof(string)));
            _jobNumberDataTable.Columns[1].Caption = " Job Number ";
            _jobNumberDataTable.Columns[1].ReadOnly = true;
            _jobNumberDataTable.Columns.Add(new DataColumn("JobNumberDate", typeof(string)));
            _jobNumberDataTable.Columns[2].Caption = " Job Date ";
            _jobNumberDataTable.Columns[2].ReadOnly = true;
            _jobNumberDataTable.Columns.Add(new DataColumn("StartTime", typeof(string)));
            _jobNumberDataTable.Columns[3].Caption = " Start Time ";
            _jobNumberDataTable.Columns[3].ReadOnly = true;
            _jobNumberDataTable.Columns.Add(new DataColumn("EndTime", typeof(string)));
            _jobNumberDataTable.Columns[4].Caption = " End Time ";
            _jobNumberDataTable.Columns[4].ReadOnly = true;
            _jobNumberDataTable.Columns.Add(new DataColumn("LoadOrigin", typeof(string)));
            _jobNumberDataTable.Columns[5].Caption = " Load Origin ";
            _jobNumberDataTable.Columns[5].ReadOnly = true;
            _jobNumberDataTable.Columns.Add(new DataColumn("LoadDestination", typeof(string)));
            _jobNumberDataTable.Columns[6].Caption = " Load Destination ";
            _jobNumberDataTable.Columns[6].ReadOnly = true;
            foreach (JobNumber item in _jobNumbers)
            {
                string pointOfOrigin = PointOfOriginName(item.OriginTypeId, item.OriginId);
                string destination = DestinationName(item.DestinationTypeId, item.DestinationId);
                object[] gridItems = new object[7] { item.JobNumberId.ToString(), item.JobNumberAssignment.ToString(), item.JobNumberDate.ToShortDateString(), item.StartTime.ToShortTimeString(), item.EndTime.ToShortTimeString(), pointOfOrigin, destination };
                _jobNumberDataTable.LoadDataRow(gridItems, true);
            }
            gvJobNumbers.Columns.Clear();
            BoundField column0 = new BoundField();
            column0.HeaderText = "Id";
            column0.DataField = "JobNumberId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            gvJobNumbers.Columns.Add(column0);

            BoundField column1 = new BoundField();
            column1.HeaderText = "Job Number";
            column1.DataField = "JobNumberAssignment";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;
            gvJobNumbers.Columns.Add(column1);

            BoundField column2 = new BoundField();
            column2.HeaderText = "Date";
            column2.DataField = "JobNumberDate";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;
            gvJobNumbers.Columns.Add(column2);

            BoundField column3 = new BoundField();
            column3.HeaderText = "Start Time";
            column3.DataField = "StartTime";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;
            gvJobNumbers.Columns.Add(column3);

            BoundField column4 = new BoundField();
            column4.HeaderText = "End Time";
            column4.DataField = "EndTime";
            column4.DataFormatString = "{0}";
            column4.ReadOnly = true;
            gvJobNumbers.Columns.Add(column4);

            BoundField column5 = new BoundField();
            column5.HeaderText = "Load Origin";
            column5.DataField = "LoadOrigin";
            column5.DataFormatString = "{0}";
            column5.ReadOnly = true;
            gvJobNumbers.Columns.Add(column5);

            BoundField column6 = new BoundField();
            column6.HeaderText = "Load Destination";
            column6.DataField = "LoadDestination";
            column6.DataFormatString = "{0}";
            column6.ReadOnly = true;
            gvJobNumbers.Columns.Add(column6);

            gvJobNumbers.DataSource = _jobNumberDataTable;
            gvJobNumbers.PageIndex = pageIndex;
            gvJobNumbers.DataBind();
            gvJobNumbers.Width = new Unit((int)900);

            _jobNumberDataTable = new DataTable("JobNumber");     // empty out data table
            _jobNumbers = new Collection<JobNumber>();           // empty out collection
            GC.Collect();                                       // consolidate heap space
        }

        private string PointOfOriginName(int pointOfOriginTypeId, int pointOfOriginId)
        {
            switch (pointOfOriginTypeId)
            {
                case 1:
                    {
                        _loadingTerminal = DataServiceLoadingTerminals.LoadingTerminalSqlGetById(pointOfOriginId);
                        if (_loadingTerminal == null) return "* Missing *";
                        return _loadingTerminal.LoadingTerminalName;
                    }
                case 2:
                    {
                        _jobSite = DataServiceJobSites.JobSiteSqlGetById(pointOfOriginId);
                        if (_jobSite == null) return "* Missing *";
                        return _jobSite.JobSiteName;
                    }
                case 3: return "Enroute";
            }
            return string.Empty;
        }

        private string DestinationName(int destinationTypeId, int destinationId)
        {
            switch (destinationTypeId)
            {
                case 1:
                    {
                        _jobSite = DataServiceJobSites.JobSiteSqlGetById(destinationId);
                        if (_jobSite == null) return "* Missing *";
                        return _jobSite.JobSiteName;
                    }
                case 2:
                    {
                        _loadingTerminal = DataServiceLoadingTerminals.LoadingTerminalSqlGetById(destinationId);
                        if (_loadingTerminal == null) return "* Missing *";
                        return _loadingTerminal.LoadingTerminalName;
                    }
            }
            return string.Empty;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobNumberDataGridClearEvent != null)
            {
                this.JobNumberDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.JobNumberDataGridSearchEvent != null)
            {
                this.JobNumberDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvJobNumbers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.JobNumberDataGridPageIndexChangingEvent != null)
            {
                this.JobNumberDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvJobNumbers_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvJobNumbers.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.JobNumberDataGridRowSelectedEvent != null)
            {
                this.JobNumberDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
