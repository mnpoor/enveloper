using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPurchaseOrder : System.Web.UI.UserControl
    {
        public event SPEventHandler PurchaseOrderClearEvent;
        public event SPEventHandler PurchaseOrderAddEvent;
        public event SPEventHandler PurchaseOrderUpdateEvent;
        public event SPEventHandler PurchaseOrderDeleteEvent;

        private PurchaseOrder _purchaseOrder;
        private Collection<PurchaseOrder> _purchaseOrders;

        private Collection<JobNumber> _jobNumbers;
        private Collection<Customer> _customers;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<Freight> _freights;
        private Collection<PurchaseOrderStatus> _purchaseOrderStatuses;
        private Collection<JobSite> _jobSites;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CustomerCount
        {
            get
            {
                return cmbCustomers.Items.Count;
            }
        }

        public int JobNumberCount
        {
            get
            {
                return cmbJobNumbers.Items.Count;
            }
        }

        public int LoadingTerminalCount
        {
            get
            {
                return cmbLoadingTerminals.Items.Count;
            }
        }

        public int FreightCount
        {
            get
            {
                return cmbFreights.Items.Count;
            }
        }

        public int PurchaseOrderStatusCount
        {
            get
            {
                return cmbPurchaseOrderStatuses.Items.Count;
            }
        }

        public int JobSiteCount
        {
            get
            {
                return cmbJobSites.Items.Count;
            }
        }

        public void CustomersFill(Collection<Customer> customers)
        {
            if (cmbCustomers.Items.Count < 1)
            {
                _customers = new Collection<Customer>(customers);
                foreach (Customer item in _customers)
                {
                    cmbCustomers.Items.Add(new ListItem(item.CustomerName.ToString(), item.CustomerId.ToString()));
                }
                cmbCustomers.DataBind();
            }
        }

        public void JobNumbersFill(Collection<JobNumber> jobNumbers)
        {
            if (cmbJobNumbers.Items.Count < 1)
            {
                _jobNumbers = new Collection<JobNumber>(jobNumbers);
                foreach (JobNumber item in _jobNumbers)
                {
                    cmbJobNumbers.Items.Add(new ListItem(item.JobNumberAssignment.ToString(), item.JobNumberId.ToString()));
                }
                cmbJobNumbers.DataBind();
            }
        }

        public void LoadingTerminalsFill(Collection<LoadingTerminal> loadingTerminals)
        {
            if (cmbLoadingTerminals.Items.Count < 1)
            {
                _loadingTerminals = new Collection<LoadingTerminal>(loadingTerminals);
                foreach (LoadingTerminal item in _loadingTerminals)
                {
                    cmbLoadingTerminals.Items.Add(new ListItem(item.LoadingTerminalName.ToString(), item.LoadingTerminalId.ToString()));
                }
                cmbLoadingTerminals.DataBind();
            }
        }

        public void FreightsFill(Collection<Freight> freights)
        {
            if (cmbFreights.Items.Count < 1)
            {
                _freights = new Collection<Freight>(freights);
                foreach (Freight item in _freights)
                {
                    cmbFreights.Items.Add(new ListItem(item.FreightName.ToString(), item.FreightId.ToString()));
                }
                cmbFreights.DataBind();
            }
        }

        public void PurchaseOrderStatusesFill(Collection<PurchaseOrderStatus> purchaseOrderStatuses)
        {
            if (cmbPurchaseOrderStatuses.Items.Count < 1)
            {
                _purchaseOrderStatuses = new Collection<PurchaseOrderStatus>(purchaseOrderStatuses);
                foreach (PurchaseOrderStatus item in _purchaseOrderStatuses)
                {
                    cmbPurchaseOrderStatuses.Items.Add(new ListItem(item.PurchaseOrderStatusDescription.ToString(), item.PurchaseOrderStatusId.ToString()));
                }
                cmbPurchaseOrderStatuses.DataBind();
            }
        }

        public void JobSitesFill(Collection<JobSite> jobSites)
        {
            if (cmbJobSites.Items.Count < 1)
            {
                _jobSites = new Collection<JobSite>(jobSites);
                foreach (JobSite item in _jobSites)
                {
                    cmbJobSites.Items.Add(new ListItem(item.JobSiteName.ToString(), item.JobSiteId.ToString()));
                }
                cmbJobSites.DataBind();
            }
        }

        public void PurchaseOrderClear()
        {
            _purchaseOrder = null;

            txtPurchaseOrderId.Text = string.Empty;
            txtPurchaseOrderNumber.Text = string.Empty;
            txtCustomerId.Text = string.Empty;
            cmbCustomers.SelectedValue = "0";
            txtJobNumberId.Text = string.Empty;
            cmbJobNumbers.SelectedValue = "0";
            txtPurchaseOrderDate.Text = string.Empty;
            txtLoadingTerminalId.Text = string.Empty;
            cmbLoadingTerminals.SelectedValue = "0";
            txtFreightId.Text = string.Empty;
            cmbFreights.SelectedValue = "0";
            txtPurchaseOrderStatusId.Text = string.Empty;
            cmbPurchaseOrderStatuses.SelectedValue = "0";
            txtMilesOneWay.Text = string.Empty;
            txtJobSiteId.Text = string.Empty;
            cmbJobSites.SelectedValue = "0";
            txtTotalOrderWeight.Text = string.Empty;
            txtShipmentWeight.Text = string.Empty;
            txtLoadCount.Text = string.Empty;
            txtLoadsAccepted.Text = string.Empty;
            txtWeightDelivered.Text = string.Empty;
            txtWeightRemaining.Text = string.Empty;
            txtPurchaseOrderCompletionDate.Text = string.Empty;
            txtShipmentWeightUndeliverable.Text = string.Empty;
            txtPurchaseOrderComments.Text = string.Empty;
        }

        public void PurchaseOrderShow(PurchaseOrder p)
        {
            _purchaseOrder = new PurchaseOrder(p);

            txtPurchaseOrderId.Text = p.PurchaseOrderId.ToString();
            txtPurchaseOrderNumber.Text = p.PurchaseOrderNumber;
            txtCustomerId.Text = p.CustomerId.ToString();
            try
            {
                cmbCustomers.SelectedValue = p.CustomerId.ToString();
            }
            catch
            {
                cmbCustomers.SelectedValue = "0";
            }
            txtJobNumberId.Text = p.JobNumberId.ToString();
            try
            {
                cmbJobNumbers.SelectedValue = p.JobNumberId.ToString();
            }
            catch
            {
                cmbJobNumbers.SelectedValue = "0";
            }
            txtPurchaseOrderDate.Text = p.PurchaseOrderDate.ToShortDateString();
            txtLoadingTerminalId.Text = p.LoadingTerminalId.ToString();
            try
            {
                cmbLoadingTerminals.SelectedValue = p.LoadingTerminalId.ToString();
            }
            catch
            {
                cmbLoadingTerminals.SelectedValue = "0";
            }
            txtFreightId.Text = p.FreightId.ToString();
            try
            {
                cmbFreights.SelectedValue = p.FreightId.ToString();
            }
            catch
            {
                cmbFreights.SelectedValue = "0";
            }
            txtPurchaseOrderStatusId.Text = p.PurchaseOrderStatusId.ToString();
            try
            {
                cmbPurchaseOrderStatuses.SelectedValue = p.PurchaseOrderStatusId.ToString();
            }
            catch
            {
                cmbPurchaseOrderStatuses.SelectedValue = "0";
            }
            txtMilesOneWay.Text = p.MilesOneWay.ToString();
            txtJobSiteId.Text = p.JobSiteId.ToString();
            try
            {
                cmbJobSites.SelectedValue = p.JobSiteId.ToString();
            }
            catch
            {
                cmbJobSites.SelectedValue = "0";
            }
            txtTotalOrderWeight.Text = p.TotalOrderWeight.ToString();
            txtShipmentWeight.Text = p.ShipmentWeight.ToString();
            txtLoadCount.Text = p.LoadCount.ToString();
            txtLoadsAccepted.Text = p.LoadsAccepted.ToString();
            txtWeightDelivered.Text = p.WeightDelivered.ToString();
            txtWeightRemaining.Text = p.WeightRemaining.ToString();
            txtPurchaseOrderCompletionDate.Text = p.PurchaseOrderCompletionDate.ToShortDateString();
            txtShipmentWeightUndeliverable.Text = p.ShipmentWeightUndeliverable.ToString();
            txtPurchaseOrderComments.Text = p.PurchaseOrderComments;
        }

        protected void cmbCustomers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCustomers.Items.Count > 0)
            {
                txtCustomerId.Text = cmbCustomers.SelectedValue;
            }
        }

        protected void cmbJobNumbers_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobNumbers.Items.Count > 0)
            {
                txtJobNumberId.Text = cmbJobNumbers.SelectedValue;
            }
        }

        protected void cmbLoadingTerminals_TextChanged(object sender, EventArgs e)
        {
            if (cmbLoadingTerminals.Items.Count > 0)
            {
                txtLoadingTerminalId.Text = cmbLoadingTerminals.SelectedValue;
            }
        }

        protected void cmbFreights_TextChanged(object sender, EventArgs e)
        {
            if (cmbFreights.Items.Count > 0)
            {
                txtFreightId.Text = cmbFreights.SelectedValue;
            }
        }

        protected void cmbPurchaseOrderStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbPurchaseOrderStatuses.Items.Count > 0)
            {
                txtPurchaseOrderStatusId.Text = cmbPurchaseOrderStatuses.SelectedValue;
            }
        }

        protected void cmbJobSites_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobSites.Items.Count > 0)
            {
                txtJobSiteId.Text = cmbJobSites.SelectedValue;
            }
        }

        public void PurchaseOrderUpdate(ref PurchaseOrder p)
        {
            try
            {
                p.PurchaseOrderId = Convert.ToInt32(txtPurchaseOrderId.Text);
            }
            catch
            {
                p.PurchaseOrderId = 0;
            }
            p.PurchaseOrderNumber = txtPurchaseOrderNumber.Text;
            try
            {
                p.CustomerId = Convert.ToInt32(txtCustomerId.Text);
            }
            catch
            {
                p.CustomerId = 0;
            }
            try
            {
                p.JobNumberId = Convert.ToInt32(txtJobNumberId.Text);
            }
            catch
            {
                p.JobNumberId = 0;
            }
            try
            {
                p.PurchaseOrderDate = Convert.ToDateTime(txtPurchaseOrderDate.Text);
            }
            catch
            {
                p.PurchaseOrderDate = new DateTime();
            }
            try
            {
                p.LoadingTerminalId = Convert.ToInt32(txtLoadingTerminalId.Text);
            }
            catch
            {
                p.LoadingTerminalId = 0;
            }
            try
            {
                p.FreightId = Convert.ToInt32(txtFreightId.Text);
            }
            catch
            {
                p.FreightId = 0;
            }
            try
            {
                p.PurchaseOrderStatusId = Convert.ToInt32(txtPurchaseOrderStatusId.Text);
            }
            catch
            {
                p.PurchaseOrderStatusId = 0;
            }
            try
            {
                p.MilesOneWay = Convert.ToInt32(txtMilesOneWay.Text);
            }
            catch
            {
                p.MilesOneWay = 0;
            }
            try
            {
                p.JobSiteId = Convert.ToInt32(txtJobSiteId.Text);
            }
            catch
            {
                p.JobSiteId = 0;
            }
            try
            {
                p.TotalOrderWeight = Convert.ToDecimal(txtTotalOrderWeight.Text);
            }
            catch
            {
                p.TotalOrderWeight = 0;
            }
            try
            {
                p.ShipmentWeight = Convert.ToDecimal(txtShipmentWeight.Text);
            }
            catch
            {
                p.ShipmentWeight = 0;
            }
            try
            {
                p.LoadCount = Convert.ToInt32(txtLoadCount.Text);
            }
            catch
            {
                p.LoadCount = 0;
            }
            try
            {
                p.LoadsAccepted = Convert.ToInt32(txtLoadsAccepted.Text);
            }
            catch
            {
                p.LoadsAccepted = 0;
            }
            try
            {
                p.WeightDelivered = Convert.ToDecimal(txtWeightDelivered.Text);
            }
            catch
            {
                p.WeightDelivered = 0;
            }
            try
            {
                p.WeightRemaining = Convert.ToDecimal(txtWeightRemaining.Text);
            }
            catch
            {
                p.WeightRemaining = 0;
            }
            try
            {
                p.PurchaseOrderCompletionDate = Convert.ToDateTime(txtPurchaseOrderCompletionDate.Text);
            }
            catch
            {
                p.PurchaseOrderCompletionDate = new DateTime();
            }
            try
            {
                p.ShipmentWeightUndeliverable = Convert.ToDecimal(txtShipmentWeightUndeliverable.Text);
            }
            catch
            {
                p.ShipmentWeightUndeliverable = 0;
            }
            p.PurchaseOrderComments = txtPurchaseOrderComments.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PurchaseOrderClearEvent != null)
            {
                this.PurchaseOrderClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.PurchaseOrderAddEvent != null)
            {
                this.PurchaseOrderAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.PurchaseOrderUpdateEvent != null)
            {
                this.PurchaseOrderUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.PurchaseOrderDeleteEvent != null)
            {
                this.PurchaseOrderDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
