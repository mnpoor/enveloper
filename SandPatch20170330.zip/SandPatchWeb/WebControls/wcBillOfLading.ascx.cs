using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcBillOfLading : System.Web.UI.UserControl
    {
        public event SPEventHandler BillOfLadingClearEvent;
        public event SPEventHandler BillOfLadingAddEvent;
        public event SPEventHandler BillOfLadingUpdateEvent;
        public event SPEventHandler BillOfLadingDeleteEvent;

        private Collection<Customer> _customers;
        private Collection<JobNumber> _jobNumbers;
        private Collection<PurchaseOrder> _purchaseOrders;
        private Collection<Carrier> _carriers;
        private Collection<Driver> _drivers;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<Freight> _freights;
        private Collection<JobSite> _jobSites;
        private Collection<BillOfLadingStatus> _billOfLadingStatuses;

        private Driver _driver;

        private BillOfLading _billOfLading;
        private Collection<BillOfLading> _billOfLadings;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CustomerCount
        {
            get
            {
                return cmbCustomers.Items.Count;
            }
        }

        public int JobNumberCount
        {
            get
            {
                return cmbJobNumbers.Items.Count;
            }
        }

        public int PurchaseOrderCount
        {
            get
            {
                return cmbPurchaseOrders.Items.Count;
            }
        }

        public int CarrierCount
        {
            get
            {
                return cmbCarriers.Items.Count;
            }
        }

        public int DriverCount
        {
            get
            {
                return cmbDrivers.Items.Count;
            }
        }

        public int LoadingTerminalCount
        {
            get
            {
                return cmbLoadingTerminals.Items.Count;
            }
        }

        public int FreightCount
        {
            get
            {
                return cmbFreights.Items.Count;
            }
        }

        public int JobSiteCount
        {
            get
            {
                return cmbJobSites.Items.Count;
            }
        }

        public int BillOfLadingStatusCount
        {
            get
            {
                return cmbBillOfLadingStatuses.Items.Count;
            }
        }

        public void CustomersFill(Collection<Customer> customers)
        {
            if (cmbCustomers.Items.Count < 1)
            {
                _customers = new Collection<Customer>(customers);
                foreach (Customer item in _customers)
                {
                    cmbCustomers.Items.Add(new ListItem(item.CustomerName.ToString(), item.CustomerId.ToString()));
                }
                cmbCustomers.DataBind();
            }
        }

        public void JobNumbersFill(Collection<JobNumber> jobNumbers)
        {
            if (cmbJobNumbers.Items.Count < 1)
            {
                _jobNumbers = new Collection<JobNumber>(jobNumbers);
                foreach (JobNumber item in _jobNumbers)
                {
                    cmbJobNumbers.Items.Add(new ListItem(item.JobNumberAssignment.ToString(), item.JobNumberId.ToString()));
                }
                cmbJobNumbers.DataBind();
            }
        }

        public void PurchaseOrdersFill(Collection<PurchaseOrder> purchaseOrders)
        {
            if (cmbPurchaseOrders.Items.Count < 1)
            {
                _purchaseOrders = new Collection<PurchaseOrder>(purchaseOrders);
                foreach (PurchaseOrder item in _purchaseOrders)
                {
                    cmbPurchaseOrders.Items.Add(new ListItem(item.PurchaseOrderNumber.ToString(), item.PurchaseOrderId.ToString()));
                }
                cmbPurchaseOrders.DataBind();
            }
        }

        public void CarriersFill(Collection<Carrier> carriers)
        {
            if (cmbCarriers.Items.Count < 1)
            {
                _carriers = new Collection<Carrier>(carriers);
                foreach (Carrier item in _carriers)
                {
                    cmbCarriers.Items.Add(new ListItem(item.CarrierCompanyName, item.CarrierId.ToString()));
                }
                cmbCarriers.DataBind();
            }
        }

        public void DriversFill(Collection<Driver> drivers)
        {
            if (cmbDrivers.Items.Count < 1)
            {
                _drivers = new Collection<Driver>(drivers);
                foreach (Driver item in _drivers)
                {
                    cmbDrivers.Items.Add(new ListItem(item.DriverName, item.DriverId.ToString()));
                }
                cmbDrivers.DataBind();
            }
        }

        public void LoadingTerminalsFill(Collection<LoadingTerminal> loadingTerminals)
        {
            if (cmbLoadingTerminals.Items.Count < 1)
            {
                _loadingTerminals = new Collection<LoadingTerminal>(loadingTerminals);
                foreach (LoadingTerminal item in _loadingTerminals)
                {
                    cmbLoadingTerminals.Items.Add(new ListItem(item.LoadingTerminalName.ToString(), item.LoadingTerminalId.ToString()));
                }
                cmbLoadingTerminals.DataBind();
            }
        }

        public void FreightsFill(Collection<Freight> freights)
        {
            if (cmbFreights.Items.Count < 1)
            {
                _freights = new Collection<Freight>(freights);
                foreach (Freight item in _freights)
                {
                    cmbFreights.Items.Add(new ListItem(item.FreightName.ToString(), item.FreightId.ToString()));
                }
                cmbFreights.DataBind();
            }
        }

        public void JobSitesFill(Collection<JobSite> jobSites)
        {
            if (cmbJobSites.Items.Count < 1)
            {
                _jobSites = new Collection<JobSite>(jobSites);
                foreach (JobSite item in _jobSites)
                {
                    cmbJobSites.Items.Add(new ListItem(item.JobSiteName.ToString(), item.JobSiteId.ToString()));
                }
                cmbJobSites.DataBind();
            }
        }

        public void BillOfLadingStatusesFill(Collection<BillOfLadingStatus> billOfLadingStatuses)
        {
            if (cmbBillOfLadingStatuses.Items.Count < 1)
            {
                _billOfLadingStatuses = new Collection<BillOfLadingStatus>(billOfLadingStatuses);
                foreach (BillOfLadingStatus item in _billOfLadingStatuses)
                {
                    cmbBillOfLadingStatuses.Items.Add(new ListItem(item.BillOfLadingStatusDescription.ToString(), item.BillOfLadingStatusId.ToString()));
                }
                cmbBillOfLadingStatuses.DataBind();
            }
        }

        public void BillOfLadingClear()
        {
            _billOfLading = null;

            txtBillOfLadingId.Text = string.Empty;
            txtCustomerId.Text = string.Empty;
            cmbCustomers.SelectedValue = "0";
            txtJobNumberId.Text = string.Empty;
            cmbJobNumbers.SelectedValue = "0";
            txtPurchaseOrderId.Text = string.Empty;
            cmbPurchaseOrders.SelectedValue = "0";
            txtBillOfLadingNumber.Text = string.Empty;
            txtCarrierId.Text = string.Empty;
            cmbCarriers.SelectedValue = "0";
            txtDriverId.Text = string.Empty;
            cmbDrivers.SelectedValue = "0";
            txtTruckNumber.Text = string.Empty;
            txtLoadingTerminalId.Text = string.Empty;
            cmbLoadingTerminals.SelectedValue = "0";
            txtFreightId.Text = string.Empty;            
            cmbFreights.SelectedValue = "0";
            txtTicketNumber.Text = string.Empty;
            txtJobSiteId.Text = string.Empty;
            cmbJobSites.SelectedValue = "0";
            txtBillOfLadingStatusId.Text = string.Empty;
            cmbBillOfLadingStatuses.SelectedValue = "0";
            txtShipmentDate.Text = string.Empty;
            txtShipmentWeight.Text = string.Empty;
            txtBillOfLadingComments.Text = string.Empty;
        }

        public void BillOfLadingShow(BillOfLading b)
        {
            _billOfLading = new BillOfLading(b);

            _driver = DataServiceDrivers.DriverSqlGetById(b.DriverId);

            txtBillOfLadingId.Text = b.BillOfLadingId.ToString();
            txtCustomerId.Text = b.CustomerId.ToString();
            try
            {
                cmbCustomers.SelectedValue = b.CustomerId.ToString();
            }
            catch
            {
                cmbCustomers.SelectedValue = "0";
            }
            txtJobNumberId.Text = b.JobNumberId.ToString();
            try
            {
                cmbJobNumbers.SelectedValue = b.JobNumberId.ToString();
            }
            catch
            {
                cmbJobNumbers.SelectedValue = "0";
            }
            txtPurchaseOrderId.Text = b.PurchaseOrderId.ToString();
            try
            {
                cmbPurchaseOrders.SelectedValue = b.PurchaseOrderId.ToString();
            }
            catch
            {
                cmbPurchaseOrders.SelectedValue = "0";
            }
            txtBillOfLadingNumber.Text = b.BillOfLadingNumber;
            txtCarrierId.Text = b.CarrierId.ToString();
            try
            {
                cmbCarriers.SelectedValue = b.CarrierId.ToString();
            }
            catch
            {
                cmbCarriers.SelectedValue = "0";
            }
            txtDriverId.Text = b.DriverId.ToString();
            try
            {
                cmbDrivers.SelectedValue = b.DriverId.ToString();
                txtTruckNumber.Text = _driver.TruckNumber.ToString();
            }
            catch
            {
                cmbDrivers.SelectedValue = "0";
                txtTruckNumber.Text = string.Empty;
            }
            txtLoadingTerminalId.Text = b.LoadingTerminalId.ToString();
            try
            {
                cmbLoadingTerminals.SelectedValue = b.LoadingTerminalId.ToString();
            }
            catch
            {
                cmbLoadingTerminals.SelectedValue = "0";
            }
            txtFreightId.Text = b.FreightId.ToString();
            try
            {
                cmbFreights.SelectedValue = b.FreightId.ToString();
            }
            catch
            {
                cmbFreights.SelectedValue = "0";
            }
            txtTicketNumber.Text = b.TicketNumber;
            txtJobSiteId.Text = b.JobSiteId.ToString();
            try
            {
                cmbJobSites.SelectedValue = b.JobSiteId.ToString();
            }
            catch
            {
                cmbJobSites.SelectedValue = "0";
            }
            txtBillOfLadingStatusId.Text = b.BillOfLadingStatusId.ToString();
            try
            {
                cmbBillOfLadingStatuses.SelectedValue = b.BillOfLadingStatusId.ToString();
            }
            catch
            {
                cmbBillOfLadingStatuses.SelectedValue = "0";
            }
            txtShipmentDate.Text = b.ShipmentDate.ToShortDateString();
            txtShipmentWeight.Text = b.ShipmentWeight.ToString();
            txtBillOfLadingComments.Text = b.BillOfLadingComments;
        }

        protected void cmbCustomers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCustomers.Items.Count > 0)
            {
                txtCustomerId.Text = cmbCustomers.SelectedValue;
            }
        }

        protected void cmbJobNumbers_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobNumbers.Items.Count > 0)
            {
                txtJobNumberId.Text = cmbJobNumbers.SelectedValue;
            }
        }

        protected void cmbPurchaseOrders_TextChanged(object sender, EventArgs e)
        {
            if (cmbPurchaseOrders.Items.Count > 0)
            {
                txtPurchaseOrderId.Text = cmbPurchaseOrders.SelectedValue;
            }
        }

        protected void cmbCarriers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCarriers.Items.Count > 0)
            {
                txtCarrierId.Text = cmbCarriers.SelectedValue;
            }
        }

        protected void cmbDrivers_TextChanged(object sender, EventArgs e)
        {
            if (cmbDrivers.Items.Count > 0)
            {
                txtDriverId.Text = cmbDrivers.SelectedValue;
            }
        }

        protected void cmbLoadingTerminals_TextChanged(object sender, EventArgs e)
        {
            if (cmbLoadingTerminals.Items.Count > 0)
            {
                txtLoadingTerminalId.Text = cmbLoadingTerminals.SelectedValue;
            }
        }

        protected void cmbFreights_TextChanged(object sender, EventArgs e)
        {
            if (cmbFreights.Items.Count > 0)
            {
                txtFreightId.Text = cmbFreights.SelectedValue;
            }
        }

        protected void cmbJobSites_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobSites.Items.Count > 0)
            {
                txtJobSiteId.Text = cmbJobSites.SelectedValue;
            }
        }

        protected void cmbBillOfLadingStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbBillOfLadingStatuses.Items.Count > 0)
            {
                txtBillOfLadingStatusId.Text = cmbBillOfLadingStatuses.SelectedValue;
            }
        }

        public void BillOfLadingUpdate(ref BillOfLading b)
        {
            try
            {
                b.BillOfLadingId = Convert.ToInt32(txtBillOfLadingId.Text);
            }
            catch
            {
                b.BillOfLadingId = 0;
            }
            try
            {
                b.BillOfLadingId = Convert.ToInt32(txtBillOfLadingId.Text);
            }
            catch
            {
                b.BillOfLadingId = 0;
            }
            try
            {
                b.CustomerId = Convert.ToInt32(txtCustomerId.Text);
            }
            catch
            {
                b.CustomerId = 0;
            }
            try
            {
                b.JobNumberId = Convert.ToInt32(txtJobNumberId.Text);
            }
            catch
            {
                b.JobNumberId = 0;
            }
            try
            {
                b.PurchaseOrderId = Convert.ToInt32(txtPurchaseOrderId.Text);
            }
            catch
            {
                b.PurchaseOrderId = 0;
            }
            b.BillOfLadingNumber = txtBillOfLadingNumber.Text;
            try
            {
                b.CarrierId = Convert.ToInt32(txtCarrierId.Text);
            }
            catch
            {
                b.CarrierId = 0;
            }
            try
            {
                b.DriverId = Convert.ToInt32(txtDriverId.Text);
            }
            catch
            {
                b.DriverId = 0;
            }
            try
            {
                b.LoadingTerminalId = Convert.ToInt32(txtLoadingTerminalId.Text);
            }
            catch
            {
                b.LoadingTerminalId = 0;
            }
            try
            {
                b.FreightId = Convert.ToInt32(txtFreightId.Text);
            }
            catch
            {
                b.FreightId = 0;
            }
            b.TicketNumber = txtTicketNumber.Text;
            try
            {
                b.JobSiteId = Convert.ToInt32(txtJobSiteId.Text);
            }
            catch
            {
                b.JobSiteId = 0;
            }
            try
            {
                b.BillOfLadingStatusId = Convert.ToInt32(txtBillOfLadingStatusId.Text);
            }
            catch
            {
                b.BillOfLadingStatusId = 0;
            }
            try
            {
                b.ShipmentDate = Convert.ToDateTime(txtShipmentDate.Text);
            }
            catch
            {
                b.ShipmentDate = new DateTime();
            }
            try
            {
                b.ShipmentWeight = Convert.ToDecimal(txtShipmentWeight.Text);
            }
            catch
            {
                b.ShipmentWeight = 0;
            }
            b.BillOfLadingComments = txtBillOfLadingComments.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.BillOfLadingClearEvent != null)
            {
                this.BillOfLadingClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.BillOfLadingAddEvent != null)
            {
                this.BillOfLadingAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.BillOfLadingUpdateEvent != null)
            {
                this.BillOfLadingUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.BillOfLadingDeleteEvent != null)
            {
                this.BillOfLadingDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
