using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcOriginTypeSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler OriginTypeDataGridClearEvent;
        public event SPEventHandler OriginTypeDataGridSearchEvent;
        public event SPEventHandler OriginTypeDataGridRowSelectedEvent;

        private Collection<OriginType> _originTypes = new Collection<OriginType>();

        private DataTable _originTypeDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void OriginTypeDataGridClear()
        {
            txtOriginTypeIdSearch.Text = string.Empty;
            txtOriginTypeDescriptionSearch.Text = string.Empty;
           //gvOriginTypes.; // clears data grid - not implemented
        }

        public void OriginTypeDataGridSearch()
        {
            Collection<OriginType> itemCollection = new Collection<OriginType>();

            txtOriginTypeIdSearch.Text = ApplyWildcards(txtOriginTypeIdSearch.Text);
            txtOriginTypeDescriptionSearch.Text = ApplyWildcards(txtOriginTypeDescriptionSearch.Text);

            _originTypes = DataServiceOriginTypes.OriginTypeSqlGetAll();

            _originTypeDataTable = new DataTable("OriginType");
            _originTypeDataTable.Columns.Add(new DataColumn("OriginTypeId", _originTypes[0].OriginTypeId.GetType()));
            _originTypeDataTable.Columns[0].Caption = "OriginTypeId ";
            _originTypeDataTable.Columns[0].ReadOnly = true;
            _originTypeDataTable.Columns.Add(new DataColumn("OriginTypeDescription", _originTypes[0].OriginTypeDescription.GetType()));
            _originTypeDataTable.Columns[1].Caption = "OriginTypeDescription ";
            _originTypeDataTable.Columns[1].ReadOnly = true;
            foreach (OriginType item in _originTypes)
            {
                object[] gridItems = new object[2] { item.OriginTypeId, item.OriginTypeDescription };
                _originTypeDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvOriginTypes.DataSource = _originTypeDataTable;
            gvOriginTypes.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.OriginTypeDataGridClearEvent != null)
            {
                this.OriginTypeDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.OriginTypeDataGridSearchEvent != null)
            {
                this.OriginTypeDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvOriginTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvOriginTypes.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.OriginTypeDataGridRowSelectedEvent != null)
            {
                this.OriginTypeDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
