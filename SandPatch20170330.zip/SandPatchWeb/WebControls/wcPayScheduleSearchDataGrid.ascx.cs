using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPayScheduleSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler PayScheduleDataGridClearEvent;
        public event SPEventHandler PayScheduleDataGridSearchEvent;
        public event SPEventHandler PayScheduleDataGridRowSelectedEvent;

        private Collection<PaySchedule> _paySchedules = new Collection<PaySchedule>();

        private DataTable _payScheduleDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void PayScheduleDataGridClear()
        {
            txtPayPeriodStartDateSearch.Text = string.Empty;
            txtPayPeriodEndDateSearch.Text = string.Empty;
            txtPayDateSearch.Text = string.Empty;
            _payScheduleDataTable = new DataTable("PaySchedule");
            gvPaySchedules.DataSource = _payScheduleDataTable;
            gvPaySchedules.DataBind();
        }

        public void PayScheduleDataGridSearch()
        {
            Collection<PaySchedule> itemCollection = new Collection<PaySchedule>();

            _paySchedules = DataServicePaySchedules.PayScheduleSqlGetBySearchTerms(txtPayPeriodStartDateSearch.Text.Trim(), txtPayPeriodEndDateSearch.Text.Trim(), txtPayDateSearch.Text.Trim());

            _payScheduleDataTable = new DataTable("PaySchedule");
            _payScheduleDataTable.Columns.Add(new DataColumn("Pay Schedule Id ", typeof(string)));
            _payScheduleDataTable.Columns[0].Caption = "Pay Schedule Id ";
            _payScheduleDataTable.Columns[0].ReadOnly = true;
            _payScheduleDataTable.Columns.Add(new DataColumn(" Pay Period Start Date ", typeof(string)));
            _payScheduleDataTable.Columns[1].Caption = " Pay Period Start Date ";
            _payScheduleDataTable.Columns[1].ReadOnly = true;
            _payScheduleDataTable.Columns.Add(new DataColumn(" Pay Period End Date", typeof(string)));
            _payScheduleDataTable.Columns[2].Caption = " Pay Period End Date ";
            _payScheduleDataTable.Columns[2].ReadOnly = true;
            _payScheduleDataTable.Columns.Add(new DataColumn(" Trip Packets Arrival Deadline ", typeof(string)));
            _payScheduleDataTable.Columns[3].Caption = " Trip Packets Arrival Deadline ";
            _payScheduleDataTable.Columns[3].ReadOnly = true;
            _payScheduleDataTable.Columns.Add(new DataColumn(" Pay Date ", typeof(string)));
            _payScheduleDataTable.Columns[4].Caption = " Pay Date ";
            _payScheduleDataTable.Columns[4].ReadOnly = true;
            foreach (PaySchedule item in _paySchedules)
            {
                object[] gridItems = new object[5] { item.PayScheduleId.ToString(), item.PayPeriodStartDate.ToShortDateString(), item.PayPeriodEndDate.ToShortDateString(), item.TripPacketsArrivalDeadline.ToShortDateString(), item.PayDate.ToShortDateString() };
                _payScheduleDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvPaySchedules.DataSource = _payScheduleDataTable;
            gvPaySchedules.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PayScheduleDataGridClearEvent != null)
            {
                this.PayScheduleDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.PayScheduleDataGridSearchEvent != null)
            {
                this.PayScheduleDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvPaySchedules_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvPaySchedules.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.PayScheduleDataGridRowSelectedEvent != null)
            {
                this.PayScheduleDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
