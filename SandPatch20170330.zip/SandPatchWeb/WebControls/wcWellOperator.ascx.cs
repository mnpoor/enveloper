using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcWellOperator : System.Web.UI.UserControl
    {
        public event SPEventHandler WellOperatorClearEvent;
        public event SPEventHandler WellOperatorAddEvent;
        public event SPEventHandler WellOperatorUpdateEvent;
        public event SPEventHandler WellOperatorDeleteEvent;

        private WellOperator _wellOperator;
        private Collection<WellOperator> _wellOperators;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void WellOperatorClear()
        {
            _wellOperator = null;

            txtWellOperatorId.Text = string.Empty;
            txtWellOperatorCompanyName.Text = string.Empty;
            txtWellOperatorStreetAddress.Text = string.Empty;
            txtWellOperatorBoxAddress.Text = string.Empty;
            txtWellOperatorCity.Text = string.Empty;
            txtWellOperatorState.Text = string.Empty;
            txtWellOperatorPostalCode.Text = string.Empty;
            txtWellOperatorStatusId.Text = string.Empty;
            txtWellOperatorPhoneNumber.Text = string.Empty;
            txtWellOperatorFaxNumber.Text = string.Empty;
            txtWellOperatorContactName.Text = string.Empty;
            txtWellOperatorContactEmail.Text = string.Empty;
            txtWellOperatorContactMobileNumber.Text = string.Empty;
            txtWellOperatorNotes.Text = string.Empty;
        }

        public void WellOperatorShow(WellOperator w)
        {
            _wellOperator = new WellOperator(w);

            txtWellOperatorId.Text = w.WellOperatorId.ToString();
            txtWellOperatorCompanyName.Text = w.WellOperatorCompanyName;
            txtWellOperatorStreetAddress.Text = w.WellOperatorStreetAddress;
            txtWellOperatorBoxAddress.Text = w.WellOperatorBoxAddress;
            txtWellOperatorCity.Text = w.WellOperatorCity;
            txtWellOperatorState.Text = w.WellOperatorState;
            txtWellOperatorPostalCode.Text = w.WellOperatorPostalCode;
            txtWellOperatorStatusId.Text = w.WellOperatorStatusId.ToString();
            txtWellOperatorPhoneNumber.Text = w.WellOperatorPhoneNumber;
            txtWellOperatorFaxNumber.Text = w.WellOperatorFaxNumber;
            txtWellOperatorContactName.Text = w.WellOperatorContactName;
            txtWellOperatorContactEmail.Text = w.WellOperatorContactEmail;
            txtWellOperatorContactMobileNumber.Text = w.WellOperatorContactMobileNumber;
            txtWellOperatorNotes.Text = w.WellOperatorNotes;
        }

        public void WellOperatorUpdate(ref WellOperator w)
        {
            try
            {
                w.WellOperatorId = Convert.ToInt32(txtWellOperatorId.Text);
            }
            catch
            {
                w.WellOperatorId = 0;
            }
            w.WellOperatorCompanyName = txtWellOperatorCompanyName.Text;
            w.WellOperatorStreetAddress = txtWellOperatorStreetAddress.Text;
            w.WellOperatorBoxAddress = txtWellOperatorBoxAddress.Text;
            w.WellOperatorCity = txtWellOperatorCity.Text;
            w.WellOperatorState = txtWellOperatorState.Text;
            w.WellOperatorPostalCode = txtWellOperatorPostalCode.Text;
            try
            {
                w.WellOperatorStatusId = Convert.ToInt32(txtWellOperatorStatusId.Text);
            }
            catch
            {
                w.WellOperatorStatusId = 0;
            }
            w.WellOperatorPhoneNumber = txtWellOperatorPhoneNumber.Text;
            w.WellOperatorFaxNumber = txtWellOperatorFaxNumber.Text;
            w.WellOperatorContactName = txtWellOperatorContactName.Text;
            w.WellOperatorContactEmail = txtWellOperatorContactEmail.Text;
            w.WellOperatorContactMobileNumber = txtWellOperatorContactMobileNumber.Text;
            w.WellOperatorNotes = txtWellOperatorNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.WellOperatorClearEvent != null)
            {
                this.WellOperatorClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.WellOperatorAddEvent != null)
            {
                this.WellOperatorAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.WellOperatorUpdateEvent != null)
            {
                this.WellOperatorUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.WellOperatorDeleteEvent != null)
            {
                this.WellOperatorDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
