using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcFreightSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler FreightDataGridClearEvent;
        public event SPEventHandler FreightDataGridSearchEvent;
        public event SPEventHandler FreightDataGridRowSelectedEvent;

        private FreightStatus _foundFreightStatus = null;

        private Collection<Freight> _freights = new Collection<Freight>();

        private DataTable _freightDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void FreightDataGridClear()
        {
            txtFreightNameSearch.Text = string.Empty;
            txtFreightDescriptionSearch.Text = string.Empty;
            _freightDataTable = new DataTable("Freight");
            gvFreights.DataSource = _freightDataTable;
            gvFreights.DataBind();
        }

        public void FreightDataGridSearch()
        {
            int rowCount = 0;
            Collection<Freight> itemCollection = new Collection<Freight>();

            txtFreightNameSearch.Text = ApplyWildcards(txtFreightNameSearch.Text);
            txtFreightDescriptionSearch.Text = ApplyWildcards(txtFreightDescriptionSearch.Text);

            _freights = DataServiceFreights.FreightSqlGetBySearchTerms(txtFreightNameSearch.Text.Trim(), txtFreightDescriptionSearch.Text.Trim());

            _freightDataTable = new DataTable("Freight");
            _freightDataTable.Columns.Add(new DataColumn(" Id ", _freights[0].FreightId.GetType()));
            _freightDataTable.Columns[0].Caption = " Id ";
            _freightDataTable.Columns[0].ReadOnly = true;
            _freightDataTable.Columns.Add(new DataColumn(" Freight Name", _freights[0].FreightName.GetType()));
            _freightDataTable.Columns[1].Caption = " Freight Name ";
            _freightDataTable.Columns[1].ReadOnly = true;
            _freightDataTable.Columns.Add(new DataColumn(" Freight Description ", _freights[0].FreightDescription.GetType()));
            _freightDataTable.Columns[2].Caption = " Freight Description ";
            _freightDataTable.Columns[2].ReadOnly = true;
            _freightDataTable.Columns.Add(new DataColumn(" Unit Of Measure ", _freights[0].FreightUnitOfMeasure.GetType()));
            _freightDataTable.Columns[3].Caption = " Unit Of Measure ";
            _freightDataTable.Columns[3].ReadOnly = true;
            _freightDataTable.Columns.Add(new DataColumn(" Freight Status ", _freights[0].FreightUnitOfMeasure.GetType()));
            _freightDataTable.Columns[4].Caption = " Freight Status ";
            _freightDataTable.Columns[4].ReadOnly = true;
            foreach (Freight item in _freights)
            {
                _foundFreightStatus = DataServiceFreightStatuses.FreightStatusSqlGetById(item.FreightStatusId);
                object[] gridItems = new object[5] { item.FreightId, item.FreightName, item.FreightDescription, item.FreightUnitOfMeasure, (_foundFreightStatus == null ? "* Unassigned *" : _foundFreightStatus.FreightStatusDescription) };
                _freightDataTable.LoadDataRow(gridItems, true);
                rowCount++;
                if (rowCount > 35) break;
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvFreights.DataSource = _freightDataTable;
            gvFreights.DataBind();
            gvFreights.Width = new Unit((int)750);
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.FreightDataGridClearEvent != null)
            {
                this.FreightDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.FreightDataGridSearchEvent != null)
            {
                this.FreightDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvFreights_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvFreights.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.FreightDataGridRowSelectedEvent != null)
            {
                this.FreightDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
