using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDispatch : System.Web.UI.UserControl
    {
        public event SPEventHandler DispatchClearEvent;
        public event SPEventHandler DispatchAddEvent;
        public event SPEventHandler DispatchUpdateEvent;
        public event SPEventHandler DispatchDeleteEvent;

        private Collection<Customer> _customers;
        private Collection<JobNumber> _jobNumbers;
        private Collection<PurchaseOrder> _purchaseOrders;
        private Collection<Carrier> _carriers;
        private Collection<Driver> _drivers;
        private Collection<DispatchStatus> _dispatchStatuses;
        private Collection<Freight> _freights;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<BillOfLading> _billsOfLading;
        private Collection<JobSite> _jobSites;

        private Carrier _carrier;
        private Driver _driver;

        private BillOfLading _billOfLading;

        private Dispatch _dispatch;
        private Collection<Dispatch> _dispatches;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CustomerCount
        {
            get
            {
                return cmbCustomers.Items.Count;
            }
        }

        public int JobNumberCount
        {
            get
            {
                return cmbJobNumbers.Items.Count;
            }
        }

        public int PurchaseOrderCount
        {
            get
            {
                return cmbPurchaseOrders.Items.Count;
            }
        }

        public int CarrierCount
        {
            get
            {
                return cmbCarriers.Items.Count;
            }
        }

        public int DriverCount
        {
            get
            {
                return cmbDrivers.Items.Count;
            }
        }

        public int DispatchStatusCount
        {
            get
            {
                return cmbDispatchStatuses.Items.Count;
            }
        }

        public int FreightCount
        {
            get
            {
                return cmbFreights.Items.Count;
            }
        }

        public int LoadingTerminalCount
        {
            get
            {
                return cmbLoadingTerminals.Items.Count;
            }
        }

        public int JobSiteCount
        {
            get
            {
                return cmbJobSites.Items.Count;
            }
        }

        public void CustomersFill(Collection<Customer> customers)
        {
            if (cmbCustomers.Items.Count < 1)
            {
                _customers = new Collection<Customer>(customers);
                foreach (Customer item in _customers)
                {
                    cmbCustomers.Items.Add(new ListItem(item.CustomerName.ToString(), item.CustomerId.ToString()));
                }
                cmbCustomers.DataBind();
            }
        }

        public void JobNumbersFill(Collection<JobNumber> jobNumbers)
        {
            if (cmbJobNumbers.Items.Count < 1)
            {
                _jobNumbers = new Collection<JobNumber>(jobNumbers);
                foreach (JobNumber item in _jobNumbers)
                {
                    cmbJobNumbers.Items.Add(new ListItem(item.JobNumberAssignment.ToString(), item.JobNumberId.ToString()));
                }
                cmbJobNumbers.DataBind();
            }
        }

        public void PurchaseOrdersFill(Collection<PurchaseOrder> purchaseOrders)
        {
            if (cmbPurchaseOrders.Items.Count < 1)
            {
                _purchaseOrders = new Collection<PurchaseOrder>(purchaseOrders);
                foreach (PurchaseOrder item in _purchaseOrders)
                {
                    cmbPurchaseOrders.Items.Add(new ListItem(item.PurchaseOrderNumber.ToString(), item.PurchaseOrderId.ToString()));
                }
                cmbPurchaseOrders.DataBind();
            }
        }

        public void CarriersFill(Collection<Carrier> carriers)
        {
            if (cmbCarriers.Items.Count < 1)
            {
                _carriers = new Collection<Carrier>(carriers);
                foreach (Carrier item in _carriers)
                {
                    cmbCarriers.Items.Add(new ListItem(item.CarrierCompanyName, item.CarrierId.ToString()));
                }
                cmbCarriers.DataBind();
            }
        }

        public void DriversFill(Collection<Driver> drivers)
        {
            if (cmbDrivers.Items.Count < 1)
            {
                _drivers = new Collection<Driver>(drivers);
                foreach (Driver item in _drivers)
                {
                    cmbDrivers.Items.Add(new ListItem(item.TruckNumber.ToString() + " - " + item.DriverName, item.DriverId.ToString()));
                }
                cmbDrivers.DataBind();
            }
        }

        public void FreightsFill(Collection<Freight> freights)
        {
            if (cmbFreights.Items.Count < 1)
            {
                _freights = new Collection<Freight>(freights);
                foreach (Freight item in _freights)
                {
                    cmbFreights.Items.Add(new ListItem(item.FreightName.ToString(), item.FreightId.ToString()));
                }
                cmbFreights.DataBind();
            }
        }

        public void DispatchStatusesFill(Collection<DispatchStatus> dispatchStatuses)
        {
            if (cmbDispatchStatuses.Items.Count < 1)
            {
                _dispatchStatuses = new Collection<DispatchStatus>(dispatchStatuses);
                foreach (DispatchStatus item in _dispatchStatuses)
                {
                    cmbDispatchStatuses.Items.Add(new ListItem(item.DispatchStatusDescription.ToString(), item.DispatchStatusId.ToString()));
                }
                cmbDispatchStatuses.DataBind();
            }
        }

        public void LoadingTerminalsFill(Collection<LoadingTerminal> loadingTerminals)
        {
            if (cmbLoadingTerminals.Items.Count < 1)
            {
                _loadingTerminals = new Collection<LoadingTerminal>(loadingTerminals);
                foreach (LoadingTerminal item in _loadingTerminals)
                {
                    cmbLoadingTerminals.Items.Add(new ListItem(item.LoadingTerminalName.ToString(), item.LoadingTerminalId.ToString()));
                }
                cmbLoadingTerminals.DataBind();
            }
        }

        public void JobSitesFill(Collection<JobSite> jobSites)
        {
            if (cmbJobSites.Items.Count < 1)
            {
                _jobSites = new Collection<JobSite>(jobSites);
                foreach (JobSite item in _jobSites)
                {
                    cmbJobSites.Items.Add(new ListItem(item.JobSiteName.ToString(), item.JobSiteId.ToString()));
                }
                cmbJobSites.DataBind();
            }
        }

        public void DispatchClear()
        {
            _dispatch = null;

            txtDispatchId.Text = string.Empty;
            txtCustomerId.Text = string.Empty;
            cmbCustomers.SelectedValue = "0";
            txtJobNumberId.Text = string.Empty;
            cmbJobNumbers.SelectedValue = "0";
            txtPurchaseOrderId.Text = string.Empty;
            cmbPurchaseOrders.SelectedValue = "0";
            txtDispatchAcceptanceNumber.Text = string.Empty;
            txtDispatchAcceptanceDate.Text = DateTime.Today.ToShortDateString();
            txtCarrierId.Text = string.Empty;
            txtCarrierId.Visible = false;
            cmbCarriers.SelectedValue = "0";
            cmbCarriers.Visible = false;
            txtDriverId.Text = string.Empty;
            //txtDriverName.Text = string.Empty;
            cmbDrivers.SelectedValue = "0";
            txtDispatchStatusId.Text = string.Empty;
            cmbDispatchStatuses.SelectedValue = "0";
            txtFreightId.Text = string.Empty;
            cmbFreights.SelectedValue = "0";
            txtLoadingTerminalId.Text = string.Empty;
            cmbLoadingTerminals.SelectedValue = "0";
            txtLoadingTerminalAppointmentDateTime.Text = string.Empty;
            txtActualLoadingTerminalArrivalTime.Text = string.Empty;
            txtActualLoadingTerminalDepartureTime.Text = string.Empty;
            txtBillOfLadingId.Text = string.Empty;
            txtBillOfLadingNumber.Text = string.Empty;
            txtShipmentWeight.Text = string.Empty;
            txtTicketNumber.Text = string.Empty;
            txtJobSiteId.Text = string.Empty;
            cmbJobSites.SelectedValue = "0";
            txtJobSiteDeliveryAppointmentDateTime.Text = string.Empty;
            txtJobSiteActualArrivalTime.Text = string.Empty;
            txtJobSiteActualDepartureTime.Text = string.Empty;
            txtDispatchMiles.Text = string.Empty;
            txtDispatchTotalHours.Text = string.Empty;
            txtDispatchComments.Text = string.Empty;
        }

        public void DispatchNew(Dispatch d)
        {
            txtDispatchId.Text = string.Empty;
            txtCustomerId.Text = string.Empty;
            cmbCustomers.SelectedValue = "0";
            txtJobNumberId.Text = string.Empty;
            cmbJobNumbers.SelectedValue = "0";
            txtPurchaseOrderId.Text = string.Empty;
            cmbPurchaseOrders.SelectedValue = "0";
            txtDispatchAcceptanceNumber.Text = string.Empty;

            txtDispatchAcceptanceDate.Text = DateTime.Today.ToShortDateString();

            txtCarrierId.Text = d.CarrierId.ToString();
            if (cmbCarriers.Visible == false) cmbCarriers.Visible = true;
            try
            {
                cmbCarriers.SelectedValue = d.CarrierId.ToString();
            }
            catch
            {
                cmbCarriers.SelectedValue = "0";
            }
            txtDriverId.Text = d.DriverId.ToString();
            try
            {
                cmbDrivers.SelectedValue = d.DriverId.ToString();
            }
            catch
            {
                cmbDrivers.SelectedValue = "0";
            }

            txtDispatchStatusId.Text = string.Empty;
            cmbDispatchStatuses.SelectedValue = "0";
            txtFreightId.Text = string.Empty;
            cmbFreights.SelectedValue = "0";
            txtLoadingTerminalId.Text = string.Empty;
            cmbLoadingTerminals.SelectedValue = "0";
            txtLoadingTerminalAppointmentDateTime.Text = string.Empty;
            txtActualLoadingTerminalArrivalTime.Text = string.Empty;
            txtActualLoadingTerminalDepartureTime.Text = string.Empty;
            txtBillOfLadingId.Text = string.Empty;
            txtBillOfLadingNumber.Text = string.Empty;
            txtShipmentWeight.Text = string.Empty;
            txtTicketNumber.Text = string.Empty;
            txtJobSiteId.Text = string.Empty;
            cmbJobSites.SelectedValue = "0";
            txtJobSiteDeliveryAppointmentDateTime.Text = string.Empty;
            txtJobSiteActualArrivalTime.Text = string.Empty;
            txtJobSiteActualDepartureTime.Text = string.Empty;
            txtDispatchMiles.Text = string.Empty;
            txtDispatchTotalHours.Text = string.Empty;
            txtDispatchComments.Text = string.Empty;
        }

        public void DispatchShow(Dispatch d)
        {
            _dispatch = new Dispatch(d);

            _driver = DataServiceDrivers.DriverSqlGetById(d.DriverId);

            txtDispatchId.Text = d.DispatchId.ToString();
            txtCustomerId.Text = d.CustomerId.ToString();
            try
            {
                cmbCustomers.SelectedValue = d.CustomerId.ToString();
            }
            catch
            {
                cmbCustomers.SelectedValue = "0";
            }
            txtJobNumberId.Text = d.JobNumberId.ToString();
            try
            {
                cmbJobNumbers.SelectedValue = d.JobNumberId.ToString();
            }
            catch
            {
                cmbJobNumbers.SelectedValue = "0";
            }
            txtPurchaseOrderId.Text = d.PurchaseOrderId.ToString();
            try
            {
                cmbPurchaseOrders.SelectedValue = d.PurchaseOrderId.ToString();
            }
            catch
            {
                cmbPurchaseOrders.SelectedValue = "0";
            }
            txtDispatchAcceptanceNumber.Text = d.DispatchAcceptanceNumber;
            txtDispatchAcceptanceDate.Text = d.DispatchAcceptanceDate.ToShortDateString();
            if (txtCarrierId.Visible == false) txtCarrierId.Visible = true;
            txtCarrierId.Text = d.CarrierId.ToString();
            if (cmbCarriers.Visible == false) cmbCarriers.Visible = true;
            try
            {
                cmbCarriers.SelectedValue = d.CarrierId.ToString();
            }
            catch
            {
                cmbCarriers.SelectedValue = "0";
            }
            txtDriverId.Text = d.DriverId.ToString();
            //if (_driver == null)
            //{
            //    txtDriverName.Text = string.Empty;
            //}
            //else
            //{
            //    txtDriverName.Text = _driver.DriverName;
            //}
            try
            {
                cmbDrivers.SelectedValue = d.DriverId.ToString();
            }
            catch
            {
                cmbDrivers.SelectedValue = "0";
            }
            txtDispatchStatusId.Text = d.DispatchStatusId.ToString();
            try
            {
                cmbDispatchStatuses.SelectedValue = d.DispatchStatusId.ToString();
            }
            catch
            {
                cmbDispatchStatuses.SelectedValue = "0";
            }
            txtFreightId.Text = d.FreightId.ToString();
            try
            {
                cmbFreights.SelectedValue = d.FreightId.ToString();
            }
            catch
            {
                cmbFreights.SelectedValue = "0";
            }
            txtLoadingTerminalId.Text = d.LoadingTerminalId.ToString();
            try
            {
                cmbLoadingTerminals.SelectedValue = d.LoadingTerminalId.ToString();
            }
            catch
            {
                cmbLoadingTerminals.SelectedValue = "0";
            }
            txtLoadingTerminalAppointmentDateTime.Text = d.LoadingTerminalAppointmentDateTime.ToString("MM/dd/yyyy HH:mm");
            txtActualLoadingTerminalArrivalTime.Text = d.ActualLoadingTerminalArrivalTime.ToString("MM/dd/yyyy HH:mm");
            txtActualLoadingTerminalDepartureTime.Text = d.ActualLoadingTerminalDepartureTime.ToString("MM/dd/yyyy HH:mm");
            txtBillOfLadingId.Text = d.BillOfLadingId.ToString();
            txtBillOfLadingNumber.Text = d.BillOfLadingNumber;
            txtShipmentWeight.Text = d.ShipmentWeight.ToString();
            txtTicketNumber.Text = d.TicketNumber;
            txtJobSiteId.Text = d.JobSiteId.ToString();
            try
            {
                cmbJobSites.SelectedValue = d.JobSiteId.ToString();
            }
            catch
            {
                cmbJobSites.SelectedValue = "0";
            }
            txtJobSiteDeliveryAppointmentDateTime.Text = d.JobSiteDeliveryAppointmentDateTime.ToString("MM/dd/yyyy HH:mm");
            txtJobSiteActualArrivalTime.Text = d.JobSiteActualArrivalTime.ToString("MM/dd/yyyy HH:mm");
            txtJobSiteActualDepartureTime.Text = d.JobSiteActualDepartureTime.ToString("MM/dd/yyyy HH:mm");
            txtDispatchMiles.Text = d.DispatchMiles.ToString();
            txtDispatchTotalHours.Text = d.DispatchTotalHours.ToString();
            txtDispatchComments.Text = d.DispatchComments;
        }

        protected void cmbCustomers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCustomers.Items.Count > 0)
            {
                txtCustomerId.Text = cmbCustomers.SelectedValue;
            }
        }

        protected void cmbJobNumbers_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobNumbers.Items.Count > 0)
            {
                txtJobNumberId.Text = cmbJobNumbers.SelectedValue;
            }
        }

        protected void cmbPurchaseOrders_TextChanged(object sender, EventArgs e)
        {
            if (cmbPurchaseOrders.Items.Count > 0)
            {
                txtPurchaseOrderId.Text = cmbPurchaseOrders.SelectedValue;
            }
        }

        protected void cmbCarriers_TextChanged(object sender, EventArgs e)
        {
            if (cmbCarriers.Items.Count > 0)
            {
                txtCarrierId.Text = cmbCarriers.SelectedValue;
            }
        }

        protected void cmbDrivers_TextChanged(object sender, EventArgs e)
        {
            if (cmbDrivers.Items.Count > 0)
            {
                txtDriverId.Text = cmbDrivers.SelectedValue;
                try
                {
                    int driverId = Convert.ToInt32(txtDriverId.Text);
                    _driver = DataServiceDrivers.DriverSqlGetById(driverId);
                    if (_driver != null)
                    { 
                        _carrier = DataServiceCarriers.CarrierSqlGetById(_driver.CarrierId);
                        txtCarrierId.Visible = true;
                        txtCarrierId.Text = _carrier.CarrierId.ToString();
                        cmbCarriers.Visible = true;
                        cmbCarriers.SelectedValue = _carrier.CarrierId.ToString();
                    }
                    //txtDriverName.Text = _driver.DriverName;
                }
                catch
                {
                    //txtDriverName.Text = string.Empty;
                }
            }
        }

        protected void cmbDispatchStatuses_TextChanged(object sender, EventArgs e)
        {
            if (cmbDispatchStatuses.Items.Count > 0)
            {
                txtDispatchStatusId.Text = cmbDispatchStatuses.SelectedValue;
            }
        }

        protected void cmbFreights_TextChanged(object sender, EventArgs e)
        {
            if (cmbFreights.Items.Count > 0)
            {
                txtFreightId.Text = cmbFreights.SelectedValue;
            }
        }

        protected void cmbLoadingTerminals_TextChanged(object sender, EventArgs e)
        {
            if (cmbLoadingTerminals.Items.Count > 0)
            {
                txtLoadingTerminalId.Text = cmbLoadingTerminals.SelectedValue;
            }
        }

        protected void FindBillOfLadingNumber(object source, ServerValidateEventArgs args)
        {
            args.IsValid = true;
            if (txtBillOfLadingNumber.Text.Trim().Length < 1) return; // if the BOL is blank ignore it.
            _billOfLading = DataServiceBillsOfLading.BillOfLadingSqlGetByBOLNumber(txtBillOfLadingNumber.Text);
            if (_billOfLading != null)
            {
                txtBillOfLadingId.Text = _billOfLading.BillOfLadingId.ToString();
            }
            else
            {
                _billOfLading = new BillOfLading();
                _billOfLading.BillOfLadingNumber = txtBillOfLadingNumber.Text;
                DataServiceBillsOfLading.SqlSave(ref _billOfLading);
                txtBillOfLadingId.Text = _billOfLading.BillOfLadingId.ToString();
            }
        }

        protected void cmbJobSites_TextChanged(object sender, EventArgs e)
        {
            if (cmbJobSites.Items.Count > 0)
            {
                txtJobSiteId.Text = cmbJobSites.SelectedValue;
            }
        }

        public void DispatchUpdate(ref Dispatch d)
        {
            try
            {
                d.DispatchId = Convert.ToInt32(txtDispatchId.Text);
            }
            catch
            {
                d.DispatchId = 0;
            }
            try
            {
                d.CustomerId = Convert.ToInt32(txtCustomerId.Text);
            }
            catch
            {
                d.CustomerId = 0;
            }
            try
            {
                d.JobNumberId = Convert.ToInt32(txtJobNumberId.Text);
            }
            catch
            {
                d.JobNumberId = 0;
            }
            try
            {
                d.PurchaseOrderId = Convert.ToInt32(txtPurchaseOrderId.Text);
            }
            catch
            {
                d.PurchaseOrderId = 0;
            }
            d.DispatchAcceptanceNumber = txtDispatchAcceptanceNumber.Text;
            try
            {
                d.DispatchAcceptanceDate = Convert.ToDateTime(txtDispatchAcceptanceDate.Text);
            }
            catch
            {
                d.DispatchAcceptanceDate = new DateTime();
            }
            try
            {
                d.CarrierId = Convert.ToInt32(txtCarrierId.Text);
            }
            catch
            {
                d.CarrierId = 0;
            }
            try
            {
                d.DriverId = Convert.ToInt32(txtDriverId.Text);
            }
            catch
            {
                d.DriverId = 0;
            }
            try
            {
                d.DispatchStatusId = Convert.ToInt32(txtDispatchStatusId.Text);
            }
            catch
            {
                d.DispatchStatusId = 0;
            }
            try
            {
                d.FreightId = Convert.ToInt32(txtFreightId.Text);
            }
            catch
            {
                d.FreightId = 0;
            }
            try
            {
                d.LoadingTerminalId = Convert.ToInt32(txtLoadingTerminalId.Text);
            }
            catch
            {
                d.LoadingTerminalId = 0;
            }
            try
            {
                d.LoadingTerminalAppointmentDateTime = Convert.ToDateTime(txtLoadingTerminalAppointmentDateTime.Text);
            }
            catch
            {
                d.LoadingTerminalAppointmentDateTime = new DateTime();
            }
            try
            {
                d.ActualLoadingTerminalArrivalTime = Convert.ToDateTime(txtActualLoadingTerminalArrivalTime.Text);
            }
            catch
            {
                d.ActualLoadingTerminalArrivalTime = new DateTime();
            }
            try
            {
                d.ActualLoadingTerminalDepartureTime = Convert.ToDateTime(txtActualLoadingTerminalDepartureTime.Text);
            }
            catch
            {
                d.ActualLoadingTerminalDepartureTime = new DateTime();
            }
            try
            {
                d.BillOfLadingId = Convert.ToInt32(txtBillOfLadingId.Text);
            }
            catch
            {
                d.BillOfLadingId = 0;
            }
            d.BillOfLadingNumber = txtBillOfLadingNumber.Text;
            try
            {
                d.ShipmentWeight = Convert.ToDecimal(txtShipmentWeight.Text);
            }
            catch
            {
                d.ShipmentWeight = 0;
            }
            d.TicketNumber = txtTicketNumber.Text;
            try
            {
                d.JobSiteId = Convert.ToInt32(txtJobSiteId.Text);
            }
            catch
            {
                d.JobSiteId = 0;
            }
            try
            {
                d.JobSiteDeliveryAppointmentDateTime = Convert.ToDateTime(txtJobSiteDeliveryAppointmentDateTime.Text);
            }
            catch
            {
                d.JobSiteDeliveryAppointmentDateTime = new DateTime();
            }
            try
            {
                d.JobSiteActualArrivalTime = Convert.ToDateTime(txtJobSiteActualArrivalTime.Text);
            }
            catch
            {
                d.JobSiteActualArrivalTime = new DateTime();
            }
            try
            {
                d.JobSiteActualDepartureTime = Convert.ToDateTime(txtJobSiteActualDepartureTime.Text);
            }
            catch
            {
                d.JobSiteActualDepartureTime = new DateTime();
            }
            try
            {
                d.DispatchMiles = Convert.ToInt32(txtDispatchMiles.Text);
            }
            catch
            {
                d.DispatchMiles = 0;
            }
            try
            {
                d.DispatchTotalHours = Convert.ToInt32(txtDispatchTotalHours.Text);
            }
            catch
            {
                d.DispatchTotalHours = 0;
            }
            d.DispatchComments = txtDispatchComments.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DispatchClearEvent != null)
            {
                this.DispatchClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.DispatchAddEvent != null)
            {
                this.DispatchAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.DispatchUpdateEvent != null)
            {
                this.DispatchUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.DispatchDeleteEvent != null)
            {
                this.DispatchDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
