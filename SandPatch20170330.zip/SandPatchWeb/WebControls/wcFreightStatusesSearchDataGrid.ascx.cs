using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcFreightStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler FreightStatusDataGridClearEvent;
        public event SPEventHandler FreightStatusDataGridSearchEvent;
        public event SPEventHandler FreightStatusDataGridRowSelectedEvent;

        private Collection<FreightStatus> _freightStatuses = new Collection<FreightStatus>();

        private DataTable _freightStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void FreightStatusDataGridClear()
        {
            txtFreightStatusIdSearch.Text = string.Empty;
            txtFreightStatusDescriptionSearch.Text = string.Empty;
           //gvFreightStatuss.; // clears data grid - not implemented
        }

        public void FreightStatusDataGridSearch()
        {
            Collection<FreightStatus> itemCollection = new Collection<FreightStatus>();

            txtFreightStatusIdSearch.Text = ApplyWildcards(txtFreightStatusIdSearch.Text);
            txtFreightStatusDescriptionSearch.Text = ApplyWildcards(txtFreightStatusDescriptionSearch.Text);

            _freightStatuses = DataServiceFreightStatuses.FreightStatusSqlGetAll();
            if (_freightStatuses.Count == 0)
            {
                _freightStatuses.Add(new FreightStatus());
                _freightStatuses[0].FreightStatusDescription = "No Records";
            }

            _freightStatusDataTable = new DataTable("FreightStatus");
            _freightStatusDataTable.Columns.Add(new DataColumn("FreightStatusId", _freightStatuses[0].FreightStatusId.GetType()));
            _freightStatusDataTable.Columns[0].Caption = "FreightStatusId ";
            _freightStatusDataTable.Columns[0].ReadOnly = true;
            _freightStatusDataTable.Columns.Add(new DataColumn("FreightStatusDescription", _freightStatuses[0].FreightStatusDescription.GetType()));
            _freightStatusDataTable.Columns[1].Caption = "FreightStatusDescription ";
            _freightStatusDataTable.Columns[1].ReadOnly = true;
            foreach (FreightStatus item in _freightStatuses)
            {
                object[] gridItems = new object[2] { item.FreightStatusId, item.FreightStatusDescription };
                _freightStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvFreightStatuss.DataSource = _freightStatusDataTable;
            gvFreightStatuss.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.FreightStatusDataGridClearEvent != null)
            {
                this.FreightStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.FreightStatusDataGridSearchEvent != null)
            {
                this.FreightStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvFreightStatuss_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvFreightStatuss.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.FreightStatusDataGridRowSelectedEvent != null)
            {
                this.FreightStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
