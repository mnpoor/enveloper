using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPaySchedule : System.Web.UI.UserControl
    {
        public event SPEventHandler PayScheduleClearEvent;
        public event SPEventHandler PayScheduleAddEvent;
        public event SPEventHandler PayScheduleUpdateEvent;
        public event SPEventHandler PayScheduleDeleteEvent;

        private PaySchedule _paySchedule;
        private Collection<PaySchedule> _paySchedules;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void PayScheduleClear()
        {
            _paySchedule = null;

            txtPayScheduleId.Text = string.Empty;
            txtPayPeriodStartDate.Text = string.Empty;
            txtPayPeriodEndDate.Text = string.Empty;
            txtTripPacketsArrivalDeadline.Text = string.Empty;
            txtPayDate.Text = string.Empty;
            txtPayScheduleNotes.Text = string.Empty;
        }

        public void PayScheduleShow(PaySchedule p)
        {
            _paySchedule = new PaySchedule(p);

            txtPayScheduleId.Text = p.PayScheduleId.ToString();
            txtPayPeriodStartDate.Text = p.PayPeriodStartDate.ToShortDateString();
            txtPayPeriodEndDate.Text = p.PayPeriodEndDate.ToShortDateString();
            txtTripPacketsArrivalDeadline.Text = p.TripPacketsArrivalDeadline.ToShortDateString();
            txtPayDate.Text = p.PayDate.ToShortDateString();
            txtPayScheduleNotes.Text = p.PayScheduleNotes;
        }

        public void PayScheduleUpdate(ref PaySchedule p)
        {
            try
            {
                p.PayScheduleId = Convert.ToInt32(txtPayScheduleId.Text);
            }
            catch
            {
                p.PayScheduleId = 0;
            }
            try
            {
                p.PayScheduleId = Convert.ToInt32(txtPayScheduleId.Text);
            }
            catch
            {
                p.PayScheduleId = 0;
            }
            try
            {
                p.PayPeriodStartDate = Convert.ToDateTime(txtPayPeriodStartDate.Text);
            }
            catch
            {
                p.PayPeriodStartDate = new DateTime();
            }
            try
            {
                p.PayPeriodEndDate = Convert.ToDateTime(txtPayPeriodEndDate.Text);
            }
            catch
            {
                p.PayPeriodEndDate = new DateTime();
            }
            try
            {
                p.TripPacketsArrivalDeadline = Convert.ToDateTime(txtTripPacketsArrivalDeadline.Text);
            }
            catch
            {
                p.TripPacketsArrivalDeadline = new DateTime();
            }
            try
            {
                p.PayDate = Convert.ToDateTime(txtPayDate.Text);
            }
            catch
            {
                p.PayDate = new DateTime();
            }
            p.PayScheduleNotes = txtPayScheduleNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PayScheduleClearEvent != null)
            {
                this.PayScheduleClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.PayScheduleAddEvent != null)
            {
                this.PayScheduleAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.PayScheduleUpdateEvent != null)
            {
                this.PayScheduleUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.PayScheduleDeleteEvent != null)
            {
                this.PayScheduleDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
