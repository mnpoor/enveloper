using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcLicensePlateStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler LicensePlateStatusClearEvent;
        public event SPEventHandler LicensePlateStatusAddEvent;
        public event SPEventHandler LicensePlateStatusUpdateEvent;
        public event SPEventHandler LicensePlateStatusDeleteEvent;

        private LicensePlateStatus _licensePlateStatus;
        private Collection<LicensePlateStatus> _licensePlateStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void LicensePlateStatusClear()
        {
            _licensePlateStatus = null;

            txtLicensePlateStatusId.Text = string.Empty;
            txtLicensePlateStatusDescription.Text = string.Empty;
        }

        public void LicensePlateStatusShow(LicensePlateStatus l)
        {
            _licensePlateStatus = new LicensePlateStatus(l);

            txtLicensePlateStatusId.Text = l.LicensePlateStatusId.ToString();
            txtLicensePlateStatusDescription.Text = l.LicensePlateStatusDescription;
        }

        public void LicensePlateStatusUpdate(ref LicensePlateStatus l)
        {
            try
            {
                l.LicensePlateStatusId = Convert.ToInt32(txtLicensePlateStatusId.Text);
            }
            catch
            {
                l.LicensePlateStatusId = 0;
            }
            try
            {
                l.LicensePlateStatusId = Convert.ToInt32(txtLicensePlateStatusId.Text);
            }
            catch
            {
                l.LicensePlateStatusId = 0;
            }
            l.LicensePlateStatusDescription = txtLicensePlateStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.LicensePlateStatusClearEvent != null)
            {
                this.LicensePlateStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.LicensePlateStatusAddEvent != null)
            {
                this.LicensePlateStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.LicensePlateStatusUpdateEvent != null)
            {
                this.LicensePlateStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.LicensePlateStatusDeleteEvent != null)
            {
                this.LicensePlateStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
