using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcWithholdingAccountDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler WithholdingAccountClearEvent;
        public event SPEventHandler WithholdingAccountAddEvent;
        public event SPEventHandler WithholdingAccountUpdateEvent;
        public event SPEventHandler WithholdingAccountDeleteEvent;

        private WithholdingAccount _withholdingAccount;
        private Collection<WithholdingAccount> _withholdingAccounts;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void WithholdingAccountClear()
        {
            _withholdingAccount = null;

            txtWithholdingId.Text = string.Empty;
            txtWithholdingAccountName.Text = string.Empty;
            txtWithholdingSummaryAccountNumber.Text = string.Empty;
        }

        public void WithholdingAccountShow(WithholdingAccount w)
        {
            _withholdingAccount = new WithholdingAccount(w);

            txtWithholdingId.Text = w.WithholdingId.ToString();
            txtWithholdingAccountName.Text = w.WithholdingAccountName;
            txtWithholdingSummaryAccountNumber.Text = w.WithholdingSummaryAccountNumber;
        }

        public void WithholdingAccountUpdate(ref WithholdingAccount w)
        {
            try
            {
                w.WithholdingId = Convert.ToInt32(txtWithholdingId.Text);
            }
            catch
            {
                w.WithholdingId = 0;
            }
            w.WithholdingAccountName = txtWithholdingAccountName.Text;
            w.WithholdingSummaryAccountNumber = txtWithholdingSummaryAccountNumber.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.WithholdingAccountClearEvent != null)
            {
                this.WithholdingAccountClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.WithholdingAccountAddEvent != null)
            {
                this.WithholdingAccountAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.WithholdingAccountUpdateEvent != null)
            {
                this.WithholdingAccountUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.WithholdingAccountDeleteEvent != null)
            {
                this.WithholdingAccountDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
