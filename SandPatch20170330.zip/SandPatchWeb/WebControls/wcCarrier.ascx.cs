using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCarrier : System.Web.UI.UserControl
    {
        public event SPEventHandler CarrierClearEvent;
        public event SPEventHandler CarrierAddEvent;
        public event SPEventHandler CarrierUpdateEvent;
        public event SPEventHandler CarrierDeleteEvent;

        private Carrier _carrier;
        private Collection<Carrier> _carriers;
        private Collection<CarrierStatus> _carrierStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public int CarrierStatusesCount
        {
            get
            {
                return cmbCarrierStatus.Items.Count;
            }
        }

        public void CarrierStatusesFill(Collection<CarrierStatus> carrierStatuses)
        {
            if (cmbCarrierStatus.Items.Count < 1)
            {
                _carrierStatuses = new Collection<CarrierStatus>(carrierStatuses);
                foreach (CarrierStatus item in _carrierStatuses)
                {
                    cmbCarrierStatus.Items.Add(new ListItem(item.CarrierStatusDescription, item.CarrierStatusId.ToString()));
                }
                cmbCarrierStatus.DataBind();
            }
        }

        public void CarrierClear()
        {
            _carrier = null;

            txtCarrierId.Text = string.Empty;
            txtCarrierCompanyName.Text = string.Empty;
            txtCarrierStreetAddress.Text = string.Empty;
            txtCarrierBoxAddress.Text = string.Empty;
            txtCarrierCity.Text = string.Empty;
            txtCarrierState.Text = string.Empty;
            txtCarrierPostalCode.Text = string.Empty;
            txtCarrierStatusId.Text = string.Empty;
            cmbCarrierStatus.SelectedValue = "0";
            txtCarrierPhoneNumber.Text = string.Empty;
            txtCarrierFaxNumber.Text = string.Empty;
            txtCarrierContactName.Text = string.Empty;
            txtCarrierContactEmail.Text = string.Empty;
            txtCarrierContactMobileNumber.Text = string.Empty;
            txtCarrierActivationDate.Text = string.Empty;
            txtCarrierSeveranceDate.Text = string.Empty;
            txtCarrierNotes.Text = string.Empty;            
        }

        public void CarrierShow(Carrier c)
        {
            _carrier = new Carrier(c);

            txtCarrierId.Text = c.CarrierId.ToString();
            txtCarrierCompanyName.Text = c.CarrierCompanyName;
            txtCarrierStreetAddress.Text = c.CarrierStreetAddress;
            txtCarrierBoxAddress.Text = c.CarrierBoxAddress;
            txtCarrierCity.Text = c.CarrierCity;
            txtCarrierState.Text = c.CarrierState;
            txtCarrierPostalCode.Text = c.CarrierPostalCode;
            txtCarrierStatusId.Text = c.CarrierStatusId.ToString();
            try
            {
                cmbCarrierStatus.SelectedValue = c.CarrierStatusId.ToString();
            }
            catch
            {
                cmbCarrierStatus.SelectedValue = "0";
            }
            txtCarrierPhoneNumber.Text = c.CarrierPhoneNumber;
            txtCarrierFaxNumber.Text = c.CarrierFaxNumber;
            txtCarrierContactName.Text = c.CarrierContactName;
            txtCarrierContactEmail.Text = c.CarrierContactEmail;
            txtCarrierContactMobileNumber.Text = c.CarrierContactMobileNumber;
            txtCarrierActivationDate.Text = c.CarrierActivationDate.ToShortDateString();
            txtCarrierSeveranceDate.Text = c.CarrierSeveranceDate.ToShortDateString();
            txtCarrierNotes.Text = c.CarrierNotes;
        }

        protected void cmbCarrierStatus_TextChanged(object sender, EventArgs e)
        {
            if (cmbCarrierStatus.Items.Count > 0)
            {
                txtCarrierStatusId.Text = cmbCarrierStatus.SelectedValue;
            }
        }

        public void CarrierUpdate(ref Carrier c)
        {
            try
            {
                c.CarrierId = Convert.ToInt32(txtCarrierId.Text);
            }
            catch
            {
                c.CarrierId = 0;
            }
            c.CarrierCompanyName = txtCarrierCompanyName.Text;
            c.CarrierStreetAddress = txtCarrierStreetAddress.Text;
            c.CarrierBoxAddress = txtCarrierBoxAddress.Text;
            c.CarrierCity = txtCarrierCity.Text;
            c.CarrierState = txtCarrierState.Text;
            c.CarrierPostalCode = txtCarrierPostalCode.Text;
            try
            {
                c.CarrierStatusId = Convert.ToInt32(txtCarrierStatusId.Text);
            }
            catch
            {
                c.CarrierStatusId = 0;
            }
            c.CarrierPhoneNumber = txtCarrierPhoneNumber.Text;
            c.CarrierFaxNumber = txtCarrierFaxNumber.Text;
            c.CarrierContactName = txtCarrierContactName.Text;
            c.CarrierContactEmail = txtCarrierContactEmail.Text;
            c.CarrierContactMobileNumber = txtCarrierContactMobileNumber.Text;
            try
            {
                c.CarrierActivationDate = Convert.ToDateTime(txtCarrierActivationDate.Text);
            }
            catch
            {
                c.CarrierActivationDate = new DateTime();
            }
            try
            {
                c.CarrierSeveranceDate = Convert.ToDateTime(txtCarrierSeveranceDate.Text);
            }
            catch
            {
                c.CarrierSeveranceDate = new DateTime();
            }
            c.CarrierNotes = txtCarrierNotes.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CarrierClearEvent != null)
            {
                this.CarrierClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.CarrierAddEvent != null)
            {
                this.CarrierAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.CarrierUpdateEvent != null)
            {
                this.CarrierUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.CarrierDeleteEvent != null)
            {
                this.CarrierDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
