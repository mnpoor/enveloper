using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDriverStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler DriverStatusClearEvent;
        public event SPEventHandler DriverStatusAddEvent;
        public event SPEventHandler DriverStatusUpdateEvent;
        public event SPEventHandler DriverStatusDeleteEvent;

        private DriverStatus _driverStatus;
        private Collection<DriverStatus> _driverStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void DriverStatusClear()
        {
            _driverStatus = null;

            txtDriverStatusId.Text = string.Empty;
            txtDriverStatusDescription.Text = string.Empty;
        }

        public void DriverStatusShow(DriverStatus d)
        {
            _driverStatus = new DriverStatus(d);

            txtDriverStatusId.Text = d.DriverStatusId.ToString();
            txtDriverStatusDescription.Text = d.DriverStatusDescription;
        }

        public void DriverStatusUpdate(ref DriverStatus d)
        {
            try
            {
                d.DriverStatusId = Convert.ToInt32(txtDriverStatusId.Text);
            }
            catch
            {
                d.DriverStatusId = 0;
            }
            try
            {
                d.DriverStatusId = Convert.ToInt32(txtDriverStatusId.Text);
            }
            catch
            {
                d.DriverStatusId = 0;
            }
            d.DriverStatusDescription = txtDriverStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DriverStatusClearEvent != null)
            {
                this.DriverStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.DriverStatusAddEvent != null)
            {
                this.DriverStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.DriverStatusUpdateEvent != null)
            {
                this.DriverStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.DriverStatusDeleteEvent != null)
            {
                this.DriverStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
