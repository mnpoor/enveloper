using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPurchaseOrderStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler PurchaseOrderStatusDataGridClearEvent;
        public event SPEventHandler PurchaseOrderStatusDataGridSearchEvent;
        public event SPEventHandler PurchaseOrderStatusDataGridRowSelectedEvent;

        private Collection<PurchaseOrderStatus> _purchaseOrderStatuses = new Collection<PurchaseOrderStatus>();

        private DataTable _purchaseOrderStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void PurchaseOrderStatusDataGridClear()
        {
            txtPurchaseOrderStatusIdSearch.Text = string.Empty;
            txtPurchaseOrderStatusDescriptionSearch.Text = string.Empty;
           //gvPurchaseOrderStatuss.; // clears data grid - not implemented
        }

        public void PurchaseOrderStatusDataGridSearch()
        {
            Collection<PurchaseOrderStatus> itemCollection = new Collection<PurchaseOrderStatus>();

            txtPurchaseOrderStatusIdSearch.Text = ApplyWildcards(txtPurchaseOrderStatusIdSearch.Text);
            txtPurchaseOrderStatusDescriptionSearch.Text = ApplyWildcards(txtPurchaseOrderStatusDescriptionSearch.Text);

            _purchaseOrderStatuses = DataServicePurchaseOrderStatuses.PurchaseOrderStatusSqlGetAll();

            _purchaseOrderStatusDataTable = new DataTable("PurchaseOrderStatus");
            _purchaseOrderStatusDataTable.Columns.Add(new DataColumn("PurchaseOrderStatusId", _purchaseOrderStatuses[0].PurchaseOrderStatusId.GetType()));
            _purchaseOrderStatusDataTable.Columns[0].Caption = "PurchaseOrderStatusId ";
            _purchaseOrderStatusDataTable.Columns[0].ReadOnly = true;
            _purchaseOrderStatusDataTable.Columns.Add(new DataColumn("PurchaseOrderStatusDescription", _purchaseOrderStatuses[0].PurchaseOrderStatusDescription.GetType()));
            _purchaseOrderStatusDataTable.Columns[1].Caption = "PurchaseOrderStatusDescription ";
            _purchaseOrderStatusDataTable.Columns[1].ReadOnly = true;
            foreach (PurchaseOrderStatus item in _purchaseOrderStatuses)
            {
                object[] gridItems = new object[2] { item.PurchaseOrderStatusId, item.PurchaseOrderStatusDescription };
                _purchaseOrderStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvPurchaseOrderStatuss.DataSource = _purchaseOrderStatusDataTable;
            gvPurchaseOrderStatuss.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PurchaseOrderStatusDataGridClearEvent != null)
            {
                this.PurchaseOrderStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.PurchaseOrderStatusDataGridSearchEvent != null)
            {
                this.PurchaseOrderStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvPurchaseOrderStatuss_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvPurchaseOrderStatuss.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.PurchaseOrderStatusDataGridRowSelectedEvent != null)
            {
                this.PurchaseOrderStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
