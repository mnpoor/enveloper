using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcDriverWithholdingSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler DriverWithholdingDataGridClearEvent;
        public event SPEventHandler DriverWithholdingDataGridSearchEvent;
        public event SPEventHandler DriverWithholdingDataGridPageIndexChangingEvent;
        public event SPEventHandler DriverWithholdingDataGridRowSelectedEvent;

        private Collection<DriverWithholding> _driverWithholdings = new Collection<DriverWithholding>();

        private DataTable _driverWithholdingDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void DriverWithholdingDataGridClear()
        {
            txtDriverWitholdingIdSearch.Text = string.Empty;
            txtCarrierIdSearch.Text = string.Empty;
            txtDriverIdSearch.Text = string.Empty;
            txtWithholdingAccountIdSearch.Text = string.Empty;
            txtDriverWitholdingLedgerAccountNameSearch.Text = string.Empty;
            _driverWithholdingDataTable = new DataTable("DriverWithholding");
            gvDriverWithholdings.DataSource = _driverWithholdingDataTable;
            gvDriverWithholdings.DataBind();
        }

        public string[] DriverWithholdingDataGridWildcard()
        {
            txtDriverWitholdingIdSearch.Text = ApplyWildcards(txtDriverWitholdingIdSearch.Text);
            txtCarrierIdSearch.Text = ApplyWildcards(txtCarrierIdSearch.Text);
            txtDriverIdSearch.Text = ApplyWildcards(txtDriverIdSearch.Text);
            txtWithholdingAccountIdSearch.Text = ApplyWildcards(txtWithholdingAccountIdSearch.Text);
            txtDriverWitholdingLedgerAccountNameSearch.Text = ApplyWildcards(txtDriverWitholdingLedgerAccountNameSearch.Text);
            return new string[] { txtDriverWitholdingIdSearch.Text.Trim(), txtCarrierIdSearch.Text.Trim(), txtDriverIdSearch.Text.Trim(), txtWithholdingAccountIdSearch.Text.Trim(), txtDriverWitholdingLedgerAccountNameSearch.Text.Trim() };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void DriverWithholdingDataGridSearch(Collection<DriverWithholding> itemCollection, int pageIndex)
        {
            _driverWithholdings = new Collection<DriverWithholding>(itemCollection);
            GridViewFill(pageIndex);
        }


        public void GridViewFill(int pageIndex)
        {
            _driverWithholdingDataTable = new DataTable("DriverWithholding");
            _driverWithholdingDataTable.Columns.Add(new DataColumn("DriverWitholdingId", _driverWithholdings[0].DriverWitholdingId.GetType()));
            _driverWithholdingDataTable.Columns[0].Caption = "DriverWitholdingId ";
            _driverWithholdingDataTable.Columns[0].ReadOnly = true;
            _driverWithholdingDataTable.Columns.Add(new DataColumn("CarrierId", _driverWithholdings[0].CarrierId.GetType()));
            _driverWithholdingDataTable.Columns[1].Caption = "CarrierId ";
            _driverWithholdingDataTable.Columns[1].ReadOnly = true;
            _driverWithholdingDataTable.Columns.Add(new DataColumn("DriverId", _driverWithholdings[0].DriverId.GetType()));
            _driverWithholdingDataTable.Columns[2].Caption = "DriverId ";
            _driverWithholdingDataTable.Columns[2].ReadOnly = true;
            _driverWithholdingDataTable.Columns.Add(new DataColumn("WithholdingAccountId", _driverWithholdings[0].WithholdingAccountId.GetType()));
            _driverWithholdingDataTable.Columns[3].Caption = "WithholdingAccountId ";
            _driverWithholdingDataTable.Columns[3].ReadOnly = true;
            _driverWithholdingDataTable.Columns.Add(new DataColumn("DriverWitholdingLedgerAccountName", _driverWithholdings[0].DriverWitholdingLedgerAccountName.GetType()));
            _driverWithholdingDataTable.Columns[4].Caption = "DriverWitholdingLedgerAccountName ";
            _driverWithholdingDataTable.Columns[4].ReadOnly = true;
            foreach (DriverWithholding item in _driverWithholdings)
            {
                object[] gridItems = new object[5] { item.DriverWitholdingId, item.CarrierId, item.DriverId, item.WithholdingAccountId, item.DriverWitholdingLedgerAccountName };
                _driverWithholdingDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvDriverWithholdings.Columns.Clear();
            BoundField column0 = new BoundField();
            column0.HeaderText = "DriverWitholdingId";
            column0.DataField = "DriverWitholdingId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            gvDriverWithholdings.Columns.Add(column0);

            BoundField column1 = new BoundField();
            column1.HeaderText = "CarrierId";
            column1.DataField = "CarrierId";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;
            gvDriverWithholdings.Columns.Add(column1);

            BoundField column2 = new BoundField();
            column2.HeaderText = "DriverId";
            column2.DataField = "DriverId";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;
            gvDriverWithholdings.Columns.Add(column2);

            BoundField column3 = new BoundField();
            column3.HeaderText = "WithholdingAccountId";
            column3.DataField = "WithholdingAccountId";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;
            gvDriverWithholdings.Columns.Add(column3);

            BoundField column4 = new BoundField();
            column4.HeaderText = "DriverWitholdingLedgerAccountName";
            column4.DataField = "DriverWitholdingLedgerAccountName";
            column4.DataFormatString = "{0}";
            column4.ReadOnly = true;
            gvDriverWithholdings.Columns.Add(column4);

            gvDriverWithholdings.DataSource = _driverWithholdingDataTable;
            gvDriverWithholdings.PageIndex = pageIndex;
            gvDriverWithholdings.DataBind();
            gvDriverWithholdings.Width = new Unit((int)700);
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.DriverWithholdingDataGridClearEvent != null)
            {
                this.DriverWithholdingDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.DriverWithholdingDataGridSearchEvent != null)
            {
                this.DriverWithholdingDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvDriverWithholdings_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.DriverWithholdingDataGridPageIndexChangingEvent != null)
            {
                this.DriverWithholdingDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvDriverWithholdings_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvDriverWithholdings.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.DriverWithholdingDataGridRowSelectedEvent != null)
            {
                this.DriverWithholdingDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
