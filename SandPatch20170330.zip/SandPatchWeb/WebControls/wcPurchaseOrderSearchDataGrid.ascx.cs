using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcPurchaseOrderSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler PurchaseOrderDataGridClearEvent;
        public event SPEventHandler PurchaseOrderDataGridSearchEvent;
        public event SPEventHandler PurchaseOrderDataGridPageIndexChangingEvent;
        public event SPEventHandler PurchaseOrderDataGridRowSelectedEvent;

        private Customer _foundCustomer = null;
        private JobNumber _foundJobNumber = null;
        private Freight _foundFreight = null;

        private Collection<PurchaseOrder> _purchaseOrders = new Collection<PurchaseOrder>();

        private DataTable _purchaseOrderDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void PurchaseOrderDataGridClear()
        {
            txtPurchaseOrderNumberSearch.Text = string.Empty;
            txtCustomerNameSearch.Text = string.Empty;
            txtJobNumberAssignmentSearch.Text = string.Empty;
            txtFreightNameSearch.Text = string.Empty;
            txtPurchaseOrderDateFromSearch.Text = string.Empty;
            txtPurchaseOrderDateToSearch.Text = string.Empty;
            _purchaseOrderDataTable = new DataTable("PurchaseOrder");
            gvPurchaseOrders.DataSource = _purchaseOrderDataTable;
            gvPurchaseOrders.DataBind();
        }

        public string[] PurchaseOrderDataGridWildcard()
        {
            txtPurchaseOrderNumberSearch.Text = ApplyWildcards(txtPurchaseOrderNumberSearch.Text);
            txtCustomerNameSearch.Text = ApplyWildcards(txtCustomerNameSearch.Text);
            txtFreightNameSearch.Text = ApplyWildcards(txtFreightNameSearch.Text);
            return new string[] { txtPurchaseOrderNumberSearch.Text.Trim(), txtCustomerNameSearch.Text.Trim(), txtJobNumberAssignmentSearch.Text.Trim(), txtFreightNameSearch.Text.Trim(), txtPurchaseOrderDateFromSearch.Text.Trim(), txtPurchaseOrderDateToSearch.Text.Trim() };
        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void PurchaseOrderDataGridSearch(Collection<PurchaseOrder> itemCollection, int pageIndex)
        {
            _purchaseOrders = new Collection<PurchaseOrder>(itemCollection);
            GridViewFill(pageIndex);
        }

        //public void PurchaseOrderDataGridSearch()
        //{
        //    Collection<PurchaseOrder> itemCollection = new Collection<PurchaseOrder>();

        //    _purchaseOrders = DataServicePurchaseOrders.PurchaseOrderSqlGetBySearchTerms(txtPurchaseOrderNumberSearch.Text.Trim(), txtCustomerNameSearch.Text.Trim(), txtJobNumberAssignmentSearch.Text.Trim(), txtFreightNameSearch.Text.Trim(), txtPurchaseOrderDateFromSearch.Text.Trim(), txtPurchaseOrderDateToSearch.Text.Trim());

        //    GridViewFill(0);
        //}

        //protected void gvPurchaseOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    _purchaseOrders = DataServicePurchaseOrders.PurchaseOrderSqlGetBySearchTerms(txtPurchaseOrderNumberSearch.Text.Trim(), txtCustomerNameSearch.Text.Trim(), txtJobNumberAssignmentSearch.Text.Trim(), txtFreightNameSearch.Text.Trim(), txtPurchaseOrderDateFromSearch.Text.Trim(), txtPurchaseOrderDateToSearch.Text.Trim());

        //    GridViewFill(e.NewPageIndex);
        //}

        protected void GridViewFill(int pageIndex)
        {
            _purchaseOrderDataTable = new DataTable("PurchaseOrder");
            _purchaseOrderDataTable.Columns.Add(new DataColumn("PurchaseOrderId", typeof(string)));
            _purchaseOrderDataTable.Columns[0].Caption = "Id";
            _purchaseOrderDataTable.Columns[0].ReadOnly = true;
            _purchaseOrderDataTable.Columns.Add(new DataColumn("PurchaseOrderNumber", typeof(string)));
            _purchaseOrderDataTable.Columns[1].Caption = " Purchase Order Number ";
            _purchaseOrderDataTable.Columns[1].ReadOnly = true;
            _purchaseOrderDataTable.Columns.Add(new DataColumn("CustomerName", typeof(string)));
            _purchaseOrderDataTable.Columns[2].Caption = " Customer Name ";
            _purchaseOrderDataTable.Columns[2].ReadOnly = true;
            _purchaseOrderDataTable.Columns.Add(new DataColumn("JobNumber", typeof(string)));
            _purchaseOrderDataTable.Columns[3].Caption = " Job Number ";
            _purchaseOrderDataTable.Columns[3].ReadOnly = true;
            _purchaseOrderDataTable.Columns.Add(new DataColumn("Freight", typeof(string)));
            _purchaseOrderDataTable.Columns[4].Caption = " Freight ";
            _purchaseOrderDataTable.Columns[4].ReadOnly = true;
            _purchaseOrderDataTable.Columns.Add(new DataColumn("PurchaseOrderDate", typeof(string)));
            _purchaseOrderDataTable.Columns[5].Caption = " Purchase Order Date ";
            _purchaseOrderDataTable.Columns[5].ReadOnly = true;
            foreach (PurchaseOrder item in _purchaseOrders)
            {
                _foundCustomer = DataServiceCustomers.CustomerSqlGetById(item.CustomerId);
                _foundJobNumber = DataServiceJobNumbers.JobNumberSqlGetById(item.JobNumberId);
                _foundFreight = DataServiceFreights.FreightSqlGetById(item.FreightId);
                object[] gridItems = new object[6] { item.PurchaseOrderId, item.PurchaseOrderNumber,
                    (_foundCustomer == null ? "* Missing *" : _foundCustomer.CustomerName),
                    (_foundJobNumber == null ? "* Missing *" : _foundJobNumber.JobNumberAssignment.ToString()),
                    (_foundFreight == null ? "* Missing *" : _foundFreight.FreightName), item.PurchaseOrderDate.ToShortDateString() };
                _purchaseOrderDataTable.LoadDataRow(gridItems, true);
            }

            gvPurchaseOrders.Columns.Clear();
            BoundField column0 = new BoundField();
            column0.HeaderText = "Id";
            column0.DataField = "PurchaseOrderId";
            column0.DataFormatString = "{0}";
            column0.ReadOnly = true;
            gvPurchaseOrders.Columns.Add(column0);

            BoundField column1 = new BoundField();
            column1.HeaderText = "PurchaseOrderNumber";
            column1.DataField = "PurchaseOrderNumber";
            column1.DataFormatString = "{0}";
            column1.ReadOnly = true;
            gvPurchaseOrders.Columns.Add(column1);

            BoundField column2 = new BoundField();
            column2.HeaderText = "Customer Name";
            column2.DataField = "CustomerName";
            column2.DataFormatString = "{0}";
            column2.ReadOnly = true;
            gvPurchaseOrders.Columns.Add(column2);

            BoundField column3 = new BoundField();
            column3.HeaderText = "Job Number";
            column3.DataField = "JobNumber";
            column3.DataFormatString = "{0}";
            column3.ReadOnly = true;
            gvPurchaseOrders.Columns.Add(column3);

            BoundField column4 = new BoundField();
            column4.HeaderText = "Freight";
            column4.DataField = "Freight";
            column4.DataFormatString = "{0}";
            column4.ReadOnly = true;
            gvPurchaseOrders.Columns.Add(column4);

            BoundField column5 = new BoundField();
            column5.HeaderText = "Date";
            column5.DataField = "PurchaseOrderDate";
            column5.DataFormatString = "{0}";
            column5.ReadOnly = true;
            gvPurchaseOrders.Columns.Add(column5);

            gvPurchaseOrders.DataSource = _purchaseOrderDataTable;
            gvPurchaseOrders.PageIndex = pageIndex;
            gvPurchaseOrders.DataBind();
            gvPurchaseOrders.Width = new Unit((int)750);

            _purchaseOrderDataTable = new DataTable("PurchaseOrder");     // empty out data table
            _purchaseOrders = new Collection<PurchaseOrder>();           // empty out collection
            GC.Collect();                                       // consolidate heap space
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.PurchaseOrderDataGridClearEvent != null)
            {
                this.PurchaseOrderDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.PurchaseOrderDataGridSearchEvent != null)
            {
                this.PurchaseOrderDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvPurchaseOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            OnPageIndexChanging(e.NewPageIndex);
        }

        private void OnPageIndexChanging(int pageIndex)
        {
            if (this.PurchaseOrderDataGridPageIndexChangingEvent != null)
            {
                this.PurchaseOrderDataGridPageIndexChangingEvent(this, new SPEventArgs(null, pageIndex));
            }
        }

        protected void gvPurchaseOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvPurchaseOrders.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.PurchaseOrderDataGridRowSelectedEvent != null)
            {
                this.PurchaseOrderDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
