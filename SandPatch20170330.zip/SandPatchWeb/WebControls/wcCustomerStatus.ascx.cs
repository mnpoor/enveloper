using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcCustomerStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler CustomerStatusClearEvent;
        public event SPEventHandler CustomerStatusAddEvent;
        public event SPEventHandler CustomerStatusUpdateEvent;
        public event SPEventHandler CustomerStatusDeleteEvent;

        private CustomerStatus _customerStatus;
        private Collection<CustomerStatus> _customerStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void CustomerStatusClear()
        {
            _customerStatus = null;

            txtCustomerStatusId.Text = string.Empty;
            txtCustomerStatusDescription.Text = string.Empty;
        }

        public void CustomerStatusShow(CustomerStatus c)
        {
            _customerStatus = new CustomerStatus(c);

            txtCustomerStatusId.Text = c.CustomerStatusId.ToString();
            txtCustomerStatusDescription.Text = c.CustomerStatusDescription;
        }

        public void CustomerStatusUpdate(ref CustomerStatus c)
        {
            try
            {
                c.CustomerStatusId = Convert.ToInt32(txtCustomerStatusId.Text);
            }
            catch
            {
                c.CustomerStatusId = 0;
            }
            try
            {
                c.CustomerStatusId = Convert.ToInt32(txtCustomerStatusId.Text);
            }
            catch
            {
                c.CustomerStatusId = 0;
            }
            c.CustomerStatusDescription = txtCustomerStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.CustomerStatusClearEvent != null)
            {
                this.CustomerStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.CustomerStatusAddEvent != null)
            {
                this.CustomerStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.CustomerStatusUpdateEvent != null)
            {
                this.CustomerStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.CustomerStatusDeleteEvent != null)
            {
                this.CustomerStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
