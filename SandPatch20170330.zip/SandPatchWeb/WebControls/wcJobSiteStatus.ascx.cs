using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcJobSiteStatus : System.Web.UI.UserControl
    {
        public event SPEventHandler JobSiteStatusClearEvent;
        public event SPEventHandler JobSiteStatusAddEvent;
        public event SPEventHandler JobSiteStatusUpdateEvent;
        public event SPEventHandler JobSiteStatusDeleteEvent;

        private JobSiteStatus _jobSiteStatus;
        private Collection<JobSiteStatus> _jobSiteStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdAdd.Click += new EventHandler(cmdAdd_Click);
                cmdUpdate.Click += new EventHandler(cmdUpdate_Click);
                cmdDelete.Click += new EventHandler(cmdDelete_Click);
            }
        }

        public void JobSiteStatusClear()
        {
            _jobSiteStatus = null;

            txtJobSiteStatusId.Text = string.Empty;
            txtJobSiteStatusDescription.Text = string.Empty;
        }

        public void JobSiteStatusShow(JobSiteStatus j)
        {
            _jobSiteStatus = new JobSiteStatus(j);

            txtJobSiteStatusId.Text = j.JobSiteStatusId.ToString();
            txtJobSiteStatusDescription.Text = j.JobSiteStatusDescription;
        }

        public void JobSiteStatusUpdate(ref JobSiteStatus j)
        {
            try
            {
                j.JobSiteStatusId = Convert.ToInt32(txtJobSiteStatusId.Text);
            }
            catch
            {
                j.JobSiteStatusId = 0;
            }
            try
            {
                j.JobSiteStatusId = Convert.ToInt32(txtJobSiteStatusId.Text);
            }
            catch
            {
                j.JobSiteStatusId = 0;
            }
            j.JobSiteStatusDescription = txtJobSiteStatusDescription.Text;
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.JobSiteStatusClearEvent != null)
            {
                this.JobSiteStatusClearEvent(this, new SPEventArgs(null, SPObjectAction.clear));
            }
        }

        public void cmdAdd_Click(object sender, EventArgs e)
        {
            OnAdd();
        }

        private void OnAdd()
        {
            if (this.JobSiteStatusAddEvent != null)
            {
                this.JobSiteStatusAddEvent(this, new SPEventArgs(null, SPObjectAction.add));
            }
        }

        public void cmdUpdate_Click(object sender, EventArgs e)
        {
            OnUpdate();
        }

        private void OnUpdate()
        {
            if (this.JobSiteStatusUpdateEvent != null)
            {
                this.JobSiteStatusUpdateEvent(this, new SPEventArgs(null, SPObjectAction.update));
            }
        }

        public void cmdDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        private void OnDelete()
        {
            if (this.JobSiteStatusDeleteEvent != null)
            {
                this.JobSiteStatusDeleteEvent(this, new SPEventArgs(null, SPObjectAction.delete));
            }
        }

    }
}
