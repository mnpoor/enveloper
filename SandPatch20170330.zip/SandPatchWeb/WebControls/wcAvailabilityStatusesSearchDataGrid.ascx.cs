using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb.WebControls
{
    public partial class wcAvailabilityStatusesSearchDataGrid : System.Web.UI.UserControl
    {
        public event SPEventHandler AvailabilityStatusDataGridClearEvent;
        public event SPEventHandler AvailabilityStatusDataGridSearchEvent;
        public event SPEventHandler AvailabilityStatusDataGridRowSelectedEvent;

        private Collection<AvailabilityStatus> _availabilityStatuss = new Collection<AvailabilityStatus>();

        private DataTable _availabilityStatusDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdClear.Click += new EventHandler(cmdClear_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
        }

        public void AvailabilityStatusDataGridClear()
        {
            _availabilityStatusDataTable = new DataTable("AvailabilityStatus");
            gvAvailabilityStatuses.DataSource = _availabilityStatusDataTable;
            gvAvailabilityStatuses.DataBind();
        }

        public void AvailabilityStatusDataGridSearch()
        {
            Collection<AvailabilityStatus> itemCollection = new Collection<AvailabilityStatus>();

            _availabilityStatuss = DataServiceAvailabilityStatuses.AvailabilityStatusSqlGetAll();

            _availabilityStatusDataTable = new DataTable("AvailabilityStatus");
            _availabilityStatusDataTable.Columns.Add(new DataColumn("Availability Status Id ", typeof(string)));
            _availabilityStatusDataTable.Columns[0].Caption = "Availability Status Id ";
            _availabilityStatusDataTable.Columns[0].ReadOnly = true;
            _availabilityStatusDataTable.Columns.Add(new DataColumn("Availability Status Description ", typeof(string)));
            _availabilityStatusDataTable.Columns[1].Caption = "Availability Status Description ";
            _availabilityStatusDataTable.Columns[1].ReadOnly = true;
            _availabilityStatusDataTable.Columns.Add(new DataColumn("Color Code ", typeof(string)));
            _availabilityStatusDataTable.Columns[2].Caption = "ColorCode ";
            _availabilityStatusDataTable.Columns[2].ReadOnly = true;
            foreach (AvailabilityStatus item in _availabilityStatuss)
            {
                object[] gridItems = new object[3] { item.AvailabilityStatusId.ToString(), item.AvailabilityStatusDescription, item.AvailabilityColorCode };
                _availabilityStatusDataTable.LoadDataRow(gridItems, true);
            }
            //Console.WriteLine(itemCollection.Count.ToString());

            gvAvailabilityStatuses.DataSource = _availabilityStatusDataTable;
            gvAvailabilityStatuses.DataBind();

        }

        private string ApplyWildcards(string searchTerm)
        {
            if (searchTerm == string.Empty) return string.Empty;
            if (searchTerm.Contains("%")) return searchTerm.Trim();
            return "%" + searchTerm.Trim() + "%";
        }

        public void cmdClear_Click(object sender, EventArgs e)
        {
            OnClear();
        }

        private void OnClear()
        {
            if (this.AvailabilityStatusDataGridClearEvent != null)
            {
                this.AvailabilityStatusDataGridClearEvent(this, new SPEventArgs(null, SPObjectAction.clearSearch));
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            OnSearch();
        }

        private void OnSearch()
        {
            if (this.AvailabilityStatusDataGridSearchEvent != null)
            {
                this.AvailabilityStatusDataGridSearchEvent(this, new SPEventArgs(null, SPObjectAction.search));
            }
        }

        protected void gvAvailabilityStatuses_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow selectedRow = gvAvailabilityStatuses.SelectedRow;
            TableCellCollection selectedRowCells = selectedRow.Cells;
            TableCell selectedCell = selectedRowCells[1];

            if (this.AvailabilityStatusDataGridRowSelectedEvent != null)
            {
                this.AvailabilityStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            }
        }

    }
}
