using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDispatch : System.Web.UI.Page
    {
        private Collection<Customer> _customers;
        private Collection<JobNumber> _jobNumbers;
        private Collection<PurchaseOrder> _purchaseOrders;
        private Collection<Carrier> _carriers;
        private Collection<Driver> _drivers;
        private Collection<DispatchStatus> _dispatchStatuses;
        private Collection<Freight> _freights;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<JobSite> _jobSites;

        private BillOfLading _billOfLading;

        private Dispatch _dispatch;
        private Collection<Dispatch> _dispatches;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _dispatch = new Dispatch();
            wcDispatchSearch.DispatchDataGridClearEvent += new SPEventHandler(wcDispatchSearch_DispatchDataGridClearEvent);
            wcDispatchSearch.DispatchDataGridSearchEvent += new SPEventHandler(wcDispatchSearch_DispatchDataGridSearchEvent);
            wcDispatchSearch.DispatchDataGridPageIndexChangingEvent += new SPEventHandler(wcDispatchSearch_DispatchDataGridPageIndexEvent);
            wcDispatchSearch.DispatchDataGridRowSelectedEvent += new SPEventHandler(wcDispatchSearch_DispatchDataGridRowSelectedEvent);
            wcDispatchEdit.DispatchClearEvent += new SPEventHandler(wcDispatchEdit_DispatchClearEvent);
            wcDispatchEdit.DispatchAddEvent += new SPEventHandler(wcDispatchEdit_DispatchAddEvent);
            wcDispatchEdit.DispatchUpdateEvent += new SPEventHandler(wcDispatchEdit_DispatchUpdateEvent);
            wcDispatchEdit.DispatchDeleteEvent += new SPEventHandler(wcDispatchEdit_DispatchDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcDispatchSearch.DispatchDataGridClear();
            }

            if (wcDispatchEdit.CustomerCount < 1)
            {
                _customers = DataServiceCustomers.CustomerSqlGetAll();
                _customers.Insert(0, new Customer());
                _customers[0].CustomerName = "* Unassigned *";
                wcDispatchEdit.CustomersFill(_customers);
            }

            if (wcDispatchEdit.JobNumberCount < 1)
            {
                _jobNumbers = DataServiceJobNumbers.JobNumberSqlGetAll();
                _jobNumbers.Insert(0, new JobNumber());
                _jobNumbers[0].JobNumberAssignment = 0;
                wcDispatchEdit.JobNumbersFill(_jobNumbers);
            }

            if (wcDispatchEdit.PurchaseOrderCount < 1)
            {
                _purchaseOrders = DataServicePurchaseOrders.PurchaseOrderSqlGetAll();
                _purchaseOrders.Insert(0, new PurchaseOrder());
                _purchaseOrders[0].PurchaseOrderNumber = "* Unassigned *";
                wcDispatchEdit.PurchaseOrdersFill(_purchaseOrders);
            }

            if (wcDispatchEdit.CarrierCount < 1)
            {
                _carriers = DataServiceCarriers.CarrierSqlGetAll();
                _carriers.Insert(0, new Carrier());
                _carriers[0].CarrierCompanyName = "* Unassigned *";
                wcDispatchEdit.CarriersFill(_carriers);
            }

            if (wcDispatchEdit.DriverCount < 1)
            {
                _drivers = DataServiceDrivers.DriverSqlGetAll();
                _drivers.Insert(0, new Driver());
                _drivers[0].DriverName = "* Unassigned *";
                wcDispatchEdit.DriversFill(_drivers);
            }

            if (wcDispatchEdit.DispatchStatusCount < 1)
            {
                _dispatchStatuses = DataServiceDispatchStatuses.DispatchStatusSqlGetAll();
                _dispatchStatuses.Insert(0, new DispatchStatus());
                _dispatchStatuses[0].DispatchStatusDescription = "* Unassigned *";
                wcDispatchEdit.DispatchStatusesFill(_dispatchStatuses);
            }

            if (wcDispatchEdit.FreightCount < 1)
            {
                _freights = DataServiceFreights.FreightSqlGetAll();
                _freights.Insert(0, new Freight());
                _freights[0].FreightName = "* Unassigned *";
                wcDispatchEdit.FreightsFill(_freights);
            }

            if (wcDispatchEdit.LoadingTerminalCount < 1)
            {
                _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                _loadingTerminals.Insert(0, new LoadingTerminal());
                _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
                wcDispatchEdit.LoadingTerminalsFill(_loadingTerminals);
            }

            if (wcDispatchEdit.JobSiteCount < 1)
            {
                _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                _jobSites.Insert(0, new JobSite());
                _jobSites[0].JobSiteName = "* Unassigned *";
                wcDispatchEdit.JobSitesFill(_jobSites);
            }

        }

        public void wcDispatchSearch_DispatchDataGridClearEvent(object sender, SPEventArgs e)
        {
            _dispatches = new Collection<Dispatch>();
            wcDispatchSearch.DispatchDataGridClear();
        }

        public void wcDispatchSearch_DispatchDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcDispatchSearch.DispatchDataGridWildcard();
            _dispatches = DataServiceDispatches.DispatchSqlGetBySearchTerms(_searchTerms);
            wcDispatchSearch.DispatchDataGridSearch(_dispatches, 0);

            _dispatches = new Collection<Dispatch>(); // free up allocated memory
            GC.Collect();                             // consolidate heap space
        }

        public void wcDispatchSearch_DispatchDataGridPageIndexEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcDispatchSearch.DispatchDataGridWildcard();
            _dispatches = DataServiceDispatches.DispatchSqlGetBySearchTerms(_searchTerms);
            wcDispatchSearch.DispatchDataGridSearch(_dispatches, e.Index);

            _dispatches = new Collection<Dispatch>(); // free up allocated memory
            GC.Collect();                             // consolidate heap space
        }

        public void wcDispatchSearch_DispatchDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _dispatch = SandPatchCL.DataServices.DataServiceDispatches.DispatchSqlGetById(e.Index);
            wcDispatchEdit.DispatchShow(_dispatch);
        }

        public void wcDispatchEdit_DispatchClearEvent(object sender, SPEventArgs e)
        {
            _dispatch = new Dispatch();
            wcDispatchEdit.DispatchClear();
        }

        public void wcDispatchEdit_DispatchAddEvent(object sender, SPEventArgs e)
        {
            wcDispatchEdit.DispatchUpdate(ref _dispatch);
            DataServiceDispatches.SqlSave(ref _dispatch);
            //if (_dispatch.BillOfLadingId > 0) SynchronizeBOLToDispatch();
            wcDispatchEdit.DispatchShow(_dispatch);
        }

        public void wcDispatchEdit_DispatchUpdateEvent(object sender, SPEventArgs e)
        {
            wcDispatchEdit.DispatchUpdate(ref _dispatch);
            DataServiceDispatches.SqlSave(ref _dispatch);
            //if (_dispatch.BillOfLadingId > 0) SynchronizeBOLToDispatch();
            wcDispatchEdit.DispatchShow(_dispatch);
        }

        public void wcDispatchEdit_DispatchDeleteEvent(object sender, SPEventArgs e)
        {
            wcDispatchEdit.DispatchUpdate(ref _dispatch);
            DataServiceDispatches.SqlDelete(ref _dispatch);
            _dispatch = new Dispatch();
            wcDispatchEdit.DispatchClear();
            _searchTerms = wcDispatchSearch.DispatchDataGridWildcard();
            _dispatches = DataServiceDispatches.DispatchSqlGetBySearchTerms(_searchTerms);
            wcDispatchSearch.DispatchDataGridSearch(_dispatches, 0);

            _dispatches = new Collection<Dispatch>(); // free up allocated memory
            GC.Collect();                             // consolidate heap space
        }

        private void SynchronizeBOLToDispatch()
        {
            _billOfLading = DataServiceBillsOfLading.BillOfLadingSqlGetById(_dispatch.BillOfLadingId);
            if (_billOfLading == null) return;
            DataServiceBillsOfLading.SynchronizeBOLToDispatch(ref _billOfLading, ref _dispatch);
        }

    }
}
