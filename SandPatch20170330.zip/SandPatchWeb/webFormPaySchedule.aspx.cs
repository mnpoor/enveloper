using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormPaySchedule : System.Web.UI.Page
    {
        private PaySchedule _paySchedule;
        private Collection<PaySchedule> _paySchedules;

        protected void Page_Load(object sender, EventArgs e)
        {
            _paySchedule = new PaySchedule();
            wcPayScheduleSearch.PayScheduleDataGridClearEvent += new SPEventHandler(wcPayScheduleSearch_PayScheduleDataGridClearEvent);
            wcPayScheduleSearch.PayScheduleDataGridSearchEvent += new SPEventHandler(wcPayScheduleSearch_PayScheduleDataGridSearchEvent);
            wcPayScheduleSearch.PayScheduleDataGridRowSelectedEvent += new SPEventHandler(wcPayScheduleSearch_PayScheduleDataGridRowSelectedEvent);
            wcPayScheduleEdit.PayScheduleClearEvent += new SPEventHandler(wcPayScheduleEdit_PayScheduleClearEvent);
            wcPayScheduleEdit.PayScheduleAddEvent += new SPEventHandler(wcPayScheduleEdit_PayScheduleAddEvent);
            wcPayScheduleEdit.PayScheduleUpdateEvent += new SPEventHandler(wcPayScheduleEdit_PayScheduleUpdateEvent);
            wcPayScheduleEdit.PayScheduleDeleteEvent += new SPEventHandler(wcPayScheduleEdit_PayScheduleDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcPayScheduleSearch.PayScheduleDataGridClear();
            }
        }

        public void wcPayScheduleSearch_PayScheduleDataGridClearEvent(object sender, SPEventArgs e)
        {
            _paySchedules = new Collection<PaySchedule>();
            wcPayScheduleSearch.PayScheduleDataGridClear();
        }

        public void wcPayScheduleSearch_PayScheduleDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleSearch.PayScheduleDataGridSearch();
        }

        public void wcPayScheduleSearch_PayScheduleDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _paySchedule = SandPatchCL.DataServices.DataServicePaySchedules.PayScheduleSqlGetById(e.Index);
            wcPayScheduleEdit.PayScheduleShow(_paySchedule);
        }

        public void wcPayScheduleEdit_PayScheduleClearEvent(object sender, SPEventArgs e)
        {
            _paySchedule = new PaySchedule();
            wcPayScheduleEdit.PayScheduleClear();
        }

        public void wcPayScheduleEdit_PayScheduleAddEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleEdit.PayScheduleUpdate(ref _paySchedule);
            DataServicePaySchedules.SqlSave(ref _paySchedule);
            wcPayScheduleEdit.PayScheduleShow(_paySchedule);
        }

        public void wcPayScheduleEdit_PayScheduleUpdateEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleEdit.PayScheduleUpdate(ref _paySchedule);
            DataServicePaySchedules.SqlSave(ref _paySchedule);
            wcPayScheduleEdit.PayScheduleShow(_paySchedule);
        }

        public void wcPayScheduleEdit_PayScheduleDeleteEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleEdit.PayScheduleUpdate(ref _paySchedule);
            DataServicePaySchedules.SqlDelete(ref _paySchedule);
            _paySchedule = new PaySchedule();
            wcPayScheduleEdit.PayScheduleClear();
            wcPayScheduleSearch.PayScheduleDataGridSearch();
        }

    }
}
