using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormJobNumber : System.Web.UI.Page
    {
        private Collection<Customer> _customers;
        private Collection<OriginType> _originTypes;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<DestinationType> _destinationTypes;
        private Collection<JobSite> _jobSites;
        private Collection<JobNumberStatus> _jobNumberStatuses;

        private JobNumber _jobNumber;
        private Collection<JobNumber> _jobNumbers;

        private OriginType _selectedOriginType;
        private DestinationType _selectedDestinationType;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _jobNumber = new JobNumber();
            wcJobNumberSearch.JobNumberDataGridClearEvent += new SPEventHandler(wcJobNumberSearch_JobNumberDataGridClearEvent);
            wcJobNumberSearch.JobNumberDataGridSearchEvent += new SPEventHandler(wcJobNumberSearch_JobNumberDataGridSearchEvent);
            wcJobNumberSearch.JobNumberDataGridPageIndexChangingEvent += new SPEventHandler(wcJobNumberSearch_JobNumberDataGridPageIndexChangingEvent);
            wcJobNumberSearch.JobNumberDataGridRowSelectedEvent += new SPEventHandler(wcJobNumberSearch_JobNumberDataGridRowSelectedEvent);
            wcJobNumberEdit.JobNumberClearEvent += new SPEventHandler(wcJobNumberEdit_JobNumberClearEvent);
            wcJobNumberEdit.JobNumberOriginTypeChangedEvent += new SPEventHandler(wcJobNumberEdit_JobNumberOriginTypeChangedEvent);
            wcJobNumberEdit.JobNumberDestinationTypeChangedEvent += new SPEventHandler(wcJobNumberEdit_JobNumberDestinationTypeChangedEvent);
            wcJobNumberEdit.JobNumberAddEvent += new SPEventHandler(wcJobNumberEdit_JobNumberAddEvent);
            wcJobNumberEdit.JobNumberUpdateEvent += new SPEventHandler(wcJobNumberEdit_JobNumberUpdateEvent);
            wcJobNumberEdit.JobNumberDeleteEvent += new SPEventHandler(wcJobNumberEdit_JobNumberDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcJobNumberSearch.JobNumberDataGridClear();
                _selectedOriginType = new OriginType();
                _selectedOriginType.OriginTypeId = 1;
                _selectedDestinationType = new DestinationType();
                _selectedDestinationType.DestinationTypeId = 1;
            }

            if (wcJobNumberEdit.CustomerCount < 1)
            {
                _customers = DataServiceCustomers.CustomerSqlGetAll();
                _customers.Insert(0, new Customer());
                _customers[0].CustomerName = "* Unassigned *";
                wcJobNumberEdit.CustomersFill(_customers);
            }

            if (wcJobNumberEdit.OriginTypeCount < 1)
            {
                _originTypes = DataServiceOriginTypes.OriginTypeSqlGetAll();
                _originTypes.Insert(0, new OriginType());
                _originTypes[0].OriginTypeDescription = "* Unassigned *";
            }

            if (wcJobNumberEdit.PointOfOriginCount < 1)
            {
                _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                _loadingTerminals.Insert(0, new LoadingTerminal());
                _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
            }

            if (wcJobNumberEdit.DestinationTypeCount < 1)
            {
                _destinationTypes = DataServiceDestinationTypes.DestinationTypeSqlGetAll();
                _destinationTypes.Insert(0, new DestinationType());
                _destinationTypes[0].DestinationTypeDescription = "* Unassigned *";
            }

            if (wcJobNumberEdit.DestinationCount < 1)
            {
                _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                _jobSites.Insert(0, new JobSite());
                _jobSites[0].JobSiteName = "* Unassigned *";
            }

            if (wcJobNumberEdit.JobNumberStatusCount < 1)
            {
                _jobNumberStatuses = DataServiceJobNumberStatuses.JobNumberStatusSqlGetAll();
                _jobNumberStatuses.Insert(0, new JobNumberStatus());
                _jobNumberStatuses[0].JobNumberStatusDescription = "* Unassigned *";
            }
            wcJobNumberEdit.OriginTypesFill(_originTypes);
            wcJobNumberEdit.LoadingTerminalsFill(_loadingTerminals);
            wcJobNumberEdit.DestinationTypesFill(_destinationTypes);
            wcJobNumberEdit.JobSitesFill(_jobSites);
            wcJobNumberEdit.JobNumberStatusesFill(_jobNumberStatuses);
        }

        public void wcJobNumberSearch_JobNumberDataGridClearEvent(object sender, SPEventArgs e)
        {
            _jobNumbers = new Collection<JobNumber>();
            wcJobNumberSearch.JobNumberDataGridClear();
        }

        public void wcJobNumberSearch_JobNumberDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcJobNumberSearch.JobNumberDataGridWildcard();
            _jobNumbers = SandPatchCL.DataServices.DataServiceJobNumbers.JobNumberSqlGetBySearchTerms(_searchTerms);
            wcJobNumberSearch.JobNumberDataGridSearch(_jobNumbers, 0);
        }

        public void wcJobNumberSearch_JobNumberDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcJobNumberSearch.JobNumberDataGridWildcard();
            _jobNumbers = SandPatchCL.DataServices.DataServiceJobNumbers.JobNumberSqlGetBySearchTerms(_searchTerms);
            wcJobNumberSearch.JobNumberDataGridSearch(_jobNumbers, e.Index);
        }

        public void wcJobNumberSearch_JobNumberDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _jobNumber = SandPatchCL.DataServices.DataServiceJobNumbers.JobNumberSqlGetById(e.Index);
            wcJobNumberEdit.JobNumberShow(_jobNumber);
        }

        public void wcJobNumberEdit_JobNumberClearEvent(object sender, SPEventArgs e)
        {
            _jobNumber = new JobNumber();
            wcJobNumberEdit.JobNumberClear();
        }

        public void wcJobNumberEdit_JobNumberOriginTypeChangedEvent(object sender, SPEventArgs e)
        {          
            switch (wcJobNumberEdit.OriginTypeIdSelected)
            {
                case 1:
                    {
                        _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                        _loadingTerminals.Insert(0, new LoadingTerminal());
                        _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
                        wcJobNumberEdit.LoadingTerminalsFill(_loadingTerminals);
                        wcJobNumberEdit.LoadingTerminalsPopulateOriginDropdown();
                        break;
                    }
                case 2:
                    {
                        _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                        _jobSites.Insert(0, new JobSite());
                        _jobSites[0].JobSiteName = "* Unassigned *";
                        wcJobNumberEdit.JobSitesFill(_jobSites);
                        wcJobNumberEdit.JobSitesPopulateOriginDropdown();
                        break;
                    }
                default:
                    {
                        wcJobNumberEdit.EnrouteClearOriginDropdown();
                        break;
                    }
            }
        }

        public void wcJobNumberEdit_JobNumberDestinationTypeChangedEvent(object sender, SPEventArgs e)
        {
            switch (wcJobNumberEdit.DestinationTypeIdSelected)
            {
                case 1:
                    {
                        _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                        _jobSites.Insert(0, new JobSite());
                        _jobSites[0].JobSiteName = "* Unassigned *";
                        wcJobNumberEdit.JobSitesFill(_jobSites);
                        wcJobNumberEdit.JobSitesPopulateDestinationDropdown();
                        break;
                    }
                case 2:
                    {
                        _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                        _loadingTerminals.Insert(0, new LoadingTerminal());
                        _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
                        wcJobNumberEdit.LoadingTerminalsFill(_loadingTerminals);
                        wcJobNumberEdit.LoadingTerminalsPopulateDestinationDropdown();
                        break;
                    }
            }
        }

        public void wcJobNumberEdit_JobNumberAddEvent(object sender, SPEventArgs e)
        {
            wcJobNumberEdit.JobNumberUpdate(ref _jobNumber);
            DataServiceJobNumbers.SqlSave(ref _jobNumber);
            wcJobNumberEdit.JobNumberShow(_jobNumber);
        }

        public void wcJobNumberEdit_JobNumberUpdateEvent(object sender, SPEventArgs e)
        {
            wcJobNumberEdit.JobNumberUpdate(ref _jobNumber);
            DataServiceJobNumbers.SqlSave(ref _jobNumber);
            wcJobNumberEdit.JobNumberShow(_jobNumber);
        }

        public void wcJobNumberEdit_JobNumberDeleteEvent(object sender, SPEventArgs e)
        {
            wcJobNumberEdit.JobNumberUpdate(ref _jobNumber);
            DataServiceJobNumbers.SqlDelete(ref _jobNumber);
            _jobNumber = new JobNumber();
            wcJobNumberEdit.JobNumberClear();
            _searchTerms = wcJobNumberSearch.JobNumberDataGridWildcard();
            _jobNumbers = SandPatchCL.DataServices.DataServiceJobNumbers.JobNumberSqlGetBySearchTerms(_searchTerms);
            wcJobNumberSearch.JobNumberDataGridSearch(_jobNumbers, 0);
        }

    }
}
