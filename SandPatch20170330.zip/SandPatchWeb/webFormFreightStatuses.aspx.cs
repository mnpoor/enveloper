using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormFreightStatuses : System.Web.UI.Page
    {
        private FreightStatus _freightStatus;
        private Collection<FreightStatus> _freightStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _freightStatus = new FreightStatus();
            wcFreightStatusesSearch.FreightStatusDataGridClearEvent += new SPEventHandler(wcFreightStatusesSearch_FreightStatusDataGridClearEvent);
            wcFreightStatusesSearch.FreightStatusDataGridSearchEvent += new SPEventHandler(wcFreightStatusesSearch_FreightStatusDataGridSearchEvent);
            wcFreightStatusesSearch.FreightStatusDataGridRowSelectedEvent += new SPEventHandler(wcFreightStatusesSearch_FreightStatusDataGridRowSelectedEvent);
            wcFreightStatusesManager.FreightStatusClearEvent += new SPEventHandler(wcFreightStatusesManager_FreightStatusClearEvent);
            wcFreightStatusesManager.FreightStatusAddEvent += new SPEventHandler(wcFreightStatusesManager_FreightStatusAddEvent);
            wcFreightStatusesManager.FreightStatusUpdateEvent += new SPEventHandler(wcFreightStatusesManager_FreightStatusUpdateEvent);
            wcFreightStatusesManager.FreightStatusDeleteEvent += new SPEventHandler(wcFreightStatusesManager_FreightStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcFreightStatusesSearch.FreightStatusDataGridClear();
            }
        }

        public void wcFreightStatusesSearch_FreightStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _freightStatuses = new Collection<FreightStatus>();
            wcFreightStatusesSearch.FreightStatusDataGridClear();
        }

        public void wcFreightStatusesSearch_FreightStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcFreightStatusesSearch.FreightStatusDataGridSearch();
        }

        public void wcFreightStatusesSearch_FreightStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _freightStatus = SandPatchCL.DataServices.DataServiceFreightStatuses.FreightStatusSqlGetById(e.Index);
            wcFreightStatusesManager.FreightStatusShow(_freightStatus);
        }

        public void wcFreightStatusesManager_FreightStatusClearEvent(object sender, SPEventArgs e)
        {
            _freightStatus = new FreightStatus();
            wcFreightStatusesManager.FreightStatusClear();
        }

        public void wcFreightStatusesManager_FreightStatusAddEvent(object sender, SPEventArgs e)
        {
            wcFreightStatusesManager.FreightStatusUpdate(ref _freightStatus);
            DataServiceFreightStatuses.SqlSave(ref _freightStatus);
            wcFreightStatusesManager.FreightStatusShow(_freightStatus);
        }

        public void wcFreightStatusesManager_FreightStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcFreightStatusesManager.FreightStatusUpdate(ref _freightStatus);
            DataServiceFreightStatuses.SqlSave(ref _freightStatus);
            wcFreightStatusesManager.FreightStatusShow(_freightStatus);
        }

        public void wcFreightStatusesManager_FreightStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcFreightStatusesManager.FreightStatusUpdate(ref _freightStatus);
            DataServiceFreightStatuses.SqlDelete(ref _freightStatus);
            _freightStatus = new FreightStatus();
            wcFreightStatusesManager.FreightStatusClear();
            wcFreightStatusesSearch.FreightStatusDataGridSearch();
        }

    }
}
