using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormFreight : System.Web.UI.Page
    {
        private Freight _freight;
        private Collection<Freight> _freights;

        private Collection<FreightStatus> _freightStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _freight = new Freight();
            wcFreightSearch.FreightDataGridClearEvent += new SPEventHandler(wcFreightSearch_FreightDataGridClearEvent);
            wcFreightSearch.FreightDataGridSearchEvent += new SPEventHandler(wcFreightSearch_FreightDataGridSearchEvent);
            wcFreightSearch.FreightDataGridRowSelectedEvent += new SPEventHandler(wcFreightSearch_FreightDataGridRowSelectedEvent);
            wcFreightEdit.FreightClearEvent += new SPEventHandler(wcFreightEdit_FreightClearEvent);
            wcFreightEdit.FreightAddEvent += new SPEventHandler(wcFreightEdit_FreightAddEvent);
            wcFreightEdit.FreightUpdateEvent += new SPEventHandler(wcFreightEdit_FreightUpdateEvent);
            wcFreightEdit.FreightDeleteEvent += new SPEventHandler(wcFreightEdit_FreightDeleteEvent);
            if (wcFreightEdit.FreightStatusesCount < 1)
            {
                _freightStatuses = DataServiceFreightStatuses.FreightStatusSqlGetAll();
                _freightStatuses.Insert(0, new FreightStatus());
                _freightStatuses[0].FreightStatusDescription = "* Unassigned *";
                wcFreightEdit.FreightStatusesFill(_freightStatuses);
            }
            if (!Page.IsPostBack)
            {
                wcFreightSearch.FreightDataGridClear();
            }
        }

        public void wcFreightSearch_FreightDataGridClearEvent(object sender, SPEventArgs e)
        {
            _freights = new Collection<Freight>();
            wcFreightSearch.FreightDataGridClear();
        }

        public void wcFreightSearch_FreightDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcFreightSearch.FreightDataGridSearch();
        }

        public void wcFreightSearch_FreightDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _freight = SandPatchCL.DataServices.DataServiceFreights.FreightSqlGetById(e.Index);
            wcFreightEdit.FreightShow(_freight);
        }

        public void wcFreightEdit_FreightClearEvent(object sender, SPEventArgs e)
        {
            _freight = new Freight();
            wcFreightEdit.FreightClear();
        }

        public void wcFreightEdit_FreightAddEvent(object sender, SPEventArgs e)
        {
            wcFreightEdit.FreightUpdate(ref _freight);
            DataServiceFreights.SqlSave(ref _freight);
            wcFreightEdit.FreightShow(_freight);
        }

        public void wcFreightEdit_FreightUpdateEvent(object sender, SPEventArgs e)
        {
            wcFreightEdit.FreightUpdate(ref _freight);
            DataServiceFreights.SqlSave(ref _freight);
            wcFreightEdit.FreightShow(_freight);
        }

        public void wcFreightEdit_FreightDeleteEvent(object sender, SPEventArgs e)
        {
            wcFreightEdit.FreightUpdate(ref _freight);
            DataServiceFreights.SqlDelete(ref _freight);
            _freight = new Freight();
            wcFreightEdit.FreightClear();
            wcFreightSearch.FreightDataGridSearch();
        }

    }
}
