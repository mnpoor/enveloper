using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormPurchaseOrderStatuses : System.Web.UI.Page
    {
        private PurchaseOrderStatus _purchaseOrderStatus;
        private Collection<PurchaseOrderStatus> _purchaseOrderStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _purchaseOrderStatus = new PurchaseOrderStatus();
            wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridClearEvent += new SPEventHandler(wcPurchaseOrderStatusesSearch_PurchaseOrderStatusDataGridClearEvent);
            wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridSearchEvent += new SPEventHandler(wcPurchaseOrderStatusesSearch_PurchaseOrderStatusDataGridSearchEvent);
            wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridRowSelectedEvent += new SPEventHandler(wcPurchaseOrderStatusesSearch_PurchaseOrderStatusDataGridRowSelectedEvent);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusClearEvent += new SPEventHandler(wcPurchaseOrderStatusesManager_PurchaseOrderStatusClearEvent);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusAddEvent += new SPEventHandler(wcPurchaseOrderStatusesManager_PurchaseOrderStatusAddEvent);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusUpdateEvent += new SPEventHandler(wcPurchaseOrderStatusesManager_PurchaseOrderStatusUpdateEvent);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusDeleteEvent += new SPEventHandler(wcPurchaseOrderStatusesManager_PurchaseOrderStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridClear();
            }
        }

        public void wcPurchaseOrderStatusesSearch_PurchaseOrderStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _purchaseOrderStatuses = new Collection<PurchaseOrderStatus>();
            wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridClear();
        }

        public void wcPurchaseOrderStatusesSearch_PurchaseOrderStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridSearch();
        }

        public void wcPurchaseOrderStatusesSearch_PurchaseOrderStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _purchaseOrderStatus = SandPatchCL.DataServices.DataServicePurchaseOrderStatuses.PurchaseOrderStatusSqlGetById(e.Index);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusShow(_purchaseOrderStatus);
        }

        public void wcPurchaseOrderStatusesManager_PurchaseOrderStatusClearEvent(object sender, SPEventArgs e)
        {
            _purchaseOrderStatus = new PurchaseOrderStatus();
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusClear();
        }

        public void wcPurchaseOrderStatusesManager_PurchaseOrderStatusAddEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusUpdate(ref _purchaseOrderStatus);
            DataServicePurchaseOrderStatuses.SqlSave(ref _purchaseOrderStatus);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusShow(_purchaseOrderStatus);
        }

        public void wcPurchaseOrderStatusesManager_PurchaseOrderStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusUpdate(ref _purchaseOrderStatus);
            DataServicePurchaseOrderStatuses.SqlSave(ref _purchaseOrderStatus);
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusShow(_purchaseOrderStatus);
        }

        public void wcPurchaseOrderStatusesManager_PurchaseOrderStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusUpdate(ref _purchaseOrderStatus);
            DataServicePurchaseOrderStatuses.SqlDelete(ref _purchaseOrderStatus);
            _purchaseOrderStatus = new PurchaseOrderStatus();
            wcPurchaseOrderStatusesManager.PurchaseOrderStatusClear();
            wcPurchaseOrderStatusesSearch.PurchaseOrderStatusDataGridSearch();
        }

    }
}
