using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDriverWithholding : System.Web.UI.Page
    {
        private DriverWithholding _driverWithholding;
        private Collection<DriverWithholding> _driverWithholdings;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _driverWithholding = new DriverWithholding();
            wcDriverWithholdingSearch.DriverWithholdingDataGridClearEvent += new SPEventHandler(wcDriverWithholdingSearch_DriverWithholdingDataGridClearEvent);
            wcDriverWithholdingSearch.DriverWithholdingDataGridSearchEvent += new SPEventHandler(wcDriverWithholdingSearch_DriverWithholdingDataGridSearchEvent);
            wcDriverWithholdingSearch.DriverWithholdingDataGridPageIndexChangingEvent += new SPEventHandler(wcDriverWithholdingSearch_DriverWithholdingDataGridPageIndexChangingEvent);
            wcDriverWithholdingSearch.DriverWithholdingDataGridRowSelectedEvent += new SPEventHandler(wcDriverWithholdingSearch_DriverWithholdingDataGridRowSelectedEvent);
            wcDriverWithholdingEdit.DriverWithholdingClearEvent += new SPEventHandler(wcDriverWithholdingEdit_DriverWithholdingClearEvent);
            wcDriverWithholdingEdit.DriverWithholdingAddEvent += new SPEventHandler(wcDriverWithholdingEdit_DriverWithholdingAddEvent);
            wcDriverWithholdingEdit.DriverWithholdingUpdateEvent += new SPEventHandler(wcDriverWithholdingEdit_DriverWithholdingUpdateEvent);
            wcDriverWithholdingEdit.DriverWithholdingDeleteEvent += new SPEventHandler(wcDriverWithholdingEdit_DriverWithholdingDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcDriverWithholdingSearch.DriverWithholdingDataGridClear();
            }
        }

        public void wcDriverWithholdingSearch_DriverWithholdingDataGridClearEvent(object sender, SPEventArgs e)
        {
            _driverWithholdings = new Collection<DriverWithholding>();
            wcDriverWithholdingSearch.DriverWithholdingDataGridClear();
        }

        public void wcDriverWithholdingSearch_DriverWithholdingDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcDriverWithholdingSearch.DriverWithholdingDataGridWildcard();
            _driverWithholdings = SandPatchCL.DataServices.DataServiceDriverWithholdings.DriverWithholdingSqlGetBySearchTerms(_searchTerms);
            wcDriverWithholdingSearch.DriverWithholdingDataGridSearch(_driverWithholdings, 0);
        }

        public void wcDriverWithholdingSearch_DriverWithholdingDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcDriverWithholdingSearch.DriverWithholdingDataGridWildcard();
            _driverWithholdings = SandPatchCL.DataServices.DataServiceDriverWithholdings.DriverWithholdingSqlGetBySearchTerms(_searchTerms);
            wcDriverWithholdingSearch.DriverWithholdingDataGridSearch(_driverWithholdings, e.Index);
        }

        public void wcDriverWithholdingSearch_DriverWithholdingDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _driverWithholding = SandPatchCL.DataServices.DataServiceDriverWithholdings.DriverWithholdingSqlGetById(e.Index);
            wcDriverWithholdingEdit.DriverWithholdingShow(_driverWithholding);
        }

        public void wcDriverWithholdingEdit_DriverWithholdingClearEvent(object sender, SPEventArgs e)
        {
            _driverWithholding = new DriverWithholding();
            wcDriverWithholdingEdit.DriverWithholdingClear();
        }

        public void wcDriverWithholdingEdit_DriverWithholdingAddEvent(object sender, SPEventArgs e)
        {
            wcDriverWithholdingEdit.DriverWithholdingUpdate(ref _driverWithholding);
            DataServiceDriverWithholdings.SqlSave(ref _driverWithholding);
            wcDriverWithholdingEdit.DriverWithholdingShow(_driverWithholding);
        }

        public void wcDriverWithholdingEdit_DriverWithholdingUpdateEvent(object sender, SPEventArgs e)
        {
            wcDriverWithholdingEdit.DriverWithholdingUpdate(ref _driverWithholding);
            DataServiceDriverWithholdings.SqlSave(ref _driverWithholding);
            wcDriverWithholdingEdit.DriverWithholdingShow(_driverWithholding);
        }

        public void wcDriverWithholdingEdit_DriverWithholdingDeleteEvent(object sender, SPEventArgs e)
        {
            wcDriverWithholdingEdit.DriverWithholdingUpdate(ref _driverWithholding);
            DataServiceDriverWithholdings.SqlDelete(ref _driverWithholding);
            _driverWithholding = new DriverWithholding();
            wcDriverWithholdingEdit.DriverWithholdingClear();
            _searchTerms = wcDriverWithholdingSearch.DriverWithholdingDataGridWildcard();
            _driverWithholdings = SandPatchCL.DataServices.DataServiceDriverWithholdings.DriverWithholdingSqlGetBySearchTerms(_searchTerms);
            wcDriverWithholdingSearch.DriverWithholdingDataGridSearch(_driverWithholdings, 0);
        }

    }
}
