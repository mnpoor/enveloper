using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormPurchaseOrder : System.Web.UI.Page
    {
        private Collection<JobNumber> _jobNumbers;
        private Collection<Customer> _customers;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<Freight> _freights;
        private Collection<PurchaseOrderStatus> _purchaseOrderStatuses;
        private Collection<JobSite> _jobSites;

        private PurchaseOrder _purchaseOrder;
        private Collection<PurchaseOrder> _purchaseOrders;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _purchaseOrder = new PurchaseOrder();
            wcPurchaseOrderSearch.PurchaseOrderDataGridClearEvent += new SPEventHandler(wcPurchaseOrderSearch_PurchaseOrderDataGridClearEvent);
            wcPurchaseOrderSearch.PurchaseOrderDataGridSearchEvent += new SPEventHandler(wcPurchaseOrderSearch_PurchaseOrderDataGridSearchEvent);
            wcPurchaseOrderSearch.PurchaseOrderDataGridPageIndexChangingEvent += new SPEventHandler(wcPurchaseOrderSearch_PurchaseOrderDataGridPageIndexChangingEvent);
            wcPurchaseOrderSearch.PurchaseOrderDataGridRowSelectedEvent += new SPEventHandler(wcPurchaseOrderSearch_PurchaseOrderDataGridRowSelectedEvent);
            wcPurchaseOrderEdit.PurchaseOrderClearEvent += new SPEventHandler(wcPurchaseOrderEdit_PurchaseOrderClearEvent);
            wcPurchaseOrderEdit.PurchaseOrderAddEvent += new SPEventHandler(wcPurchaseOrderEdit_PurchaseOrderAddEvent);
            wcPurchaseOrderEdit.PurchaseOrderUpdateEvent += new SPEventHandler(wcPurchaseOrderEdit_PurchaseOrderUpdateEvent);
            wcPurchaseOrderEdit.PurchaseOrderDeleteEvent += new SPEventHandler(wcPurchaseOrderEdit_PurchaseOrderDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcPurchaseOrderSearch.PurchaseOrderDataGridClear();
            }

            if (wcPurchaseOrderEdit.JobNumberCount < 1)
            {
                _jobNumbers = DataServiceJobNumbers.JobNumberSqlGetAll();
                _jobNumbers.Insert(0, new JobNumber());
                _jobNumbers[0].JobNumberAssignment = 0;
                wcPurchaseOrderEdit.JobNumbersFill(_jobNumbers);
            }

            if (wcPurchaseOrderEdit.CustomerCount < 1)
            {
                _customers = DataServiceCustomers.CustomerSqlGetAll();
                _customers.Insert(0, new Customer());
                _customers[0].CustomerName = "* Unassigned *";
                wcPurchaseOrderEdit.CustomersFill(_customers);
            }

            if (wcPurchaseOrderEdit.LoadingTerminalCount < 1)
            {
                _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                _loadingTerminals.Insert(0, new LoadingTerminal());
                _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
                wcPurchaseOrderEdit.LoadingTerminalsFill(_loadingTerminals);
            }

            if (wcPurchaseOrderEdit.FreightCount < 1)
            {
                _freights = DataServiceFreights.FreightSqlGetAll();
                _freights.Insert(0, new Freight());
                _freights[0].FreightName = "* Unassigned *";
                wcPurchaseOrderEdit.FreightsFill(_freights);
            }

            if (wcPurchaseOrderEdit.PurchaseOrderStatusCount < 1)
            {
                _purchaseOrderStatuses = DataServicePurchaseOrderStatuses.PurchaseOrderStatusSqlGetAll();
                _purchaseOrderStatuses.Insert(0, new PurchaseOrderStatus());
                _purchaseOrderStatuses[0].PurchaseOrderStatusDescription = "* Unassigned *";
                wcPurchaseOrderEdit.PurchaseOrderStatusesFill(_purchaseOrderStatuses);
            }

            if (wcPurchaseOrderEdit.JobSiteCount < 1)
            {
                _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                _jobSites.Insert(0, new JobSite());
                _jobSites[0].JobSiteName = "* Unassigned *";
                wcPurchaseOrderEdit.JobSitesFill(_jobSites);
            }
        }

        public void wcPurchaseOrderSearch_PurchaseOrderDataGridClearEvent(object sender, SPEventArgs e)
        {
            _purchaseOrders = new Collection<PurchaseOrder>();
            wcPurchaseOrderSearch.PurchaseOrderDataGridClear();
        }

        public void wcPurchaseOrderSearch_PurchaseOrderDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcPurchaseOrderSearch.PurchaseOrderDataGridWildcard();
            _purchaseOrders = SandPatchCL.DataServices.DataServicePurchaseOrders.PurchaseOrderSqlGetBySearchTerms(_searchTerms);
            wcPurchaseOrderSearch.PurchaseOrderDataGridSearch(_purchaseOrders, 0);
        }

        public void wcPurchaseOrderSearch_PurchaseOrderDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcPurchaseOrderSearch.PurchaseOrderDataGridWildcard();
            _purchaseOrders = SandPatchCL.DataServices.DataServicePurchaseOrders.PurchaseOrderSqlGetBySearchTerms(_searchTerms);
            wcPurchaseOrderSearch.PurchaseOrderDataGridSearch(_purchaseOrders, e.Index);
        }

        public void wcPurchaseOrderSearch_PurchaseOrderDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _purchaseOrder = SandPatchCL.DataServices.DataServicePurchaseOrders.PurchaseOrderSqlGetById(e.Index);
            wcPurchaseOrderEdit.PurchaseOrderShow(_purchaseOrder);
        }

        public void wcPurchaseOrderEdit_PurchaseOrderClearEvent(object sender, SPEventArgs e)
        {
            _purchaseOrder = new PurchaseOrder();
            wcPurchaseOrderEdit.PurchaseOrderClear();
        }

        public void wcPurchaseOrderEdit_PurchaseOrderAddEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderEdit.PurchaseOrderUpdate(ref _purchaseOrder);
            DataServicePurchaseOrders.SqlSave(ref _purchaseOrder);
            wcPurchaseOrderEdit.PurchaseOrderShow(_purchaseOrder);
        }

        public void wcPurchaseOrderEdit_PurchaseOrderUpdateEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderEdit.PurchaseOrderUpdate(ref _purchaseOrder);
            DataServicePurchaseOrders.SqlSave(ref _purchaseOrder);
            wcPurchaseOrderEdit.PurchaseOrderShow(_purchaseOrder);
        }

        public void wcPurchaseOrderEdit_PurchaseOrderDeleteEvent(object sender, SPEventArgs e)
        {
            wcPurchaseOrderEdit.PurchaseOrderUpdate(ref _purchaseOrder);
            DataServicePurchaseOrders.SqlDelete(ref _purchaseOrder);
            _purchaseOrder = new PurchaseOrder();
            wcPurchaseOrderEdit.PurchaseOrderClear();
            _searchTerms = wcPurchaseOrderSearch.PurchaseOrderDataGridWildcard();
            _purchaseOrders = SandPatchCL.DataServices.DataServicePurchaseOrders.PurchaseOrderSqlGetBySearchTerms(_searchTerms);
            wcPurchaseOrderSearch.PurchaseOrderDataGridSearch(_purchaseOrders, 0);
        }

    }
}
