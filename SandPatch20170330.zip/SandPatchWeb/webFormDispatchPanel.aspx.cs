using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDispatchPanel : System.Web.UI.Page
    {
        private DispatchPanel _dispatchPanel;
        private Collection<DispatchPanel> _dispatchPanels;

        private Collection<AvailabilityStatus> _availabilityStatuses = new Collection<AvailabilityStatus>();

        private DataTable _dispatchPanelDataTable;
        //private DataRow _dispatchPanelDataRow;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                cmdRefresh.Click += new EventHandler(cmdRefresh_Click);
                cmdSearch.Click += new EventHandler(cmdSearch_Click);
            }
            if (_availabilityStatuses.Count < 1)
            { 
                _availabilityStatuses = DataServiceAvailabilityStatuses.AvailabilityStatusSqlGetAll();
                _availabilityStatuses.Insert(0, new AvailabilityStatus());
                _availabilityStatuses[0].AvailabilityStatusDescription = "*** Unassigned ***";
                _availabilityStatuses[0].AvailabilityColorCode = "Gray";
            }
        }

        public void cmdRefresh_Click(object sender, EventArgs e)
        {
            DataServiceDispatchPanel.DispatchPanelSqlGenerate();

            _dispatchPanels = DataServiceDispatchPanel.DispatchPanelSqlGetAll();

            _dispatchPanelDataTable = new DataTable("DispatchPanel");
            _dispatchPanelDataTable.Columns.Add(new DataColumn("TruckNumber1", typeof(string)));
            _dispatchPanelDataTable.Columns[0].Caption = " Truck Number ";
            _dispatchPanelDataTable.Columns[0].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("AvailabilityStatusId1", typeof(string)));
            _dispatchPanelDataTable.Columns[1].Caption = " Availability Status Id ";
            _dispatchPanelDataTable.Columns.Add(new DataColumn("JobNumber1", typeof(string)));
            _dispatchPanelDataTable.Columns[2].Caption = " Job Number ";
            _dispatchPanelDataTable.Columns[2].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("JobSiteName1", typeof(string)));
            _dispatchPanelDataTable.Columns[3].Caption = " Job Site Name ";
            _dispatchPanelDataTable.Columns[3].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("Status1", typeof(string)));
            _dispatchPanelDataTable.Columns[4].Caption = " Status ";
            _dispatchPanelDataTable.Columns[4].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("TruckNumber2", typeof(string)));
            _dispatchPanelDataTable.Columns[5].Caption = " Truck_Number ";
            _dispatchPanelDataTable.Columns[5].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("AvailabilityStatusId2", typeof(string)));
            _dispatchPanelDataTable.Columns[6].Caption = " Availability Status Id ";
            _dispatchPanelDataTable.Columns.Add(new DataColumn("JobNumber2", typeof(string)));
            _dispatchPanelDataTable.Columns[7].Caption = " Job_Number ";
            _dispatchPanelDataTable.Columns[7].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("JobSiteName2", typeof(string)));
            _dispatchPanelDataTable.Columns[8].Caption = " Job_Site Name ";
            _dispatchPanelDataTable.Columns[8].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("Status2", typeof(string)));
            _dispatchPanelDataTable.Columns[9].Caption = " Status_ ";
            _dispatchPanelDataTable.Columns[9].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("TruckNumber3", typeof(string)));
            _dispatchPanelDataTable.Columns[10].Caption = " Truck_Number_";
            _dispatchPanelDataTable.Columns[10].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("AvailabilityStatusId3", typeof(string)));
            _dispatchPanelDataTable.Columns[11].Caption = " Availability Status Id ";
            _dispatchPanelDataTable.Columns.Add(new DataColumn("JobNumber3", typeof(string)));
            _dispatchPanelDataTable.Columns[12].Caption = " Job_Number_";
            _dispatchPanelDataTable.Columns[12].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("JobSiteName3", typeof(string)));
            _dispatchPanelDataTable.Columns[13].Caption = " Job_Site_Name ";
            _dispatchPanelDataTable.Columns[13].ReadOnly = true;
            _dispatchPanelDataTable.Columns.Add(new DataColumn("Status3", typeof(string)));
            _dispatchPanelDataTable.Columns[14].Caption = " Status-";
            _dispatchPanelDataTable.Columns[14].ReadOnly = true;

            object[] gridItems = new object[15]; // { string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty };

            foreach (DispatchPanel item in _dispatchPanels)
            {
                switch (item.PanelColumn)
                {
                    case 1:
                        {
                            gridItems = new object[15] { string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty };
                            gridItems[0] = item.TruckNumber.ToString() + ((item.ActiveDispatches > 1) ? "(" + item.ActiveDispatches.ToString() + ")" : string.Empty);
                            gridItems[1] = item.AvailabilityStatusId.ToString();
                            gridItems[2] = item.JobNumberAssignment.ToString();
                            gridItems[3] = item.JobSiteName;
                            gridItems[4] = item.DispatchStatusDescription;
                            break;
                        }
                    case 2:
                        {
                            gridItems[5] = item.TruckNumber.ToString() + ((item.ActiveDispatches > 1) ? "(" + item.ActiveDispatches.ToString() + ")" : string.Empty);
                            gridItems[6] = item.AvailabilityStatusId.ToString();
                            gridItems[7] = item.JobNumberAssignment.ToString();
                            gridItems[8] = item.JobSiteName;
                            gridItems[9] = item.DispatchStatusDescription;
                            break;
                        }
                    case 3:
                        {
                            if (item.TruckNumber > 0)
                            {
                                gridItems[10] = item.TruckNumber.ToString() + ((item.ActiveDispatches > 1) ? "(" + item.ActiveDispatches.ToString() + ")" : string.Empty);
                                gridItems[11] = item.AvailabilityStatusId.ToString();
                                gridItems[12] = item.JobNumberAssignment.ToString();
                                gridItems[13] = item.JobSiteName;
                                gridItems[14] = item.DispatchStatusDescription;
                            }
                            else
                            {
                                gridItems[10] = string.Empty;
                                gridItems[11] = item.AvailabilityStatusId.ToString();
                                gridItems[12] = string.Empty;
                                gridItems[13] = string.Empty;
                                gridItems[14] = string.Empty;
                            }
                            DataRow addedDataRow = _dispatchPanelDataTable.LoadDataRow(gridItems, true);                            
                            gridItems[0] = string.Empty;
                            break;
                        }
                }
            }
            //if ((string)gridItems[0] != string.Empty) _dispatchPanelDataTable.LoadDataRow(gridItems, true);

            //HyperLinkField column0 = new HyperLinkField();
            //column0.HeaderText = "Truck";
            //column0.DataNavigateUrlFields = new string[] {"TruckNumber1"};
            //column0.DataNavigateUrlFormatString = "~/webFormDispatchEdit.aspx?id={0}";
            //column0.DataTextField = "TruckNumber1";
            //column0.DataTextFormatString = "{0}";            
            //column0.Target = "_blank";

            //BoundField column1 = new BoundField();
            //column1.HeaderText = "Job Number";
            //column1.DataField = "JobNumber1";
            //column1.DataFormatString = "{0}";
            //column1.ReadOnly = true;

            //BoundField column2 = new BoundField();
            //column2.HeaderText = "Job Site Name";
            //column2.DataField = "JobSiteName1";
            //column2.DataFormatString = "{0}";
            //column2.ReadOnly = true;

            //BoundField column3 = new BoundField();
            //column3.HeaderText = "Status";
            //column3.DataField = "Status1";
            //column3.DataFormatString = "{0}";
            //column3.ReadOnly = true;

            //DropDownList availabilityStatus1 = new DropDownList();
            //foreach (AvailabilityStatus item in _availabilityStatuses)
            //{
            //    ListItem statusItem = new ListItem(item.AvailabilityStatusDescription, item.AvailabilityStatusId.ToString());
            //    availabilityStatus1.Items.Add(statusItem);
            //}
            //TemplateField column3a = new TemplateField();
            ////column3a.ItemTemplate.InstantiateIn()

            //TemplateField column4 = new TemplateField();
            //column4.HeaderText = " ";
            
            //HyperLinkField column5 = new HyperLinkField();
            //column5.HeaderText = "Truck";
            //column5.DataNavigateUrlFields = new string[] { "TruckNumber2" };
            //column5.DataNavigateUrlFormatString = "~/webFormDispatchEdit.aspx?id={0}";
            //column5.DataTextField = "TruckNumber2";
            //column5.DataTextFormatString = "{0}";
            //column5.Target = "_blank";

            //BoundField column6 = new BoundField();
            //column6.HeaderText = "Job Number";
            //column6.DataField = "JobNumber2";
            //column6.DataFormatString = "{0}";
            //column6.ReadOnly = true;

            //BoundField column7 = new BoundField();
            //column7.HeaderText = "Job Site Name";
            //column7.DataField = "JobSiteName2";
            //column7.DataFormatString = "{0}";
            //column7.ReadOnly = true;

            //BoundField column8 = new BoundField();
            //column8.HeaderText = "Status";
            //column8.DataField = "Status2";
            //column8.DataFormatString = "{0}";
            //column8.ReadOnly = true;

            //TemplateField column9 = new TemplateField();
            //column9.HeaderText = " ";
            
            //HyperLinkField column10 = new HyperLinkField();
            //column10.HeaderText = "Truck";
            //column10.DataNavigateUrlFields = new string[] { "TruckNumber3" };
            //column10.DataNavigateUrlFormatString = "~/webFormDispatchEdit.aspx?id={0}";
            //column10.DataTextField = "TruckNumber3";
            //column10.DataTextFormatString = "{0}";
            //column10.Target = "_blank";

            //BoundField column11 = new BoundField();
            //column11.HeaderText = "Job Number";
            //column11.DataField = "JobNumber3";
            //column11.DataFormatString = "{0}";
            //column11.ReadOnly = true;

            //BoundField column12 = new BoundField();
            //column12.HeaderText = "Job Site Name";
            //column12.DataField = "JobSiteName3";
            //column12.DataFormatString = "{0}";
            //column12.ReadOnly = true;

            //BoundField column13 = new BoundField();
            //column13.HeaderText = "Status";
            //column13.DataField = "Status3";
            //column13.DataFormatString = "{0}";
            //column13.ReadOnly = true;

            //gvDispatchPanel.Columns.Clear();
            //gvDispatchPanel.Columns.Add(column0);
            //gvDispatchPanel.Columns.Add(column1);
            //gvDispatchPanel.Columns.Add(column2);
            //gvDispatchPanel.Columns.Add(column3);
            //gvDispatchPanel.Columns.Add(column4);
            //gvDispatchPanel.Columns.Add(column5);
            //gvDispatchPanel.Columns.Add(column6);
            //gvDispatchPanel.Columns.Add(column7);
            //gvDispatchPanel.Columns.Add(column8);
            //gvDispatchPanel.Columns.Add(column9);
            //gvDispatchPanel.Columns.Add(column10);
            //gvDispatchPanel.Columns.Add(column11);
            //gvDispatchPanel.Columns.Add(column12);
            //gvDispatchPanel.Columns.Add(column13);
            gvDispatchPanel.DataSource = _dispatchPanelDataTable;
            gvDispatchPanel.DataBind();

            _dispatchPanelDataTable = new DataTable("DispatchPanel");   // empty out data table
            _dispatchPanels = new Collection<DispatchPanel>();          // empty out collection
            GC.Collect();                                               // consolidate heap space
        }

        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            string rowName = e.Row.Parent.ID;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //Find the DropDownList in the Row
                GridViewRow panelRow = e.Row;
                System.Data.DataRowView panelRowView = (System.Data.DataRowView)panelRow.DataItem;
                System.Data.DataRow panelDataRow = panelRowView.Row;
                
                DropDownList dropDownListAvailabilityStatus1 = (e.Row.FindControl("dropDownListAvailabilityStatus1") as DropDownList);
                dropDownListAvailabilityStatus1.DataSource = _availabilityStatuses;
                dropDownListAvailabilityStatus1.DataTextField = "AvailabilityStatusDescription";
                dropDownListAvailabilityStatus1.DataValueField = "AvailabilityStatusId";
                string itemArray0 = (string)panelDataRow.ItemArray[0];
                if (itemArray0.Contains("(")) itemArray0 = itemArray0.Substring(0, itemArray0.IndexOf("("));
                int truckNumber1 = Convert.ToInt32(itemArray0);
                _dispatchPanel = DataServiceDispatchPanel.DispatchPanelSqlGetByTruckNumber(truckNumber1);
                dropDownListAvailabilityStatus1.SelectedValue = _dispatchPanel.AvailabilityStatusId.ToString();
                dropDownListAvailabilityStatus1.DataBind();
                HiddenField truckNumberConstant1 = (e.Row.FindControl("TruckNumberConstant1") as HiddenField);
                truckNumberConstant1.Value = (string)panelDataRow.ItemArray[0];

                DropDownList dropDownListAvailabilityStatus2 = (e.Row.FindControl("dropDownListAvailabilityStatus2") as DropDownList);
                dropDownListAvailabilityStatus2.DataSource = _availabilityStatuses;
                dropDownListAvailabilityStatus2.DataTextField = "AvailabilityStatusDescription";
                dropDownListAvailabilityStatus2.DataValueField = "AvailabilityStatusId";
                string itemArray5 = (string)panelDataRow.ItemArray[5];
                if (itemArray5.Contains("(")) itemArray5 = itemArray5.Substring(0, itemArray5.IndexOf("("));
                int truckNumber2 = Convert.ToInt32(itemArray5);
                _dispatchPanel = DataServiceDispatchPanel.DispatchPanelSqlGetByTruckNumber(truckNumber2);
                dropDownListAvailabilityStatus2.SelectedValue = _dispatchPanel.AvailabilityStatusId.ToString();
                dropDownListAvailabilityStatus2.DataBind();
                HiddenField truckNumberConstant2 = (e.Row.FindControl("TruckNumberConstant2") as HiddenField);
                truckNumberConstant2.Value = (string)panelDataRow.ItemArray[5];

                DropDownList dropDownListAvailabilityStatus3 = (e.Row.FindControl("dropDownListAvailabilityStatus3") as DropDownList);
                dropDownListAvailabilityStatus3.DataSource = _availabilityStatuses;
                dropDownListAvailabilityStatus3.DataTextField = "AvailabilityStatusDescription";
                dropDownListAvailabilityStatus3.DataValueField = "AvailabilityStatusId";
                string itemArray10 = (string)panelDataRow.ItemArray[10];
                if (itemArray10 == string.Empty) itemArray10 = "0";
                if (itemArray10.Contains("(")) itemArray10 = itemArray10.Substring(0, itemArray10.IndexOf("("));
                int truckNumber3 = Convert.ToInt32(itemArray10);
                if (truckNumber3 > 0)
                {
                    _dispatchPanel = DataServiceDispatchPanel.DispatchPanelSqlGetByTruckNumber(truckNumber3);
                    if (_dispatchPanel == null)
                    {
                        dropDownListAvailabilityStatus3.Visible = false;
                    }
                    else
                    {
                        dropDownListAvailabilityStatus3.SelectedValue = _dispatchPanel.AvailabilityStatusId.ToString();
                    }
                }
                else
                {
                    dropDownListAvailabilityStatus3.Visible = false;
                }
                dropDownListAvailabilityStatus3.DataBind();
                HiddenField truckNumberConstant3 = (e.Row.FindControl("TruckNumberConstant3") as HiddenField);
                truckNumberConstant3.Value = (string)panelDataRow.ItemArray[10];
            }
        }

        public void cmdSearch_Click(object sender, EventArgs e)
        {
            //OnSearch();
        }

        protected void gvDispatchPanel_SelectedIndexChanged(object sender, EventArgs e)
        {
            //GridViewRow selectedRow = gvFreightStatuss.SelectedRow;
            //TableCellCollection selectedRowCells = selectedRow.Cells;
            //TableCell selectedCell = selectedRowCells[1];

            //if (this.FreightStatusDataGridRowSelectedEvent != null)
            //{
            //    this.FreightStatusDataGridRowSelectedEvent(this, new SPEventArgs(null, Convert.ToInt32(selectedCell.Text)));
            //}
        }

        protected void dropDownListAvailabilityStatus_SelectedIndexChanged1(object sender, EventArgs e)
        {
            //DropDownList dropDownSender = (DropDownList)sender;
            string clientId = ((DropDownList)sender).ClientID;
            //ContentPlaceHolder placeHolder = (ContentPlaceHolder)Form.FindControl("MainContent");
            //GridView dispatchGridView = (GridView)placeHolder.FindControl("gvDispatchPanel");
            //GridViewRowCollection dispatchRowCollection = dispatchGridView.Rows;
            System.Web.UI.Control dropDownControl1 = ((DropDownList)sender).Parent;
            GridViewRow selectedRow = (GridViewRow)dropDownControl1.DataItemContainer;
            //GridView dispatchGridView = (GridView)dispatchPanelForm.FindControl("MainContent_gvDispatchPanel");
            string hiddenField = clientId.Replace("dropDownListAvailabilityStatus1", "TruckNumberConstant1");
            int availabilityStatusId = Convert.ToInt32(((DropDownList)sender).SelectedValue);
            HiddenField truckNumberConstant1 = (HiddenField)selectedRow.FindControl("TruckNumberConstant1");
            int truckNumber = Convert.ToInt32(truckNumberConstant1.Value);
            UpdateAvailabilityStatus(truckNumber, clientId, 1, availabilityStatusId);
        }

        protected void dropDownListAvailabilityStatus_SelectedIndexChanged2(object sender, EventArgs e)
        {
            string clientId = ((DropDownList)sender).ClientID;
            System.Web.UI.Control dropDownControl2 = ((DropDownList)sender).Parent;
            GridViewRow selectedRow = (GridViewRow)dropDownControl2.DataItemContainer;
            int availabilityStatusId = Convert.ToInt32(((DropDownList)sender).SelectedValue);
            HiddenField truckNumberConstant2 = (HiddenField)selectedRow.FindControl("TruckNumberConstant2");
            int truckNumber = Convert.ToInt32(truckNumberConstant2.Value);
            UpdateAvailabilityStatus(truckNumber, clientId, 2, availabilityStatusId);
        }

        protected void dropDownListAvailabilityStatus_SelectedIndexChanged3(object sender, EventArgs e)
        {
            string clientId = ((DropDownList)sender).ClientID;
            System.Web.UI.Control dropDownControl3 = ((DropDownList)sender).Parent;
            GridViewRow selectedRow = (GridViewRow)dropDownControl3.DataItemContainer;
            int availabilityStatusId = Convert.ToInt32(((DropDownList)sender).SelectedValue);
            HiddenField truckNumberConstant3 = (HiddenField)selectedRow.FindControl("TruckNumberConstant3");
            int truckNumber = Convert.ToInt32(truckNumberConstant3.Value);
            UpdateAvailabilityStatus(truckNumber, clientId, 3, availabilityStatusId);
        }

        protected void UpdateAvailabilityStatus(int truckNumber, string clientId, int column, int availabilityStatusId)
        {
            //string rowNumberString = clientId.Substring(clientId.LastIndexOf("_") + 1);
            //int rowNumber = Convert.ToInt32(rowNumberString);
            //_dispatchPanel = DataServiceDispatchPanel.DispatchPanelSqlGetByRowAndColumn(column, rowNumber + 1);
            _dispatchPanel = DataServiceDispatchPanel.DispatchPanelSqlGetByTruckNumber(truckNumber);
            _dispatchPanel.AvailabilityStatusId = availabilityStatusId;
            DataServiceDispatchPanel.SqlSave(ref _dispatchPanel);
            DataServiceDispatchPanel.DispatchPanelSqlSynchronize();
        }

    }
}
