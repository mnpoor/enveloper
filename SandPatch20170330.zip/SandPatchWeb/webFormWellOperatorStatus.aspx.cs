using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormWellOperatorStatus : System.Web.UI.Page
    {
        private WellOperatorStatus _wellOperatorStatus;
        private Collection<WellOperatorStatus> _wellOperatorStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _wellOperatorStatus = new WellOperatorStatus();
            wcWellOperatorStatusesSearch.WellOperatorStatusDataGridClearEvent += new SPEventHandler(wcWellOperatorStatusesSearch_WellOperatorStatusDataGridClearEvent);
            wcWellOperatorStatusesSearch.WellOperatorStatusDataGridSearchEvent += new SPEventHandler(wcWellOperatorStatusesSearch_WellOperatorStatusDataGridSearchEvent);
            wcWellOperatorStatusesSearch.WellOperatorStatusDataGridRowSelectedEvent += new SPEventHandler(wcWellOperatorStatusesSearch_WellOperatorStatusDataGridRowSelectedEvent);
            wcWellOperatorStatusEdit.WellOperatorStatusClearEvent += new SPEventHandler(wcWellOperatorStatusEdit_WellOperatorStatusClearEvent);
            wcWellOperatorStatusEdit.WellOperatorStatusAddEvent += new SPEventHandler(wcWellOperatorStatusEdit_WellOperatorStatusAddEvent);
            wcWellOperatorStatusEdit.WellOperatorStatusUpdateEvent += new SPEventHandler(wcWellOperatorStatusEdit_WellOperatorStatusUpdateEvent);
            wcWellOperatorStatusEdit.WellOperatorStatusDeleteEvent += new SPEventHandler(wcWellOperatorStatusEdit_WellOperatorStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcWellOperatorStatusesSearch.WellOperatorStatusDataGridClear();
            }
        }

        public void wcWellOperatorStatusesSearch_WellOperatorStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _wellOperatorStatuss = new Collection<WellOperatorStatus>();
            wcWellOperatorStatusesSearch.WellOperatorStatusDataGridClear();
        }

        public void wcWellOperatorStatusesSearch_WellOperatorStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorStatusesSearch.WellOperatorStatusDataGridSearch();
        }

        public void wcWellOperatorStatusesSearch_WellOperatorStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _wellOperatorStatus = SandPatchCL.DataServices.DataServiceWellOperatorStatuses.WellOperatorStatusSqlGetById(e.Index);
            wcWellOperatorStatusEdit.WellOperatorStatusShow(_wellOperatorStatus);
        }

        public void wcWellOperatorStatusEdit_WellOperatorStatusClearEvent(object sender, SPEventArgs e)
        {
            _wellOperatorStatus = new WellOperatorStatus();
            wcWellOperatorStatusEdit.WellOperatorStatusClear();
        }

        public void wcWellOperatorStatusEdit_WellOperatorStatusAddEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorStatusEdit.WellOperatorStatusUpdate(ref _wellOperatorStatus);
            DataServiceWellOperatorStatuses.SqlSave(ref _wellOperatorStatus);
            wcWellOperatorStatusEdit.WellOperatorStatusShow(_wellOperatorStatus);
        }

        public void wcWellOperatorStatusEdit_WellOperatorStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorStatusEdit.WellOperatorStatusUpdate(ref _wellOperatorStatus);
            DataServiceWellOperatorStatuses.SqlSave(ref _wellOperatorStatus);
            wcWellOperatorStatusEdit.WellOperatorStatusShow(_wellOperatorStatus);
        }

        public void wcWellOperatorStatusEdit_WellOperatorStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcWellOperatorStatusEdit.WellOperatorStatusUpdate(ref _wellOperatorStatus);
            DataServiceWellOperatorStatuses.SqlDelete(ref _wellOperatorStatus);
            _wellOperatorStatus = new WellOperatorStatus();
            wcWellOperatorStatusEdit.WellOperatorStatusClear();
            wcWellOperatorStatusesSearch.WellOperatorStatusDataGridSearch();
        }

    }
}
