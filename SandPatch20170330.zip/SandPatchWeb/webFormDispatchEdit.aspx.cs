using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDispatchEdit : System.Web.UI.Page
    {
        private Collection<Customer> _customers;
        private Collection<JobNumber> _jobNumbers;
        private Collection<PurchaseOrder> _purchaseOrders;
        private Collection<Carrier> _carriers;
        private Collection<Driver> _drivers;
        private Collection<DispatchStatus> _dispatchStatuses;
        private Collection<Freight> _freights;
        private Collection<LoadingTerminal> _loadingTerminals;
        private Collection<JobSite> _jobSites;

        private BillOfLading _billOfLading;

        private System.Collections.Specialized.NameValueCollection _queries;

        private int _truckNumber;
        private DispatchPanel _dispatchPanel;
        private Dispatch _dispatch;
        private Driver _driver;
        private Collection<Dispatch> _dispatchs;

        protected void Page_Load(object sender, EventArgs e)
        {
            wcDispatchEditItem.DispatchClearEvent += new SPEventHandler(wcDispatchEditItem_DispatchClearEvent);
            wcDispatchEditItem.DispatchAddEvent += new SPEventHandler(wcDispatchEditItem_DispatchAddEvent);
            wcDispatchEditItem.DispatchUpdateEvent += new SPEventHandler(wcDispatchEditItem_DispatchUpdateEvent);
            wcDispatchEditItem.DispatchDeleteEvent += new SPEventHandler(wcDispatchEditItem_DispatchDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcDispatchEditItem.DispatchClear();
                _queries = Request.QueryString;
                string expectedTruckNumber = _queries[0];
                try
                {
                    _truckNumber = Convert.ToInt32(expectedTruckNumber);
                    _dispatchPanel = DataServiceDispatchPanel.DispatchPanelSqlGetByTruckNumber(_truckNumber);
                    if (_dispatchPanel == null)
                    {
                        Page.Title = _truckNumber.ToString() + " ***";
                    }
                    else
                    {
                        _driver = DataServiceDrivers.DriverSqlGetById(_dispatchPanel.DriverId);
                        if (_dispatchPanel.JobNumberId < 1)
                        {
                            Page.Title = _dispatchPanel.TruckNumber.ToString() + " - " + _dispatchPanel.JobNumberAssignment.ToString() + " - " + _dispatchPanel.JobSiteName;
                        }
                        else
                        {
                            Page.Title = _dispatchPanel.TruckNumber.ToString() + " (" + _dispatchPanel.DispatchStatusDescription + ")";
                        }
                    }
                    if (_dispatchPanel.DispatchId > 0)
                    {
                        _dispatch = DataServiceDispatches.DispatchSqlGetById(_dispatchPanel.DispatchId);
                    }
                    else
                    {
                        _dispatch = new Dispatch();                        
                        _dispatch.CarrierId = _driver.CarrierId;
                        _dispatch.DriverId = _driver.DriverId;
                        wcDispatchEditItem.DispatchNew(_dispatch);
                    }
                }
                catch
                {
                    _truckNumber = 0;
                    _dispatch = new Dispatch();
                }
                wcDispatchEditItem.DispatchShow(_dispatch);
            }
            if (wcDispatchEditItem.CustomerCount < 1)
            {
                _customers = DataServiceCustomers.CustomerSqlGetAll();
                _customers.Insert(0, new Customer());
                _customers[0].CustomerName = "* Unassigned *";
                wcDispatchEditItem.CustomersFill(_customers);
            }

            if (wcDispatchEditItem.JobNumberCount < 1)
            {
                _jobNumbers = DataServiceJobNumbers.JobNumberSqlGetAll();
                _jobNumbers.Insert(0, new JobNumber());
                _jobNumbers[0].JobNumberAssignment = 0;
                wcDispatchEditItem.JobNumbersFill(_jobNumbers);
            }

            if (wcDispatchEditItem.PurchaseOrderCount < 1)
            {
                _purchaseOrders = DataServicePurchaseOrders.PurchaseOrderSqlGetAll();
                _purchaseOrders.Insert(0, new PurchaseOrder());
                _purchaseOrders[0].PurchaseOrderNumber = "* Unassigned *";
                wcDispatchEditItem.PurchaseOrdersFill(_purchaseOrders);
            }

            if (wcDispatchEditItem.CarrierCount < 1)
            {
                _carriers = DataServiceCarriers.CarrierSqlGetAll();
                _carriers.Insert(0, new Carrier());
                _carriers[0].CarrierCompanyName = "* Unassigned *";
                wcDispatchEditItem.CarriersFill(_carriers);
            }

            if (wcDispatchEditItem.DriverCount < 1)
            {
                _drivers = DataServiceDrivers.DriverSqlGetAll();
                _drivers.Insert(0, new Driver());
                _drivers[0].DriverName = "* Unassigned *";
                wcDispatchEditItem.DriversFill(_drivers);
            }

            if (wcDispatchEditItem.DispatchStatusCount < 1)
            {
                _dispatchStatuses = DataServiceDispatchStatuses.DispatchStatusSqlGetAll();
                _dispatchStatuses.Insert(0, new DispatchStatus());
                _dispatchStatuses[0].DispatchStatusDescription = "* Unassigned *";
                wcDispatchEditItem.DispatchStatusesFill(_dispatchStatuses);
            }

            if (wcDispatchEditItem.FreightCount < 1)
            {
                _freights = DataServiceFreights.FreightSqlGetAll();
                _freights.Insert(0, new Freight());
                _freights[0].FreightName = "* Unassigned *";
                wcDispatchEditItem.FreightsFill(_freights);
            }

            if (wcDispatchEditItem.LoadingTerminalCount < 1)
            {
                _loadingTerminals = DataServiceLoadingTerminals.LoadingTerminalSqlGetAll();
                _loadingTerminals.Insert(0, new LoadingTerminal());
                _loadingTerminals[0].LoadingTerminalName = "* Unassigned *";
                wcDispatchEditItem.LoadingTerminalsFill(_loadingTerminals);
            }

            if (wcDispatchEditItem.JobSiteCount < 1)
            {
                _jobSites = DataServiceJobSites.JobSiteSqlGetAll();
                _jobSites.Insert(0, new JobSite());
                _jobSites[0].JobSiteName = "* Unassigned *";
                wcDispatchEditItem.JobSitesFill(_jobSites);
            }

        }

        public void wcDispatchEditItem_DispatchClearEvent(object sender, SPEventArgs e)
        {
            _dispatch = new Dispatch();
            wcDispatchEditItem.DispatchClear();
        }

        public void wcDispatchEditItem_DispatchAddEvent(object sender, SPEventArgs e)
        {
            _dispatch = new Dispatch();
            wcDispatchEditItem.DispatchUpdate(ref _dispatch);
            DataServiceDispatches.SqlSave(ref _dispatch);
            if (_dispatch.BillOfLadingId > 0) SynchronizeBOLToDispatch();
            wcDispatchEditItem.DispatchShow(_dispatch);
        }

        public void wcDispatchEditItem_DispatchUpdateEvent(object sender, SPEventArgs e)
        {
            _dispatch = new Dispatch();
            wcDispatchEditItem.DispatchUpdate(ref _dispatch);
            DataServiceDispatches.SqlSave(ref _dispatch);
            if (_dispatch.BillOfLadingId > 0) SynchronizeBOLToDispatch();
            wcDispatchEditItem.DispatchShow(_dispatch);
        }

        public void wcDispatchEditItem_DispatchDeleteEvent(object sender, SPEventArgs e)
        {
            _dispatch = new Dispatch();
            wcDispatchEditItem.DispatchUpdate(ref _dispatch);
            DataServiceDispatches.SqlDelete(ref _dispatch);
            _dispatch = new Dispatch();
            wcDispatchEditItem.DispatchClear();
        }

        private void SynchronizeBOLToDispatch()
        {
            _billOfLading = DataServiceBillsOfLading.BillOfLadingSqlGetById(_dispatch.BillOfLadingId);
            if (_billOfLading == null) return;
            DataServiceBillsOfLading.SynchronizeBOLToDispatch(ref _billOfLading, ref _dispatch);
        }

    }
}
