using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormLicensePlateStatus : System.Web.UI.Page
    {
        private LicensePlateStatus _licensePlateStatus;
        private Collection<LicensePlateStatus> _licensePlateStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _licensePlateStatus = new LicensePlateStatus();
            wcLicensePlateStatusesSearch.LicensePlateStatusDataGridClearEvent += new SPEventHandler(wcLicensePlateStatusesSearch_LicensePlateStatusDataGridClearEvent);
            wcLicensePlateStatusesSearch.LicensePlateStatusDataGridSearchEvent += new SPEventHandler(wcLicensePlateStatusesSearch_LicensePlateStatusDataGridSearchEvent);
            wcLicensePlateStatusesSearch.LicensePlateStatusDataGridRowSelectedEvent += new SPEventHandler(wcLicensePlateStatusesSearch_LicensePlateStatusDataGridRowSelectedEvent);
            wcLicensePlateStatusEdit.LicensePlateStatusClearEvent += new SPEventHandler(wcLicensePlateStatusEdit_LicensePlateStatusClearEvent);
            wcLicensePlateStatusEdit.LicensePlateStatusAddEvent += new SPEventHandler(wcLicensePlateStatusEdit_LicensePlateStatusAddEvent);
            wcLicensePlateStatusEdit.LicensePlateStatusUpdateEvent += new SPEventHandler(wcLicensePlateStatusEdit_LicensePlateStatusUpdateEvent);
            wcLicensePlateStatusEdit.LicensePlateStatusDeleteEvent += new SPEventHandler(wcLicensePlateStatusEdit_LicensePlateStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcLicensePlateStatusesSearch.LicensePlateStatusDataGridClear();
            }
        }

        public void wcLicensePlateStatusesSearch_LicensePlateStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _licensePlateStatuss = new Collection<LicensePlateStatus>();
            wcLicensePlateStatusesSearch.LicensePlateStatusDataGridClear();
        }

        public void wcLicensePlateStatusesSearch_LicensePlateStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcLicensePlateStatusesSearch.LicensePlateStatusDataGridSearch();
        }

        public void wcLicensePlateStatusesSearch_LicensePlateStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _licensePlateStatus = SandPatchCL.DataServices.DataServiceLicensePlateStatuses.LicensePlateStatusSqlGetById(e.Index);
            wcLicensePlateStatusEdit.LicensePlateStatusShow(_licensePlateStatus);
        }

        public void wcLicensePlateStatusEdit_LicensePlateStatusClearEvent(object sender, SPEventArgs e)
        {
            _licensePlateStatus = new LicensePlateStatus();
            wcLicensePlateStatusEdit.LicensePlateStatusClear();
        }

        public void wcLicensePlateStatusEdit_LicensePlateStatusAddEvent(object sender, SPEventArgs e)
        {
            wcLicensePlateStatusEdit.LicensePlateStatusUpdate(ref _licensePlateStatus);
            DataServiceLicensePlateStatuses.SqlSave(ref _licensePlateStatus);
            wcLicensePlateStatusEdit.LicensePlateStatusShow(_licensePlateStatus);
        }

        public void wcLicensePlateStatusEdit_LicensePlateStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcLicensePlateStatusEdit.LicensePlateStatusUpdate(ref _licensePlateStatus);
            DataServiceLicensePlateStatuses.SqlSave(ref _licensePlateStatus);
            wcLicensePlateStatusEdit.LicensePlateStatusShow(_licensePlateStatus);
        }

        public void wcLicensePlateStatusEdit_LicensePlateStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcLicensePlateStatusEdit.LicensePlateStatusUpdate(ref _licensePlateStatus);
            DataServiceLicensePlateStatuses.SqlDelete(ref _licensePlateStatus);
            _licensePlateStatus = new LicensePlateStatus();
            wcLicensePlateStatusEdit.LicensePlateStatusClear();
            wcLicensePlateStatusesSearch.LicensePlateStatusDataGridSearch();
        }

    }
}
