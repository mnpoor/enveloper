using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDriver : System.Web.UI.Page
    {
        private Collection<Carrier> _carriers;
        private Collection<DriverStatus> _driverStatuses;
        private Collection<FuelCardStatus> _fuelCardStatuses;
        private Collection<LicensePlateStatus> _licensePlateStatuses;

        private Driver _driver;
        private Collection<Driver> _drivers;

        protected void Page_Load(object sender, EventArgs e)
        {
            _driver = new Driver();
            wcDriverSearch.DriverDataGridClearEvent += new SPEventHandler(wcDriverSearch_DriverDataGridClearEvent);
            wcDriverSearch.DriverDataGridSearchEvent += new SPEventHandler(wcDriverSearch_DriverDataGridSearchEvent);
            wcDriverSearch.DriverDataGridRowSelectedEvent += new SPEventHandler(wcDriverSearch_DriverDataGridRowSelectedEvent);
            wcDriverEdit.DriverClearEvent += new SPEventHandler(wcDriverEdit_DriverClearEvent);
            wcDriverEdit.DriverAddEvent += new SPEventHandler(wcDriverEdit_DriverAddEvent);
            wcDriverEdit.DriverUpdateEvent += new SPEventHandler(wcDriverEdit_DriverUpdateEvent);
            wcDriverEdit.DriverDeleteEvent += new SPEventHandler(wcDriverEdit_DriverDeleteEvent);
            if (wcDriverEdit.CarriersCount < 1)
            {
                _carriers = DataServiceCarriers.CarrierSqlGetAll();
                _carriers.Insert(0, new Carrier());
                _carriers[0].CarrierCompanyName = "* Unassigned *";
                wcDriverEdit.CarriersFill(_carriers);
            }

            if (wcDriverEdit.DriverStatusesCount < 1)
            {
                _driverStatuses = DataServiceDriverStatuses.DriverStatusSqlGetAll();
                _driverStatuses.Insert(0, new DriverStatus());
                _driverStatuses[0].DriverStatusDescription = "* Unassigned *";
                wcDriverEdit.DriverStatusesFill(_driverStatuses);
            }

            if (wcDriverEdit.FuelCardStatusesCount < 1)
            {
                _fuelCardStatuses = DataServiceFuelCardStatuses.FuelCardStatusSqlGetAll();
                _fuelCardStatuses.Insert(0, new FuelCardStatus());
                _fuelCardStatuses[0].FuelCardStatusDescription = "* Unassigned *";
                wcDriverEdit.FuelCardStatusesFill(_fuelCardStatuses);
            }

            if (wcDriverEdit.LicensePlateStatusesCount < 1)
            {
                _licensePlateStatuses = DataServiceLicensePlateStatuses.LicensePlateStatusSqlGetAll();
                _licensePlateStatuses.Insert(0, new LicensePlateStatus());
                _licensePlateStatuses[0].LicensePlateStatusDescription = "* Unassigned *";
                wcDriverEdit.LicensePlateStatusesFill(_licensePlateStatuses);
            }
            //wcDriverSearch.DriverDataGridClear();
        }

        public void wcDriverSearch_DriverDataGridClearEvent(object sender, SPEventArgs e)
        {
            _drivers = new Collection<Driver>();
            wcDriverSearch.DriverDataGridClear();
        }

        public void wcDriverSearch_DriverDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcDriverSearch.DriverDataGridSearch();
        }

        public void wcDriverSearch_DriverDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _driver = SandPatchCL.DataServices.DataServiceDrivers.DriverSqlGetById(e.Index);
            wcDriverEdit.DriverShow(_driver);
        }

        public void wcDriverEdit_DriverClearEvent(object sender, SPEventArgs e)
        {
            _driver = new Driver();
            wcDriverEdit.DriverClear();
        }

        public void wcDriverEdit_DriverAddEvent(object sender, SPEventArgs e)
        {
            wcDriverEdit.DriverUpdate(ref _driver);
            DataServiceDrivers.SqlSave(ref _driver);
            wcDriverEdit.DriverShow(_driver);
        }

        public void wcDriverEdit_DriverUpdateEvent(object sender, SPEventArgs e)
        {
            wcDriverEdit.DriverUpdate(ref _driver);
            DataServiceDrivers.SqlSave(ref _driver);
            wcDriverEdit.DriverShow(_driver);
        }

        public void wcDriverEdit_DriverDeleteEvent(object sender, SPEventArgs e)
        {
            wcDriverEdit.DriverUpdate(ref _driver);
            DataServiceDrivers.SqlDelete(ref _driver);
            _driver = new Driver();
            wcDriverEdit.DriverClear();
            wcDriverSearch.DriverDataGridSearch();
        }

    }
}
