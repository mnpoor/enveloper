using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormLoadingTerminal : System.Web.UI.Page
    {
        private LoadingTerminal _loadingTerminal;
        private Collection<LoadingTerminal> _loadingTerminals;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _loadingTerminal = new LoadingTerminal();
            wcLoadingTerminalSearch.LoadingTerminalDataGridClearEvent += new SPEventHandler(wcLoadingTerminalSearch_LoadingTerminalDataGridClearEvent);
            wcLoadingTerminalSearch.LoadingTerminalDataGridSearchEvent += new SPEventHandler(wcLoadingTerminalSearch_LoadingTerminalDataGridSearchEvent);
            wcLoadingTerminalSearch.LoadingTerminalDataGridPageIndexChangingEvent += new SPEventHandler(wcLoadingTerminalSearch_LoadingTerminalDataGridPageIndexChangingEvent);
            wcLoadingTerminalSearch.LoadingTerminalDataGridRowSelectedEvent += new SPEventHandler(wcLoadingTerminalSearch_LoadingTerminalDataGridRowSelectedEvent);
            wcLoadingTerminalEdit.LoadingTerminalClearEvent += new SPEventHandler(wcLoadingTerminalEdit_LoadingTerminalClearEvent);
            wcLoadingTerminalEdit.LoadingTerminalAddEvent += new SPEventHandler(wcLoadingTerminalEdit_LoadingTerminalAddEvent);
            wcLoadingTerminalEdit.LoadingTerminalUpdateEvent += new SPEventHandler(wcLoadingTerminalEdit_LoadingTerminalUpdateEvent);
            wcLoadingTerminalEdit.LoadingTerminalDeleteEvent += new SPEventHandler(wcLoadingTerminalEdit_LoadingTerminalDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcLoadingTerminalSearch.LoadingTerminalDataGridClear();
            }
        }

        public void wcLoadingTerminalSearch_LoadingTerminalDataGridClearEvent(object sender, SPEventArgs e)
        {
            _loadingTerminals = new Collection<LoadingTerminal>();
            wcLoadingTerminalSearch.LoadingTerminalDataGridClear();
        }

        public void wcLoadingTerminalSearch_LoadingTerminalDataGridSearchEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcLoadingTerminalSearch.LoadingTerminalDataGridWildcard();
            _loadingTerminals = SandPatchCL.DataServices.DataServiceLoadingTerminals.LoadingTerminalSqlGetBySearchTerms(_searchTerms);
            wcLoadingTerminalSearch.LoadingTerminalDataGridSearch(_loadingTerminals, 0);
        }

        public void wcLoadingTerminalSearch_LoadingTerminalDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            _searchTerms = wcLoadingTerminalSearch.LoadingTerminalDataGridWildcard();
            _loadingTerminals = SandPatchCL.DataServices.DataServiceLoadingTerminals.LoadingTerminalSqlGetBySearchTerms(_searchTerms);
            wcLoadingTerminalSearch.LoadingTerminalDataGridSearch(_loadingTerminals, e.Index);
        }

        public void wcLoadingTerminalSearch_LoadingTerminalDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _loadingTerminal = SandPatchCL.DataServices.DataServiceLoadingTerminals.LoadingTerminalSqlGetById(e.Index);
            wcLoadingTerminalEdit.LoadingTerminalShow(_loadingTerminal);
        }

        public void wcLoadingTerminalEdit_LoadingTerminalClearEvent(object sender, SPEventArgs e)
        {
            _loadingTerminal = new LoadingTerminal();
            wcLoadingTerminalEdit.LoadingTerminalClear();
        }

        public void wcLoadingTerminalEdit_LoadingTerminalAddEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalEdit.LoadingTerminalUpdate(ref _loadingTerminal);
            DataServiceLoadingTerminals.SqlSave(ref _loadingTerminal);
            wcLoadingTerminalEdit.LoadingTerminalShow(_loadingTerminal);
        }

        public void wcLoadingTerminalEdit_LoadingTerminalUpdateEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalEdit.LoadingTerminalUpdate(ref _loadingTerminal);
            DataServiceLoadingTerminals.SqlSave(ref _loadingTerminal);
            wcLoadingTerminalEdit.LoadingTerminalShow(_loadingTerminal);
        }

        public void wcLoadingTerminalEdit_LoadingTerminalDeleteEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalEdit.LoadingTerminalUpdate(ref _loadingTerminal);
            DataServiceLoadingTerminals.SqlDelete(ref _loadingTerminal);
            _loadingTerminal = new LoadingTerminal();
            wcLoadingTerminalEdit.LoadingTerminalClear();
            _searchTerms = wcLoadingTerminalSearch.LoadingTerminalDataGridWildcard();
            _loadingTerminals = SandPatchCL.DataServices.DataServiceLoadingTerminals.LoadingTerminalSqlGetBySearchTerms(_searchTerms);
            wcLoadingTerminalSearch.LoadingTerminalDataGridSearch(_loadingTerminals, 0);
        }

    }
}
