using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormCarrierStatus : System.Web.UI.Page
    {
        private CarrierStatus _carrierStatus;
        private Collection<CarrierStatus> _carrierStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _carrierStatus = new CarrierStatus();
            wcCarrierStatusesSearch.CarrierStatusDataGridClearEvent += new SPEventHandler(wcCarrierStatusesSearch_CarrierStatusDataGridClearEvent);
            wcCarrierStatusesSearch.CarrierStatusDataGridSearchEvent += new SPEventHandler(wcCarrierStatusesSearch_CarrierStatusDataGridSearchEvent);
            wcCarrierStatusesSearch.CarrierStatusDataGridRowSelectedEvent += new SPEventHandler(wcCarrierStatusesSearch_CarrierStatusDataGridRowSelectedEvent);
            wcCarrierStatusEdit.CarrierStatusClearEvent += new SPEventHandler(wcCarrierStatusEdit_CarrierStatusClearEvent);
            wcCarrierStatusEdit.CarrierStatusAddEvent += new SPEventHandler(wcCarrierStatusEdit_CarrierStatusAddEvent);
            wcCarrierStatusEdit.CarrierStatusUpdateEvent += new SPEventHandler(wcCarrierStatusEdit_CarrierStatusUpdateEvent);
            wcCarrierStatusEdit.CarrierStatusDeleteEvent += new SPEventHandler(wcCarrierStatusEdit_CarrierStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcCarrierStatusesSearch.CarrierStatusDataGridClear();
            }
        }

        public void wcCarrierStatusesSearch_CarrierStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _carrierStatuss = new Collection<CarrierStatus>();
            wcCarrierStatusesSearch.CarrierStatusDataGridClear();
        }

        public void wcCarrierStatusesSearch_CarrierStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcCarrierStatusesSearch.CarrierStatusDataGridSearch();
        }

        public void wcCarrierStatusesSearch_CarrierStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _carrierStatus = SandPatchCL.DataServices.DataServiceCarrierStatuses.CarrierStatusSqlGetById(e.Index);
            wcCarrierStatusEdit.CarrierStatusShow(_carrierStatus);
        }

        public void wcCarrierStatusEdit_CarrierStatusClearEvent(object sender, SPEventArgs e)
        {
            _carrierStatus = new CarrierStatus();
            wcCarrierStatusEdit.CarrierStatusClear();
        }

        public void wcCarrierStatusEdit_CarrierStatusAddEvent(object sender, SPEventArgs e)
        {
            wcCarrierStatusEdit.CarrierStatusUpdate(ref _carrierStatus);
            DataServiceCarrierStatuses.SqlSave(ref _carrierStatus);
            wcCarrierStatusEdit.CarrierStatusShow(_carrierStatus);
        }

        public void wcCarrierStatusEdit_CarrierStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcCarrierStatusEdit.CarrierStatusUpdate(ref _carrierStatus);
            DataServiceCarrierStatuses.SqlSave(ref _carrierStatus);
            wcCarrierStatusEdit.CarrierStatusShow(_carrierStatus);
        }

        public void wcCarrierStatusEdit_CarrierStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcCarrierStatusEdit.CarrierStatusUpdate(ref _carrierStatus);
            DataServiceCarrierStatuses.SqlDelete(ref _carrierStatus);
            _carrierStatus = new CarrierStatus();
            wcCarrierStatusEdit.CarrierStatusClear();
            wcCarrierStatusesSearch.CarrierStatusDataGridSearch();
        }

    }
}
