using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormLoadingTerminalStatus : System.Web.UI.Page
    {
        private LoadingTerminalStatus _loadingTerminalStatus;
        private Collection<LoadingTerminalStatus> _loadingTerminalStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _loadingTerminalStatus = new LoadingTerminalStatus();
            wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridClearEvent += new SPEventHandler(wcLoadingTerminalStatusesSearch_LoadingTerminalStatusDataGridClearEvent);
            wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridSearchEvent += new SPEventHandler(wcLoadingTerminalStatusesSearch_LoadingTerminalStatusDataGridSearchEvent);
            wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridRowSelectedEvent += new SPEventHandler(wcLoadingTerminalStatusesSearch_LoadingTerminalStatusDataGridRowSelectedEvent);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusClearEvent += new SPEventHandler(wcLoadingTerminalStatusEdit_LoadingTerminalStatusClearEvent);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusAddEvent += new SPEventHandler(wcLoadingTerminalStatusEdit_LoadingTerminalStatusAddEvent);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusUpdateEvent += new SPEventHandler(wcLoadingTerminalStatusEdit_LoadingTerminalStatusUpdateEvent);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusDeleteEvent += new SPEventHandler(wcLoadingTerminalStatusEdit_LoadingTerminalStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridClear();
            }
        }

        public void wcLoadingTerminalStatusesSearch_LoadingTerminalStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _loadingTerminalStatuss = new Collection<LoadingTerminalStatus>();
            wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridClear();
        }

        public void wcLoadingTerminalStatusesSearch_LoadingTerminalStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridSearch();
        }

        public void wcLoadingTerminalStatusesSearch_LoadingTerminalStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _loadingTerminalStatus = SandPatchCL.DataServices.DataServiceLoadingTerminalStatuses.LoadingTerminalStatusSqlGetById(e.Index);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusShow(_loadingTerminalStatus);
        }

        public void wcLoadingTerminalStatusEdit_LoadingTerminalStatusClearEvent(object sender, SPEventArgs e)
        {
            _loadingTerminalStatus = new LoadingTerminalStatus();
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusClear();
        }

        public void wcLoadingTerminalStatusEdit_LoadingTerminalStatusAddEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusUpdate(ref _loadingTerminalStatus);
            DataServiceLoadingTerminalStatuses.SqlSave(ref _loadingTerminalStatus);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusShow(_loadingTerminalStatus);
        }

        public void wcLoadingTerminalStatusEdit_LoadingTerminalStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusUpdate(ref _loadingTerminalStatus);
            DataServiceLoadingTerminalStatuses.SqlSave(ref _loadingTerminalStatus);
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusShow(_loadingTerminalStatus);
        }

        public void wcLoadingTerminalStatusEdit_LoadingTerminalStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusUpdate(ref _loadingTerminalStatus);
            DataServiceLoadingTerminalStatuses.SqlDelete(ref _loadingTerminalStatus);
            _loadingTerminalStatus = new LoadingTerminalStatus();
            wcLoadingTerminalStatusEdit.LoadingTerminalStatusClear();
            wcLoadingTerminalStatusesSearch.LoadingTerminalStatusDataGridSearch();
        }

    }
}
