using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormCustomer : System.Web.UI.Page
    {
        private Customer _customer;
        private Collection<Customer> _customers;

        private Collection<CustomerStatus> _customerStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _customer = new Customer();
            wcCustomerSearch.CustomerDataGridClearEvent += new SPEventHandler(wcCustomerSearch_CustomerDataGridClearEvent);
            wcCustomerSearch.CustomerDataGridSearchEvent += new SPEventHandler(wcCustomerSearch_CustomerDataGridSearchEvent);
            wcCustomerSearch.CustomerDataGridRowSelectedEvent += new SPEventHandler(wcCustomerSearch_CustomerDataGridRowSelectedEvent);
            wcCustomerEdit.CustomerClearEvent += new SPEventHandler(wcCustomerEdit_CustomerClearEvent);
            wcCustomerEdit.CustomerAddEvent += new SPEventHandler(wcCustomerEdit_CustomerAddEvent);
            wcCustomerEdit.CustomerUpdateEvent += new SPEventHandler(wcCustomerEdit_CustomerUpdateEvent);
            wcCustomerEdit.CustomerDeleteEvent += new SPEventHandler(wcCustomerEdit_CustomerDeleteEvent);
            if (wcCustomerEdit.CustomerStatusesCount < 1)
            {
                _customerStatuses = DataServiceCustomerStatuses.CustomerStatusSqlGetAll();
                _customerStatuses.Insert(0, new CustomerStatus());
                _customerStatuses[0].CustomerStatusDescription = "* Unassigned *";
                wcCustomerEdit.CustomerStatusesFill(_customerStatuses);
            }
            //wcCustomerSearch.CustomerDataGridViewClear();
        }

        public void wcCustomerSearch_CustomerDataGridClearEvent(object sender, SPEventArgs e)
        {
            _customers = new Collection<Customer>();
            wcCustomerSearch.CustomerDataGridViewClear();
        }

        public void wcCustomerSearch_CustomerDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcCustomerSearch.CustomerDataGridSearch();
        }

        public void wcCustomerSearch_CustomerDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _customer = SandPatchCL.DataServices.DataServiceCustomers.CustomerSqlGetById(e.Index);
            wcCustomerEdit.CustomerShow(_customer);
        }

        public void wcCustomerEdit_CustomerClearEvent(object sender, SPEventArgs e)
        {
            _customer = new Customer();
            wcCustomerEdit.CustomerClear();
        }

        public void wcCustomerEdit_CustomerAddEvent(object sender, SPEventArgs e)
        {
            wcCustomerEdit.CustomerUpdate(ref _customer);
            DataServiceCustomers.SqlSave(ref _customer);
            wcCustomerEdit.CustomerShow(_customer);
        }

        public void wcCustomerEdit_CustomerUpdateEvent(object sender, SPEventArgs e)
        {
            wcCustomerEdit.CustomerUpdate(ref _customer);
            DataServiceCustomers.SqlSave(ref _customer);
            wcCustomerEdit.CustomerShow(_customer);
        }

        public void wcCustomerEdit_CustomerDeleteEvent(object sender, SPEventArgs e)
        {
            wcCustomerEdit.CustomerUpdate(ref _customer);
            DataServiceCustomers.SqlDelete(ref _customer);
            _customer = new Customer();
            wcCustomerEdit.CustomerClear();
            wcCustomerSearch.CustomerDataGridSearch();
        }

    }
}
