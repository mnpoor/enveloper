using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormWithholdingAccounts : System.Web.UI.Page
    {
        private WithholdingAccount _withholdingAccount;
        private Collection<WithholdingAccount> _withholdingAccounts;

        private string[] _searchTerms;

        protected void Page_Load(object sender, EventArgs e)
        {
            _withholdingAccount = new WithholdingAccount();
            wcWithholdingAccountSearch.WithholdingAccountDataGridClearEvent += new SPEventHandler(wcWithholdingAccountSearch_WithholdingAccountDataGridClearEvent);
            wcWithholdingAccountSearch.WithholdingAccountDataGridSearchEvent += new SPEventHandler(wcWithholdingAccountSearch_WithholdingAccountDataGridSearchEvent);
            wcWithholdingAccountSearch.WithholdingAccountDataGridPageIndexChangingEvent += new SPEventHandler(wcWithholdingAccountSearch_WithholdingAccountDataGridPageIndexChangingEvent);
            wcWithholdingAccountSearch.WithholdingAccountDataGridRowSelectedEvent += new SPEventHandler(wcWithholdingAccountSearch_WithholdingAccountDataGridRowSelectedEvent);
            wcWithholdingAccountManager.WithholdingAccountClearEvent += new SPEventHandler(wcWithholdingAccountManager_WithholdingAccountClearEvent);
            wcWithholdingAccountManager.WithholdingAccountAddEvent += new SPEventHandler(wcWithholdingAccountManager_WithholdingAccountAddEvent);
            wcWithholdingAccountManager.WithholdingAccountUpdateEvent += new SPEventHandler(wcWithholdingAccountManager_WithholdingAccountUpdateEvent);
            wcWithholdingAccountManager.WithholdingAccountDeleteEvent += new SPEventHandler(wcWithholdingAccountManager_WithholdingAccountDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcWithholdingAccountSearch.WithholdingAccountDataGridClear();
            }
        }

        public void wcWithholdingAccountSearch_WithholdingAccountDataGridClearEvent(object sender, SPEventArgs e)
        {
            _withholdingAccounts = new Collection<WithholdingAccount>();
            wcWithholdingAccountSearch.WithholdingAccountDataGridClear();
        }

        public void wcWithholdingAccountSearch_WithholdingAccountDataGridSearchEvent(object sender, SPEventArgs e)
        {
            //_searchTerms = wcWithholdingAccountSearch.WithholdingAccountDataGridWildcard();
            _withholdingAccounts = SandPatchCL.DataServices.DataServiceWithholdingAccounts.WithholdingAccountSqlGetAll();
            wcWithholdingAccountSearch.WithholdingAccountDataGridSearch(_withholdingAccounts, 0);
        }

        public void wcWithholdingAccountSearch_WithholdingAccountDataGridPageIndexChangingEvent(object sender, SPEventArgs e)
        {
            //_searchTerms = wcWithholdingAccountSearch.WithholdingAccountDataGridWildcard();
            _withholdingAccounts = SandPatchCL.DataServices.DataServiceWithholdingAccounts.WithholdingAccountSqlGetAll();
            wcWithholdingAccountSearch.WithholdingAccountDataGridSearch(_withholdingAccounts, e.Index);
        }

        public void wcWithholdingAccountSearch_WithholdingAccountDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _withholdingAccount = SandPatchCL.DataServices.DataServiceWithholdingAccounts.WithholdingAccountSqlGetById(e.Index);
            wcWithholdingAccountManager.WithholdingAccountShow(_withholdingAccount);
        }

        public void wcWithholdingAccountManager_WithholdingAccountClearEvent(object sender, SPEventArgs e)
        {
            _withholdingAccount = new WithholdingAccount();
            wcWithholdingAccountManager.WithholdingAccountClear();
        }

        public void wcWithholdingAccountManager_WithholdingAccountAddEvent(object sender, SPEventArgs e)
        {
            wcWithholdingAccountManager.WithholdingAccountUpdate(ref _withholdingAccount);
            DataServiceWithholdingAccounts.SqlSave(ref _withholdingAccount);
            wcWithholdingAccountManager.WithholdingAccountShow(_withholdingAccount);
        }

        public void wcWithholdingAccountManager_WithholdingAccountUpdateEvent(object sender, SPEventArgs e)
        {
            wcWithholdingAccountManager.WithholdingAccountUpdate(ref _withholdingAccount);
            DataServiceWithholdingAccounts.SqlSave(ref _withholdingAccount);
            wcWithholdingAccountManager.WithholdingAccountShow(_withholdingAccount);
        }

        public void wcWithholdingAccountManager_WithholdingAccountDeleteEvent(object sender, SPEventArgs e)
        {
            wcWithholdingAccountManager.WithholdingAccountUpdate(ref _withholdingAccount);
            DataServiceWithholdingAccounts.SqlDelete(ref _withholdingAccount);
            _withholdingAccount = new WithholdingAccount();
            wcWithholdingAccountManager.WithholdingAccountClear();
            //_searchTerms = wcWithholdingAccountSearch.WithholdingAccountDataGridWildcard();
            _withholdingAccounts = SandPatchCL.DataServices.DataServiceWithholdingAccounts.WithholdingAccountSqlGetAll();
            wcWithholdingAccountSearch.WithholdingAccountDataGridSearch(_withholdingAccounts, 0);
        }

    }
}
