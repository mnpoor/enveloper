using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDispatchStatuses : System.Web.UI.Page
    {
        private DispatchStatus _dispatchStatus;
        private Collection<DispatchStatus> _dispatchStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _dispatchStatus = new DispatchStatus();
            wcDispatchStatusesSearch.DispatchStatusDataGridClearEvent += new SPEventHandler(wcDispatchStatusesSearch_DispatchStatusDataGridClearEvent);
            wcDispatchStatusesSearch.DispatchStatusDataGridSearchEvent += new SPEventHandler(wcDispatchStatusesSearch_DispatchStatusDataGridSearchEvent);
            wcDispatchStatusesSearch.DispatchStatusDataGridRowSelectedEvent += new SPEventHandler(wcDispatchStatusesSearch_DispatchStatusDataGridRowSelectedEvent);
            wcDispatchStatusesManager.DispatchStatusClearEvent += new SPEventHandler(wcDispatchStatusesManager_DispatchStatusClearEvent);
            wcDispatchStatusesManager.DispatchStatusAddEvent += new SPEventHandler(wcDispatchStatusesManager_DispatchStatusAddEvent);
            wcDispatchStatusesManager.DispatchStatusUpdateEvent += new SPEventHandler(wcDispatchStatusesManager_DispatchStatusUpdateEvent);
            wcDispatchStatusesManager.DispatchStatusDeleteEvent += new SPEventHandler(wcDispatchStatusesManager_DispatchStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcDispatchStatusesSearch.DispatchStatusDataGridClear();
            }
        }

        public void wcDispatchStatusesSearch_DispatchStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _dispatchStatuses = new Collection<DispatchStatus>();
            wcDispatchStatusesSearch.DispatchStatusDataGridClear();
        }

        public void wcDispatchStatusesSearch_DispatchStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcDispatchStatusesSearch.DispatchStatusDataGridSearch();
        }

        public void wcDispatchStatusesSearch_DispatchStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _dispatchStatus = SandPatchCL.DataServices.DataServiceDispatchStatuses.DispatchStatusSqlGetById(e.Index);
            wcDispatchStatusesManager.DispatchStatusShow(_dispatchStatus);
        }

        public void wcDispatchStatusesManager_DispatchStatusClearEvent(object sender, SPEventArgs e)
        {
            _dispatchStatus = new DispatchStatus();
            wcDispatchStatusesManager.DispatchStatusClear();
        }

        public void wcDispatchStatusesManager_DispatchStatusAddEvent(object sender, SPEventArgs e)
        {
            wcDispatchStatusesManager.DispatchStatusUpdate(ref _dispatchStatus);
            DataServiceDispatchStatuses.SqlSave(ref _dispatchStatus);
            wcDispatchStatusesManager.DispatchStatusShow(_dispatchStatus);
        }

        public void wcDispatchStatusesManager_DispatchStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcDispatchStatusesManager.DispatchStatusUpdate(ref _dispatchStatus);
            DataServiceDispatchStatuses.SqlSave(ref _dispatchStatus);
            wcDispatchStatusesManager.DispatchStatusShow(_dispatchStatus);
        }

        public void wcDispatchStatusesManager_DispatchStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcDispatchStatusesManager.DispatchStatusUpdate(ref _dispatchStatus);
            DataServiceDispatchStatuses.SqlDelete(ref _dispatchStatus);
            _dispatchStatus = new DispatchStatus();
            wcDispatchStatusesManager.DispatchStatusClear();
            wcDispatchStatusesSearch.DispatchStatusDataGridSearch();
        }

    }
}
