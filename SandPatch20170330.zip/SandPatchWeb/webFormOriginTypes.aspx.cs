using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormOriginTypes : System.Web.UI.Page
    {
        private OriginType _originType;
        private Collection<OriginType> _originTypes;

        protected void Page_Load(object sender, EventArgs e)
        {
            _originType = new OriginType();
            wcOriginTypeSearch.OriginTypeDataGridClearEvent += new SPEventHandler(wcOriginTypeSearch_OriginTypeDataGridClearEvent);
            wcOriginTypeSearch.OriginTypeDataGridSearchEvent += new SPEventHandler(wcOriginTypeSearch_OriginTypeDataGridSearchEvent);
            wcOriginTypeSearch.OriginTypeDataGridRowSelectedEvent += new SPEventHandler(wcOriginTypeSearch_OriginTypeDataGridRowSelectedEvent);
            wcOriginTypeManager.OriginTypeClearEvent += new SPEventHandler(wcOriginTypeManager_OriginTypeClearEvent);
            wcOriginTypeManager.OriginTypeAddEvent += new SPEventHandler(wcOriginTypeManager_OriginTypeAddEvent);
            wcOriginTypeManager.OriginTypeUpdateEvent += new SPEventHandler(wcOriginTypeManager_OriginTypeUpdateEvent);
            wcOriginTypeManager.OriginTypeDeleteEvent += new SPEventHandler(wcOriginTypeManager_OriginTypeDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcOriginTypeSearch.OriginTypeDataGridClear();
            }
        }

        public void wcOriginTypeSearch_OriginTypeDataGridClearEvent(object sender, SPEventArgs e)
        {
            _originTypes = new Collection<OriginType>();
            wcOriginTypeSearch.OriginTypeDataGridClear();
        }

        public void wcOriginTypeSearch_OriginTypeDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcOriginTypeSearch.OriginTypeDataGridSearch();
        }

        public void wcOriginTypeSearch_OriginTypeDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _originType = SandPatchCL.DataServices.DataServiceOriginTypes.OriginTypeSqlGetById(e.Index);
            wcOriginTypeManager.OriginTypeShow(_originType);
        }

        public void wcOriginTypeManager_OriginTypeClearEvent(object sender, SPEventArgs e)
        {
            _originType = new OriginType();
            wcOriginTypeManager.OriginTypeClear();
        }

        public void wcOriginTypeManager_OriginTypeAddEvent(object sender, SPEventArgs e)
        {
            wcOriginTypeManager.OriginTypeUpdate(ref _originType);
            DataServiceOriginTypes.SqlSave(ref _originType);
            wcOriginTypeManager.OriginTypeShow(_originType);
        }

        public void wcOriginTypeManager_OriginTypeUpdateEvent(object sender, SPEventArgs e)
        {
            wcOriginTypeManager.OriginTypeUpdate(ref _originType);
            DataServiceOriginTypes.SqlSave(ref _originType);
            wcOriginTypeManager.OriginTypeShow(_originType);
        }

        public void wcOriginTypeManager_OriginTypeDeleteEvent(object sender, SPEventArgs e)
        {
            wcOriginTypeManager.OriginTypeUpdate(ref _originType);
            DataServiceOriginTypes.SqlDelete(ref _originType);
            _originType = new OriginType();
            wcOriginTypeManager.OriginTypeClear();
            wcOriginTypeSearch.OriginTypeDataGridSearch();
        }

    }
}
