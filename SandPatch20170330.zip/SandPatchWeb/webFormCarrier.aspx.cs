using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormCarrier : System.Web.UI.Page
    {
        private Carrier _carrier;
        private Collection<Carrier> _carriers;

        private Collection<CarrierStatus> _carrierStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _carrier = new Carrier();
            wcCarrierSearch.CarrierDataGridClearEvent += new SPEventHandler(wcCarrierSearch_CarrierDataGridClearEvent);
            wcCarrierSearch.CarrierDataGridSearchEvent += new SPEventHandler(wcCarrierSearch_CarrierDataGridSearchEvent);
            wcCarrierSearch.CarrierDataGridRowSelectedEvent += new SPEventHandler(wcCarrierSearch_CarrierDataGridRowSelectedEvent);
            wcCarrierEdit.CarrierClearEvent += new SPEventHandler(wcCarrierEdit_CarrierClearEvent);
            wcCarrierEdit.CarrierAddEvent += new SPEventHandler(wcCarrierEdit_CarrierAddEvent);
            wcCarrierEdit.CarrierUpdateEvent += new SPEventHandler(wcCarrierEdit_CarrierUpdateEvent);
            wcCarrierEdit.CarrierDeleteEvent += new SPEventHandler(wcCarrierEdit_CarrierDeleteEvent);
            if (wcCarrierEdit.CarrierStatusesCount < 1)
            {
                _carrierStatuses = DataServiceCarrierStatuses.CarrierStatusSqlGetAll();
                _carrierStatuses.Insert(0, new CarrierStatus());
                _carrierStatuses[0].CarrierStatusDescription = "* Unassigned *";
                wcCarrierEdit.CarrierStatusesFill(_carrierStatuses);
            }
            if (!Page.IsPostBack)
            {
                wcCarrierSearch.CarrierDataGridClear();
            }
        }

        public void wcCarrierSearch_CarrierDataGridClearEvent(object sender, SPEventArgs e)
        {
            _carriers = new Collection<Carrier>();
            wcCarrierSearch.CarrierDataGridClear();
        }

        public void wcCarrierSearch_CarrierDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcCarrierSearch.CarrierDataGridSearch();
        }

        public void wcCarrierSearch_CarrierDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _carrier = SandPatchCL.DataServices.DataServiceCarriers.CarrierSqlGetById(e.Index);
            wcCarrierEdit.CarrierShow(_carrier);
        }

        public void wcCarrierEdit_CarrierClearEvent(object sender, SPEventArgs e)
        {
            _carrier = new Carrier();
            wcCarrierEdit.CarrierClear();
        }

        public void wcCarrierEdit_CarrierAddEvent(object sender, SPEventArgs e)
        {
            wcCarrierEdit.CarrierUpdate(ref _carrier);
            DataServiceCarriers.SqlSave(ref _carrier);
            wcCarrierEdit.CarrierShow(_carrier);
        }

        public void wcCarrierEdit_CarrierUpdateEvent(object sender, SPEventArgs e)
        {
            wcCarrierEdit.CarrierUpdate(ref _carrier);
            DataServiceCarriers.SqlSave(ref _carrier);
            wcCarrierEdit.CarrierShow(_carrier);
        }

        public void wcCarrierEdit_CarrierDeleteEvent(object sender, SPEventArgs e)
        {
            wcCarrierEdit.CarrierUpdate(ref _carrier);
            DataServiceCarriers.SqlDelete(ref _carrier);
            _carrier = new Carrier();
            wcCarrierEdit.CarrierClear();
            wcCarrierSearch.CarrierDataGridSearch();
        }

    }
}
