﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDispatchReport : System.Web.UI.Page
    {

        protected SandPatchWeb.SandPatchReports.ActiveDispatchesReportDataTable _activeDispatchesDataTable;
        protected SandPatchWeb.SandPatchReportsTableAdapters.ActiveDispatchesReportTableAdapter _activeDispatchesReportTableAdapter;
        protected ReportDataSource _activeDispatchesReportDataSource;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void cmdPrint_Click(object sender, EventArgs e)
        {
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportActiveDispatches", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;

            preprocess.ExecuteNonQuery();

            _activeDispatchesDataTable = new SandPatchReports.ActiveDispatchesReportDataTable();

            _activeDispatchesReportTableAdapter = new SandPatchReportsTableAdapters.ActiveDispatchesReportTableAdapter();
            _activeDispatchesReportTableAdapter.Connection = connection;
            _activeDispatchesReportTableAdapter.Fill(_activeDispatchesDataTable);

            _activeDispatchesReportDataSource = new ReportDataSource("ActiveDispatchesDataSet", (System.Data.DataTable)_activeDispatchesDataTable);

            reportViewerDispatch.LocalReport.DataSources.Add(_activeDispatchesReportDataSource);

            reportViewerDispatch.LocalReport.Refresh();



            /*
            SqlConnection connection = SandPatchCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportActiveDispatches", connection);
            preprocess.CommandType = System.Data.CommandType.StoredProcedure;

            preprocess.ExecuteNonQuery();

            _activeDispatchesReportTableAdapter = new SandPatchReportsTableAdapters.ActiveDispatchesReportTableAdapter();
            _activeDispatchesReportTableAdapter.Connection = connection;

            _activeDispatchesDataTable = new SandPatchReports.ActiveDispatchesReportDataTable();

            _activeDispatchesReportTableAdapter.Fill(_activeDispatchesDataTable);

            _activeDispatchesReportDataSource = new ReportDataSource(_activeDispatchesDataTable.TableName, (System.Data.DataTable)_activeDispatchesDataTable);

            //reportViewerDispatch.LocalReport.DataSources += _activeDispatchesReportDataSource;

            reportViewerDispatch.LocalReport.Refresh();
            */
            /*
            SqlConnection connection = BHCHMineralManagerCL.DataServices.DataServiceBase.GetSQLConnection();
            SqlCommand preprocess = new SqlCommand("ReportPendingAndActiveLeases", connection);
            preprocess.CommandType = CommandType.StoredProcedure;

            if (cmbState.Text != string.Empty)
            {
                if (cmbState.Text != "All")
                {
                    preprocess.Parameters.Add(new SqlParameter("@StateName", (object)cmbState.Text));
                }
            }

            if (cmbCounty.Text != string.Empty)
            {
                if (cmbCounty.Text != "All")
                {
                    preprocess.Parameters.Add(new SqlParameter("@CountyName", (object)cmbCounty.Text));
                }
            }
            if (dtpLeaseOfferOnOrAfter.Format != DateTimePickerFormat.Custom)
            {
                preprocess.Parameters.Add(new SqlParameter("@StartingDate", (object)dtpLeaseOfferOnOrAfter.Value));
            }

            if (dtpLeaseExpiresAfter.Format != DateTimePickerFormat.Custom)
            {
                preprocess.Parameters.Add(new SqlParameter("@EndingDate", (object)dtpLeaseExpiresAfter.Value));
            }

            preprocess.ExecuteNonQuery();

            Application.DoEvents();

            this.PendingAndActiveLeasesReportTableAdapter.Connection = BHCHMineralManagerCL.DataServices.DataServiceBase.GetSQLConnection();

            this.PendingAndActiveLeasesReportTableAdapter.Fill(this.BHCHMineralManagerDataSet.PendingAndActiveLeasesReport);

            this.pendingAndActiveLeasesReportViewer.RefreshReport();
             */
        }
    }
}