using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormFuelCardStatus : System.Web.UI.Page
    {
        private FuelCardStatus _fuelCardStatus;
        private Collection<FuelCardStatus> _fuelCardStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _fuelCardStatus = new FuelCardStatus();
            wcFuelCardStatusesSearch.FuelCardStatusDataGridClearEvent += new SPEventHandler(wcFuelCardStatusesSearch_FuelCardStatusDataGridClearEvent);
            wcFuelCardStatusesSearch.FuelCardStatusDataGridSearchEvent += new SPEventHandler(wcFuelCardStatusesSearch_FuelCardStatusDataGridSearchEvent);
            wcFuelCardStatusesSearch.FuelCardStatusDataGridRowSelectedEvent += new SPEventHandler(wcFuelCardStatusesSearch_FuelCardStatusDataGridRowSelectedEvent);
            wcFuelCardStatusEdit.FuelCardStatusClearEvent += new SPEventHandler(wcFuelCardStatusEdit_FuelCardStatusClearEvent);
            wcFuelCardStatusEdit.FuelCardStatusAddEvent += new SPEventHandler(wcFuelCardStatusEdit_FuelCardStatusAddEvent);
            wcFuelCardStatusEdit.FuelCardStatusUpdateEvent += new SPEventHandler(wcFuelCardStatusEdit_FuelCardStatusUpdateEvent);
            wcFuelCardStatusEdit.FuelCardStatusDeleteEvent += new SPEventHandler(wcFuelCardStatusEdit_FuelCardStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcFuelCardStatusesSearch.FuelCardStatusDataGridClear();
            }
        }

        public void wcFuelCardStatusesSearch_FuelCardStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _fuelCardStatuss = new Collection<FuelCardStatus>();
            wcFuelCardStatusesSearch.FuelCardStatusDataGridClear();
        }

        public void wcFuelCardStatusesSearch_FuelCardStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcFuelCardStatusesSearch.FuelCardStatusDataGridSearch();
        }

        public void wcFuelCardStatusesSearch_FuelCardStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _fuelCardStatus = SandPatchCL.DataServices.DataServiceFuelCardStatuses.FuelCardStatusSqlGetById(e.Index);
            wcFuelCardStatusEdit.FuelCardStatusShow(_fuelCardStatus);
        }

        public void wcFuelCardStatusEdit_FuelCardStatusClearEvent(object sender, SPEventArgs e)
        {
            _fuelCardStatus = new FuelCardStatus();
            wcFuelCardStatusEdit.FuelCardStatusClear();
        }

        public void wcFuelCardStatusEdit_FuelCardStatusAddEvent(object sender, SPEventArgs e)
        {
            wcFuelCardStatusEdit.FuelCardStatusUpdate(ref _fuelCardStatus);
            DataServiceFuelCardStatuses.SqlSave(ref _fuelCardStatus);
            wcFuelCardStatusEdit.FuelCardStatusShow(_fuelCardStatus);
        }

        public void wcFuelCardStatusEdit_FuelCardStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcFuelCardStatusEdit.FuelCardStatusUpdate(ref _fuelCardStatus);
            DataServiceFuelCardStatuses.SqlSave(ref _fuelCardStatus);
            wcFuelCardStatusEdit.FuelCardStatusShow(_fuelCardStatus);
        }

        public void wcFuelCardStatusEdit_FuelCardStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcFuelCardStatusEdit.FuelCardStatusUpdate(ref _fuelCardStatus);
            DataServiceFuelCardStatuses.SqlDelete(ref _fuelCardStatus);
            _fuelCardStatus = new FuelCardStatus();
            wcFuelCardStatusEdit.FuelCardStatusClear();
            wcFuelCardStatusesSearch.FuelCardStatusDataGridSearch();
        }

    }
}
