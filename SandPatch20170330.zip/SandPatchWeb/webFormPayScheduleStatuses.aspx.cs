using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormPayScheduleStatuses : System.Web.UI.Page
    {
        private PayScheduleStatus _payScheduleStatus;
        private Collection<PayScheduleStatus> _payScheduleStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _payScheduleStatus = new PayScheduleStatus();
            wcPayScheduleStatusesSearch.PayScheduleStatusDataGridClearEvent += new SPEventHandler(wcPayScheduleStatusesSearch_PayScheduleStatusDataGridClearEvent);
            wcPayScheduleStatusesSearch.PayScheduleStatusDataGridSearchEvent += new SPEventHandler(wcPayScheduleStatusesSearch_PayScheduleStatusDataGridSearchEvent);
            wcPayScheduleStatusesSearch.PayScheduleStatusDataGridRowSelectedEvent += new SPEventHandler(wcPayScheduleStatusesSearch_PayScheduleStatusDataGridRowSelectedEvent);
            wcPayScheduleStatusesManager.PayScheduleStatusClearEvent += new SPEventHandler(wcPayScheduleStatusesManager_PayScheduleStatusClearEvent);
            wcPayScheduleStatusesManager.PayScheduleStatusAddEvent += new SPEventHandler(wcPayScheduleStatusesManager_PayScheduleStatusAddEvent);
            wcPayScheduleStatusesManager.PayScheduleStatusUpdateEvent += new SPEventHandler(wcPayScheduleStatusesManager_PayScheduleStatusUpdateEvent);
            wcPayScheduleStatusesManager.PayScheduleStatusDeleteEvent += new SPEventHandler(wcPayScheduleStatusesManager_PayScheduleStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcPayScheduleStatusesSearch.PayScheduleStatusDataGridClear();
            }
        }

        public void wcPayScheduleStatusesSearch_PayScheduleStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _payScheduleStatuss = new Collection<PayScheduleStatus>();
            wcPayScheduleStatusesManager.PayScheduleStatusClear();
            wcPayScheduleStatusesSearch.PayScheduleStatusDataGridClear();
        }

        public void wcPayScheduleStatusesSearch_PayScheduleStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleStatusesSearch.PayScheduleStatusDataGridSearch();
        }

        public void wcPayScheduleStatusesSearch_PayScheduleStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _payScheduleStatus = SandPatchCL.DataServices.DataServicePayScheduleStatuses.PayScheduleStatusSqlGetById(e.Index);
            wcPayScheduleStatusesManager.PayScheduleStatusShow(_payScheduleStatus);
        }

        public void wcPayScheduleStatusesManager_PayScheduleStatusClearEvent(object sender, SPEventArgs e)
        {
            _payScheduleStatus = new PayScheduleStatus();
            wcPayScheduleStatusesManager.PayScheduleStatusClear();
        }

        public void wcPayScheduleStatusesManager_PayScheduleStatusAddEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleStatusesManager.PayScheduleStatusUpdate(ref _payScheduleStatus);
            DataServicePayScheduleStatuses.SqlSave(ref _payScheduleStatus);
            wcPayScheduleStatusesManager.PayScheduleStatusShow(_payScheduleStatus);
        }

        public void wcPayScheduleStatusesManager_PayScheduleStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleStatusesManager.PayScheduleStatusUpdate(ref _payScheduleStatus);
            DataServicePayScheduleStatuses.SqlSave(ref _payScheduleStatus);
            wcPayScheduleStatusesManager.PayScheduleStatusShow(_payScheduleStatus);
        }

        public void wcPayScheduleStatusesManager_PayScheduleStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcPayScheduleStatusesManager.PayScheduleStatusUpdate(ref _payScheduleStatus);
            DataServicePayScheduleStatuses.SqlDelete(ref _payScheduleStatus);
            _payScheduleStatus = new PayScheduleStatus();
            wcPayScheduleStatusesManager.PayScheduleStatusClear();
            wcPayScheduleStatusesSearch.PayScheduleStatusDataGridSearch();
        }

    }
}
