using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormBillOfLadingStatuses : System.Web.UI.Page
    {
        private BillOfLadingStatus _billOfLadingStatus;
        private Collection<BillOfLadingStatus> _billOfLadingStatuses;

        protected void Page_Load(object sender, EventArgs e)
        {
            _billOfLadingStatus = new BillOfLadingStatus();
            wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridClearEvent += new SPEventHandler(wcBillOfLadingStatusesSearch_BillOfLadingStatusDataGridClearEvent);
            wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridSearchEvent += new SPEventHandler(wcBillOfLadingStatusesSearch_BillOfLadingStatusDataGridSearchEvent);
            wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridRowSelectedEvent += new SPEventHandler(wcBillOfLadingStatusesSearch_BillOfLadingStatusDataGridRowSelectedEvent);
            wcBillOfLadingStatusesManager.BillOfLadingStatusClearEvent += new SPEventHandler(wcBillOfLadingStatusesManager_BillOfLadingStatusClearEvent);
            wcBillOfLadingStatusesManager.BillOfLadingStatusAddEvent += new SPEventHandler(wcBillOfLadingStatusesManager_BillOfLadingStatusAddEvent);
            wcBillOfLadingStatusesManager.BillOfLadingStatusUpdateEvent += new SPEventHandler(wcBillOfLadingStatusesManager_BillOfLadingStatusUpdateEvent);
            wcBillOfLadingStatusesManager.BillOfLadingStatusDeleteEvent += new SPEventHandler(wcBillOfLadingStatusesManager_BillOfLadingStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridClear();
            }
        }

        public void wcBillOfLadingStatusesSearch_BillOfLadingStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _billOfLadingStatuses = new Collection<BillOfLadingStatus>();
            wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridClear();
        }

        public void wcBillOfLadingStatusesSearch_BillOfLadingStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridSearch();
        }

        public void wcBillOfLadingStatusesSearch_BillOfLadingStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _billOfLadingStatus = SandPatchCL.DataServices.DataServiceBillOfLadingStatuses.BillOfLadingStatusSqlGetById(e.Index);
            wcBillOfLadingStatusesManager.BillOfLadingStatusShow(_billOfLadingStatus);
        }

        public void wcBillOfLadingStatusesManager_BillOfLadingStatusClearEvent(object sender, SPEventArgs e)
        {
            _billOfLadingStatus = new BillOfLadingStatus();
            wcBillOfLadingStatusesManager.BillOfLadingStatusClear();
        }

        public void wcBillOfLadingStatusesManager_BillOfLadingStatusAddEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingStatusesManager.BillOfLadingStatusUpdate(ref _billOfLadingStatus);
            DataServiceBillOfLadingStatuses.SqlSave(ref _billOfLadingStatus);
            wcBillOfLadingStatusesManager.BillOfLadingStatusShow(_billOfLadingStatus);
        }

        public void wcBillOfLadingStatusesManager_BillOfLadingStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingStatusesManager.BillOfLadingStatusUpdate(ref _billOfLadingStatus);
            DataServiceBillOfLadingStatuses.SqlSave(ref _billOfLadingStatus);
            wcBillOfLadingStatusesManager.BillOfLadingStatusShow(_billOfLadingStatus);
        }

        public void wcBillOfLadingStatusesManager_BillOfLadingStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcBillOfLadingStatusesManager.BillOfLadingStatusUpdate(ref _billOfLadingStatus);
            DataServiceBillOfLadingStatuses.SqlDelete(ref _billOfLadingStatus);
            _billOfLadingStatus = new BillOfLadingStatus();
            wcBillOfLadingStatusesManager.BillOfLadingStatusClear();
            wcBillOfLadingStatusesSearch.BillOfLadingStatusDataGridSearch();
        }

    }
}
