using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormDestinationTypes : System.Web.UI.Page
    {
        private DestinationType _destinationType;
        private Collection<DestinationType> _destinationTypes;

        protected void Page_Load(object sender, EventArgs e)
        {
            _destinationType = new DestinationType();
            wcDestinationTypeSearch.DestinationTypeDataGridClearEvent += new SPEventHandler(wcDestinationTypeSearch_DestinationTypeDataGridClearEvent);
            wcDestinationTypeSearch.DestinationTypeDataGridSearchEvent += new SPEventHandler(wcDestinationTypeSearch_DestinationTypeDataGridSearchEvent);
            wcDestinationTypeSearch.DestinationTypeDataGridRowSelectedEvent += new SPEventHandler(wcDestinationTypeSearch_DestinationTypeDataGridRowSelectedEvent);
            wcDestinationTypeManager.DestinationTypeClearEvent += new SPEventHandler(wcDestinationTypeManager_DestinationTypeClearEvent);
            wcDestinationTypeManager.DestinationTypeAddEvent += new SPEventHandler(wcDestinationTypeManager_DestinationTypeAddEvent);
            wcDestinationTypeManager.DestinationTypeUpdateEvent += new SPEventHandler(wcDestinationTypeManager_DestinationTypeUpdateEvent);
            wcDestinationTypeManager.DestinationTypeDeleteEvent += new SPEventHandler(wcDestinationTypeManager_DestinationTypeDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcDestinationTypeSearch.DestinationTypeDataGridClear();
            }
        }

        public void wcDestinationTypeSearch_DestinationTypeDataGridClearEvent(object sender, SPEventArgs e)
        {
            _destinationTypes = new Collection<DestinationType>();
            wcDestinationTypeSearch.DestinationTypeDataGridClear();
        }

        public void wcDestinationTypeSearch_DestinationTypeDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcDestinationTypeSearch.DestinationTypeDataGridSearch();
        }

        public void wcDestinationTypeSearch_DestinationTypeDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _destinationType = SandPatchCL.DataServices.DataServiceDestinationTypes.DestinationTypeSqlGetById(e.Index);
            wcDestinationTypeManager.DestinationTypeShow(_destinationType);
        }

        public void wcDestinationTypeManager_DestinationTypeClearEvent(object sender, SPEventArgs e)
        {
            _destinationType = new DestinationType();
            wcDestinationTypeManager.DestinationTypeClear();
        }

        public void wcDestinationTypeManager_DestinationTypeAddEvent(object sender, SPEventArgs e)
        {
            wcDestinationTypeManager.DestinationTypeUpdate(ref _destinationType);
            DataServiceDestinationTypes.SqlSave(ref _destinationType);
            wcDestinationTypeManager.DestinationTypeShow(_destinationType);
        }

        public void wcDestinationTypeManager_DestinationTypeUpdateEvent(object sender, SPEventArgs e)
        {
            wcDestinationTypeManager.DestinationTypeUpdate(ref _destinationType);
            DataServiceDestinationTypes.SqlSave(ref _destinationType);
            wcDestinationTypeManager.DestinationTypeShow(_destinationType);
        }

        public void wcDestinationTypeManager_DestinationTypeDeleteEvent(object sender, SPEventArgs e)
        {
            wcDestinationTypeManager.DestinationTypeUpdate(ref _destinationType);
            DataServiceDestinationTypes.SqlDelete(ref _destinationType);
            _destinationType = new DestinationType();
            wcDestinationTypeManager.DestinationTypeClear();
            wcDestinationTypeSearch.DestinationTypeDataGridSearch();
        }

    }
}
