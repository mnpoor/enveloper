using SandPatchCL;
using SandPatchCL.DataServices;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SandPatchWeb
{
    public partial class webFormShipperStatus : System.Web.UI.Page
    {
        private ShipperStatus _shipperStatus;
        private Collection<ShipperStatus> _shipperStatuss;

        protected void Page_Load(object sender, EventArgs e)
        {
            _shipperStatus = new ShipperStatus();
            wcShipperStatusesSearch.ShipperStatusDataGridClearEvent += new SPEventHandler(wcShipperStatusesSearch_ShipperStatusDataGridClearEvent);
            wcShipperStatusesSearch.ShipperStatusDataGridSearchEvent += new SPEventHandler(wcShipperStatusesSearch_ShipperStatusDataGridSearchEvent);
            wcShipperStatusesSearch.ShipperStatusDataGridRowSelectedEvent += new SPEventHandler(wcShipperStatusesSearch_ShipperStatusDataGridRowSelectedEvent);
            wcShipperStatusEdit.ShipperStatusClearEvent += new SPEventHandler(wcShipperStatusEdit_ShipperStatusClearEvent);
            wcShipperStatusEdit.ShipperStatusAddEvent += new SPEventHandler(wcShipperStatusEdit_ShipperStatusAddEvent);
            wcShipperStatusEdit.ShipperStatusUpdateEvent += new SPEventHandler(wcShipperStatusEdit_ShipperStatusUpdateEvent);
            wcShipperStatusEdit.ShipperStatusDeleteEvent += new SPEventHandler(wcShipperStatusEdit_ShipperStatusDeleteEvent);
            if (!Page.IsPostBack)
            {
                wcShipperStatusesSearch.ShipperStatusDataGridClear();
            }
        }

        public void wcShipperStatusesSearch_ShipperStatusDataGridClearEvent(object sender, SPEventArgs e)
        {
            _shipperStatuss = new Collection<ShipperStatus>();
            wcShipperStatusesSearch.ShipperStatusDataGridClear();
        }

        public void wcShipperStatusesSearch_ShipperStatusDataGridSearchEvent(object sender, SPEventArgs e)
        {
            wcShipperStatusesSearch.ShipperStatusDataGridSearch();
        }

        public void wcShipperStatusesSearch_ShipperStatusDataGridRowSelectedEvent(object sender, SPEventArgs e)
        {
            _shipperStatus = SandPatchCL.DataServices.DataServiceShipperStatuses.ShipperStatusSqlGetById(e.Index);
            wcShipperStatusEdit.ShipperStatusShow(_shipperStatus);
        }

        public void wcShipperStatusEdit_ShipperStatusClearEvent(object sender, SPEventArgs e)
        {
            _shipperStatus = new ShipperStatus();
            wcShipperStatusEdit.ShipperStatusClear();
        }

        public void wcShipperStatusEdit_ShipperStatusAddEvent(object sender, SPEventArgs e)
        {
            wcShipperStatusEdit.ShipperStatusUpdate(ref _shipperStatus);
            DataServiceShipperStatuses.SqlSave(ref _shipperStatus);
            wcShipperStatusEdit.ShipperStatusShow(_shipperStatus);
        }

        public void wcShipperStatusEdit_ShipperStatusUpdateEvent(object sender, SPEventArgs e)
        {
            wcShipperStatusEdit.ShipperStatusUpdate(ref _shipperStatus);
            DataServiceShipperStatuses.SqlSave(ref _shipperStatus);
            wcShipperStatusEdit.ShipperStatusShow(_shipperStatus);
        }

        public void wcShipperStatusEdit_ShipperStatusDeleteEvent(object sender, SPEventArgs e)
        {
            wcShipperStatusEdit.ShipperStatusUpdate(ref _shipperStatus);
            DataServiceShipperStatuses.SqlDelete(ref _shipperStatus);
            _shipperStatus = new ShipperStatus();
            wcShipperStatusEdit.ShipperStatusClear();
            wcShipperStatusesSearch.ShipperStatusDataGridSearch();
        }

    }
}
