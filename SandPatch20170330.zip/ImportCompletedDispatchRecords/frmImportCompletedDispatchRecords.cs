﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportCompletedDispatchRecords
{
    public partial class frmImportCompletedDispatchRecords : Form
    {
        private Collection<ExcelCSVRow> _excelCSVRows = new Collection<ExcelCSVRow>();
        private DispatchExcelRow _dispatchExcelRow = new DispatchExcelRow();
        private Collection<DispatchExcelRow> _dispatchExcelRows = new Collection<DispatchExcelRow>();
        private RawImport _rawImport = new RawImport();
        private Collection<RawImport> _rawImports = new Collection<RawImport>();

        public frmImportCompletedDispatchRecords()
        {
            InitializeComponent();
        }

        private void menuFileConnection_Click(object sender, EventArgs e)
        {
            frmSQLServerConnectionBuilder sqlServerConnectionBuilderForm = new frmSQLServerConnectionBuilder();
            sqlServerConnectionBuilderForm.Show();
        }

        /*
        namespace AcreageImportFromExcelUI
        {
            public partial class frmAcreageImportFromExcel : Form
            {
                private Collection<ExcelCSVRow> _excelCSVRows = new Collection<ExcelCSVRow>();
                private AcreageExcelRow _acreageExcelRow = new AcreageExcelRow();
                private Collection<AcreageExcelRow> _acreageExcelRows = new Collection<AcreageExcelRow>();
                private Acreage _acreage = new Acreage();

                private void ucSpreadsheetReportImageImportToolController_ExcelGenericImportEvent(object sender, SPEventArgs e)
                {
                    ucSpreadsheetReportImageImportToolController.AcreageImportDataGridViewClear();

                    Application.DoEvents();

                    ucSpreadsheetReportImageImportToolController.SpreadsheetReportImageImport(ref _acreageExcelRows);
            
                    Application.DoEvents();

                    ucSpreadsheetReportImageImportToolController.AcreageImportDataGridViewFill(ref _acreageExcelRows);
                }

                private void ucSpreadsheetReportImageImportToolController_ExcelGenericImportPauseEvent(object sender, SPEventArgs e)
                {
                    if (ucSpreadsheetReportImageImportToolController.Pause == true)
                    {
                        ucSpreadsheetReportImageImportToolController.Pause = false;
                    }
                    else
                    {
                        ucSpreadsheetReportImageImportToolController.Pause = true;
                    }
                }

                private void ucSpreadsheetReportImageImportToolController_ExcelGenericImportCancelImmediatelyEvent(object sender, SPEventArgs e)
                {
                    ucSpreadsheetReportImageImportToolController.CancelImmediately();
                }

                private void ucSpreadsheetReportImageImportToolController_ExcelAcquisitionSaveToTableEvent(object sender, SPEventArgs e)
                {
                    ucSpreadsheetReportImageImportToolController.lblAllRecordsSaved.Visible = false;
                    Application.DoEvents();

                    DialogResult response = MessageBox.Show("This adds the spreadsheet rows to the Acreage table.  Is this what you want to do?", Program.DialogBoxCaption, MessageBoxButtons.YesNo);
                    if (response == System.Windows.Forms.DialogResult.Yes)
                    {
                        foreach (AcreageExcelRow item in _acreageExcelRows)
                        {
                            _acreage = new Acreage();
                            _acreage.CountyId = 0;
                            if (item.StateAbbreviation != null)
                            {
                                if (item.CountyName != null)
                                {
                                    if (item.StateAbbreviation.Trim().Length > 0)
                                    {
                                        if (item.CountyName.Trim().Length > 0)
                                        {
                                            _acreage.CountyId = AcreageImportFromExcelCL.DataServices.DataServiceCounties.CountySqlGetCountyIdByStateNameAndCountyName(item.StateAbbreviation, item.CountyName);
                                        }
                                    }
                                }
                            }
                            _acreage.AcreageLocation = item.AcreageLocation;
                            _acreage.Section = item.Section;
                            _acreage.Township = item.Township;
                            _acreage.LandRange = item.LandRange;
                            _acreage.Abstract = item.Abstract;
                            _acreage.Survey = item.Survey;
                            if (item.AcreageLocation != null) // Acreage Location is assembled from either Section/Township/Range or Abstract/Survey
                            {
                                if (item.AcreageLocation.Trim().Length > 0)
                                {
                                    _acreage.AcreageLocation = item.AcreageLocation;
                                }
                                else
                                {
                                    GenerateAcreageLocation();
                                }                    
                            }
                            else
                            {
                                GenerateAcreageLocation();
                            }
                            _acreage.StateTaxMapNumber = item.StateTaxMapNumber;
                            _acreage.AcreageLandDescriptionDetail = item.AcreageLandDescriptionDetail;
                            _acreage.AcreageNotes = item.AcreageNotes;
                            AcreageImportFromExcelCL.DataServices.DataServiceAcreage.SqlSave(ref _acreage);
                        }

                        ucSpreadsheetReportImageImportToolController.lblAllRecordsSaved.Visible = true;
                    }
                }

                private void GenerateAcreageLocation()
                {
                    _acreage.AcreageLocation = string.Empty;
                    if (_acreage.Section != null)
                    {
                        if (_acreage.Section.Trim().Length > 0)
                        {
                            _acreage.AcreageLocation += _acreage.Section;
                            PlusTownship();
                            PlusLandRange();
                            return;
                        }
                    }
                    if (_acreage.Abstract != null)
                    {
                        if (_acreage.Abstract.Trim().Length > 0)
                        {
                            _acreage.AcreageLocation += _acreage.Abstract;
                            PlusSurvey();
                        }
                    }
                }

                private void PlusTownship()
                {
                    if (_acreage.Township != null)
                    {
                        if (_acreage.Township.Trim().Length > 0)
                        {
                            _acreage.AcreageLocation += " " + _acreage.Township;
                        }
                    }
                }

                private void PlusLandRange()
                {
                    if (_acreage.LandRange != null)
                    {
                        if (_acreage.LandRange.Trim().Length > 0)
                        {
                            _acreage.AcreageLocation += " " + _acreage.LandRange;
                        }
                    }
                }

                private void PlusSurvey()
                {
                    if (_acreage.Survey != null)
                    {
                        if (_acreage.Survey.Trim().Length > 0)
                        {
                            _acreage.AcreageLocation += " " + _acreage.Survey;
                        }
                    }
                }
         */

        private void ucSpreadsheetReportImageImportToolController_ExcelGenericImportEvent(object sender, SPEventArgs e)
        {
            ucSpreadsheetReportImageImportToolController.DispatchesImportDataGridViewClear();

            Application.DoEvents();

            ucSpreadsheetReportImageImportToolController.SpreadsheetReportImageImport(ref _rawImports);

            Application.DoEvents();

            ucSpreadsheetReportImageImportToolController.DispatchesImportDataGridViewFill(ref _rawImports);
        }

        private void ucSpreadsheetReportImageImportToolController_ExcelGenericImportPauseEvent(object sender, SPEventArgs e)
        {
            if (ucSpreadsheetReportImageImportToolController.Pause == true)
            {
                ucSpreadsheetReportImageImportToolController.Pause = false;
            }
            else
            {
                ucSpreadsheetReportImageImportToolController.Pause = true;
            }
        }

        private void ucSpreadsheetReportImageImportToolController_ExcelGenericImportCancelImmediatelyEvent(object sender, SPEventArgs e)
        {
            ucSpreadsheetReportImageImportToolController.CancelImmediately();
        }

        private void ucSpreadsheetReportImageImportToolController_ExcelAcquisitionSaveToTableEvent(object sender, SPEventArgs e)
        {
            ucSpreadsheetReportImageImportToolController.lblAllRecordsSaved.Visible = false;
            Application.DoEvents();

            DialogResult response = MessageBox.Show("This adds the spreadsheet rows to the Dispatches table.  Is this what you want to do?", Program.DialogBoxCaption, MessageBoxButtons.YesNo);
            if (response == System.Windows.Forms.DialogResult.Yes)
            {
                foreach (RawImport item in _rawImports)
                {
                    _rawImport = new RawImport(item);
                    SandPatchCL.DataServices.DataServiceRawImports.SqlSave(ref _rawImport);
                }

                ucSpreadsheetReportImageImportToolController.lblAllRecordsSaved.Visible = true;
            }
        }

        //private void GenerateDispatchLocation()
        //{
        //    _acreage.AcreageLocation = string.Empty;
        //    if (_acreage.Section != null)
        //    {
        //        if (_acreage.Section.Trim().Length > 0)
        //        {
        //            _acreage.AcreageLocation += _acreage.Section;
        //            PlusTownship();
        //            PlusLandRange();
        //            return;
        //        }
        //    }
        //    if (_acreage.Abstract != null)
        //    {
        //        if (_acreage.Abstract.Trim().Length > 0)
        //        {
        //            _acreage.AcreageLocation += _acreage.Abstract;
        //            PlusSurvey();
        //        }
        //    }
        //}

        //private void PlusTownship()
        //{
        //    if (_acreage.Township != null)
        //    {
        //        if (_acreage.Township.Trim().Length > 0)
        //        {
        //            _acreage.AcreageLocation += " " + _acreage.Township;
        //        }
        //    }
        //}

        //private void PlusLandRange()
        //{
        //    if (_acreage.LandRange != null)
        //    {
        //        if (_acreage.LandRange.Trim().Length > 0)
        //        {
        //            _acreage.AcreageLocation += " " + _acreage.LandRange;
        //        }
        //    }
        //}

        //private void PlusSurvey()
        //{
        //    if (_acreage.Survey != null)
        //    {
        //        if (_acreage.Survey.Trim().Length > 0)
        //        {
        //            _acreage.AcreageLocation += " " + _acreage.Survey;
        //        }
        //    }
        //}

        private void menuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
