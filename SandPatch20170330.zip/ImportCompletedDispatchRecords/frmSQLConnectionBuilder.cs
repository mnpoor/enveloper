﻿using SandPatchCL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ImportCompletedDispatchRecords
{
    public partial class frmSQLServerConnectionBuilder : Form
    {
        public frmSQLServerConnectionBuilder()
        {
            InitializeComponent();
        }

        private void frmSQLConnectionBuilder_Load(object sender, EventArgs e)        
        {
            txtDatabaseServerName.Text = Properties.Settings.Default.SandPatchServerName;
            txtDatabaseInitialCatalog.Text = Properties.Settings.Default.SandPatchCatalogName;
            chkUseDatabaseIntegratedSecurity.Checked = Properties.Settings.Default.SandPatchIntegratedSecurityFlag;
            if (chkUseDatabaseIntegratedSecurity.Checked == false)
            {
                txtDatabaseUserName.Text = Properties.Settings.Default.SandPatchUserName;
                txtDatabasePassword.Text = Properties.Settings.Default.SandPatchPassword;
            }
            else
            {
                txtDatabaseUserName.Text = string.Empty;
                txtDatabasePassword.Text = string.Empty;
            }
            txtDatabaseCommandTimeout.Text = Properties.Settings.Default.SandPatchCommandTimeout.ToString();
        }

        private void chkUseIntegratedSecurity_CheckedChanged(object sender, EventArgs e)
        {
            if (chkUseDatabaseIntegratedSecurity.Checked == true)
            {
                lblDatabaseUserName.Enabled = false;
                txtDatabaseUserName.Enabled = false;
                lblDatabasePassword.Enabled = false;
                txtDatabasePassword.Enabled = false;
            }
            else
            {
                lblDatabaseUserName.Enabled = true;
                txtDatabaseUserName.Enabled = true;
                lblDatabasePassword.Enabled = true;
                txtDatabasePassword.Enabled = true;
            }
        }

        private void cmdConfigurePublisherDatabaseConnectionString_Click(object sender, EventArgs e)
        {
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
            builder["Data Source"] = txtDatabaseServerName.Text;
            builder["Initial Catalog"] = txtDatabaseInitialCatalog.Text;
            if (chkUseDatabaseIntegratedSecurity.Checked == true)
            {
                builder["integrated Security"] = true;
            }
            else
            {
                builder["User Id"] = txtDatabaseUserName.Text;
                builder["password"] = txtDatabasePassword.Text;
            }
            this.txtDatabaseConnectionString.Text = builder.ConnectionString;
        }

        private void cmdSaveSandPatchDatabaseSettings_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.SandPatchServerName = txtDatabaseServerName.Text;
            Properties.Settings.Default.SandPatchCatalogName = txtDatabaseInitialCatalog.Text;
            Properties.Settings.Default.SandPatchIntegratedSecurityFlag = chkUseDatabaseIntegratedSecurity.Checked;
            if (chkUseDatabaseIntegratedSecurity.Checked == false)
            {
                Properties.Settings.Default.SandPatchUserName = txtDatabaseUserName.Text;
                Properties.Settings.Default.SandPatchPassword = txtDatabasePassword.Text;
            }
            else
            {
                Properties.Settings.Default.SandPatchUserName = string.Empty;
                Properties.Settings.Default.SandPatchPassword = string.Empty;
            }
            try
            {
                Properties.Settings.Default.SandPatchCommandTimeout = Convert.ToInt32(txtDatabaseCommandTimeout.Text);
            }
            catch
            {
                Properties.Settings.Default.SandPatchCommandTimeout = 30;
            }
            Properties.Settings.Default.Save();
            if (txtDatabaseConnectionString.Text.Trim().Length > 0)
            {
                SandPatchCL.DataServices.DataServiceBase.SetSQLServerConnectionString(txtDatabaseConnectionString.Text);
            }
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
