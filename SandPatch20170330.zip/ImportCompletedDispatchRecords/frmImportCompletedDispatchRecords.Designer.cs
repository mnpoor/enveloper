﻿namespace ImportCompletedDispatchRecords
{
    partial class frmImportCompletedDispatchRecords
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTitle = new System.Windows.Forms.Label();
            this.ucSpreadsheetReportImageImportToolController = new ImportCompletedDispatchRecords.WinControls.ucImportCompletedDispatchRecords();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFile});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1160, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuImportCompletedDispatchRecords";
            // 
            // menuFile
            // 
            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFileConnection,
            this.menuFileSeparator1,
            this.menuFileExit});
            this.menuFile.Name = "menuFile";
            this.menuFile.Size = new System.Drawing.Size(37, 20);
            this.menuFile.Text = "File";
            // 
            // menuFileConnection
            // 
            this.menuFileConnection.Name = "menuFileConnection";
            this.menuFileConnection.Size = new System.Drawing.Size(145, 22);
            this.menuFileConnection.Text = "Connection...";
            this.menuFileConnection.Click += new System.EventHandler(this.menuFileConnection_Click);
            // 
            // menuFileSeparator1
            // 
            this.menuFileSeparator1.Name = "menuFileSeparator1";
            this.menuFileSeparator1.Size = new System.Drawing.Size(142, 6);
            // 
            // menuFileExit
            // 
            this.menuFileExit.Name = "menuFileExit";
            this.menuFileExit.Size = new System.Drawing.Size(145, 22);
            this.menuFileExit.Text = "Exit";
            this.menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(347, 45);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(467, 37);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "Job Record Import from Excel";
            // 
            // ucSpreadsheetReportImageImportToolController
            // 
            this.ucSpreadsheetReportImageImportToolController.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucSpreadsheetReportImageImportToolController.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucSpreadsheetReportImageImportToolController.Location = new System.Drawing.Point(13, 93);
            this.ucSpreadsheetReportImageImportToolController.Margin = new System.Windows.Forms.Padding(4);
            this.ucSpreadsheetReportImageImportToolController.Name = "ucSpreadsheetReportImageImportToolController";
            this.ucSpreadsheetReportImageImportToolController.Pause = false;
            this.ucSpreadsheetReportImageImportToolController.Size = new System.Drawing.Size(1135, 767);
            this.ucSpreadsheetReportImageImportToolController.TabIndex = 4;
            this.ucSpreadsheetReportImageImportToolController.DispatchesSpreadsheetImportEvent += new SandPatchCL.SPEventHandler(this.ucSpreadsheetReportImageImportToolController_ExcelGenericImportEvent);
            this.ucSpreadsheetReportImageImportToolController.ExcelGenericImportPauseEvent += new SandPatchCL.SPEventHandler(this.ucSpreadsheetReportImageImportToolController_ExcelGenericImportPauseEvent);
            this.ucSpreadsheetReportImageImportToolController.ExcelGenericImportCancelImmediatelyEvent += new SandPatchCL.SPEventHandler(this.ucSpreadsheetReportImageImportToolController_ExcelGenericImportCancelImmediatelyEvent);
            this.ucSpreadsheetReportImageImportToolController.ExcelDispatchesSaveToTableEvent += new SandPatchCL.SPEventHandler(this.ucSpreadsheetReportImageImportToolController_ExcelAcquisitionSaveToTableEvent);
            // 
            // frmImportCompletedDispatchRecords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 878);
            this.Controls.Add(this.ucSpreadsheetReportImageImportToolController);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmImportCompletedDispatchRecords";
            this.Text = "Import Completed Dispatch Records";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuFile;
        private System.Windows.Forms.ToolStripMenuItem menuFileConnection;
        private System.Windows.Forms.ToolStripSeparator menuFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem menuFileExit;
        private System.Windows.Forms.Label lblTitle;
        private WinControls.ucImportCompletedDispatchRecords ucSpreadsheetReportImageImportToolController;
    }
}

