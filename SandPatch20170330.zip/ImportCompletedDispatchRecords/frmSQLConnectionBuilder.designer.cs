﻿namespace ImportCompletedDispatchRecords
{
    partial class frmSQLServerConnectionBuilder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlSQLServerConnection = new System.Windows.Forms.TabControl();
            this.tabDatabaseConnectionString = new System.Windows.Forms.TabPage();
            this.lblDatabaseCommandTimeout = new System.Windows.Forms.Label();
            this.txtDatabaseCommandTimeout = new System.Windows.Forms.TextBox();
            this.cmdSaveDatabaseSettings = new System.Windows.Forms.Button();
            this.cmdConfigureDatabaseConnectionString = new System.Windows.Forms.Button();
            this.lblDatabaseConnectionString = new System.Windows.Forms.Label();
            this.txtDatabaseConnectionString = new System.Windows.Forms.TextBox();
            this.chkUseDatabaseIntegratedSecurity = new System.Windows.Forms.CheckBox();
            this.lblDatabasePassword = new System.Windows.Forms.Label();
            this.txtDatabasePassword = new System.Windows.Forms.TextBox();
            this.lblDatabaseUserName = new System.Windows.Forms.Label();
            this.txtDatabaseUserName = new System.Windows.Forms.TextBox();
            this.lblDatabaseInitialCatalog = new System.Windows.Forms.Label();
            this.txtDatabaseInitialCatalog = new System.Windows.Forms.TextBox();
            this.lblDatabaseServerName = new System.Windows.Forms.Label();
            this.txtDatabaseServerName = new System.Windows.Forms.TextBox();
            this.cmdExit = new System.Windows.Forms.Button();
            this.tabControlSQLServerConnection.SuspendLayout();
            this.tabDatabaseConnectionString.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlSQLServerConnection
            // 
            this.tabControlSQLServerConnection.Controls.Add(this.tabDatabaseConnectionString);
            this.tabControlSQLServerConnection.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlSQLServerConnection.Location = new System.Drawing.Point(12, 12);
            this.tabControlSQLServerConnection.Name = "tabControlSQLServerConnection";
            this.tabControlSQLServerConnection.SelectedIndex = 0;
            this.tabControlSQLServerConnection.Size = new System.Drawing.Size(799, 282);
            this.tabControlSQLServerConnection.TabIndex = 0;
            // 
            // tabDatabaseConnectionString
            // 
            this.tabDatabaseConnectionString.Controls.Add(this.lblDatabaseCommandTimeout);
            this.tabDatabaseConnectionString.Controls.Add(this.txtDatabaseCommandTimeout);
            this.tabDatabaseConnectionString.Controls.Add(this.cmdSaveDatabaseSettings);
            this.tabDatabaseConnectionString.Controls.Add(this.cmdConfigureDatabaseConnectionString);
            this.tabDatabaseConnectionString.Controls.Add(this.lblDatabaseConnectionString);
            this.tabDatabaseConnectionString.Controls.Add(this.txtDatabaseConnectionString);
            this.tabDatabaseConnectionString.Controls.Add(this.chkUseDatabaseIntegratedSecurity);
            this.tabDatabaseConnectionString.Controls.Add(this.lblDatabasePassword);
            this.tabDatabaseConnectionString.Controls.Add(this.txtDatabasePassword);
            this.tabDatabaseConnectionString.Controls.Add(this.lblDatabaseUserName);
            this.tabDatabaseConnectionString.Controls.Add(this.txtDatabaseUserName);
            this.tabDatabaseConnectionString.Controls.Add(this.lblDatabaseInitialCatalog);
            this.tabDatabaseConnectionString.Controls.Add(this.txtDatabaseInitialCatalog);
            this.tabDatabaseConnectionString.Controls.Add(this.lblDatabaseServerName);
            this.tabDatabaseConnectionString.Controls.Add(this.txtDatabaseServerName);
            this.tabDatabaseConnectionString.Location = new System.Drawing.Point(4, 25);
            this.tabDatabaseConnectionString.Name = "tabDatabaseConnectionString";
            this.tabDatabaseConnectionString.Padding = new System.Windows.Forms.Padding(3);
            this.tabDatabaseConnectionString.Size = new System.Drawing.Size(791, 253);
            this.tabDatabaseConnectionString.TabIndex = 0;
            this.tabDatabaseConnectionString.Text = "Database Connection String";
            this.tabDatabaseConnectionString.UseVisualStyleBackColor = true;
            // 
            // lblDatabaseCommandTimeout
            // 
            this.lblDatabaseCommandTimeout.AutoSize = true;
            this.lblDatabaseCommandTimeout.BackColor = System.Drawing.Color.Transparent;
            this.lblDatabaseCommandTimeout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabaseCommandTimeout.Location = new System.Drawing.Point(506, 101);
            this.lblDatabaseCommandTimeout.Name = "lblDatabaseCommandTimeout";
            this.lblDatabaseCommandTimeout.Size = new System.Drawing.Size(141, 16);
            this.lblDatabaseCommandTimeout.TabIndex = 9;
            this.lblDatabaseCommandTimeout.Text = "Command Timeout:";
            // 
            // txtDatabaseCommandTimeout
            // 
            this.txtDatabaseCommandTimeout.Location = new System.Drawing.Point(668, 101);
            this.txtDatabaseCommandTimeout.Name = "txtDatabaseCommandTimeout";
            this.txtDatabaseCommandTimeout.Size = new System.Drawing.Size(93, 22);
            this.txtDatabaseCommandTimeout.TabIndex = 10;
            // 
            // cmdSaveDatabaseSettings
            // 
            this.cmdSaveDatabaseSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSaveDatabaseSettings.Location = new System.Drawing.Point(605, 198);
            this.cmdSaveDatabaseSettings.Name = "cmdSaveDatabaseSettings";
            this.cmdSaveDatabaseSettings.Size = new System.Drawing.Size(156, 36);
            this.cmdSaveDatabaseSettings.TabIndex = 14;
            this.cmdSaveDatabaseSettings.Text = "Save Settings";
            this.cmdSaveDatabaseSettings.UseVisualStyleBackColor = true;
            this.cmdSaveDatabaseSettings.Click += new System.EventHandler(this.cmdSaveSandPatchDatabaseSettings_Click);
            // 
            // cmdConfigureDatabaseConnectionString
            // 
            this.cmdConfigureDatabaseConnectionString.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdConfigureDatabaseConnectionString.Location = new System.Drawing.Point(159, 198);
            this.cmdConfigureDatabaseConnectionString.Name = "cmdConfigureDatabaseConnectionString";
            this.cmdConfigureDatabaseConnectionString.Size = new System.Drawing.Size(354, 36);
            this.cmdConfigureDatabaseConnectionString.TabIndex = 13;
            this.cmdConfigureDatabaseConnectionString.Text = "Configure Database Connection String";
            this.cmdConfigureDatabaseConnectionString.UseVisualStyleBackColor = true;
            this.cmdConfigureDatabaseConnectionString.Click += new System.EventHandler(this.cmdConfigurePublisherDatabaseConnectionString_Click);
            // 
            // lblDatabaseConnectionString
            // 
            this.lblDatabaseConnectionString.AutoSize = true;
            this.lblDatabaseConnectionString.BackColor = System.Drawing.Color.Transparent;
            this.lblDatabaseConnectionString.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabaseConnectionString.Location = new System.Drawing.Point(21, 164);
            this.lblDatabaseConnectionString.Name = "lblDatabaseConnectionString";
            this.lblDatabaseConnectionString.Size = new System.Drawing.Size(133, 16);
            this.lblDatabaseConnectionString.TabIndex = 11;
            this.lblDatabaseConnectionString.Text = "Connection String:";
            // 
            // txtDatabaseConnectionString
            // 
            this.txtDatabaseConnectionString.Location = new System.Drawing.Point(158, 163);
            this.txtDatabaseConnectionString.Name = "txtDatabaseConnectionString";
            this.txtDatabaseConnectionString.Size = new System.Drawing.Size(603, 22);
            this.txtDatabaseConnectionString.TabIndex = 12;
            // 
            // chkUseDatabaseIntegratedSecurity
            // 
            this.chkUseDatabaseIntegratedSecurity.AutoSize = true;
            this.chkUseDatabaseIntegratedSecurity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUseDatabaseIntegratedSecurity.Location = new System.Drawing.Point(159, 75);
            this.chkUseDatabaseIntegratedSecurity.Name = "chkUseDatabaseIntegratedSecurity";
            this.chkUseDatabaseIntegratedSecurity.Size = new System.Drawing.Size(197, 20);
            this.chkUseDatabaseIntegratedSecurity.TabIndex = 4;
            this.chkUseDatabaseIntegratedSecurity.Text = "Use Integrated Security?";
            this.chkUseDatabaseIntegratedSecurity.UseVisualStyleBackColor = true;
            this.chkUseDatabaseIntegratedSecurity.CheckedChanged += new System.EventHandler(this.chkUseIntegratedSecurity_CheckedChanged);
            // 
            // lblDatabasePassword
            // 
            this.lblDatabasePassword.AutoSize = true;
            this.lblDatabasePassword.BackColor = System.Drawing.Color.Transparent;
            this.lblDatabasePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabasePassword.Location = new System.Drawing.Point(21, 128);
            this.lblDatabasePassword.Name = "lblDatabasePassword";
            this.lblDatabasePassword.Size = new System.Drawing.Size(80, 16);
            this.lblDatabasePassword.TabIndex = 7;
            this.lblDatabasePassword.Text = "Password:";
            // 
            // txtDatabasePassword
            // 
            this.txtDatabasePassword.Location = new System.Drawing.Point(158, 127);
            this.txtDatabasePassword.Name = "txtDatabasePassword";
            this.txtDatabasePassword.PasswordChar = '*';
            this.txtDatabasePassword.Size = new System.Drawing.Size(196, 22);
            this.txtDatabasePassword.TabIndex = 8;
            // 
            // lblDatabaseUserName
            // 
            this.lblDatabaseUserName.AutoSize = true;
            this.lblDatabaseUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblDatabaseUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabaseUserName.Location = new System.Drawing.Point(21, 102);
            this.lblDatabaseUserName.Name = "lblDatabaseUserName";
            this.lblDatabaseUserName.Size = new System.Drawing.Size(90, 16);
            this.lblDatabaseUserName.TabIndex = 5;
            this.lblDatabaseUserName.Text = "User Name:";
            // 
            // txtDatabaseUserName
            // 
            this.txtDatabaseUserName.Location = new System.Drawing.Point(158, 101);
            this.txtDatabaseUserName.Name = "txtDatabaseUserName";
            this.txtDatabaseUserName.Size = new System.Drawing.Size(196, 22);
            this.txtDatabaseUserName.TabIndex = 6;
            // 
            // lblDatabaseInitialCatalog
            // 
            this.lblDatabaseInitialCatalog.AutoSize = true;
            this.lblDatabaseInitialCatalog.BackColor = System.Drawing.Color.Transparent;
            this.lblDatabaseInitialCatalog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabaseInitialCatalog.Location = new System.Drawing.Point(22, 50);
            this.lblDatabaseInitialCatalog.Name = "lblDatabaseInitialCatalog";
            this.lblDatabaseInitialCatalog.Size = new System.Drawing.Size(107, 16);
            this.lblDatabaseInitialCatalog.TabIndex = 2;
            this.lblDatabaseInitialCatalog.Text = "Initial Catalog:";
            // 
            // txtDatabaseInitialCatalog
            // 
            this.txtDatabaseInitialCatalog.Location = new System.Drawing.Point(159, 49);
            this.txtDatabaseInitialCatalog.Name = "txtDatabaseInitialCatalog";
            this.txtDatabaseInitialCatalog.Size = new System.Drawing.Size(406, 22);
            this.txtDatabaseInitialCatalog.TabIndex = 3;
            // 
            // lblDatabaseServerName
            // 
            this.lblDatabaseServerName.AutoSize = true;
            this.lblDatabaseServerName.BackColor = System.Drawing.Color.Transparent;
            this.lblDatabaseServerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabaseServerName.Location = new System.Drawing.Point(22, 24);
            this.lblDatabaseServerName.Name = "lblDatabaseServerName";
            this.lblDatabaseServerName.Size = new System.Drawing.Size(103, 16);
            this.lblDatabaseServerName.TabIndex = 0;
            this.lblDatabaseServerName.Text = "Server Name:";
            // 
            // txtDatabaseServerName
            // 
            this.txtDatabaseServerName.Location = new System.Drawing.Point(159, 23);
            this.txtDatabaseServerName.Name = "txtDatabaseServerName";
            this.txtDatabaseServerName.Size = new System.Drawing.Size(406, 22);
            this.txtDatabaseServerName.TabIndex = 1;
            // 
            // cmdExit
            // 
            this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExit.Location = new System.Drawing.Point(719, 311);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(88, 36);
            this.cmdExit.TabIndex = 1;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = true;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // frmSQLServerConnectionBuilder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(831, 366);
            this.Controls.Add(this.cmdExit);
            this.Controls.Add(this.tabControlSQLServerConnection);
            this.Name = "frmSQLServerConnectionBuilder";
            this.Text = "Set SQL Server Connection";
            this.Load += new System.EventHandler(this.frmSQLConnectionBuilder_Load);
            this.tabControlSQLServerConnection.ResumeLayout(false);
            this.tabDatabaseConnectionString.ResumeLayout(false);
            this.tabDatabaseConnectionString.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlSQLServerConnection;
        private System.Windows.Forms.TabPage tabDatabaseConnectionString;
        private System.Windows.Forms.Button cmdSaveDatabaseSettings;
        private System.Windows.Forms.Button cmdConfigureDatabaseConnectionString;
        private System.Windows.Forms.Label lblDatabaseConnectionString;
        private System.Windows.Forms.TextBox txtDatabaseConnectionString;
        private System.Windows.Forms.CheckBox chkUseDatabaseIntegratedSecurity;
        private System.Windows.Forms.Label lblDatabasePassword;
        private System.Windows.Forms.TextBox txtDatabasePassword;
        private System.Windows.Forms.Label lblDatabaseUserName;
        private System.Windows.Forms.TextBox txtDatabaseUserName;
        private System.Windows.Forms.Label lblDatabaseInitialCatalog;
        private System.Windows.Forms.TextBox txtDatabaseInitialCatalog;
        private System.Windows.Forms.Label lblDatabaseServerName;
        private System.Windows.Forms.TextBox txtDatabaseServerName;
        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.Label lblDatabaseCommandTimeout;
        private System.Windows.Forms.TextBox txtDatabaseCommandTimeout;

    }
}

