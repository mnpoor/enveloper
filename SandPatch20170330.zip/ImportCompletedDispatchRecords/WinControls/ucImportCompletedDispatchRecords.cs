﻿using Microsoft.Office.Interop.Excel;
using SandPatchCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportCompletedDispatchRecords.WinControls
{
    public partial class ucImportCompletedDispatchRecords : UserControl
    {
        public event SPEventHandler DispatchesSpreadsheetImportEvent;
        public event SPEventHandler ExcelGenericImportPauseEvent;
        public event SPEventHandler ExcelGenericImportCancelImmediatelyEvent;
        public event SPEventHandler ExcelDispatchesSaveToTableEvent;

        private bool _pause = false;
        private bool _cancelImmediately = false;

        string xLSFileName = string.Empty;
        string cSVFileName = string.Empty;

        private Microsoft.Office.Interop.Excel.Application _excelApp = new Microsoft.Office.Interop.Excel.Application();
        private Microsoft.Office.Interop.Excel.Workbook _excelWorkbook = null;
        private Microsoft.Office.Interop.Excel.Sheets _workSheets = null;
        private Microsoft.Office.Interop.Excel.Worksheet _work = null;
        private Microsoft.Office.Interop.Excel.Range _range = null;
        private Microsoft.Office.Interop.Excel.Range _rangePeek = null;

        private SqlConnection _connection = new SqlConnection();
        private SqlCommand _sqlCommand = new SqlCommand();

        private Collection<ExcelRowArray> _excelRows = new Collection<ExcelRowArray>();
        private Collection<RawImport> _rawImpots = new Collection<RawImport>();

        public ucImportCompletedDispatchRecords()
        {
            InitializeComponent();
        }

        /*
namespace AcreageImportFromExcelUI.WinControls
{
    public partial class ucSpreadsheetReportImageImportTool : UserControl
    {
        public event DoEventHandler AcreageSpreadsheetImportEvent;
        public event DoEventHandler ExcelGenericImportPauseEvent;
        public event DoEventHandler ExcelGenericImportCancelImmediatelyEvent;
        public event DoEventHandler ExcelAcreageSaveToTableEvent;

        private bool _pause = false;
        private bool _cancelImmediately = false;

        string xLSFileName = string.Empty;
        string cSVFileName = string.Empty;

        private Microsoft.Office.Interop.Excel.Application _excelApp = new Microsoft.Office.Interop.Excel.Application();
        private Microsoft.Office.Interop.Excel.Workbook _excelWorkbook = null;
        private Microsoft.Office.Interop.Excel.Sheets _workSheets = null;
        private Microsoft.Office.Interop.Excel.Worksheet _work = null;
        private Microsoft.Office.Interop.Excel.Range _range = null;

        private SqlConnection _connection = new SqlConnection();
        private SqlCommand _sqlCommand = new SqlCommand();

        private Collection<ExcelRowArray> _excelRows = new Collection<ExcelRowArray>();

        public void SpreadsheetReportImageImport(ref Collection<AcreageExcelRow> acreageExcelRows)
        {
            lblImportComplete.Visible = false;
            lblCancelPending.Visible = false;

            cmdPause.Enabled = true;
            cmdCancelImmediately.Enabled = true;

            xLSFileName = Properties.Settings.Default.ReportImageSpreadsheetImportFileName;
            lblImportFileName.Text = "Importing: " + xLSFileName;
            XLSFile(xLSFileName, ref acreageExcelRows);

            cmdPause.Enabled = false;
            cmdCancelImmediately.Enabled = false;

            lblImportComplete.Visible = true;
        }

        private void cmdSelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog acreageFileDialog = new OpenFileDialog();
            acreageFileDialog.InitialDirectory = Properties.Settings.Default.ReportImageSpreadsheetImportDirectory;
            acreageFileDialog.DefaultExt = "xls;xlxs";
            DialogResult selectedPath = acreageFileDialog.ShowDialog();
            if (acreageFileDialog.FileName != null)
            {
                if (acreageFileDialog.FileName.Length > 0)
                {
                    Properties.Settings.Default.ReportImageSpreadsheetImportFileName = acreageFileDialog.FileName;
                    Properties.Settings.Default.Save();
                    lblImportFileName.Text = "Importing: " + acreageFileDialog.FileName;
                }
            }
        }

        private void cmdAcreageImport_Click(object sender, EventArgs e)
        {
            OnAcreageImport();
        }

        private void OnAcreageImport()
        {
            if (this.AcreageSpreadsheetImportEvent != null)
            {
                this.AcreageSpreadsheetImportEvent(this, new DoEventArgs(null, DoObjectAction.acreageImport));
            }
        }

        private void cmdPause_Click(object sender, EventArgs e)
        {
            OnPause();
        }

        private void OnPause()
        {
            if (this.ExcelGenericImportPauseEvent != null)
            {
                this.ExcelGenericImportPauseEvent(this, new DoEventArgs(null, DoObjectAction.pause));
            }
        }

        private void cmdCancelImmediately_Click(object sender, EventArgs e)
        {
            OnCancelImmediately();
        }

        private void OnCancelImmediately()
        {
            if (this.ExcelGenericImportCancelImmediatelyEvent != null)
            {
                this.ExcelGenericImportCancelImmediatelyEvent(this, new DoEventArgs(null, DoObjectAction.cancel));
            }
        }

        private void cmdSaveToAcreageTable_Click(object sender, EventArgs e)
        {
            OnAcreageSaveToTable();
        }

        private void OnAcreageSaveToTable()
        {
            if (this.ExcelAcreageSaveToTableEvent != null)
            {
                this.ExcelAcreageSaveToTableEvent(this, new DoEventArgs(null, DoObjectAction.saveToTable));
            }
        }

        public void AcreageImportDataGridViewFill(ref Collection<AcreageExcelRow> acreageExcelRows)
        {
            foreach (AcreageExcelRow item in acreageExcelRows)
            {
                string[] textArray = new string[] { item.AcreageImportId.ToString(), item.SpreadsheetFileName, item.StateAbbreviation, item.CountyName, item.AcreageLocation,
                    item.Section, item.Township, item.LandRange, item.Abstract, item.Survey, item.StateTaxMapNumber, item.AcreageLandDescriptionDetail, item.AcreageNotes };
                DataGridViewRow acreageGridRow = new DataGridViewRow();
                acreageGridRow.CreateCells(dgAcreageRows);
                acreageGridRow.SetValues(textArray);
                acreageGridRow.Tag = new AcreageExcelRow(item);
                dgAcreageRows.Rows.Add(acreageGridRow);
            }
        }

        private void XLSFile(string fileName, ref Collection<AcreageExcelRow> acreageExcelRows)
        {
            _excelWorkbook = _excelApp.Workbooks.Open(fileName, 0, true, 5, System.Reflection.Missing.Value, System.Reflection.Missing.Value, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value, false, false, System.Reflection.Missing.Value, false, false, false);

            _workSheets = _excelWorkbook.Sheets;

            _work = new Microsoft.Office.Interop.Excel.Worksheet();

            _work = (Microsoft.Office.Interop.Excel.Worksheet)_workSheets[1];

            System.Windows.Forms.Application.DoEvents();

            int rowsProcessed = MergeOneSpreadsheet(fileName, ref acreageExcelRows);

            _excelWorkbook.Close(false, string.Empty, false);

            _excelApp.Workbooks.Close();

            _excelApp.Quit();

        }

        private int MergeOneSpreadsheet(string fileName, ref Collection<AcreageExcelRow> acreageExcelRows)
        {
            int rowIndex = 0;
            int columnIndex = 0;

            int acreageCollectionIndex = 0;

            string cellValue = string.Empty;
            string[] thisLine = new string[1];
            string notesBlock = string.Empty;

            int rowCount = 0;

            _excelRows = new Collection<ExcelRowArray>();

            for (rowIndex = 2; rowIndex < 1000000; rowIndex++) // first row should contain column names and should be ignored.
            {
                ExcelRowArray currentRow = new ExcelRowArray();
                currentRow.RowElements = new string[11];
                currentRow.ArrayElementCount = 11;
                for (columnIndex = 0; columnIndex < 11; columnIndex++)
                {
                    _range = _work.Cells[rowIndex, columnIndex + 1];
                    if (_range.Value != null) currentRow.RowElements[columnIndex] = _range.Value.ToString();
                }
                currentRow.RowNumber = rowIndex;
                _excelRows.Add(currentRow);
                _range = _work.Cells[rowIndex, 1];  // if the state isn't found, this row is empty
                if (_range.Value == null) break;
            }

            for (rowIndex = 0; rowIndex < _excelRows.Count; rowIndex++)
            {
                ExcelRowArray currentRow = new ExcelRowArray(_excelRows[rowIndex]);  // get local copy to speed things up
                AssignAcreageExcelRowValues(ref currentRow, rowIndex, ref acreageExcelRows);
                acreageCollectionIndex = acreageExcelRows.Count - 1;
                if (rowIndex % 1000 == 0)
                {
                    System.Windows.Forms.Application.DoEvents();
                }
                if (_cancelImmediately == true) break;
            }

            return (rowCount);
        }

        private void AssignAcreageExcelRowValues(ref ExcelRowArray currentRow, int rowIndex, ref Collection<AcreageExcelRow> acreageExcelRows)
        {
            if (currentRow.RowElements[0] == null) return; // zero (State) should not be null
            if (currentRow.RowElements[0].Trim().Length < 1) return; // zero length is also invalid
            if (currentRow.RowElements[1] == null) return; // one (County) should not be null
            if (currentRow.RowElements[1].Trim().Length < 1) return; // zero length is also invalid
            acreageExcelRows.Add(new AcreageExcelRow(0, xLSFileName, currentRow.RowElements[0].Trim(), currentRow.RowElements[1].Trim(), // up to county name
                currentRow.RowElements[2] == null ? string.Empty : currentRow.RowElements[2].Trim(),
                currentRow.RowElements[3] == null ? string.Empty : currentRow.RowElements[3].Trim(),
                currentRow.RowElements[4] == null ? string.Empty : currentRow.RowElements[4].Trim(),
                currentRow.RowElements[5] == null ? string.Empty : currentRow.RowElements[5].Trim(),
                currentRow.RowElements[6] == null ? string.Empty : currentRow.RowElements[6].Trim(),
                currentRow.RowElements[7] == null ? string.Empty : currentRow.RowElements[7].Trim(),
                currentRow.RowElements[8] == null ? string.Empty : currentRow.RowElements[8].Trim(),
                currentRow.RowElements[9] == null ? string.Empty : currentRow.RowElements[9].Trim(),
                currentRow.RowElements[10] == null ? string.Empty : currentRow.RowElements[10].Trim()));
        }
         */
        public void DispatchesImportDataGridViewClear()
        {
            dgDispatchesRows.Rows.Clear();
        }

        public bool Pause
        {
            get
            {
                return this._pause;
            }
            set
            {
                this._pause = value;
                if (_pause == true)
                {
                    cmdPause.Text = "Resume";
                }
                else
                {
                    cmdPause.Text = "Pause";
                }
            }
        }

        public void CancelImmediately()
        {
            _cancelImmediately = true;
            lblCancelPending.Visible = true;
        }

        public void SpreadsheetReportImageImport(ref Collection<RawImport> rawImports)
        {
            lblImportComplete.Visible = false;
            lblCancelPending.Visible = false;

            cmdPause.Enabled = true;
            cmdCancelImmediately.Enabled = true;

            xLSFileName = Properties.Settings.Default.ReportImageSpreadsheetImportFileName;
            lblImportFileName.Text = "Importing: " + xLSFileName;
            XLSFile(xLSFileName, ref rawImports);

            cmdPause.Enabled = false;
            cmdCancelImmediately.Enabled = false;

            lblImportComplete.Visible = true;
        }

        private void cmdSelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dispatchFileDialog = new OpenFileDialog();
            dispatchFileDialog.InitialDirectory = Properties.Settings.Default.ReportImageSpreadsheetImportDirectory;
            dispatchFileDialog.DefaultExt = "xls;xlsx";
            DialogResult selectedPath = dispatchFileDialog.ShowDialog();
            if (dispatchFileDialog.FileName != null)
            {
                if (dispatchFileDialog.FileName.Length > 0)
                {
                    Properties.Settings.Default.ReportImageSpreadsheetImportFileName = dispatchFileDialog.FileName;
                    Properties.Settings.Default.Save();
                    lblImportFileName.Text = "Importing: " + dispatchFileDialog.FileName;
                }
            }
        }

        private void cmdDispatchesImport_Click(object sender, EventArgs e)
        {
            OnDispatchesImport();
        }

        private void OnDispatchesImport()
        {
            if (this.DispatchesSpreadsheetImportEvent != null)
            {
                this.DispatchesSpreadsheetImportEvent(this, new SPEventArgs(null, SPObjectAction.dispatchImport));
            }
        }

        private void cmdPause_Click(object sender, EventArgs e)
        {
            OnPause();
        }

        private void OnPause()
        {
            if (this.ExcelGenericImportPauseEvent != null)
            {
                this.ExcelGenericImportPauseEvent(this, new SPEventArgs(null, SPObjectAction.pause));
            }
        }

        private void cmdCancelImmediately_Click(object sender, EventArgs e)
        {
            OnCancelImmediately();
        }

        private void OnCancelImmediately()
        {
            if (this.ExcelGenericImportCancelImmediatelyEvent != null)
            {
                this.ExcelGenericImportCancelImmediatelyEvent(this, new SPEventArgs(null, SPObjectAction.cancel));
            }
        }

        private void cmdSaveToDispatchesTable_Click(object sender, EventArgs e)
        {
            OnDispatchesSaveToTable();
        }

        private void OnDispatchesSaveToTable()
        {
            if (this.ExcelDispatchesSaveToTableEvent != null)
            {
                this.ExcelDispatchesSaveToTableEvent(this, new SPEventArgs(null, SPObjectAction.saveToTable));
            }
        }

        public void DispatchesImportDataGridViewFill(ref Collection<RawImport> rawImports)
        {
            foreach (RawImport item in rawImports)
            {
                string[] textArray = new string[] { item.RawImportId.ToString(), string.Empty, item.TruckNumber, item.DispatchAcceptanceNumber, item.DispatchAcceptanceDate,
                    item.SandType, item.PurchaseOrderNumber, item.LoadingTerminalAppointmentDateTime, item.ActualLoadingTerminalArrivalTime, item.ActualLoadingTerminalDepartureTime,
                    item.BillOfLading, item.ShipmentWeight, item.TicketNumber, item.JobSiteDeliveryAppointmentDateTime, item.JobSiteActualArrivalTime, item.JobSiteActualDepartureTime };
                DataGridViewRow dispatchGridRow = new DataGridViewRow();
                dispatchGridRow.CreateCells(dgDispatchesRows);
                dispatchGridRow.SetValues(textArray);
                dispatchGridRow.Tag = new RawImport(item);
                dgDispatchesRows.Rows.Add(dispatchGridRow);
            }
        }

        private void XLSFile(string fileName, ref Collection<RawImport> rawImports)
        {
            _excelWorkbook = _excelApp.Workbooks.Open(fileName, 0, true, 5, System.Reflection.Missing.Value, System.Reflection.Missing.Value, false, System.Reflection.Missing.Value, System.Reflection.Missing.Value, false, false, System.Reflection.Missing.Value, false, false, false);

            _workSheets = _excelWorkbook.Sheets;

            _work = new Microsoft.Office.Interop.Excel.Worksheet();

            _work = (Microsoft.Office.Interop.Excel.Worksheet)_workSheets[1];

            System.Windows.Forms.Application.DoEvents();

            int rowsProcessed = MergeOneSpreadsheet(fileName, ref rawImports);

            _excelWorkbook.Close(false, string.Empty, false);

            _excelApp.Workbooks.Close();

            _excelApp.Quit();

            Console.WriteLine(rawImports.Count.ToString());
        }

        private int MergeOneSpreadsheet(string fileName, ref Collection<RawImport> rawImports)
        {
            int rowIndex = 0;
            int columnIndex = 0;

            int acreageCollectionIndex = 0;

            string cellValue = string.Empty;
            string[] thisLine = new string[1];
            string notesBlock = string.Empty;

            int rowCount = 0;

            _excelRows = new Collection<ExcelRowArray>();

            for (rowIndex = 1; rowIndex < 1000000; rowIndex++)
            {
                ExcelRowArray currentRow = new ExcelRowArray();
                currentRow.RowElements = new string[16];
                currentRow.ArrayElementCount = 16;
                for (columnIndex = 0; columnIndex < 16; columnIndex++)
                {
                    _range = _work.Cells[rowIndex, columnIndex + 1];
                    if (_range.Value != null) currentRow.RowElements[columnIndex] = _range.Value.ToString();
                }
                currentRow.RowNumber = rowIndex;
                _excelRows.Add(currentRow);
                
                _range = _work.Cells[rowIndex, 2];  // if TMS number is null
                if (_range.Value == null)
                { 
                    if (rowIndex > 12)              //some initial cells will be empty
                    {
                        _rangePeek = _work.Cells[rowIndex + 1, 2];
                        {
                            if (_rangePeek.Value == null) break; // Current row might be separator, if next line is also null we've run out of rows.
                        }
                    }
                }
            }

            for (rowIndex = 0; rowIndex < _excelRows.Count; rowIndex++)
            {
                ExcelRowArray currentRow = new ExcelRowArray(_excelRows[rowIndex]);  // get local copy to speed things up
                AssignDispatchExcelRowValues(ref currentRow, rowIndex, ref rawImports);
                acreageCollectionIndex = rawImports.Count - 1;
                if (rowIndex % 1000 == 0)
                {
                    System.Windows.Forms.Application.DoEvents();
                }
                if (_cancelImmediately == true) break;
            }

            return (rowCount);
        }

        private void AssignDispatchExcelRowValues(ref ExcelRowArray currentRow, int rowIndex, ref Collection<RawImport> rawImports)
        {
            //if (currentRow.RowElements[0] == null) return; // zero (State) should not be null
            //if (currentRow.RowElements[0].Trim().Length < 1) return; // zero length is also invalid
            //if (currentRow.RowElements[1] == null) return; // one (County) should not be null
            //if (currentRow.RowElements[1].Trim().Length < 1) return; // zero length is also invalid
            rawImports.Add(new RawImport(0,
                currentRow.RowElements[0] == null ? string.Empty : currentRow.RowElements[0].Trim(),
                currentRow.RowElements[1] == null ? string.Empty : currentRow.RowElements[1].Trim(),
                currentRow.RowElements[2] == null ? string.Empty : currentRow.RowElements[2].Trim(),
                currentRow.RowElements[3] == null ? string.Empty : currentRow.RowElements[3].Trim(),
                currentRow.RowElements[4] == null ? string.Empty : currentRow.RowElements[4].Trim(),
                currentRow.RowElements[5] == null ? string.Empty : currentRow.RowElements[5].Trim(),
                currentRow.RowElements[6] == null ? string.Empty : currentRow.RowElements[6].Trim(),
                currentRow.RowElements[7] == null ? string.Empty : currentRow.RowElements[7].Trim(),
                currentRow.RowElements[8] == null ? string.Empty : currentRow.RowElements[8].Trim(),
                currentRow.RowElements[9] == null ? string.Empty : currentRow.RowElements[9].Trim(),
                currentRow.RowElements[10] == null ? string.Empty : currentRow.RowElements[10].Trim(),
                currentRow.RowElements[11] == null ? string.Empty : currentRow.RowElements[11].Trim(),
                currentRow.RowElements[12] == null ? string.Empty : currentRow.RowElements[12].Trim(),
                currentRow.RowElements[13] == null ? string.Empty : currentRow.RowElements[13].Trim()));
        }
    }
}
