﻿namespace ImportCompletedDispatchRecords.WinControls
{
    partial class ucImportCompletedDispatchRecords
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdDispatchesImport = new System.Windows.Forms.Button();
            this.lblAllRecordsSaved = new System.Windows.Forms.Label();
            this.cmdSaveToDispatchesTable = new System.Windows.Forms.Button();
            this.dgDispatchesRows = new System.Windows.Forms.DataGridView();
            this.dgcTimesheetId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcSpreadsheetFileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcTruckNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcTMSNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDispatchDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcSandType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcPurchaseOrderNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcLoadAppointment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcLoadArrivalTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcLoadDepartureTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcBillOfLading = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcWeight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcTicketNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcDeliveryAppointment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcSiteActualArrivalTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcSiteActualDepartureTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmdSelectFile = new System.Windows.Forms.Button();
            this.lblImportFileName = new System.Windows.Forms.Label();
            this.lblImportComplete = new System.Windows.Forms.Label();
            this.cmdCancelImmediately = new System.Windows.Forms.Button();
            this.cmdPause = new System.Windows.Forms.Button();
            this.lblCancelPending = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgDispatchesRows)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdDispatchesImport
            // 
            this.cmdDispatchesImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdDispatchesImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdDispatchesImport.Location = new System.Drawing.Point(209, 787);
            this.cmdDispatchesImport.Margin = new System.Windows.Forms.Padding(5);
            this.cmdDispatchesImport.Name = "cmdDispatchesImport";
            this.cmdDispatchesImport.Size = new System.Drawing.Size(95, 43);
            this.cmdDispatchesImport.TabIndex = 13;
            this.cmdDispatchesImport.Text = "Import";
            this.cmdDispatchesImport.UseVisualStyleBackColor = true;
            this.cmdDispatchesImport.Click += new System.EventHandler(this.cmdDispatchesImport_Click);
            // 
            // lblAllRecordsSaved
            // 
            this.lblAllRecordsSaved.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblAllRecordsSaved.AutoSize = true;
            this.lblAllRecordsSaved.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblAllRecordsSaved.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAllRecordsSaved.Location = new System.Drawing.Point(945, 826);
            this.lblAllRecordsSaved.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAllRecordsSaved.Name = "lblAllRecordsSaved";
            this.lblAllRecordsSaved.Padding = new System.Windows.Forms.Padding(5);
            this.lblAllRecordsSaved.Size = new System.Drawing.Size(133, 25);
            this.lblAllRecordsSaved.TabIndex = 19;
            this.lblAllRecordsSaved.Text = "All Records Saved";
            this.lblAllRecordsSaved.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAllRecordsSaved.Visible = false;
            // 
            // cmdSaveToDispatchesTable
            // 
            this.cmdSaveToDispatchesTable.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdSaveToDispatchesTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSaveToDispatchesTable.Location = new System.Drawing.Point(889, 787);
            this.cmdSaveToDispatchesTable.Margin = new System.Windows.Forms.Padding(5);
            this.cmdSaveToDispatchesTable.Name = "cmdSaveToDispatchesTable";
            this.cmdSaveToDispatchesTable.Size = new System.Drawing.Size(244, 43);
            this.cmdSaveToDispatchesTable.TabIndex = 16;
            this.cmdSaveToDispatchesTable.Text = "Save To Dispatches Table";
            this.cmdSaveToDispatchesTable.UseVisualStyleBackColor = true;
            this.cmdSaveToDispatchesTable.Click += new System.EventHandler(this.cmdSaveToDispatchesTable_Click);
            // 
            // dgDispatchesRows
            // 
            this.dgDispatchesRows.AllowUserToAddRows = false;
            this.dgDispatchesRows.AllowUserToDeleteRows = false;
            this.dgDispatchesRows.AllowUserToOrderColumns = true;
            this.dgDispatchesRows.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgDispatchesRows.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDispatchesRows.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgcTimesheetId,
            this.dgcSpreadsheetFileName,
            this.dgcTruckNumber,
            this.dgcTMSNumber,
            this.dgcDispatchDate,
            this.dgcSandType,
            this.dgcPurchaseOrderNumber,
            this.dgcLoadAppointment,
            this.dgcLoadArrivalTime,
            this.dgcLoadDepartureTime,
            this.dgcBillOfLading,
            this.dgcWeight,
            this.dgcTicketNumber,
            this.dgcDeliveryAppointment,
            this.dgcSiteActualArrivalTime,
            this.dgcSiteActualDepartureTime});
            this.dgDispatchesRows.Location = new System.Drawing.Point(5, 70);
            this.dgDispatchesRows.Margin = new System.Windows.Forms.Padding(5);
            this.dgDispatchesRows.Name = "dgDispatchesRows";
            this.dgDispatchesRows.ReadOnly = true;
            this.dgDispatchesRows.Size = new System.Drawing.Size(1131, 690);
            this.dgDispatchesRows.TabIndex = 11;
            // 
            // dgcTimesheetId
            // 
            this.dgcTimesheetId.HeaderText = "Id";
            this.dgcTimesheetId.Name = "dgcTimesheetId";
            this.dgcTimesheetId.ReadOnly = true;
            this.dgcTimesheetId.Width = 50;
            // 
            // dgcSpreadsheetFileName
            // 
            this.dgcSpreadsheetFileName.HeaderText = "Spreadsheet File Name";
            this.dgcSpreadsheetFileName.Name = "dgcSpreadsheetFileName";
            this.dgcSpreadsheetFileName.ReadOnly = true;
            this.dgcSpreadsheetFileName.Width = 250;
            // 
            // dgcTruckNumber
            // 
            this.dgcTruckNumber.HeaderText = "Truck Number";
            this.dgcTruckNumber.Name = "dgcTruckNumber";
            this.dgcTruckNumber.ReadOnly = true;
            this.dgcTruckNumber.Width = 50;
            // 
            // dgcTMSNumber
            // 
            this.dgcTMSNumber.HeaderText = "TMS Number";
            this.dgcTMSNumber.Name = "dgcTMSNumber";
            this.dgcTMSNumber.ReadOnly = true;
            // 
            // dgcDispatchDate
            // 
            this.dgcDispatchDate.HeaderText = "Dispatch Date";
            this.dgcDispatchDate.Name = "dgcDispatchDate";
            this.dgcDispatchDate.ReadOnly = true;
            this.dgcDispatchDate.Width = 150;
            // 
            // dgcSandType
            // 
            this.dgcSandType.HeaderText = "Sand Type";
            this.dgcSandType.Name = "dgcSandType";
            this.dgcSandType.ReadOnly = true;
            // 
            // dgcPurchaseOrderNumber
            // 
            this.dgcPurchaseOrderNumber.HeaderText = "Purchase Order Number";
            this.dgcPurchaseOrderNumber.Name = "dgcPurchaseOrderNumber";
            this.dgcPurchaseOrderNumber.ReadOnly = true;
            // 
            // dgcLoadAppointment
            // 
            this.dgcLoadAppointment.HeaderText = "Load Appointment";
            this.dgcLoadAppointment.Name = "dgcLoadAppointment";
            this.dgcLoadAppointment.ReadOnly = true;
            // 
            // dgcLoadArrivalTime
            // 
            this.dgcLoadArrivalTime.HeaderText = "Load Arrival Time";
            this.dgcLoadArrivalTime.Name = "dgcLoadArrivalTime";
            this.dgcLoadArrivalTime.ReadOnly = true;
            // 
            // dgcLoadDepartureTime
            // 
            this.dgcLoadDepartureTime.HeaderText = "Load Departure Time";
            this.dgcLoadDepartureTime.Name = "dgcLoadDepartureTime";
            this.dgcLoadDepartureTime.ReadOnly = true;
            // 
            // dgcBillOfLading
            // 
            this.dgcBillOfLading.HeaderText = "Bill of Lading";
            this.dgcBillOfLading.Name = "dgcBillOfLading";
            this.dgcBillOfLading.ReadOnly = true;
            this.dgcBillOfLading.Width = 80;
            // 
            // dgcWeight
            // 
            this.dgcWeight.HeaderText = "Weight";
            this.dgcWeight.Name = "dgcWeight";
            this.dgcWeight.ReadOnly = true;
            this.dgcWeight.Width = 300;
            // 
            // dgcTicketNumber
            // 
            this.dgcTicketNumber.HeaderText = "Ticket Number";
            this.dgcTicketNumber.Name = "dgcTicketNumber";
            this.dgcTicketNumber.ReadOnly = true;
            this.dgcTicketNumber.Width = 300;
            // 
            // dgcDeliveryAppointment
            // 
            this.dgcDeliveryAppointment.HeaderText = "Delivery Appointment";
            this.dgcDeliveryAppointment.Name = "dgcDeliveryAppointment";
            this.dgcDeliveryAppointment.ReadOnly = true;
            // 
            // dgcSiteActualArrivalTime
            // 
            this.dgcSiteActualArrivalTime.HeaderText = "Site Actual Arrival Time";
            this.dgcSiteActualArrivalTime.Name = "dgcSiteActualArrivalTime";
            this.dgcSiteActualArrivalTime.ReadOnly = true;
            // 
            // dgcSiteActualDepartureTime
            // 
            this.dgcSiteActualDepartureTime.HeaderText = "Site Actual Departure Time";
            this.dgcSiteActualDepartureTime.Name = "dgcSiteActualDepartureTime";
            this.dgcSiteActualDepartureTime.ReadOnly = true;
            // 
            // cmdSelectFile
            // 
            this.cmdSelectFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdSelectFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdSelectFile.Location = new System.Drawing.Point(5, 787);
            this.cmdSelectFile.Margin = new System.Windows.Forms.Padding(5);
            this.cmdSelectFile.Name = "cmdSelectFile";
            this.cmdSelectFile.Size = new System.Drawing.Size(117, 43);
            this.cmdSelectFile.TabIndex = 12;
            this.cmdSelectFile.Text = "Select File";
            this.cmdSelectFile.UseVisualStyleBackColor = true;
            this.cmdSelectFile.Click += new System.EventHandler(this.cmdSelectFile_Click);
            // 
            // lblImportFileName
            // 
            this.lblImportFileName.AutoSize = true;
            this.lblImportFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImportFileName.Location = new System.Drawing.Point(489, 24);
            this.lblImportFileName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblImportFileName.Name = "lblImportFileName";
            this.lblImportFileName.Size = new System.Drawing.Size(164, 18);
            this.lblImportFileName.TabIndex = 10;
            this.lblImportFileName.Text = "Importing: File Name";
            // 
            // lblImportComplete
            // 
            this.lblImportComplete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblImportComplete.AutoSize = true;
            this.lblImportComplete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblImportComplete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImportComplete.Location = new System.Drawing.Point(195, 826);
            this.lblImportComplete.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblImportComplete.Name = "lblImportComplete";
            this.lblImportComplete.Padding = new System.Windows.Forms.Padding(5);
            this.lblImportComplete.Size = new System.Drawing.Size(123, 25);
            this.lblImportComplete.TabIndex = 18;
            this.lblImportComplete.Text = "Import Complete";
            this.lblImportComplete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblImportComplete.Visible = false;
            // 
            // cmdCancelImmediately
            // 
            this.cmdCancelImmediately.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdCancelImmediately.Enabled = false;
            this.cmdCancelImmediately.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCancelImmediately.Location = new System.Drawing.Point(596, 787);
            this.cmdCancelImmediately.Margin = new System.Windows.Forms.Padding(5);
            this.cmdCancelImmediately.Name = "cmdCancelImmediately";
            this.cmdCancelImmediately.Size = new System.Drawing.Size(208, 43);
            this.cmdCancelImmediately.TabIndex = 15;
            this.cmdCancelImmediately.Text = "Cancel Immediately";
            this.cmdCancelImmediately.UseVisualStyleBackColor = true;
            this.cmdCancelImmediately.Click += new System.EventHandler(this.cmdCancelImmediately_Click);
            // 
            // cmdPause
            // 
            this.cmdPause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdPause.Enabled = false;
            this.cmdPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPause.Location = new System.Drawing.Point(405, 787);
            this.cmdPause.Margin = new System.Windows.Forms.Padding(5);
            this.cmdPause.Name = "cmdPause";
            this.cmdPause.Size = new System.Drawing.Size(100, 43);
            this.cmdPause.TabIndex = 14;
            this.cmdPause.Text = "Pause";
            this.cmdPause.UseVisualStyleBackColor = true;
            this.cmdPause.Click += new System.EventHandler(this.cmdPause_Click);
            // 
            // lblCancelPending
            // 
            this.lblCancelPending.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblCancelPending.AutoSize = true;
            this.lblCancelPending.BackColor = System.Drawing.Color.Yellow;
            this.lblCancelPending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCancelPending.Location = new System.Drawing.Point(637, 765);
            this.lblCancelPending.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCancelPending.Name = "lblCancelPending";
            this.lblCancelPending.Padding = new System.Windows.Forms.Padding(5);
            this.lblCancelPending.Size = new System.Drawing.Size(127, 26);
            this.lblCancelPending.TabIndex = 17;
            this.lblCancelPending.Text = "Cancel Pending";
            this.lblCancelPending.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCancelPending.Visible = false;
            // 
            // ucImportCompletedDispatchRecords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblImportComplete);
            this.Controls.Add(this.cmdDispatchesImport);
            this.Controls.Add(this.lblAllRecordsSaved);
            this.Controls.Add(this.cmdSaveToDispatchesTable);
            this.Controls.Add(this.dgDispatchesRows);
            this.Controls.Add(this.cmdSelectFile);
            this.Controls.Add(this.lblImportFileName);
            this.Controls.Add(this.cmdCancelImmediately);
            this.Controls.Add(this.cmdPause);
            this.Controls.Add(this.lblCancelPending);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucImportCompletedDispatchRecords";
            this.Size = new System.Drawing.Size(1142, 859);
            ((System.ComponentModel.ISupportInitialize)(this.dgDispatchesRows)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdDispatchesImport;
        public System.Windows.Forms.Label lblAllRecordsSaved;
        private System.Windows.Forms.Button cmdSaveToDispatchesTable;
        private System.Windows.Forms.DataGridView dgDispatchesRows;
        private System.Windows.Forms.Button cmdSelectFile;
        private System.Windows.Forms.Label lblImportFileName;
        private System.Windows.Forms.Label lblImportComplete;
        private System.Windows.Forms.Button cmdCancelImmediately;
        private System.Windows.Forms.Button cmdPause;
        private System.Windows.Forms.Label lblCancelPending;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTimesheetId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcSpreadsheetFileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTruckNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTMSNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDispatchDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcSandType;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcPurchaseOrderNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcLoadAppointment;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcLoadArrivalTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcLoadDepartureTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcBillOfLading;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcWeight;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcTicketNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcDeliveryAppointment;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcSiteActualArrivalTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgcSiteActualDepartureTime;
    }
}
