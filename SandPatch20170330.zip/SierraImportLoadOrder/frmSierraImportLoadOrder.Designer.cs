﻿namespace SierraImportLoadOrder
{
    partial class frmSierraImportLoadOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdImport = new System.Windows.Forms.Button();
            this.cmdExit = new System.Windows.Forms.Button();
            this.tabControlLoadOrderImport = new System.Windows.Forms.TabControl();
            this.tabPageLoadOrderWebsite = new System.Windows.Forms.TabPage();
            this.webBrowserLoadOrders = new System.Windows.Forms.WebBrowser();
            this.tabPageExtractedFields = new System.Windows.Forms.TabPage();
            this.txtLoadId = new System.Windows.Forms.TextBox();
            this.lblLoadId = new System.Windows.Forms.Label();
            this.txtTruckNumber = new System.Windows.Forms.TextBox();
            this.lblTruckNumber = new System.Windows.Forms.Label();
            this.tabPageText = new System.Windows.Forms.TabPage();
            this.txtWebPageSource = new System.Windows.Forms.TextBox();
            this.cmdInsertOrUpdateDatabaseRecords = new System.Windows.Forms.Button();
            this.tabControlLoadOrderImport.SuspendLayout();
            this.tabPageLoadOrderWebsite.SuspendLayout();
            this.tabPageExtractedFields.SuspendLayout();
            this.tabPageText.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdImport
            // 
            this.cmdImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdImport.Location = new System.Drawing.Point(29, 882);
            this.cmdImport.Name = "cmdImport";
            this.cmdImport.Size = new System.Drawing.Size(91, 39);
            this.cmdImport.TabIndex = 1;
            this.cmdImport.Text = "Import";
            this.cmdImport.UseVisualStyleBackColor = true;
            this.cmdImport.Click += new System.EventHandler(this.cmdImport_Click);
            // 
            // cmdExit
            // 
            this.cmdExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExit.Location = new System.Drawing.Point(1168, 882);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(91, 39);
            this.cmdExit.TabIndex = 2;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = true;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // tabControlLoadOrderImport
            // 
            this.tabControlLoadOrderImport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlLoadOrderImport.Controls.Add(this.tabPageLoadOrderWebsite);
            this.tabControlLoadOrderImport.Controls.Add(this.tabPageExtractedFields);
            this.tabControlLoadOrderImport.Controls.Add(this.tabPageText);
            this.tabControlLoadOrderImport.Location = new System.Drawing.Point(29, 23);
            this.tabControlLoadOrderImport.Name = "tabControlLoadOrderImport";
            this.tabControlLoadOrderImport.SelectedIndex = 0;
            this.tabControlLoadOrderImport.Size = new System.Drawing.Size(1230, 848);
            this.tabControlLoadOrderImport.TabIndex = 3;
            // 
            // tabPageLoadOrderWebsite
            // 
            this.tabPageLoadOrderWebsite.Controls.Add(this.webBrowserLoadOrders);
            this.tabPageLoadOrderWebsite.Location = new System.Drawing.Point(4, 25);
            this.tabPageLoadOrderWebsite.Name = "tabPageLoadOrderWebsite";
            this.tabPageLoadOrderWebsite.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLoadOrderWebsite.Size = new System.Drawing.Size(1222, 819);
            this.tabPageLoadOrderWebsite.TabIndex = 0;
            this.tabPageLoadOrderWebsite.Text = "Load Order Website";
            this.tabPageLoadOrderWebsite.UseVisualStyleBackColor = true;
            // 
            // webBrowserLoadOrders
            // 
            this.webBrowserLoadOrders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserLoadOrders.Location = new System.Drawing.Point(3, 3);
            this.webBrowserLoadOrders.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserLoadOrders.Name = "webBrowserLoadOrders";
            this.webBrowserLoadOrders.Size = new System.Drawing.Size(1216, 813);
            this.webBrowserLoadOrders.TabIndex = 1;
            // 
            // tabPageExtractedFields
            // 
            this.tabPageExtractedFields.Controls.Add(this.txtLoadId);
            this.tabPageExtractedFields.Controls.Add(this.lblLoadId);
            this.tabPageExtractedFields.Controls.Add(this.txtTruckNumber);
            this.tabPageExtractedFields.Controls.Add(this.lblTruckNumber);
            this.tabPageExtractedFields.Location = new System.Drawing.Point(4, 25);
            this.tabPageExtractedFields.Name = "tabPageExtractedFields";
            this.tabPageExtractedFields.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageExtractedFields.Size = new System.Drawing.Size(1222, 819);
            this.tabPageExtractedFields.TabIndex = 1;
            this.tabPageExtractedFields.Text = "Extracted Fields";
            this.tabPageExtractedFields.UseVisualStyleBackColor = true;
            // 
            // txtLoadId
            // 
            this.txtLoadId.Location = new System.Drawing.Point(166, 46);
            this.txtLoadId.Name = "txtLoadId";
            this.txtLoadId.Size = new System.Drawing.Size(119, 22);
            this.txtLoadId.TabIndex = 3;
            // 
            // lblLoadId
            // 
            this.lblLoadId.AutoSize = true;
            this.lblLoadId.Location = new System.Drawing.Point(33, 49);
            this.lblLoadId.Name = "lblLoadId";
            this.lblLoadId.Size = new System.Drawing.Size(53, 16);
            this.lblLoadId.TabIndex = 2;
            this.lblLoadId.Text = "Load Id";
            // 
            // txtTruckNumber
            // 
            this.txtTruckNumber.Location = new System.Drawing.Point(166, 90);
            this.txtTruckNumber.Name = "txtTruckNumber";
            this.txtTruckNumber.Size = new System.Drawing.Size(58, 22);
            this.txtTruckNumber.TabIndex = 1;
            // 
            // lblTruckNumber
            // 
            this.lblTruckNumber.AutoSize = true;
            this.lblTruckNumber.Location = new System.Drawing.Point(33, 93);
            this.lblTruckNumber.Name = "lblTruckNumber";
            this.lblTruckNumber.Size = new System.Drawing.Size(93, 16);
            this.lblTruckNumber.TabIndex = 0;
            this.lblTruckNumber.Text = "Truck Number";
            // 
            // tabPageText
            // 
            this.tabPageText.Controls.Add(this.txtWebPageSource);
            this.tabPageText.Location = new System.Drawing.Point(4, 25);
            this.tabPageText.Name = "tabPageText";
            this.tabPageText.Size = new System.Drawing.Size(1222, 819);
            this.tabPageText.TabIndex = 2;
            this.tabPageText.Text = "Text";
            this.tabPageText.UseVisualStyleBackColor = true;
            // 
            // txtWebPageSource
            // 
            this.txtWebPageSource.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWebPageSource.Location = new System.Drawing.Point(0, 0);
            this.txtWebPageSource.MaxLength = 2048000;
            this.txtWebPageSource.Multiline = true;
            this.txtWebPageSource.Name = "txtWebPageSource";
            this.txtWebPageSource.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtWebPageSource.Size = new System.Drawing.Size(1222, 819);
            this.txtWebPageSource.TabIndex = 0;
            // 
            // cmdInsertOrUpdateDatabaseRecords
            // 
            this.cmdInsertOrUpdateDatabaseRecords.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdInsertOrUpdateDatabaseRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdInsertOrUpdateDatabaseRecords.Location = new System.Drawing.Point(521, 882);
            this.cmdInsertOrUpdateDatabaseRecords.Name = "cmdInsertOrUpdateDatabaseRecords";
            this.cmdInsertOrUpdateDatabaseRecords.Size = new System.Drawing.Size(331, 39);
            this.cmdInsertOrUpdateDatabaseRecords.TabIndex = 4;
            this.cmdInsertOrUpdateDatabaseRecords.Text = "Insert or Update Database Records";
            this.cmdInsertOrUpdateDatabaseRecords.UseVisualStyleBackColor = true;
            // 
            // frmSierraImportLoadOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 933);
            this.Controls.Add(this.cmdInsertOrUpdateDatabaseRecords);
            this.Controls.Add(this.tabControlLoadOrderImport);
            this.Controls.Add(this.cmdExit);
            this.Controls.Add(this.cmdImport);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmSierraImportLoadOrder";
            this.Text = "Import Load Order";
            this.Load += new System.EventHandler(this.frmSierraImportLoadOrder_Load);
            this.tabControlLoadOrderImport.ResumeLayout(false);
            this.tabPageLoadOrderWebsite.ResumeLayout(false);
            this.tabPageExtractedFields.ResumeLayout(false);
            this.tabPageExtractedFields.PerformLayout();
            this.tabPageText.ResumeLayout(false);
            this.tabPageText.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdImport;
        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.TabControl tabControlLoadOrderImport;
        private System.Windows.Forms.TabPage tabPageLoadOrderWebsite;
        private System.Windows.Forms.WebBrowser webBrowserLoadOrders;
        private System.Windows.Forms.TabPage tabPageExtractedFields;
        private System.Windows.Forms.TextBox txtTruckNumber;
        private System.Windows.Forms.Label lblTruckNumber;
        private System.Windows.Forms.TabPage tabPageText;
        private System.Windows.Forms.TextBox txtWebPageSource;
        private System.Windows.Forms.Button cmdInsertOrUpdateDatabaseRecords;
        private System.Windows.Forms.TextBox txtLoadId;
        private System.Windows.Forms.Label lblLoadId;
    }
}

