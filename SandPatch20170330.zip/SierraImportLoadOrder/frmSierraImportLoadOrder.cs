﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SierraImportLoadOrder
{
    public partial class frmSierraImportLoadOrder : Form
    {
        private string _allText = string.Empty;
        private string _fieldExtraction = string.Empty;

        public frmSierraImportLoadOrder()
        {
            InitializeComponent();
        }

        private void frmSierraImportLoadOrder_Load(object sender, EventArgs e)
        {
            webBrowserLoadOrders.Navigate(@"D:\Documents\SierraCountry\ViewSourceHalliburton.html");
        }

        private void cmdImport_Click(object sender, EventArgs e)
        {
            txtWebPageSource.Text = webBrowserLoadOrders.DocumentText;
            _allText = txtWebPageSource.Text;
            //<td width="10%" class="loadreportsubhead" align="left" nowrap> Load ID&nbsp;<br /> Load Group&nbsp;<br /> Current Type&nbsp;<br /> Current Status&nbsp;<br />  </td>
            //<td width="20%" class="loadreportbody" align="left" nowrap> 49775722&nbsp;<br />  HALLIBURTON&nbsp;<br />  TENDER LOAD&nbsp;<br />  COMPLETED &nbsp;<br />  </td>
            //<td width="30%" class="loadreportbody" align="left">  HALLIBURTON<br />10200 BELLAIRE BLVD<br />HOUSTON, TX&nbsp;77072&nbsp;US<br /> <b>Contact</b> HALLIBURTON TMS<br /> <b>BOL</b> HAL49775722<br /><b>PO</b> 4701458643<br /><b>PRO #</b> 17198406<br /><b>Sales Order #</b> 902725704<br /> </td>
            _fieldExtraction = _allText.Substring(_allText.IndexOf("<td width=\"10%\" class=\"loadreportsubhead\""));
            _fieldExtraction = _fieldExtraction.Substring(0, _fieldExtraction.IndexOf("</td>"));

            _fieldExtraction = _allText.Substring(_allText.IndexOf("<b>Vehicle #</b>"), 65);            // isolates body of text that contains the string Vehicle #
            _fieldExtraction = _fieldExtraction.Substring(0, _fieldExtraction.IndexOf("<br />"));       // trims it further to eliminate text at and beyond the 'break' (<br />)
            txtTruckNumber.Text = _fieldExtraction.Substring(_fieldExtraction.IndexOf("&nbsp;") + 6);   // takes whatever follows the nonblank space expression;

            //<tr> <td class="loadreportbody" colspan="6"><div class="ck_div">ALL DRIVERS ARE REQUIRED TO CHECK IN UPON ARRIVAL AND DEPARTURE. FAILURE TO DO SO WILL PREVENT PAYMENT FOR ANY CLAIMED DETENTION</div></td> </tr>
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
