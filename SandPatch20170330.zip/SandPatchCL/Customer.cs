using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Customer : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _customerId;
        private string _customerName;
        private string _contactName;
        private string _streetAddress;
        private string _boxAddress;
        private string _city;
        private string _customerState;
        private string _postalCode;
        private int _customerStatusId;
        private string _phoneNumber;
        private string _faxNumber;
        private string _mobileNumber;
        private string _customerWebURL;
        private string _contactEmailAddress;
        private string _customerNotes;

        #endregion


        #region Constructor

        public Customer()
        {
            this._customerId = 0;
            this._customerName = string.Empty;
            this._contactName = string.Empty;
            this._streetAddress = string.Empty;
            this._boxAddress = string.Empty;
            this._city = string.Empty;
            this._customerState = string.Empty;
            this._postalCode = string.Empty;
            this._customerStatusId = 0;
            this._phoneNumber = string.Empty;
            this._faxNumber = string.Empty;
            this._mobileNumber = string.Empty;
            this._customerWebURL = string.Empty;
            this._contactEmailAddress = string.Empty;
            this._customerNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Customer(Customer c)
        {
            this._customerId = c.CustomerId;
            this._customerName = c.CustomerName;
            this._contactName = c.ContactName;
            this._streetAddress = c.StreetAddress;
            this._boxAddress = c.BoxAddress;
            this._city = c.City;
            this._customerState = c.CustomerState;
            this._postalCode = c.PostalCode;
            this._customerStatusId = c.CustomerStatusId;
            this._phoneNumber = c.PhoneNumber;
            this._faxNumber = c.FaxNumber;
            this._mobileNumber = c.MobileNumber;
            this._customerWebURL = c.CustomerWebURL;
            this._contactEmailAddress = c.ContactEmailAddress;
            this._customerNotes = c.CustomerNotes;
            this._dateAdded = c.DateAdded;
            this._addedBy = c.AddedBy;
            this._dateUpdated = c.DateUpdated;
            this._updatedBy = c.UpdatedBy;
            this._rowUpdateVersion = c.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Customer;
            }
        }

        public int CustomerId
        {
            get
            {
                return this._customerId;
            }
            set
            {
                this._customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        public string CustomerName
        {
            get
            {
                return this._customerName;
            }
            set
            {
                this._customerName = value;
                NotifyPropertyChanged("CustomerName");
            }
        }

        public string ContactName
        {
            get
            {
                return this._contactName;
            }
            set
            {
                this._contactName = value;
                NotifyPropertyChanged("ContactName");
            }
        }

        public string StreetAddress
        {
            get
            {
                return this._streetAddress;
            }
            set
            {
                this._streetAddress = value;
                NotifyPropertyChanged("StreetAddress");
            }
        }

        public string BoxAddress
        {
            get
            {
                return this._boxAddress;
            }
            set
            {
                this._boxAddress = value;
                NotifyPropertyChanged("BoxAddress");
            }
        }

        public string City
        {
            get
            {
                return this._city;
            }
            set
            {
                this._city = value;
                NotifyPropertyChanged("City");
            }
        }

        public string CustomerState
        {
            get
            {
                return this._customerState;
            }
            set
            {
                this._customerState = value;
                NotifyPropertyChanged("CustomerState");
            }
        }

        public string PostalCode
        {
            get
            {
                return this._postalCode;
            }
            set
            {
                this._postalCode = value;
                NotifyPropertyChanged("PostalCode");
            }
        }

        public int CustomerStatusId
        {
            get
            {
                return this._customerStatusId;
            }
            set
            {
                this._customerStatusId = value;
                NotifyPropertyChanged("CustomerStatusId");
            }
        }

        public string PhoneNumber
        {
            get
            {
                return this._phoneNumber;
            }
            set
            {
                this._phoneNumber = value;
                NotifyPropertyChanged("PhoneNumber");
            }
        }

        public string FaxNumber
        {
            get
            {
                return this._faxNumber;
            }
            set
            {
                this._faxNumber = value;
                NotifyPropertyChanged("FaxNumber");
            }
        }

        public string MobileNumber
        {
            get
            {
                return this._mobileNumber;
            }
            set
            {
                this._mobileNumber = value;
                NotifyPropertyChanged("MobileNumber");
            }
        }

        public string CustomerWebURL
        {
            get
            {
                return this._customerWebURL;
            }
            set
            {
                this._customerWebURL = value;
                NotifyPropertyChanged("CustomerWebURL");
            }
        }

        public string ContactEmailAddress
        {
            get
            {
                return this._contactEmailAddress;
            }
            set
            {
                this._contactEmailAddress = value;
                NotifyPropertyChanged("ContactEmailAddress");
            }
        }

        public string CustomerNotes
        {
            get
            {
                return this._customerNotes;
            }
            set
            {
                this._customerNotes = value;
                NotifyPropertyChanged("CustomerNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Customer c)
        {
            #region Compare Members

            if (this._customerId != c.CustomerId)
            {
                return false;
            }

            if (this._customerName != c.CustomerName)
            {
                return false;
            }

            if (this._contactName != c.ContactName)
            {
                return false;
            }

            if (this._streetAddress != c.StreetAddress)
            {
                return false;
            }

            if (this._boxAddress != c.BoxAddress)
            {
                return false;
            }

            if (this._city != c.City)
            {
                return false;
            }

            if (this._customerState != c.CustomerState)
            {
                return false;
            }

            if (this._postalCode != c.PostalCode)
            {
                return false;
            }

            if (this._customerStatusId != c.CustomerStatusId)
            {
                return false;
            }

            if (this._phoneNumber != c.PhoneNumber)
            {
                return false;
            }

            if (this._faxNumber != c.FaxNumber)
            {
                return false;
            }

            if (this._mobileNumber != c.MobileNumber)
            {
                return false;
            }

            if (this._customerWebURL != c.CustomerWebURL)
            {
                return false;
            }

            if (this._contactEmailAddress != c.ContactEmailAddress)
            {
                return false;
            }

            if (this._customerNotes != c.CustomerNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Customer c = obj as Customer;
            if ((System.Object)c == null)
            {
                return false;
            }

            if (!this.Equals(c))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Customer a, Customer b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.CustomerId != b.CustomerId)
            {
                return false;
            }

            if (a.CustomerName != b.CustomerName)
            {
                return false;
            }

            if (a.ContactName != b.ContactName)
            {
                return false;
            }

            if (a.StreetAddress != b.StreetAddress)
            {
                return false;
            }

            if (a.BoxAddress != b.BoxAddress)
            {
                return false;
            }

            if (a.City != b.City)
            {
                return false;
            }

            if (a.CustomerState != b.CustomerState)
            {
                return false;
            }

            if (a.PostalCode != b.PostalCode)
            {
                return false;
            }

            if (a.CustomerStatusId != b.CustomerStatusId)
            {
                return false;
            }

            if (a.PhoneNumber != b.PhoneNumber)
            {
                return false;
            }

            if (a.FaxNumber != b.FaxNumber)
            {
                return false;
            }

            if (a.MobileNumber != b.MobileNumber)
            {
                return false;
            }

            if (a.CustomerWebURL != b.CustomerWebURL)
            {
                return false;
            }

            if (a.ContactEmailAddress != b.ContactEmailAddress)
            {
                return false;
            }

            if (a.CustomerNotes != b.CustomerNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Customer a, Customer b)
        {
            return !(a == b);
        }

        #endregion

    }

}
