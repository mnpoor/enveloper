using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class DriverStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _driverStatusId;
        private string _driverStatusDescription;

        #endregion


        #region Constructor

        public DriverStatus()
        {
            this._driverStatusId = 0;
            this._driverStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public DriverStatus(DriverStatus d)
        {
            this._driverStatusId = d.DriverStatusId;
            this._driverStatusDescription = d.DriverStatusDescription;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.DriverStatus;
            }
        }

        public int DriverStatusId
        {
            get
            {
                return this._driverStatusId;
            }
            set
            {
                this._driverStatusId = value;
                NotifyPropertyChanged("DriverStatusId");
            }
        }

        public string DriverStatusDescription
        {
            get
            {
                return this._driverStatusDescription;
            }
            set
            {
                this._driverStatusDescription = value;
                NotifyPropertyChanged("DriverStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(DriverStatus d)
        {
            #region Compare Members

            if (this._driverStatusId != d.DriverStatusId)
            {
                return false;
            }

            if (this._driverStatusDescription != d.DriverStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            DriverStatus d = obj as DriverStatus;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(DriverStatus a, DriverStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DriverStatusId != b.DriverStatusId)
            {
                return false;
            }

            if (a.DriverStatusDescription != b.DriverStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(DriverStatus a, DriverStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
