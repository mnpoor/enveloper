using System;

namespace SandPatchCL
{
    public sealed class SPSingleton
    {
        private static readonly SPSingleton instance = new SPSingleton();

        private SPSingleton() { }

        public static SPSingleton Instance
        {
            get
            {
                return instance;
            }
        }
    }
}
