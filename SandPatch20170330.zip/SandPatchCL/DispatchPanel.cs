using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class DispatchPanel : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _dispatchPanelId;
        private int _panelColumn;
        private int _panelRow;
        private int _dispatchId;
        private int _driverId;
        private int _truckNumber;
        private int _activeDispatches;
        private string _driverName;
        private int _availabilityStatusId;
        private string _availabilityStatusDescription;
        private string _availabilityColorCode;
        private int _jobNumberId;
        private int _jobNumberAssignment;
        private string _dispatchAcceptanceNumber;
        private int _dispatchStatusId;
        private string _dispatchStatusDescription;
        private int _loadingTerminalId;
        private string _loadingTerminalName;
        private DateTime _loadingTerminalAppointmentDateTime;
        private DateTime _actualLoadingTerminalArrivalTime;
        private DateTime _actualLoadingTerminalDepartureTime;
        private int _jobSiteId;
        private string _jobSiteName;
        private DateTime _jobSiteDeliveryAppointmentDateTime;
        private DateTime _jobSiteActualArrivalTime;
        private DateTime _jobSiteActualDepartureTime;

        #endregion


        #region Constructor

        public DispatchPanel()
        {
            this._dispatchPanelId = 0;
            this._panelColumn = 0;
            this._panelRow = 0;
            this._dispatchId = 0;
            this._driverId = 0;
            this._truckNumber = 0;
            this._activeDispatches = 0;
            this._driverName = string.Empty;
            this._availabilityStatusId = 0;
            this._availabilityStatusDescription = string.Empty;
            this._availabilityColorCode = string.Empty;
            this._jobNumberId = 0;
            this._jobNumberAssignment = 0;
            this._dispatchAcceptanceNumber = string.Empty;
            this._dispatchStatusId = 0;
            this._dispatchStatusDescription = string.Empty;
            this._loadingTerminalId = 0;
            this._loadingTerminalName = string.Empty;
            this._loadingTerminalAppointmentDateTime = new DateTime();
            this._actualLoadingTerminalArrivalTime = new DateTime();
            this._actualLoadingTerminalDepartureTime = new DateTime();
            this._jobSiteId = 0;
            this._jobSiteName = string.Empty;
            this._jobSiteDeliveryAppointmentDateTime = new DateTime();
            this._jobSiteActualArrivalTime = new DateTime();
            this._jobSiteActualDepartureTime = new DateTime();
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public DispatchPanel(DispatchPanel d)
        {
            this._dispatchPanelId = d.DispatchPanelId;
            this._panelColumn = d.PanelColumn;
            this._panelRow = d.PanelRow;
            this._dispatchId = d.DispatchId;
            this._driverId = d.DriverId;
            this._truckNumber = d.TruckNumber;
            this._activeDispatches = d.ActiveDispatches;
            this._driverName = d.DriverName;
            this._availabilityStatusId = d.AvailabilityStatusId;
            this._availabilityStatusDescription = d.AvailabilityStatusDescription;
            this._availabilityColorCode = d.AvailabilityColorCode;
            this._jobNumberId = d.JobNumberId;
            this._jobNumberAssignment = d.JobNumberAssignment;
            this._dispatchAcceptanceNumber = d.DispatchAcceptanceNumber;
            this._dispatchStatusId = d.DispatchStatusId;
            this._dispatchStatusDescription = d.DispatchStatusDescription;
            this._loadingTerminalId = d.LoadingTerminalId;
            this._loadingTerminalName = d.LoadingTerminalName;
            this._loadingTerminalAppointmentDateTime = d.LoadingTerminalAppointmentDateTime;
            this._actualLoadingTerminalArrivalTime = d.ActualLoadingTerminalArrivalTime;
            this._actualLoadingTerminalDepartureTime = d.ActualLoadingTerminalDepartureTime;
            this._jobSiteId = d.JobSiteId;
            this._jobSiteName = d.JobSiteName;
            this._jobSiteDeliveryAppointmentDateTime = d.JobSiteDeliveryAppointmentDateTime;
            this._jobSiteActualArrivalTime = d.JobSiteActualArrivalTime;
            this._jobSiteActualDepartureTime = d.JobSiteActualDepartureTime;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.DispatchPanel;
            }
        }

        public int DispatchPanelId
        {
            get
            {
                return this._dispatchPanelId;
            }
            set
            {
                this._dispatchPanelId = value;
                NotifyPropertyChanged("DispatchPanelId");
            }
        }

        public int PanelColumn
        {
            get
            {
                return this._panelColumn;
            }
            set
            {
                this._panelColumn = value;
                NotifyPropertyChanged("PanelColumn");
            }
        }

        public int PanelRow
        {
            get
            {
                return this._panelRow;
            }
            set
            {
                this._panelRow = value;
                NotifyPropertyChanged("PanelRow");
            }
        }

        public int DispatchId
        {
            get
            {
                return this._dispatchId;
            }
            set
            {
                this._dispatchId = value;
                NotifyPropertyChanged("DispatchId");
            }
        }

        public int DriverId
        {
            get
            {
                return this._driverId;
            }
            set
            {
                this._driverId = value;
                NotifyPropertyChanged("DriverId");
            }
        }

        public int TruckNumber
        {
            get
            {
                return this._truckNumber;
            }
            set
            {
                this._truckNumber = value;
                NotifyPropertyChanged("TruckNumber");
            }
        }

        public int ActiveDispatches
        {
            get
            {
                return this._activeDispatches;
            }
            set
            {
                this._activeDispatches = value;
                NotifyPropertyChanged("ActiveDispatches");
            }
        }

        public string DriverName
        {
            get
            {
                return this._driverName;
            }
            set
            {
                this._driverName = value;
                NotifyPropertyChanged("DriverName");
            }
        }

        public int AvailabilityStatusId
        {
            get
            {
                return this._availabilityStatusId;
            }
            set
            {
                this._availabilityStatusId = value;
                NotifyPropertyChanged("AvailabilityStatusId");
            }
        }

        public string AvailabilityStatusDescription
        {
            get
            {
                return this._availabilityStatusDescription;
            }
            set
            {
                this._availabilityStatusDescription = value;
                NotifyPropertyChanged("AvailabilityStatusDescription");
            }
        }

        public string AvailabilityColorCode
        {
            get
            {
                return this._availabilityColorCode;
            }
            set
            {
                this._availabilityColorCode = value;
                NotifyPropertyChanged("AvailabilityColorCode");
            }
        }

        public int JobNumberId
        {
            get
            {
                return this._jobNumberId;
            }
            set
            {
                this._jobNumberId = value;
                NotifyPropertyChanged("JobNumberId");
            }
        }

        public int JobNumberAssignment
        {
            get
            {
                return this._jobNumberAssignment;
            }
            set
            {
                this._jobNumberAssignment = value;
                NotifyPropertyChanged("JobNumberAssignment");
            }
        }

        public string DispatchAcceptanceNumber
        {
            get
            {
                return this._dispatchAcceptanceNumber;
            }
            set
            {
                this._dispatchAcceptanceNumber = value;
                NotifyPropertyChanged("DispatchAcceptanceNumber");
            }
        }

        public int DispatchStatusId
        {
            get
            {
                return this._dispatchStatusId;
            }
            set
            {
                this._dispatchStatusId = value;
                NotifyPropertyChanged("DispatchStatusId");
            }
        }

        public string DispatchStatusDescription
        {
            get
            {
                return this._dispatchStatusDescription;
            }
            set
            {
                this._dispatchStatusDescription = value;
                NotifyPropertyChanged("DispatchStatusDescription");
            }
        }

        public int LoadingTerminalId
        {
            get
            {
                return this._loadingTerminalId;
            }
            set
            {
                this._loadingTerminalId = value;
                NotifyPropertyChanged("LoadingTerminalId");
            }
        }

        public string LoadingTerminalName
        {
            get
            {
                return this._loadingTerminalName;
            }
            set
            {
                this._loadingTerminalName = value;
                NotifyPropertyChanged("LoadingTerminalName");
            }
        }

        public DateTime LoadingTerminalAppointmentDateTime
        {
            get
            {
                return this._loadingTerminalAppointmentDateTime;
            }
            set
            {
                this._loadingTerminalAppointmentDateTime = value;
                NotifyPropertyChanged("LoadingTerminalAppointmentDateTime");
            }
        }

        public DateTime ActualLoadingTerminalArrivalTime
        {
            get
            {
                return this._actualLoadingTerminalArrivalTime;
            }
            set
            {
                this._actualLoadingTerminalArrivalTime = value;
                NotifyPropertyChanged("ActualLoadingTerminalArrivalTime");
            }
        }

        public DateTime ActualLoadingTerminalDepartureTime
        {
            get
            {
                return this._actualLoadingTerminalDepartureTime;
            }
            set
            {
                this._actualLoadingTerminalDepartureTime = value;
                NotifyPropertyChanged("ActualLoadingTerminalDepartureTime");
            }
        }

        public int JobSiteId
        {
            get
            {
                return this._jobSiteId;
            }
            set
            {
                this._jobSiteId = value;
                NotifyPropertyChanged("JobSiteId");
            }
        }

        public string JobSiteName
        {
            get
            {
                return this._jobSiteName;
            }
            set
            {
                this._jobSiteName = value;
                NotifyPropertyChanged("JobSiteName");
            }
        }

        public DateTime JobSiteDeliveryAppointmentDateTime
        {
            get
            {
                return this._jobSiteDeliveryAppointmentDateTime;
            }
            set
            {
                this._jobSiteDeliveryAppointmentDateTime = value;
                NotifyPropertyChanged("JobSiteDeliveryAppointmentDateTime");
            }
        }

        public DateTime JobSiteActualArrivalTime
        {
            get
            {
                return this._jobSiteActualArrivalTime;
            }
            set
            {
                this._jobSiteActualArrivalTime = value;
                NotifyPropertyChanged("JobSiteActualArrivalTime");
            }
        }

        public DateTime JobSiteActualDepartureTime
        {
            get
            {
                return this._jobSiteActualDepartureTime;
            }
            set
            {
                this._jobSiteActualDepartureTime = value;
                NotifyPropertyChanged("JobSiteActualDepartureTime");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(DispatchPanel d)
        {
            #region Compare Members

            if (this._dispatchPanelId != d.DispatchPanelId)
            {
                return false;
            }

            if (this._panelColumn != d.PanelColumn)
            {
                return false;
            }

            if (this._panelRow != d.PanelRow)
            {
                return false;
            }

            if (this._dispatchId != d.DispatchId)
            {
                return false;
            }

            if (this._driverId != d.DriverId)
            {
                return false;
            }

            if (this._truckNumber != d.TruckNumber)
            {
                return false;
            }

            if (this._activeDispatches != d.ActiveDispatches)
            {
                return false;
            }

            if (this._driverName != d.DriverName)
            {
                return false;
            }

            if (this._availabilityStatusId != d.AvailabilityStatusId)
            {
                return false;
            }

            if (this._availabilityStatusDescription != d.AvailabilityStatusDescription)
            {
                return false;
            }

            if (this._availabilityColorCode != d.AvailabilityColorCode)
            {
                return false;
            }

            if (this._jobNumberId != d.JobNumberId)
            {
                return false;
            }

            if (this._jobNumberAssignment != d.JobNumberAssignment)
            {
                return false;
            }

            if (this._dispatchAcceptanceNumber != d.DispatchAcceptanceNumber)
            {
                return false;
            }

            if (this._dispatchStatusId != d.DispatchStatusId)
            {
                return false;
            }

            if (this._dispatchStatusDescription != d.DispatchStatusDescription)
            {
                return false;
            }

            if (this._loadingTerminalId != d.LoadingTerminalId)
            {
                return false;
            }

            if (this._loadingTerminalName != d.LoadingTerminalName)
            {
                return false;
            }

            if (this._loadingTerminalAppointmentDateTime != d.LoadingTerminalAppointmentDateTime)
            {
                return false;
            }

            if (this._actualLoadingTerminalArrivalTime != d.ActualLoadingTerminalArrivalTime)
            {
                return false;
            }

            if (this._actualLoadingTerminalDepartureTime != d.ActualLoadingTerminalDepartureTime)
            {
                return false;
            }

            if (this._jobSiteId != d.JobSiteId)
            {
                return false;
            }

            if (this._jobSiteName != d.JobSiteName)
            {
                return false;
            }

            if (this._jobSiteDeliveryAppointmentDateTime != d.JobSiteDeliveryAppointmentDateTime)
            {
                return false;
            }

            if (this._jobSiteActualArrivalTime != d.JobSiteActualArrivalTime)
            {
                return false;
            }

            if (this._jobSiteActualDepartureTime != d.JobSiteActualDepartureTime)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            DispatchPanel d = obj as DispatchPanel;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(DispatchPanel a, DispatchPanel b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DispatchPanelId != b.DispatchPanelId)
            {
                return false;
            }

            if (a.PanelColumn != b.PanelColumn)
            {
                return false;
            }

            if (a.PanelRow != b.PanelRow)
            {
                return false;
            }

            if (a.DispatchId != b.DispatchId)
            {
                return false;
            }

            if (a.DriverId != b.DriverId)
            {
                return false;
            }

            if (a.TruckNumber != b.TruckNumber)
            {
                return false;
            }

            if (a.ActiveDispatches != b.ActiveDispatches)
            {
                return false;
            }

            if (a.DriverName != b.DriverName)
            {
                return false;
            }

            if (a.AvailabilityStatusId != b.AvailabilityStatusId)
            {
                return false;
            }

            if (a.AvailabilityStatusDescription != b.AvailabilityStatusDescription)
            {
                return false;
            }

            if (a.AvailabilityColorCode != b.AvailabilityColorCode)
            {
                return false;
            }

            if (a.JobNumberId != b.JobNumberId)
            {
                return false;
            }

            if (a.JobNumberAssignment != b.JobNumberAssignment)
            {
                return false;
            }

            if (a.DispatchAcceptanceNumber != b.DispatchAcceptanceNumber)
            {
                return false;
            }

            if (a.DispatchStatusId != b.DispatchStatusId)
            {
                return false;
            }

            if (a.DispatchStatusDescription != b.DispatchStatusDescription)
            {
                return false;
            }

            if (a.LoadingTerminalId != b.LoadingTerminalId)
            {
                return false;
            }

            if (a.LoadingTerminalName != b.LoadingTerminalName)
            {
                return false;
            }

            if (a.LoadingTerminalAppointmentDateTime != b.LoadingTerminalAppointmentDateTime)
            {
                return false;
            }

            if (a.ActualLoadingTerminalArrivalTime != b.ActualLoadingTerminalArrivalTime)
            {
                return false;
            }

            if (a.ActualLoadingTerminalDepartureTime != b.ActualLoadingTerminalDepartureTime)
            {
                return false;
            }

            if (a.JobSiteId != b.JobSiteId)
            {
                return false;
            }

            if (a.JobSiteName != b.JobSiteName)
            {
                return false;
            }

            if (a.JobSiteDeliveryAppointmentDateTime != b.JobSiteDeliveryAppointmentDateTime)
            {
                return false;
            }

            if (a.JobSiteActualArrivalTime != b.JobSiteActualArrivalTime)
            {
                return false;
            }

            if (a.JobSiteActualDepartureTime != b.JobSiteActualDepartureTime)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(DispatchPanel a, DispatchPanel b)
        {
            return !(a == b);
        }

        #endregion

    }

}
