using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class FuelCardStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _fuelCardStatusId;
        private string _fuelCardStatusDescription;

        #endregion


        #region Constructor

        public FuelCardStatus()
        {
            this._fuelCardStatusId = 0;
            this._fuelCardStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public FuelCardStatus(FuelCardStatus f)
        {
            this._fuelCardStatusId = f.FuelCardStatusId;
            this._fuelCardStatusDescription = f.FuelCardStatusDescription;
            this._dateAdded = f.DateAdded;
            this._addedBy = f.AddedBy;
            this._dateUpdated = f.DateUpdated;
            this._updatedBy = f.UpdatedBy;
            this._rowUpdateVersion = f.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.FuelCardStatus;
            }
        }

        public int FuelCardStatusId
        {
            get
            {
                return this._fuelCardStatusId;
            }
            set
            {
                this._fuelCardStatusId = value;
                NotifyPropertyChanged("FuelCardStatusId");
            }
        }

        public string FuelCardStatusDescription
        {
            get
            {
                return this._fuelCardStatusDescription;
            }
            set
            {
                this._fuelCardStatusDescription = value;
                NotifyPropertyChanged("FuelCardStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(FuelCardStatus f)
        {
            #region Compare Members

            if (this._fuelCardStatusId != f.FuelCardStatusId)
            {
                return false;
            }

            if (this._fuelCardStatusDescription != f.FuelCardStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            FuelCardStatus f = obj as FuelCardStatus;
            if ((System.Object)f == null)
            {
                return false;
            }

            if (!this.Equals(f))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(FuelCardStatus a, FuelCardStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.FuelCardStatusId != b.FuelCardStatusId)
            {
                return false;
            }

            if (a.FuelCardStatusDescription != b.FuelCardStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(FuelCardStatus a, FuelCardStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
