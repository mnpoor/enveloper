using System;
using System.Collections.Generic;
using System.Text;

namespace SandPatchCL
{
    public class DispatchExcelRow : SPClassBase, ISPClass
    {

        #region Private Members

        private int _dispatchImportId;        
        private string _spreadsheetFileName;
        private string _jobNumber;
        private string _sandFacility;
        private string _oneWayMile;
        private string _loadAmount;
        private string _totalAmount;
        private string _loadCount;
        private string _tmsIssued;
        private string _currentBalance;
        private string _truckNumber;
        private string _tmsNumber;
        private string _dispatchDate;
        private string _sandType;
        private string _purchaseOrderNumber;
        private string _loadAppointmentDateTime;
        private string _sandFacilityArrivalTime;
        private string _sandFacilityDepartureTime;
        private string _billOfLading;
        private string _loadWeight;
        private string _ticketNumber;
        private string _deliveryAppointmentDateTime;
        private string _siteArrivalTime;
        private string _siteDepartureTime;

        #endregion


        #region Constructor

        public DispatchExcelRow()
        {
            this._dispatchImportId = 0;
            this._spreadsheetFileName = string.Empty;
            this._jobNumber = string.Empty;
            this._sandFacility = string.Empty;
            this._oneWayMile = string.Empty;
            this._loadAmount = string.Empty;
            this._totalAmount = string.Empty;
            this._loadCount = string.Empty;
            this._tmsIssued = string.Empty;
            this._currentBalance = string.Empty;
            this._truckNumber = string.Empty;
            this._tmsNumber = string.Empty;
            this._dispatchDate = string.Empty;
            this._sandType = string.Empty;
            this._purchaseOrderNumber = string.Empty;
            this._loadAppointmentDateTime = string.Empty;
            this._sandFacilityArrivalTime = string.Empty;
            this._sandFacilityDepartureTime = string.Empty;
            this._billOfLading = string.Empty;
            this._loadWeight = string.Empty;
            this._ticketNumber = string.Empty;
            this._deliveryAppointmentDateTime = string.Empty;
            this._siteArrivalTime = string.Empty;
            this._siteDepartureTime = string.Empty;
        }

        public DispatchExcelRow(DispatchExcelRow d)
        {
            this._dispatchImportId = d.DispatchImportId;
            this._spreadsheetFileName = d.SpreadsheetFileName;
            this._jobNumber = d.JobNumber;
            this._sandFacility = d.SandFacility;
            this._oneWayMile = d.OneWayMile;
            this._loadAmount = d.LoadAmount;
            this._totalAmount = d.TotalAmount;
            this._loadCount = d.LoadCount;
            this._tmsIssued = d.TMSIssued;
            this._currentBalance = d.CurrentBalance;
            this._truckNumber = d.TruckNumber;
            this._tmsNumber = d.TMSNumber;
            this._dispatchDate = d.DispatchDate;
            this._sandType = d.SandType;
            this._purchaseOrderNumber = d.PurchaseOrderNumber;
            this._loadAppointmentDateTime = d.LoadAppointmentDateTime;
            this._sandFacilityArrivalTime = d.SandFacilityArrivalTime;
            this._sandFacilityDepartureTime = d.SandFacilityDepartureTime;
            this._billOfLading = d.BillOfLading;
            this._loadWeight = d.LoadWeight;
            this._ticketNumber = d.TicketNumber;
            this._deliveryAppointmentDateTime = d.DeliveryAppointmentDateTime;
            this._siteArrivalTime = d.SiteArrivalTime;
            this._siteDepartureTime = d.SiteDepartureTime;
        }

        public DispatchExcelRow(int timeSheetEntryId, string spreadsheetFileName, string truckNumber, string tmsNumber, string dispatchDate, string sandType, string purchaseOrderNumber,
            string loadAppointmentDateTime, string sandFacilityArrivalTime, string sandFacilityDepartureTime, string billOfLading, string loadWeight, string ticketNumber,
            string deliveryAppointmentDateTime, string siteArrivalTime, string siteDepartureTime)
        {
            this._dispatchImportId = timeSheetEntryId;
            this._spreadsheetFileName = spreadsheetFileName;
            this._truckNumber = truckNumber;
            this._tmsNumber = tmsNumber;
            this._dispatchDate = dispatchDate;
            this._sandType = sandType;
            this._purchaseOrderNumber = purchaseOrderNumber;
            this._loadAppointmentDateTime = loadAppointmentDateTime;
            this._sandFacilityArrivalTime = sandFacilityArrivalTime;
            this._sandFacilityDepartureTime = sandFacilityDepartureTime;
            this._billOfLading = billOfLading;
            this._loadWeight = loadWeight;
            this._ticketNumber = ticketNumber;
            this._deliveryAppointmentDateTime = deliveryAppointmentDateTime;
            this._siteArrivalTime = siteArrivalTime;
            this._siteDepartureTime = siteDepartureTime;
        }

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.DispatchExcelRow;
            }
        }

        public int DispatchImportId
        {
            get
            {
                return this._dispatchImportId;
            }
            set
            {
                this._dispatchImportId = value;
            }
        }

        public string SpreadsheetFileName
        {
            get
            {
                return this._spreadsheetFileName;
            }
            set
            {
                this._spreadsheetFileName = value;
            }
        }

        public string JobNumber
        {
            get
            {
                return this._jobNumber;
            }
            set
            {
                this._jobNumber = value;
            }
        }

        public string SandFacility
        {
            get
            {
                return this._sandFacility;
            }
            set
            {
                this._sandFacility = value;
            }
        }

        public string OneWayMile
        {
            get
            {
                return this._oneWayMile;
            }
            set
            {
                this._oneWayMile = value;
            }
        }

        public string LoadAmount
        {
            get
            {
                return this._loadAmount;
            }
            set
            {
                this._loadAmount = value;
            }
        }

        public string TotalAmount
        {
            get
            {
                return this._totalAmount;
            }
            set
            {
                this._totalAmount = value;
            }
        }

        public string LoadCount
        {
            get
            {
                return this._loadCount;
            }
            set
            {
                this._loadCount = value;
            }
        }

        public string TMSIssued
        {
            get
            {
                return this._tmsIssued;
            }
            set
            {
                this._tmsIssued = value;
            }
        }

        public string CurrentBalance
        {
            get
            {
                return this._currentBalance;
            }
            set
            {
                this._currentBalance = value;
            }
        }

        public string TruckNumber
        {
            get
            {
                return this._truckNumber;
            }
            set
            {
                this._truckNumber = value;
            }
        }

        public string TMSNumber
        {
            get
            {
                return this._tmsNumber;
            }
            set
            {
                this._tmsNumber = value;
            }
        }

        public string DispatchDate
        {
            get
            {
                return this._dispatchDate;
            }
            set
            {
                this._dispatchDate = value;
            }
        }

        public string SandType
        {
            get
            {
                return this._sandType;
            }
            set
            {
                this._sandType = value;
            }
        }

        public string PurchaseOrderNumber
        {
            get
            {
                return this._purchaseOrderNumber;
            }
            set
            {
                this._purchaseOrderNumber = value;
            }
        }

        public string LoadAppointmentDateTime
        {
            get
            {
                return this._loadAppointmentDateTime;
            }
            set
            {
                this._loadAppointmentDateTime = value;
            }
        }

        public string SandFacilityArrivalTime
        {
            get
            {
                return this._sandFacilityArrivalTime;
            }
            set
            {
                this._sandFacilityArrivalTime = value;
            }
        }

        public string SandFacilityDepartureTime
        {
            get
            {
                return this._sandFacilityDepartureTime;
            }
            set
            {
                this._sandFacilityDepartureTime = value;
            }
        }

        public string BillOfLading
        {
            get
            {
                return this._billOfLading;
            }
            set
            {
                this._billOfLading = value;
            }
        }

        public string LoadWeight
        {
            get
            {
                return this._loadWeight;
            }
            set
            {
                this._loadWeight = value;
            }
        }

        public string TicketNumber
        {
            get
            {
                return this._ticketNumber;
            }
            set
            {
                this._ticketNumber = value;
            }
        }

        public string DeliveryAppointmentDateTime
        {
            get
            {
                return this._deliveryAppointmentDateTime;
            }
            set
            {
                this._deliveryAppointmentDateTime = value;
            }
        }

        public string SiteArrivalTime
        {
            get
            {
                return this._siteArrivalTime;
            }
            set
            {
                this._siteArrivalTime = value;
            }
        }

        public string SiteDepartureTime
        {
            get
            {
                return this._siteDepartureTime;
            }
            set
            {
                this._siteDepartureTime = value;
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(DispatchExcelRow d)
        {
            #region Compare Members

            if (this._dispatchImportId != d.DispatchImportId)
            {
                return false;
            }

            if (this._spreadsheetFileName != d.SpreadsheetFileName)
            {
                return false;
            }

            if (this._jobNumber != d.JobNumber)
            {
                return false;
            }

            if (this._sandFacility != d.SandFacility)
            {
                return false;
            }

            if (this._oneWayMile != d.OneWayMile)
            {
                return false;
            }

            if (this._loadAmount != d.LoadAmount)
            {
                return false;
            }

            if (this._totalAmount != d.TotalAmount)
            {
                return false;
            }

            if (this._loadCount != d.LoadCount)
            {
                return false;
            }

            if (this._tmsIssued != d.TMSIssued)
            {
                return false;
            }

            if (this._currentBalance != d.CurrentBalance)
            {
                return false;
            }

            if (this._truckNumber != d.TruckNumber)
            {
                return false;
            }

            if (this._tmsNumber != d.TMSNumber)
            {
                return false;
            }

            if (this._dispatchDate != d.DispatchDate)
            {
                return false;
            }

            if (this._sandType != d.SandType)
            {
                return false;
            }

            if (this._purchaseOrderNumber != d.PurchaseOrderNumber)
            {
                return false;
            }

            if (this._loadAppointmentDateTime != d.LoadAppointmentDateTime)
            {
                return false;
            }

            if (this._sandFacilityArrivalTime != d.SandFacilityArrivalTime)
            {
                return false;
            }

            if (this._sandFacilityDepartureTime != d.SandFacilityDepartureTime)
            {
                return false;
            }

            if (this._billOfLading != d.BillOfLading)
            {
                return false;
            }

            if (this._loadWeight != d.LoadWeight)
            {
                return false;
            }

            if (this._ticketNumber != d.TicketNumber)
            {
                return false;
            }

            if (this._deliveryAppointmentDateTime != d.DeliveryAppointmentDateTime)
            {
                return false;
            }

            if (this._siteArrivalTime != d.SiteArrivalTime)
            {
                return false;
            }

            if (this._siteDepartureTime != d.SiteDepartureTime)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            DispatchExcelRow t = obj as DispatchExcelRow;
            if ((System.Object)t == null)
            {
                return false;
            }

            if (!this.Equals(t))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(DispatchExcelRow a, DispatchExcelRow b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DispatchImportId != b.DispatchImportId)
            {
                return false;
            }

            if (a.SpreadsheetFileName != b.SpreadsheetFileName)
            {
                return false;
            }

            if (a.JobNumber != b.JobNumber)
            {
                return false;
            }

            if (a.SandFacility != b.SandFacility)
            {
                return false;
            }

            if (a.OneWayMile != b.OneWayMile)
            {
                return false;
            }

            if (a.LoadAmount != b.LoadAmount)
            {
                return false;
            }

            if (a.TotalAmount != b.TotalAmount)
            {
                return false;
            }

            if (a.LoadCount != b.LoadCount)
            {
                return false;
            }

            if (a.TMSIssued != b.TMSIssued)
            {
                return false;
            }

            if (a.CurrentBalance != b.CurrentBalance)
            {
                return false;
            }

            if (a.TruckNumber != b.TruckNumber)
            {
                return false;
            }

            if (a.TMSNumber != b.TMSNumber)
            {
                return false;
            }

            if (a.DispatchDate != b.DispatchDate)
            {
                return false;
            }

            if (a.SandType != b.SandType)
            {
                return false;
            }

            if (a.PurchaseOrderNumber != b.PurchaseOrderNumber)
            {
                return false;
            }

            if (a.LoadAppointmentDateTime != b.LoadAppointmentDateTime)
            {
                return false;
            }

            if (a.SandFacilityArrivalTime != b.SandFacilityArrivalTime)
            {
                return false;
            }

            if (a.SandFacilityDepartureTime != b.SandFacilityDepartureTime)
            {
                return false;
            }

            if (a.BillOfLading != b.BillOfLading)
            {
                return false;
            }

            if (a.LoadWeight != b.LoadWeight)
            {
                return false;
            }

            if (a.TicketNumber != b.TicketNumber)
            {
                return false;
            }

            if (a.DeliveryAppointmentDateTime != b.DeliveryAppointmentDateTime)
            {
                return false;
            }

            if (a.SiteArrivalTime != b.SiteArrivalTime)
            {
                return false;
            }

            if (a.SiteDepartureTime != b.SiteDepartureTime)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(DispatchExcelRow a, DispatchExcelRow b)
        {
            return !(a == b);
        }

        #endregion

    }
}
