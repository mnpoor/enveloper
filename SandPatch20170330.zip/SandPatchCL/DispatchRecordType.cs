using System;
using System.Collections.Generic;
using System.Text;

namespace SandPatchCL
{
    public enum DispatchRecordType
    {
        Unassigned = 0,
        PageBreak = 1,
        ReportHeader = 2,
        SectionHeader = 3,
        HeaderSpacer = 4,
        ReportBody = 5,
        LastLine = 6
    }
}
