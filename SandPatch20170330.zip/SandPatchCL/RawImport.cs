using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class RawImport : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _rawImportId;
        private int _customerId;
        private string _truckNumber;
        private string _dispatchAcceptanceNumber;
        private string _dispatchAcceptanceDate;
        private string _sandType;
        private string _purchaseOrderNumber;
        private string _loadingTerminalAppointmentDateTime;
        private string _actualLoadingTerminalArrivalTime;
        private string _actualLoadingTerminalDepartureTime;
        private string _billOfLading;
        private string _shipmentWeight;
        private string _ticketNumber;
        private string _jobSiteDeliveryAppointmentDateTime;
        private string _jobSiteActualArrivalTime;
        private string _jobSiteActualDepartureTime;

        #endregion


        #region Constructor

        public RawImport()
        {
            this._rawImportId = 0;
            this._customerId = 0;
            this._truckNumber = string.Empty;
            this._dispatchAcceptanceNumber = string.Empty;
            this._dispatchAcceptanceDate = string.Empty;
            this._sandType = string.Empty;
            this._purchaseOrderNumber = string.Empty;
            this._loadingTerminalAppointmentDateTime = string.Empty;
            this._actualLoadingTerminalArrivalTime = string.Empty;
            this._actualLoadingTerminalDepartureTime = string.Empty;
            this._billOfLading = string.Empty;
            this._shipmentWeight = string.Empty;
            this._ticketNumber = string.Empty;
            this._jobSiteDeliveryAppointmentDateTime = string.Empty;
            this._jobSiteActualArrivalTime = string.Empty;
            this._jobSiteActualDepartureTime = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public RawImport(RawImport r)
        {
            this._rawImportId = r.RawImportId;
            this._customerId = r.CustomerId;
            this._truckNumber = r.TruckNumber;
            this._dispatchAcceptanceNumber = r.DispatchAcceptanceNumber;
            this._dispatchAcceptanceDate = r.DispatchAcceptanceDate;
            this._sandType = r.SandType;
            this._purchaseOrderNumber = r.PurchaseOrderNumber;
            this._loadingTerminalAppointmentDateTime = r.LoadingTerminalAppointmentDateTime;
            this._actualLoadingTerminalArrivalTime = r.ActualLoadingTerminalArrivalTime;
            this._actualLoadingTerminalDepartureTime = r.ActualLoadingTerminalDepartureTime;
            this._billOfLading = r.BillOfLading;
            this._shipmentWeight = r.ShipmentWeight;
            this._ticketNumber = r.TicketNumber;
            this._jobSiteDeliveryAppointmentDateTime = r.JobSiteDeliveryAppointmentDateTime;
            this._jobSiteActualArrivalTime = r.JobSiteActualArrivalTime;
            this._jobSiteActualDepartureTime = r.JobSiteActualDepartureTime;
            this._dateAdded = r.DateAdded;
            this._addedBy = r.AddedBy;
            this._dateUpdated = r.DateUpdated;
            this._updatedBy = r.UpdatedBy;
            this._rowUpdateVersion = r.RowUpdateVersion;
        }

        public RawImport(int rawImportId, string truckNumber, string tmsNumber, string dispatchDate, string sandType, string purchaseOrderNumber,
            string loadAppointmentDateTime, string sandFacilityArrivalTime, string sandFacilityDepartureTime, string billOfLading, string loadWeight, string ticketNumber,
            string deliveryAppointmentDateTime, string siteArrivalTime, string siteDepartureTime)
        {
            this._rawImportId = rawImportId;
            this._truckNumber = truckNumber;
            this._dispatchAcceptanceNumber = tmsNumber;
            this._dispatchAcceptanceDate = dispatchDate;
            this._sandType = sandType;
            this._purchaseOrderNumber = purchaseOrderNumber;
            this._loadingTerminalAppointmentDateTime = loadAppointmentDateTime;
            this._actualLoadingTerminalArrivalTime = sandFacilityArrivalTime;
            this._actualLoadingTerminalDepartureTime = sandFacilityDepartureTime;
            this._billOfLading = billOfLading;
            this._shipmentWeight = loadWeight;
            this._ticketNumber = ticketNumber;
            this._jobSiteDeliveryAppointmentDateTime = deliveryAppointmentDateTime;
            this._jobSiteActualArrivalTime = siteArrivalTime;
            this._jobSiteActualDepartureTime = siteDepartureTime;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.RawImport;
            }
        }

        public int RawImportId
        {
            get
            {
                return this._rawImportId;
            }
            set
            {
                this._rawImportId = value;
                NotifyPropertyChanged("RawImportId");
            }
        }

        public int CustomerId
        {
            get
            {
                return this._customerId;
            }
            set
            {
                this._customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        public string TruckNumber
        {
            get
            {
                return this._truckNumber;
            }
            set
            {
                this._truckNumber = value;
                NotifyPropertyChanged("TruckNumber");
            }
        }

        public string DispatchAcceptanceNumber
        {
            get
            {
                return this._dispatchAcceptanceNumber;
            }
            set
            {
                this._dispatchAcceptanceNumber = value;
                NotifyPropertyChanged("DispatchAcceptanceNumber");
            }
        }

        public string DispatchAcceptanceDate
        {
            get
            {
                return this._dispatchAcceptanceDate;
            }
            set
            {
                this._dispatchAcceptanceDate = value;
                NotifyPropertyChanged("DispatchAcceptanceDate");
            }
        }

        public string SandType
        {
            get
            {
                return this._sandType;
            }
            set
            {
                this._sandType = value;
                NotifyPropertyChanged("SandType");
            }
        }

        public string PurchaseOrderNumber
        {
            get
            {
                return this._purchaseOrderNumber;
            }
            set
            {
                this._purchaseOrderNumber = value;
                NotifyPropertyChanged("PurchaseOrderNumber");
            }
        }

        public string LoadingTerminalAppointmentDateTime
        {
            get
            {
                return this._loadingTerminalAppointmentDateTime;
            }
            set
            {
                this._loadingTerminalAppointmentDateTime = value;
                NotifyPropertyChanged("LoadingTerminalAppointmentDateTime");
            }
        }

        public string ActualLoadingTerminalArrivalTime
        {
            get
            {
                return this._actualLoadingTerminalArrivalTime;
            }
            set
            {
                this._actualLoadingTerminalArrivalTime = value;
                NotifyPropertyChanged("ActualLoadingTerminalArrivalTime");
            }
        }

        public string ActualLoadingTerminalDepartureTime
        {
            get
            {
                return this._actualLoadingTerminalDepartureTime;
            }
            set
            {
                this._actualLoadingTerminalDepartureTime = value;
                NotifyPropertyChanged("ActualLoadingTerminalDepartureTime");
            }
        }

        public string BillOfLading
        {
            get
            {
                return this._billOfLading;
            }
            set
            {
                this._billOfLading = value;
                NotifyPropertyChanged("BillOfLading");
            }
        }

        public string ShipmentWeight
        {
            get
            {
                return this._shipmentWeight;
            }
            set
            {
                this._shipmentWeight = value;
                NotifyPropertyChanged("ShipmentWeight");
            }
        }

        public string TicketNumber
        {
            get
            {
                return this._ticketNumber;
            }
            set
            {
                this._ticketNumber = value;
                NotifyPropertyChanged("TicketNumber");
            }
        }

        public string JobSiteDeliveryAppointmentDateTime
        {
            get
            {
                return this._jobSiteDeliveryAppointmentDateTime;
            }
            set
            {
                this._jobSiteDeliveryAppointmentDateTime = value;
                NotifyPropertyChanged("JobSiteDeliveryAppointmentDateTime");
            }
        }

        public string JobSiteActualArrivalTime
        {
            get
            {
                return this._jobSiteActualArrivalTime;
            }
            set
            {
                this._jobSiteActualArrivalTime = value;
                NotifyPropertyChanged("JobSiteActualArrivalTime");
            }
        }

        public string JobSiteActualDepartureTime
        {
            get
            {
                return this._jobSiteActualDepartureTime;
            }
            set
            {
                this._jobSiteActualDepartureTime = value;
                NotifyPropertyChanged("JobSiteActualDepartureTime");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(RawImport r)
        {
            #region Compare Members

            if (this._rawImportId != r.RawImportId)
            {
                return false;
            }

            if (this._customerId != r.CustomerId)
            {
                return false;
            }

            if (this._truckNumber != r.TruckNumber)
            {
                return false;
            }

            if (this._dispatchAcceptanceNumber != r.DispatchAcceptanceNumber)
            {
                return false;
            }

            if (this._dispatchAcceptanceDate != r.DispatchAcceptanceDate)
            {
                return false;
            }

            if (this._sandType != r.SandType)
            {
                return false;
            }

            if (this._purchaseOrderNumber != r.PurchaseOrderNumber)
            {
                return false;
            }

            if (this._loadingTerminalAppointmentDateTime != r.LoadingTerminalAppointmentDateTime)
            {
                return false;
            }

            if (this._actualLoadingTerminalArrivalTime != r.ActualLoadingTerminalArrivalTime)
            {
                return false;
            }

            if (this._actualLoadingTerminalDepartureTime != r.ActualLoadingTerminalDepartureTime)
            {
                return false;
            }

            if (this._billOfLading != r.BillOfLading)
            {
                return false;
            }

            if (this._shipmentWeight != r.ShipmentWeight)
            {
                return false;
            }

            if (this._ticketNumber != r.TicketNumber)
            {
                return false;
            }

            if (this._jobSiteDeliveryAppointmentDateTime != r.JobSiteDeliveryAppointmentDateTime)
            {
                return false;
            }

            if (this._jobSiteActualArrivalTime != r.JobSiteActualArrivalTime)
            {
                return false;
            }

            if (this._jobSiteActualDepartureTime != r.JobSiteActualDepartureTime)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            RawImport r = obj as RawImport;
            if ((System.Object)r == null)
            {
                return false;
            }

            if (!this.Equals(r))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(RawImport a, RawImport b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.RawImportId != b.RawImportId)
            {
                return false;
            }

            if (a.CustomerId != b.CustomerId)
            {
                return false;
            }

            if (a.TruckNumber != b.TruckNumber)
            {
                return false;
            }

            if (a.DispatchAcceptanceNumber != b.DispatchAcceptanceNumber)
            {
                return false;
            }

            if (a.DispatchAcceptanceDate != b.DispatchAcceptanceDate)
            {
                return false;
            }

            if (a.SandType != b.SandType)
            {
                return false;
            }

            if (a.PurchaseOrderNumber != b.PurchaseOrderNumber)
            {
                return false;
            }

            if (a.LoadingTerminalAppointmentDateTime != b.LoadingTerminalAppointmentDateTime)
            {
                return false;
            }

            if (a.ActualLoadingTerminalArrivalTime != b.ActualLoadingTerminalArrivalTime)
            {
                return false;
            }

            if (a.ActualLoadingTerminalDepartureTime != b.ActualLoadingTerminalDepartureTime)
            {
                return false;
            }

            if (a.BillOfLading != b.BillOfLading)
            {
                return false;
            }

            if (a.ShipmentWeight != b.ShipmentWeight)
            {
                return false;
            }

            if (a.TicketNumber != b.TicketNumber)
            {
                return false;
            }

            if (a.JobSiteDeliveryAppointmentDateTime != b.JobSiteDeliveryAppointmentDateTime)
            {
                return false;
            }

            if (a.JobSiteActualArrivalTime != b.JobSiteActualArrivalTime)
            {
                return false;
            }

            if (a.JobSiteActualDepartureTime != b.JobSiteActualDepartureTime)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(RawImport a, RawImport b)
        {
            return !(a == b);
        }

        #endregion

    }

}
