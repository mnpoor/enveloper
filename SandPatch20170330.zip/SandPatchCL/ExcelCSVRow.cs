using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace SandPatchCL
{
    public class ExcelCSVRow : SPClassBase, ISPClass
    {

        #region Private Members

        private int _rowNumber;
        private DispatchRecordType _recordType;
        private DispatchRowType _rowType;
        private int _lastPageHeadingRowNumber;
        private int _lastPropertyRowNumber;
        private int _lastNoteGroupHeadingRowNumber;
        private string _rowLine;
        private int _weight;

        #endregion


        #region Constructor

        public ExcelCSVRow()
        {
            this._rowNumber = 0;
            this._recordType = DispatchRecordType.Unassigned;
            this._rowType = DispatchRowType.Unknown;
            this._lastPageHeadingRowNumber = 0;
            this._lastPropertyRowNumber = 0;
            this._lastNoteGroupHeadingRowNumber = 0;
            this._rowLine = string.Empty;
            this._weight = 0;
        }

        public ExcelCSVRow(ExcelCSVRow n)
        {
            this._rowNumber = n.RowNumber;
            this._recordType = n.RecordType;
            this._rowType = n.RowType;
            this._lastPageHeadingRowNumber = n.LastPageHeadingRowNumber;
            this._lastPropertyRowNumber = n.LastPropertyRowNumber;
            this._lastNoteGroupHeadingRowNumber = n.LastGroupHeadingRowNumber;
            this._rowLine = n.RowLine;
            this._weight = n.Weight;
        }

        public ExcelCSVRow(int rowNumber, int lastPageHeadingRowNumber, int lastPropertyRowNumber, int lastNoteGroupHeadingRowNumber, string rowLine)
        {
            this._rowNumber = rowNumber;
            this._recordType = DispatchRecordType.Unassigned;
            this._rowType = DispatchRowType.Unknown;
            this._lastPageHeadingRowNumber = lastPageHeadingRowNumber;
            this._lastPropertyRowNumber = lastPropertyRowNumber;
            this._lastNoteGroupHeadingRowNumber = lastNoteGroupHeadingRowNumber;
            this._rowLine = rowLine;
            this._weight = 0;
        }

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.ExcelCSVRow;
            }
        }

        public int RowNumber
        {
            get
            {
                return this._rowNumber;
            }
            set
            {
                this._rowNumber = value;
            }
        }

        public DispatchRecordType RecordType
        {
            get
            {
                return this._recordType;
            }
            set
            {
                this._recordType = value;
            }
        }

        public DispatchRowType RowType
        {
            get
            {
                return this._rowType;
            }
            set
            {
                this._rowType = value;
            }
        }

        public int LastPageHeadingRowNumber
        {
            get
            {
                return this._lastPageHeadingRowNumber;
            }
            set
            {
                this._lastPageHeadingRowNumber = value;
            }
        }

        public int LastPropertyRowNumber
        {
            get
            {
                return this._lastPropertyRowNumber;
            }
            set
            {
                this._lastPropertyRowNumber = value;
            }
        }

        public int LastGroupHeadingRowNumber
        {
            get
            {
                return this._lastNoteGroupHeadingRowNumber;
            }
            set
            {
                this._lastNoteGroupHeadingRowNumber = value;
            }
        }

        public string RowLine
        {
            get
            {
                return this._rowLine;
            }
            set
            {
                this._rowLine = value;
            }
        }

        public int Weight
        {
            get
            {
                return this._weight;
            }
            set
            {
                this._weight = value;
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(ExcelCSVRow n)
        {

            #region Compare Members

            if (this._rowNumber != n.RowNumber)
            {
                return false;
            }

            if (this._recordType != n.RecordType)
            {
                return false;
            }

            if (this._rowType != n.RowType)
            {
                return false;
            }

            if (this._lastPageHeadingRowNumber != n.LastPageHeadingRowNumber)
            {
                return false;
            }

            if (this._lastNoteGroupHeadingRowNumber != n.LastGroupHeadingRowNumber)
            {
                return false;
            }

            if (this._lastPropertyRowNumber != n.LastPropertyRowNumber)
            {
                return false;
            }

            if (this._rowLine != n.RowLine)
            {
                return false;
            }

            if (this._weight != n.Weight)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            ExcelCSVRow n = obj as ExcelCSVRow;
            if ((System.Object)n == null)
            {
                return false;
            }

            if (!this.Equals(n))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(ExcelCSVRow a, ExcelCSVRow b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.RowNumber != b.RowNumber)
            {
                return false;
            }

            if (a.RecordType != b.RecordType)
            {
                return false;
            }

            if (a.RowType != b.RowType)
            {
                return false;
            }

            if (a.LastPageHeadingRowNumber != b.LastPageHeadingRowNumber)
            {
                return false;
            }

            if (a.LastGroupHeadingRowNumber != b.LastGroupHeadingRowNumber)
            {
                return false;
            }

            if (a.LastPropertyRowNumber != b.LastPropertyRowNumber)
            {
                return false;
            }

            if (a.RowLine != b.RowLine)
            {
                return false;
            }

            if (a.Weight != b.Weight)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(ExcelCSVRow a, ExcelCSVRow b)
        {
            return !(a == b);
        }

        #endregion

    }
}
