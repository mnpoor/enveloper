using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class JobSiteStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _jobSiteStatusId;
        private string _jobSiteStatusDescription;

        #endregion


        #region Constructor

        public JobSiteStatus()
        {
            this._jobSiteStatusId = 0;
            this._jobSiteStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public JobSiteStatus(JobSiteStatus j)
        {
            this._jobSiteStatusId = j.JobSiteStatusId;
            this._jobSiteStatusDescription = j.JobSiteStatusDescription;
            this._dateAdded = j.DateAdded;
            this._addedBy = j.AddedBy;
            this._dateUpdated = j.DateUpdated;
            this._updatedBy = j.UpdatedBy;
            this._rowUpdateVersion = j.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.JobSiteStatus;
            }
        }

        public int JobSiteStatusId
        {
            get
            {
                return this._jobSiteStatusId;
            }
            set
            {
                this._jobSiteStatusId = value;
                NotifyPropertyChanged("JobSiteStatusId");
            }
        }

        public string JobSiteStatusDescription
        {
            get
            {
                return this._jobSiteStatusDescription;
            }
            set
            {
                this._jobSiteStatusDescription = value;
                NotifyPropertyChanged("JobSiteStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(JobSiteStatus j)
        {
            #region Compare Members

            if (this._jobSiteStatusId != j.JobSiteStatusId)
            {
                return false;
            }

            if (this._jobSiteStatusDescription != j.JobSiteStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            JobSiteStatus j = obj as JobSiteStatus;
            if ((System.Object)j == null)
            {
                return false;
            }

            if (!this.Equals(j))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(JobSiteStatus a, JobSiteStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.JobSiteStatusId != b.JobSiteStatusId)
            {
                return false;
            }

            if (a.JobSiteStatusDescription != b.JobSiteStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(JobSiteStatus a, JobSiteStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
