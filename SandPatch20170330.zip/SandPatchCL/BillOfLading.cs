using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class BillOfLading : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _billOfLadingId;
        private int _customerId;
        private int _jobNumberId;
        private int _purchaseOrderId;
        private string _billOfLadingNumber;
        private int _carrierId;
        private int _driverId;
        private int _loadingTerminalId;
        private int _freightId;
        private string _ticketNumber;
        private int _jobSiteId;
        private int _billOfLadingStatusId;
        private DateTime _shipmentDate;
        private decimal _shipmentWeight;
        private string _billOfLadingComments;

        #endregion


        #region Constructor

        public BillOfLading()
        {
            this._billOfLadingId = 0;
            this._customerId = 0;
            this._jobNumberId = 0;
            this._purchaseOrderId = 0;
            this._billOfLadingNumber = string.Empty;
            this._carrierId = 0;
            this._driverId = 0;
            this._loadingTerminalId = 0;
            this._freightId = 0;
            this._ticketNumber = string.Empty;
            this._jobSiteId = 0;
            this._billOfLadingStatusId = 0;
            this._shipmentDate = new DateTime();
            this._shipmentWeight = 0;
            this._billOfLadingComments = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public BillOfLading(BillOfLading b)
        {
            this._billOfLadingId = b.BillOfLadingId;
            this._customerId = b.CustomerId;
            this._jobNumberId = b.JobNumberId;
            this._purchaseOrderId = b.PurchaseOrderId;
            this._billOfLadingNumber = b.BillOfLadingNumber;
            this._carrierId = b.CarrierId;
            this._driverId = b.DriverId;
            this._loadingTerminalId = b.LoadingTerminalId;
            this._freightId = b.FreightId;
            this._ticketNumber = b.TicketNumber;
            this._jobSiteId = b.JobSiteId;
            this._billOfLadingStatusId = b.BillOfLadingStatusId;
            this._shipmentDate = b.ShipmentDate;
            this._shipmentWeight = b.ShipmentWeight;
            this._billOfLadingComments = b.BillOfLadingComments;
            this._dateAdded = b.DateAdded;
            this._addedBy = b.AddedBy;
            this._dateUpdated = b.DateUpdated;
            this._updatedBy = b.UpdatedBy;
            this._rowUpdateVersion = b.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.BillOfLading;
            }
        }

        public int BillOfLadingId
        {
            get
            {
                return this._billOfLadingId;
            }
            set
            {
                this._billOfLadingId = value;
                NotifyPropertyChanged("BillOfLadingId");
            }
        }

        public int CustomerId
        {
            get
            {
                return this._customerId;
            }
            set
            {
                this._customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        public int JobNumberId
        {
            get
            {
                return this._jobNumberId;
            }
            set
            {
                this._jobNumberId = value;
                NotifyPropertyChanged("JobNumberId");
            }
        }

        public int PurchaseOrderId
        {
            get
            {
                return this._purchaseOrderId;
            }
            set
            {
                this._purchaseOrderId = value;
                NotifyPropertyChanged("PurchaseOrderId");
            }
        }

        public string BillOfLadingNumber
        {
            get
            {
                return this._billOfLadingNumber;
            }
            set
            {
                this._billOfLadingNumber = value;
                NotifyPropertyChanged("BillOfLadingNumber");
            }
        }

        public int CarrierId
        {
            get
            {
                return this._carrierId;
            }
            set
            {
                this._carrierId = value;
                NotifyPropertyChanged("CarrierId");
            }
        }

        public int DriverId
        {
            get
            {
                return this._driverId;
            }
            set
            {
                this._driverId = value;
                NotifyPropertyChanged("DriverId");
            }
        }

        public int LoadingTerminalId
        {
            get
            {
                return this._loadingTerminalId;
            }
            set
            {
                this._loadingTerminalId = value;
                NotifyPropertyChanged("LoadingTerminalId");
            }
        }

        public int FreightId
        {
            get
            {
                return this._freightId;
            }
            set
            {
                this._freightId = value;
                NotifyPropertyChanged("FreightId");
            }
        }

        public string TicketNumber
        {
            get
            {
                return this._ticketNumber;
            }
            set
            {
                this._ticketNumber = value;
                NotifyPropertyChanged("TicketNumber");
            }
        }

        public int JobSiteId
        {
            get
            {
                return this._jobSiteId;
            }
            set
            {
                this._jobSiteId = value;
                NotifyPropertyChanged("JobSiteId");
            }
        }

        public int BillOfLadingStatusId
        {
            get
            {
                return this._billOfLadingStatusId;
            }
            set
            {
                this._billOfLadingStatusId = value;
                NotifyPropertyChanged("BillOfLadingStatusId");
            }
        }

        public DateTime ShipmentDate
        {
            get
            {
                return this._shipmentDate;
            }
            set
            {
                this._shipmentDate = value;
                NotifyPropertyChanged("ShipmentDate");
            }
        }

        public decimal ShipmentWeight
        {
            get
            {
                return this._shipmentWeight;
            }
            set
            {
                this._shipmentWeight = value;
                NotifyPropertyChanged("ShipmentWeight");
            }
        }

        public string BillOfLadingComments
        {
            get
            {
                return this._billOfLadingComments;
            }
            set
            {
                this._billOfLadingComments = value;
                NotifyPropertyChanged("BillOfLadingComments");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(BillOfLading b)
        {
            #region Compare Members

            if (this._billOfLadingId != b.BillOfLadingId)
            {
                return false;
            }

            if (this._customerId != b.CustomerId)
            {
                return false;
            }

            if (this._jobNumberId != b.JobNumberId)
            {
                return false;
            }

            if (this._purchaseOrderId != b.PurchaseOrderId)
            {
                return false;
            }

            if (this._billOfLadingNumber != b.BillOfLadingNumber)
            {
                return false;
            }

            if (this._carrierId != b.CarrierId)
            {
                return false;
            }

            if (this._driverId != b.DriverId)
            {
                return false;
            }

            if (this._loadingTerminalId != b.LoadingTerminalId)
            {
                return false;
            }

            if (this._freightId != b.FreightId)
            {
                return false;
            }

            if (this._ticketNumber != b.TicketNumber)
            {
                return false;
            }

            if (this._jobSiteId != b.JobSiteId)
            {
                return false;
            }

            if (this._billOfLadingStatusId != b.BillOfLadingStatusId)
            {
                return false;
            }

            if (this._shipmentDate != b.ShipmentDate)
            {
                return false;
            }

            if (this._shipmentWeight != b.ShipmentWeight)
            {
                return false;
            }

            if (this._billOfLadingComments != b.BillOfLadingComments)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            BillOfLading b = obj as BillOfLading;
            if ((System.Object)b == null)
            {
                return false;
            }

            if (!this.Equals(b))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(BillOfLading a, BillOfLading b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.BillOfLadingId != b.BillOfLadingId)
            {
                return false;
            }

            if (a.CustomerId != b.CustomerId)
            {
                return false;
            }

            if (a.JobNumberId != b.JobNumberId)
            {
                return false;
            }

            if (a.PurchaseOrderId != b.PurchaseOrderId)
            {
                return false;
            }

            if (a.BillOfLadingNumber != b.BillOfLadingNumber)
            {
                return false;
            }

            if (a.CarrierId != b.CarrierId)
            {
                return false;
            }

            if (a.DriverId != b.DriverId)
            {
                return false;
            }

            if (a.LoadingTerminalId != b.LoadingTerminalId)
            {
                return false;
            }

            if (a.FreightId != b.FreightId)
            {
                return false;
            }

            if (a.TicketNumber != b.TicketNumber)
            {
                return false;
            }

            if (a.JobSiteId != b.JobSiteId)
            {
                return false;
            }

            if (a.BillOfLadingStatusId != b.BillOfLadingStatusId)
            {
                return false;
            }

            if (a.ShipmentDate != b.ShipmentDate)
            {
                return false;
            }

            if (a.ShipmentWeight != b.ShipmentWeight)
            {
                return false;
            }

            if (a.BillOfLadingComments != b.BillOfLadingComments)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(BillOfLading a, BillOfLading b)
        {
            return !(a == b);
        }

        #endregion

    }
}
