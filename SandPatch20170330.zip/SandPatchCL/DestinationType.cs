using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class DestinationType : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _destinationTypeId;
        private string _destinationTypeDescription;

        #endregion


        #region Constructor

        public DestinationType()
        {
            this._destinationTypeId = 0;
            this._destinationTypeDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public DestinationType(DestinationType d)
        {
            this._destinationTypeId = d.DestinationTypeId;
            this._destinationTypeDescription = d.DestinationTypeDescription;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.DestinationType;
            }
        }

        public int DestinationTypeId
        {
            get
            {
                return this._destinationTypeId;
            }
            set
            {
                this._destinationTypeId = value;
                NotifyPropertyChanged("DestinationTypeId");
            }
        }

        public string DestinationTypeDescription
        {
            get
            {
                return this._destinationTypeDescription;
            }
            set
            {
                this._destinationTypeDescription = value;
                NotifyPropertyChanged("DestinationTypeDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(DestinationType d)
        {
            #region Compare Members

            if (this._destinationTypeId != d.DestinationTypeId)
            {
                return false;
            }

            if (this._destinationTypeDescription != d.DestinationTypeDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            DestinationType d = obj as DestinationType;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(DestinationType a, DestinationType b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DestinationTypeId != b.DestinationTypeId)
            {
                return false;
            }

            if (a.DestinationTypeDescription != b.DestinationTypeDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(DestinationType a, DestinationType b)
        {
            return !(a == b);
        }

        #endregion

    }

}
