using System;

namespace SandPatchCL
{
    public delegate void SPEventHandler(object sender, SPEventArgs e);
}
