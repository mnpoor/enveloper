using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class LicensePlateStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _licensePlateStatusId;
        private string _licensePlateStatusDescription;

        #endregion


        #region Constructor

        public LicensePlateStatus()
        {
            this._licensePlateStatusId = 0;
            this._licensePlateStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public LicensePlateStatus(LicensePlateStatus l)
        {
            this._licensePlateStatusId = l.LicensePlateStatusId;
            this._licensePlateStatusDescription = l.LicensePlateStatusDescription;
            this._dateAdded = l.DateAdded;
            this._addedBy = l.AddedBy;
            this._dateUpdated = l.DateUpdated;
            this._updatedBy = l.UpdatedBy;
            this._rowUpdateVersion = l.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.LicensePlateStatus;
            }
        }

        public int LicensePlateStatusId
        {
            get
            {
                return this._licensePlateStatusId;
            }
            set
            {
                this._licensePlateStatusId = value;
                NotifyPropertyChanged("LicensePlateStatusId");
            }
        }

        public string LicensePlateStatusDescription
        {
            get
            {
                return this._licensePlateStatusDescription;
            }
            set
            {
                this._licensePlateStatusDescription = value;
                NotifyPropertyChanged("LicensePlateStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(LicensePlateStatus l)
        {
            #region Compare Members

            if (this._licensePlateStatusId != l.LicensePlateStatusId)
            {
                return false;
            }

            if (this._licensePlateStatusDescription != l.LicensePlateStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            LicensePlateStatus l = obj as LicensePlateStatus;
            if ((System.Object)l == null)
            {
                return false;
            }

            if (!this.Equals(l))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(LicensePlateStatus a, LicensePlateStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.LicensePlateStatusId != b.LicensePlateStatusId)
            {
                return false;
            }

            if (a.LicensePlateStatusDescription != b.LicensePlateStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(LicensePlateStatus a, LicensePlateStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
