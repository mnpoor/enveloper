using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Dispatch : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _dispatchId;
        private int _customerId;
        private int _jobNumberId;
        private int _purchaseOrderId;
        private string _dispatchAcceptanceNumber;
        private DateTime _dispatchAcceptanceDate;
        private int _carrierId;
        private int _driverId;
        private int _dispatchStatusId;
        private int _freightId;
        private int _loadingTerminalId;
        private DateTime _loadingTerminalAppointmentDateTime;
        private DateTime _actualLoadingTerminalArrivalTime;
        private DateTime _actualLoadingTerminalDepartureTime;
        private int _billOfLadingId;
        private string _billOfLadingNumber;
        private decimal _shipmentWeight;
        private string _ticketNumber;
        private int _jobSiteId;
        private DateTime _jobSiteDeliveryAppointmentDateTime;
        private DateTime _jobSiteActualArrivalTime;
        private DateTime _jobSiteActualDepartureTime;
        private int _dispatchMiles;
        private int _dispatchTotalHours;
        private string _dispatchComments;

        #endregion


        #region Constructor

        public Dispatch()
        {
            this._dispatchId = 0;
            this._customerId = 0;
            this._jobNumberId = 0;
            this._purchaseOrderId = 0;
            this._dispatchAcceptanceNumber = string.Empty;
            this._dispatchAcceptanceDate = new DateTime();
            this._carrierId = 0;
            this._driverId = 0;
            this._dispatchStatusId = 0;
            this._freightId = 0;
            this._loadingTerminalId = 0;
            this._loadingTerminalAppointmentDateTime = new DateTime();
            this._actualLoadingTerminalArrivalTime = new DateTime();
            this._actualLoadingTerminalDepartureTime = new DateTime();
            this._billOfLadingId = 0;
            this._billOfLadingNumber = string.Empty;
            this._shipmentWeight = 0;
            this._ticketNumber = string.Empty;
            this._jobSiteId = 0;
            this._jobSiteDeliveryAppointmentDateTime = new DateTime();
            this._jobSiteActualArrivalTime = new DateTime();
            this._jobSiteActualDepartureTime = new DateTime();
            this._dispatchMiles = 0;
            this._dispatchTotalHours = 0;
            this._dispatchComments = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Dispatch(Dispatch d)
        {
            this._dispatchId = d.DispatchId;
            this._customerId = d.CustomerId;
            this._jobNumberId = d.JobNumberId;
            this._purchaseOrderId = d.PurchaseOrderId;
            this._dispatchAcceptanceNumber = d.DispatchAcceptanceNumber;
            this._dispatchAcceptanceDate = d.DispatchAcceptanceDate;
            this._carrierId = d.CarrierId;
            this._driverId = d.DriverId;
            this._dispatchStatusId = d.DispatchStatusId;
            this._freightId = d.FreightId;
            this._loadingTerminalId = d.LoadingTerminalId;
            this._loadingTerminalAppointmentDateTime = d.LoadingTerminalAppointmentDateTime;
            this._actualLoadingTerminalArrivalTime = d.ActualLoadingTerminalArrivalTime;
            this._actualLoadingTerminalDepartureTime = d.ActualLoadingTerminalDepartureTime;
            this._billOfLadingId = d.BillOfLadingId;
            this._billOfLadingNumber = d.BillOfLadingNumber;
            this._shipmentWeight = d.ShipmentWeight;
            this._ticketNumber = d.TicketNumber;
            this._jobSiteId = d.JobSiteId;
            this._jobSiteDeliveryAppointmentDateTime = d.JobSiteDeliveryAppointmentDateTime;
            this._jobSiteActualArrivalTime = d.JobSiteActualArrivalTime;
            this._jobSiteActualDepartureTime = d.JobSiteActualDepartureTime;
            this._dispatchMiles = d.DispatchMiles;
            this._dispatchTotalHours = d.DispatchTotalHours;
            this._dispatchComments = d.DispatchComments;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Dispatch;
            }
        }

        public int DispatchId
        {
            get
            {
                return this._dispatchId;
            }
            set
            {
                this._dispatchId = value;
                NotifyPropertyChanged("DispatchId");
            }
        }

        public int CustomerId
        {
            get
            {
                return this._customerId;
            }
            set
            {
                this._customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        public int JobNumberId
        {
            get
            {
                return this._jobNumberId;
            }
            set
            {
                this._jobNumberId = value;
                NotifyPropertyChanged("JobNumberId");
            }
        }

        public int PurchaseOrderId
        {
            get
            {
                return this._purchaseOrderId;
            }
            set
            {
                this._purchaseOrderId = value;
                NotifyPropertyChanged("PurchaseOrderId");
            }
        }

        public string DispatchAcceptanceNumber
        {
            get
            {
                return this._dispatchAcceptanceNumber;
            }
            set
            {
                this._dispatchAcceptanceNumber = value;
                NotifyPropertyChanged("DispatchAcceptanceNumber");
            }
        }

        public DateTime DispatchAcceptanceDate
        {
            get
            {
                return this._dispatchAcceptanceDate;
            }
            set
            {
                this._dispatchAcceptanceDate = value;
                NotifyPropertyChanged("DispatchAcceptanceDate");
            }
        }

        public int CarrierId
        {
            get
            {
                return this._carrierId;
            }
            set
            {
                this._carrierId = value;
                NotifyPropertyChanged("CarrierId");
            }
        }

        public int DriverId
        {
            get
            {
                return this._driverId;
            }
            set
            {
                this._driverId = value;
                NotifyPropertyChanged("DriverId");
            }
        }

        public int DispatchStatusId
        {
            get
            {
                return this._dispatchStatusId;
            }
            set
            {
                this._dispatchStatusId = value;
                NotifyPropertyChanged("DispatchStatusId");
            }
        }

        public int FreightId
        {
            get
            {
                return this._freightId;
            }
            set
            {
                this._freightId = value;
                NotifyPropertyChanged("FreightId");
            }
        }

        public int LoadingTerminalId
        {
            get
            {
                return this._loadingTerminalId;
            }
            set
            {
                this._loadingTerminalId = value;
                NotifyPropertyChanged("LoadingTerminalId");
            }
        }

        public DateTime LoadingTerminalAppointmentDateTime
        {
            get
            {
                return this._loadingTerminalAppointmentDateTime;
            }
            set
            {
                this._loadingTerminalAppointmentDateTime = value;
                NotifyPropertyChanged("LoadingTerminalAppointmentDateTime");
            }
        }

        public DateTime ActualLoadingTerminalArrivalTime
        {
            get
            {
                return this._actualLoadingTerminalArrivalTime;
            }
            set
            {
                this._actualLoadingTerminalArrivalTime = value;
                NotifyPropertyChanged("ActualLoadingTerminalArrivalTime");
            }
        }

        public DateTime ActualLoadingTerminalDepartureTime
        {
            get
            {
                return this._actualLoadingTerminalDepartureTime;
            }
            set
            {
                this._actualLoadingTerminalDepartureTime = value;
                NotifyPropertyChanged("ActualLoadingTerminalDepartureTime");
            }
        }

        public int BillOfLadingId
        {
            get
            {
                return this._billOfLadingId;
            }
            set
            {
                this._billOfLadingId = value;
                NotifyPropertyChanged("BillOfLadingId");
            }
        }

        public string BillOfLadingNumber
        {
            get
            {
                return this._billOfLadingNumber;
            }
            set
            {
                this._billOfLadingNumber = value;
                NotifyPropertyChanged("BillOfLadingNumber");
            }
        }

        public decimal ShipmentWeight
        {
            get
            {
                return this._shipmentWeight;
            }
            set
            {
                this._shipmentWeight = value;
                NotifyPropertyChanged("ShipmentWeight");
            }
        }

        public string TicketNumber
        {
            get
            {
                return this._ticketNumber;
            }
            set
            {
                this._ticketNumber = value;
                NotifyPropertyChanged("TicketNumber");
            }
        }

        public int JobSiteId
        {
            get
            {
                return this._jobSiteId;
            }
            set
            {
                this._jobSiteId = value;
                NotifyPropertyChanged("JobSiteId");
            }
        }

        public DateTime JobSiteDeliveryAppointmentDateTime
        {
            get
            {
                return this._jobSiteDeliveryAppointmentDateTime;
            }
            set
            {
                this._jobSiteDeliveryAppointmentDateTime = value;
                NotifyPropertyChanged("JobSiteDeliveryAppointmentDateTime");
            }
        }

        public DateTime JobSiteActualArrivalTime
        {
            get
            {
                return this._jobSiteActualArrivalTime;
            }
            set
            {
                this._jobSiteActualArrivalTime = value;
                NotifyPropertyChanged("JobSiteActualArrivalTime");
            }
        }

        public DateTime JobSiteActualDepartureTime
        {
            get
            {
                return this._jobSiteActualDepartureTime;
            }
            set
            {
                this._jobSiteActualDepartureTime = value;
                NotifyPropertyChanged("JobSiteActualDepartureTime");
            }
        }

        public int DispatchMiles
        {
            get
            {
                return this._dispatchMiles;
            }
            set
            {
                this._dispatchMiles = value;
                NotifyPropertyChanged("DispatchMiles");
            }
        }

        public int DispatchTotalHours
        {
            get
            {
                return this._dispatchTotalHours;
            }
            set
            {
                this._dispatchTotalHours = value;
                NotifyPropertyChanged("DispatchTotalHours");
            }
        }

        public string DispatchComments
        {
            get
            {
                return this._dispatchComments;
            }
            set
            {
                this._dispatchComments = value;
                NotifyPropertyChanged("DispatchComments");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Dispatch d)
        {
            #region Compare Members

            if (this._dispatchId != d.DispatchId)
            {
                return false;
            }

            if (this._customerId != d.CustomerId)
            {
                return false;
            }

            if (this._jobNumberId != d.JobNumberId)
            {
                return false;
            }

            if (this._purchaseOrderId != d.PurchaseOrderId)
            {
                return false;
            }

            if (this._dispatchAcceptanceNumber != d.DispatchAcceptanceNumber)
            {
                return false;
            }

            if (this._dispatchAcceptanceDate != d.DispatchAcceptanceDate)
            {
                return false;
            }

            if (this._carrierId != d.CarrierId)
            {
                return false;
            }

            if (this._driverId != d.DriverId)
            {
                return false;
            }

            if (this._dispatchStatusId != d.DispatchStatusId)
            {
                return false;
            }

            if (this._freightId != d.FreightId)
            {
                return false;
            }

            if (this._loadingTerminalId != d.LoadingTerminalId)
            {
                return false;
            }

            if (this._loadingTerminalAppointmentDateTime != d.LoadingTerminalAppointmentDateTime)
            {
                return false;
            }

            if (this._actualLoadingTerminalArrivalTime != d.ActualLoadingTerminalArrivalTime)
            {
                return false;
            }

            if (this._actualLoadingTerminalDepartureTime != d.ActualLoadingTerminalDepartureTime)
            {
                return false;
            }

            if (this._billOfLadingId != d.BillOfLadingId)
            {
                return false;
            }

            if (this._billOfLadingNumber != d.BillOfLadingNumber)
            {
                return false;
            }

            if (this._shipmentWeight != d.ShipmentWeight)
            {
                return false;
            }

            if (this._ticketNumber != d.TicketNumber)
            {
                return false;
            }

            if (this._jobSiteId != d.JobSiteId)
            {
                return false;
            }

            if (this._jobSiteDeliveryAppointmentDateTime != d.JobSiteDeliveryAppointmentDateTime)
            {
                return false;
            }

            if (this._jobSiteActualArrivalTime != d.JobSiteActualArrivalTime)
            {
                return false;
            }

            if (this._jobSiteActualDepartureTime != d.JobSiteActualDepartureTime)
            {
                return false;
            }

            if (this._dispatchMiles != d.DispatchMiles)
            {
                return false;
            }

            if (this._dispatchTotalHours != d.DispatchTotalHours)
            {
                return false;
            }

            if (this._dispatchComments != d.DispatchComments)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Dispatch d = obj as Dispatch;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Dispatch a, Dispatch b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DispatchId != b.DispatchId)
            {
                return false;
            }

            if (a.CustomerId != b.CustomerId)
            {
                return false;
            }

            if (a.JobNumberId != b.JobNumberId)
            {
                return false;
            }

            if (a.PurchaseOrderId != b.PurchaseOrderId)
            {
                return false;
            }

            if (a.DispatchAcceptanceNumber != b.DispatchAcceptanceNumber)
            {
                return false;
            }

            if (a.DispatchAcceptanceDate != b.DispatchAcceptanceDate)
            {
                return false;
            }

            if (a.CarrierId != b.CarrierId)
            {
                return false;
            }

            if (a.DriverId != b.DriverId)
            {
                return false;
            }

            if (a.DispatchStatusId != b.DispatchStatusId)
            {
                return false;
            }

            if (a.FreightId != b.FreightId)
            {
                return false;
            }

            if (a.LoadingTerminalId != b.LoadingTerminalId)
            {
                return false;
            }

            if (a.LoadingTerminalAppointmentDateTime != b.LoadingTerminalAppointmentDateTime)
            {
                return false;
            }

            if (a.ActualLoadingTerminalArrivalTime != b.ActualLoadingTerminalArrivalTime)
            {
                return false;
            }

            if (a.ActualLoadingTerminalDepartureTime != b.ActualLoadingTerminalDepartureTime)
            {
                return false;
            }

            if (a.BillOfLadingId != b.BillOfLadingId)
            {
                return false;
            }

            if (a.BillOfLadingNumber != b.BillOfLadingNumber)
            {
                return false;
            }

            if (a.ShipmentWeight != b.ShipmentWeight)
            {
                return false;
            }

            if (a.TicketNumber != b.TicketNumber)
            {
                return false;
            }

            if (a.JobSiteId != b.JobSiteId)
            {
                return false;
            }

            if (a.JobSiteDeliveryAppointmentDateTime != b.JobSiteDeliveryAppointmentDateTime)
            {
                return false;
            }

            if (a.JobSiteActualArrivalTime != b.JobSiteActualArrivalTime)
            {
                return false;
            }

            if (a.JobSiteActualDepartureTime != b.JobSiteActualDepartureTime)
            {
                return false;
            }

            if (a.DispatchMiles != b.DispatchMiles)
            {
                return false;
            }

            if (a.DispatchTotalHours != b.DispatchTotalHours)
            {
                return false;
            }

            if (a.DispatchComments != b.DispatchComments)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Dispatch a, Dispatch b)
        {
            return !(a == b);
        }

        #endregion

    }
}
