using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class OriginType : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _originTypeId;
        private string _originTypeDescription;

        #endregion


        #region Constructor

        public OriginType()
        {
            this._originTypeId = 0;
            this._originTypeDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public OriginType(OriginType o)
        {
            this._originTypeId = o.OriginTypeId;
            this._originTypeDescription = o.OriginTypeDescription;
            this._dateAdded = o.DateAdded;
            this._addedBy = o.AddedBy;
            this._dateUpdated = o.DateUpdated;
            this._updatedBy = o.UpdatedBy;
            this._rowUpdateVersion = o.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.OriginType;
            }
        }

        public int OriginTypeId
        {
            get
            {
                return this._originTypeId;
            }
            set
            {
                this._originTypeId = value;
                NotifyPropertyChanged("OriginTypeId");
            }
        }

        public string OriginTypeDescription
        {
            get
            {
                return this._originTypeDescription;
            }
            set
            {
                this._originTypeDescription = value;
                NotifyPropertyChanged("OriginTypeDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(OriginType o)
        {
            #region Compare Members

            if (this._originTypeId != o.OriginTypeId)
            {
                return false;
            }

            if (this._originTypeDescription != o.OriginTypeDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            OriginType o = obj as OriginType;
            if ((System.Object)o == null)
            {
                return false;
            }

            if (!this.Equals(o))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(OriginType a, OriginType b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.OriginTypeId != b.OriginTypeId)
            {
                return false;
            }

            if (a.OriginTypeDescription != b.OriginTypeDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(OriginType a, OriginType b)
        {
            return !(a == b);
        }

        #endregion

    }

}
