using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class JobNumberStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _jobNumberStatusId;
        private string _jobNumberStatusDescription;

        #endregion


        #region Constructor

        public JobNumberStatus()
        {
            this._jobNumberStatusId = 0;
            this._jobNumberStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public JobNumberStatus(JobNumberStatus j)
        {
            this._jobNumberStatusId = j.JobNumberStatusId;
            this._jobNumberStatusDescription = j.JobNumberStatusDescription;
            this._dateAdded = j.DateAdded;
            this._addedBy = j.AddedBy;
            this._dateUpdated = j.DateUpdated;
            this._updatedBy = j.UpdatedBy;
            this._rowUpdateVersion = j.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.JobNumberStatus;
            }
        }

        public int JobNumberStatusId
        {
            get
            {
                return this._jobNumberStatusId;
            }
            set
            {
                this._jobNumberStatusId = value;
                NotifyPropertyChanged("JobNumberStatusId");
            }
        }

        public string JobNumberStatusDescription
        {
            get
            {
                return this._jobNumberStatusDescription;
            }
            set
            {
                this._jobNumberStatusDescription = value;
                NotifyPropertyChanged("JobNumberStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(JobNumberStatus j)
        {
            #region Compare Members

            if (this._jobNumberStatusId != j.JobNumberStatusId)
            {
                return false;
            }

            if (this._jobNumberStatusDescription != j.JobNumberStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            JobNumberStatus j = obj as JobNumberStatus;
            if ((System.Object)j == null)
            {
                return false;
            }

            if (!this.Equals(j))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(JobNumberStatus a, JobNumberStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.JobNumberStatusId != b.JobNumberStatusId)
            {
                return false;
            }

            if (a.JobNumberStatusDescription != b.JobNumberStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(JobNumberStatus a, JobNumberStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
