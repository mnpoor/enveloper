using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class DispatchStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _dispatchStatusId;
        private string _dispatchStatusDescription;
        private short _dispatchIncludeInOpenDispatches;

        #endregion


        #region Constructor

        public DispatchStatus()
        {
            this._dispatchStatusId = 0;
            this._dispatchStatusDescription = string.Empty;
            this._dispatchIncludeInOpenDispatches = (short)0;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public DispatchStatus(DispatchStatus d)
        {
            this._dispatchStatusId = d.DispatchStatusId;
            this._dispatchStatusDescription = d.DispatchStatusDescription;
            this._dispatchIncludeInOpenDispatches = d.DispatchIncludeInOpenDispatches;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.DispatchStatus;
            }
        }

        public int DispatchStatusId
        {
            get
            {
                return this._dispatchStatusId;
            }
            set
            {
                this._dispatchStatusId = value;
                NotifyPropertyChanged("DispatchStatusId");
            }
        }

        public string DispatchStatusDescription
        {
            get
            {
                return this._dispatchStatusDescription;
            }
            set
            {
                this._dispatchStatusDescription = value;
                NotifyPropertyChanged("DispatchStatusDescription");
            }
        }

        public short DispatchIncludeInOpenDispatches
        {
            get
            {
                return this._dispatchIncludeInOpenDispatches;
            }
            set
            {
                this._dispatchIncludeInOpenDispatches = value;
                NotifyPropertyChanged("DispatchIncludeInOpenDispatches");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(DispatchStatus d)
        {
            #region Compare Members

            if (this._dispatchStatusId != d.DispatchStatusId)
            {
                return false;
            }

            if (this._dispatchStatusDescription != d.DispatchStatusDescription)
            {
                return false;
            }

            if (this._dispatchIncludeInOpenDispatches != d.DispatchIncludeInOpenDispatches)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            DispatchStatus d = obj as DispatchStatus;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(DispatchStatus a, DispatchStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DispatchStatusId != b.DispatchStatusId)
            {
                return false;
            }

            if (a.DispatchStatusDescription != b.DispatchStatusDescription)
            {
                return false;
            }

            if (a.DispatchIncludeInOpenDispatches != b.DispatchIncludeInOpenDispatches)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(DispatchStatus a, DispatchStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
