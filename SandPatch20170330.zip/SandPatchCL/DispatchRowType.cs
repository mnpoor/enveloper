﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SandPatchCL
{
    public enum DispatchRowType
    {
        Unknown = 0,
        PageHeader = 1,
        AcquisitionRow = 2,
        ContactHeader = 3,
        ContactRow = 4,
        NotesHeader = 5,
        NotesRow = 6
    }
}
