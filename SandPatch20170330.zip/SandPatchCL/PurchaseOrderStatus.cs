using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class PurchaseOrderStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _purchaseOrderStatusId;
        private string _purchaseOrderStatusDescription;

        #endregion


        #region Constructor

        public PurchaseOrderStatus()
        {
            this._purchaseOrderStatusId = 0;
            this._purchaseOrderStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public PurchaseOrderStatus(PurchaseOrderStatus p)
        {
            this._purchaseOrderStatusId = p.PurchaseOrderStatusId;
            this._purchaseOrderStatusDescription = p.PurchaseOrderStatusDescription;
            this._dateAdded = p.DateAdded;
            this._addedBy = p.AddedBy;
            this._dateUpdated = p.DateUpdated;
            this._updatedBy = p.UpdatedBy;
            this._rowUpdateVersion = p.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.PurchaseOrderStatus;
            }
        }

        public int PurchaseOrderStatusId
        {
            get
            {
                return this._purchaseOrderStatusId;
            }
            set
            {
                this._purchaseOrderStatusId = value;
                NotifyPropertyChanged("PurchaseOrderStatusId");
            }
        }

        public string PurchaseOrderStatusDescription
        {
            get
            {
                return this._purchaseOrderStatusDescription;
            }
            set
            {
                this._purchaseOrderStatusDescription = value;
                NotifyPropertyChanged("PurchaseOrderStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(PurchaseOrderStatus p)
        {
            #region Compare Members

            if (this._purchaseOrderStatusId != p.PurchaseOrderStatusId)
            {
                return false;
            }

            if (this._purchaseOrderStatusDescription != p.PurchaseOrderStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            PurchaseOrderStatus p = obj as PurchaseOrderStatus;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (!this.Equals(p))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(PurchaseOrderStatus a, PurchaseOrderStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.PurchaseOrderStatusId != b.PurchaseOrderStatusId)
            {
                return false;
            }

            if (a.PurchaseOrderStatusDescription != b.PurchaseOrderStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(PurchaseOrderStatus a, PurchaseOrderStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
