using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Carrier : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _carrierId;
        private string _carrierCompanyName;
        private string _carrierStreetAddress;
        private string _carrierBoxAddress;
        private string _carrierCity;
        private string _carrierState;
        private string _carrierPostalCode;
        private int _carrierStatusId;
        private string _carrierPhoneNumber;
        private string _carrierFaxNumber;
        private string _carrierContactName;
        private string _carrierContactEmail;
        private string _carrierContactMobileNumber;
        private DateTime _carrierActivationDate;
        private DateTime _carrierSeveranceDate;
        private string _carrierNotes;

        #endregion


        #region Constructor

        public Carrier()
        {
            this._carrierId = 0;
            this._carrierCompanyName = string.Empty;
            this._carrierStreetAddress = string.Empty;
            this._carrierBoxAddress = string.Empty;
            this._carrierCity = string.Empty;
            this._carrierState = string.Empty;
            this._carrierPostalCode = string.Empty;
            this._carrierStatusId = 0;
            this._carrierPhoneNumber = string.Empty;
            this._carrierFaxNumber = string.Empty;
            this._carrierContactName = string.Empty;
            this._carrierContactEmail = string.Empty;
            this._carrierContactMobileNumber = string.Empty;
            this._carrierActivationDate = new DateTime();
            this._carrierSeveranceDate = new DateTime();
            this._carrierNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Carrier(Carrier c)
        {
            this._carrierId = c.CarrierId;
            this._carrierCompanyName = c.CarrierCompanyName;
            this._carrierStreetAddress = c.CarrierStreetAddress;
            this._carrierBoxAddress = c.CarrierBoxAddress;
            this._carrierCity = c.CarrierCity;
            this._carrierState = c.CarrierState;
            this._carrierPostalCode = c.CarrierPostalCode;
            this._carrierStatusId = c.CarrierStatusId;
            this._carrierPhoneNumber = c.CarrierPhoneNumber;
            this._carrierFaxNumber = c.CarrierFaxNumber;
            this._carrierContactName = c.CarrierContactName;
            this._carrierContactEmail = c.CarrierContactEmail;
            this._carrierContactMobileNumber = c.CarrierContactMobileNumber;
            this._carrierActivationDate = c.CarrierActivationDate;
            this._carrierSeveranceDate = c.CarrierSeveranceDate;
            this._carrierNotes = c.CarrierNotes;
            this._dateAdded = c.DateAdded;
            this._addedBy = c.AddedBy;
            this._dateUpdated = c.DateUpdated;
            this._updatedBy = c.UpdatedBy;
            this._rowUpdateVersion = c.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Carrier;
            }
        }

        public int CarrierId
        {
            get
            {
                return this._carrierId;
            }
            set
            {
                this._carrierId = value;
                NotifyPropertyChanged("CarrierId");
            }
        }

        public string CarrierCompanyName
        {
            get
            {
                return this._carrierCompanyName;
            }
            set
            {
                this._carrierCompanyName = value;
                NotifyPropertyChanged("CarrierCompanyName");
            }
        }

        public string CarrierStreetAddress
        {
            get
            {
                return this._carrierStreetAddress;
            }
            set
            {
                this._carrierStreetAddress = value;
                NotifyPropertyChanged("CarrierStreetAddress");
            }
        }

        public string CarrierBoxAddress
        {
            get
            {
                return this._carrierBoxAddress;
            }
            set
            {
                this._carrierBoxAddress = value;
                NotifyPropertyChanged("CarrierBoxAddress");
            }
        }

        public string CarrierCity
        {
            get
            {
                return this._carrierCity;
            }
            set
            {
                this._carrierCity = value;
                NotifyPropertyChanged("CarrierCity");
            }
        }

        public string CarrierState
        {
            get
            {
                return this._carrierState;
            }
            set
            {
                this._carrierState = value;
                NotifyPropertyChanged("CarrierState");
            }
        }

        public string CarrierPostalCode
        {
            get
            {
                return this._carrierPostalCode;
            }
            set
            {
                this._carrierPostalCode = value;
                NotifyPropertyChanged("CarrierPostalCode");
            }
        }

        public int CarrierStatusId
        {
            get
            {
                return this._carrierStatusId;
            }
            set
            {
                this._carrierStatusId = value;
                NotifyPropertyChanged("CarrierStatusId");
            }
        }

        public string CarrierPhoneNumber
        {
            get
            {
                return this._carrierPhoneNumber;
            }
            set
            {
                this._carrierPhoneNumber = value;
                NotifyPropertyChanged("CarrierPhoneNumber");
            }
        }

        public string CarrierFaxNumber
        {
            get
            {
                return this._carrierFaxNumber;
            }
            set
            {
                this._carrierFaxNumber = value;
                NotifyPropertyChanged("CarrierFaxNumber");
            }
        }

        public string CarrierContactName
        {
            get
            {
                return this._carrierContactName;
            }
            set
            {
                this._carrierContactName = value;
                NotifyPropertyChanged("CarrierContactName");
            }
        }

        public string CarrierContactEmail
        {
            get
            {
                return this._carrierContactEmail;
            }
            set
            {
                this._carrierContactEmail = value;
                NotifyPropertyChanged("CarrierContactEmail");
            }
        }

        public string CarrierContactMobileNumber
        {
            get
            {
                return this._carrierContactMobileNumber;
            }
            set
            {
                this._carrierContactMobileNumber = value;
                NotifyPropertyChanged("CarrierContactMobileNumber");
            }
        }

        public DateTime CarrierActivationDate
        {
            get
            {
                return this._carrierActivationDate;
            }
            set
            {
                this._carrierActivationDate = value;
                NotifyPropertyChanged("CarrierActivationDate");
            }
        }

        public DateTime CarrierSeveranceDate
        {
            get
            {
                return this._carrierSeveranceDate;
            }
            set
            {
                this._carrierSeveranceDate = value;
                NotifyPropertyChanged("CarrierSeveranceDate");
            }
        }

        public string CarrierNotes
        {
            get
            {
                return this._carrierNotes;
            }
            set
            {
                this._carrierNotes = value;
                NotifyPropertyChanged("CarrierNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Carrier c)
        {
            #region Compare Members

            if (this._carrierId != c.CarrierId)
            {
                return false;
            }

            if (this._carrierCompanyName != c.CarrierCompanyName)
            {
                return false;
            }

            if (this._carrierStreetAddress != c.CarrierStreetAddress)
            {
                return false;
            }

            if (this._carrierBoxAddress != c.CarrierBoxAddress)
            {
                return false;
            }

            if (this._carrierCity != c.CarrierCity)
            {
                return false;
            }

            if (this._carrierState != c.CarrierState)
            {
                return false;
            }

            if (this._carrierPostalCode != c.CarrierPostalCode)
            {
                return false;
            }

            if (this._carrierStatusId != c.CarrierStatusId)
            {
                return false;
            }

            if (this._carrierPhoneNumber != c.CarrierPhoneNumber)
            {
                return false;
            }

            if (this._carrierFaxNumber != c.CarrierFaxNumber)
            {
                return false;
            }

            if (this._carrierContactName != c.CarrierContactName)
            {
                return false;
            }

            if (this._carrierContactEmail != c.CarrierContactEmail)
            {
                return false;
            }

            if (this._carrierContactMobileNumber != c.CarrierContactMobileNumber)
            {
                return false;
            }

            if (this._carrierActivationDate != c.CarrierActivationDate)
            {
                return false;
            }

            if (this._carrierSeveranceDate != c.CarrierSeveranceDate)
            {
                return false;
            }

            if (this._carrierNotes != c.CarrierNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Carrier c = obj as Carrier;
            if ((System.Object)c == null)
            {
                return false;
            }

            if (!this.Equals(c))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Carrier a, Carrier b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.CarrierId != b.CarrierId)
            {
                return false;
            }

            if (a.CarrierCompanyName != b.CarrierCompanyName)
            {
                return false;
            }

            if (a.CarrierStreetAddress != b.CarrierStreetAddress)
            {
                return false;
            }

            if (a.CarrierBoxAddress != b.CarrierBoxAddress)
            {
                return false;
            }

            if (a.CarrierCity != b.CarrierCity)
            {
                return false;
            }

            if (a.CarrierState != b.CarrierState)
            {
                return false;
            }

            if (a.CarrierPostalCode != b.CarrierPostalCode)
            {
                return false;
            }

            if (a.CarrierStatusId != b.CarrierStatusId)
            {
                return false;
            }

            if (a.CarrierPhoneNumber != b.CarrierPhoneNumber)
            {
                return false;
            }

            if (a.CarrierFaxNumber != b.CarrierFaxNumber)
            {
                return false;
            }

            if (a.CarrierContactName != b.CarrierContactName)
            {
                return false;
            }

            if (a.CarrierContactEmail != b.CarrierContactEmail)
            {
                return false;
            }

            if (a.CarrierContactMobileNumber != b.CarrierContactMobileNumber)
            {
                return false;
            }

            if (a.CarrierActivationDate != b.CarrierActivationDate)
            {
                return false;
            }

            if (a.CarrierSeveranceDate != b.CarrierSeveranceDate)
            {
                return false;
            }

            if (a.CarrierNotes != b.CarrierNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Carrier a, Carrier b)
        {
            return !(a == b);
        }

        #endregion

    }

}
