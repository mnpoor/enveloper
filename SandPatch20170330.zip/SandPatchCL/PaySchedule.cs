using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class PaySchedule : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _payScheduleId;
        private DateTime _payPeriodStartDate;
        private DateTime _payPeriodEndDate;
        private DateTime _tripPacketsArrivalDeadline;
        private DateTime _payDate;
        private string _payScheduleNotes;

        #endregion


        #region Constructor

        public PaySchedule()
        {
            this._payScheduleId = 0;
            this._payPeriodStartDate = new DateTime();
            this._payPeriodEndDate = new DateTime();
            this._tripPacketsArrivalDeadline = new DateTime();
            this._payDate = new DateTime();
            this._payScheduleNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public PaySchedule(PaySchedule p)
        {
            this._payScheduleId = p.PayScheduleId;
            this._payPeriodStartDate = p.PayPeriodStartDate;
            this._payPeriodEndDate = p.PayPeriodEndDate;
            this._tripPacketsArrivalDeadline = p.TripPacketsArrivalDeadline;
            this._payDate = p.PayDate;
            this._payScheduleNotes = p.PayScheduleNotes;
            this._dateAdded = p.DateAdded;
            this._addedBy = p.AddedBy;
            this._dateUpdated = p.DateUpdated;
            this._updatedBy = p.UpdatedBy;
            this._rowUpdateVersion = p.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.PaySchedule;
            }
        }

        public int PayScheduleId
        {
            get
            {
                return this._payScheduleId;
            }
            set
            {
                this._payScheduleId = value;
                NotifyPropertyChanged("PayScheduleId");
            }
        }

        public DateTime PayPeriodStartDate
        {
            get
            {
                return this._payPeriodStartDate;
            }
            set
            {
                this._payPeriodStartDate = value;
                NotifyPropertyChanged("PayPeriodStartDate");
            }
        }

        public DateTime PayPeriodEndDate
        {
            get
            {
                return this._payPeriodEndDate;
            }
            set
            {
                this._payPeriodEndDate = value;
                NotifyPropertyChanged("PayPeriodEndDate");
            }
        }

        public DateTime TripPacketsArrivalDeadline
        {
            get
            {
                return this._tripPacketsArrivalDeadline;
            }
            set
            {
                this._tripPacketsArrivalDeadline = value;
                NotifyPropertyChanged("TripPacketsArrivalDeadline");
            }
        }

        public DateTime PayDate
        {
            get
            {
                return this._payDate;
            }
            set
            {
                this._payDate = value;
                NotifyPropertyChanged("PayDate");
            }
        }

        public string PayScheduleNotes
        {
            get
            {
                return this._payScheduleNotes;
            }
            set
            {
                this._payScheduleNotes = value;
                NotifyPropertyChanged("PayScheduleNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(PaySchedule p)
        {
            #region Compare Members

            if (this._payScheduleId != p.PayScheduleId)
            {
                return false;
            }

            if (this._payPeriodStartDate != p.PayPeriodStartDate)
            {
                return false;
            }

            if (this._payPeriodEndDate != p.PayPeriodEndDate)
            {
                return false;
            }

            if (this._tripPacketsArrivalDeadline != p.TripPacketsArrivalDeadline)
            {
                return false;
            }

            if (this._payDate != p.PayDate)
            {
                return false;
            }

            if (this._payScheduleNotes != p.PayScheduleNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            PaySchedule p = obj as PaySchedule;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (!this.Equals(p))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(PaySchedule a, PaySchedule b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.PayScheduleId != b.PayScheduleId)
            {
                return false;
            }

            if (a.PayPeriodStartDate != b.PayPeriodStartDate)
            {
                return false;
            }

            if (a.PayPeriodEndDate != b.PayPeriodEndDate)
            {
                return false;
            }

            if (a.TripPacketsArrivalDeadline != b.TripPacketsArrivalDeadline)
            {
                return false;
            }

            if (a.PayDate != b.PayDate)
            {
                return false;
            }

            if (a.PayScheduleNotes != b.PayScheduleNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(PaySchedule a, PaySchedule b)
        {
            return !(a == b);
        }

        #endregion

    }

}
