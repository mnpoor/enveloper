using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Invoice : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _invoiceId;
        private string _invoiceNumber;
        private DateTime _invoiceDate;
        private int _shipperBillingId;
        private int _billToCustomerId;
        private int _originTypeId;
        private int _originId;
        private int _destinationTypeId;
        private int _destinationId;
        private string _chargeCode;
        private int _paymentTermsId;
        private int _billOfLadingId;
        private int _dispatchId;
        private decimal _invoiceSubtotalAmount;
        private decimal _invoiceAdjustmentsAmount;
        private decimal _invoiceTotalAmount;

        #endregion


        #region Constructor

        public Invoice()
        {
            this._invoiceId = 0;
            this._invoiceNumber = string.Empty;
            this._invoiceDate = new DateTime();
            this._shipperBillingId = 0;
            this._billToCustomerId = 0;
            this._originTypeId = 0;
            this._originId = 0;
            this._destinationTypeId = 0;
            this._destinationId = 0;
            this._chargeCode = string.Empty;
            this._paymentTermsId = 0;
            this._billOfLadingId = 0;
            this._dispatchId = 0;
            this._invoiceSubtotalAmount = 0;
            this._invoiceAdjustmentsAmount = 0;
            this._invoiceTotalAmount = 0;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Invoice(Invoice i)
        {
            this._invoiceId = i.InvoiceId;
            this._invoiceNumber = i.InvoiceNumber;
            this._invoiceDate = i.InvoiceDate;
            this._shipperBillingId = i.ShipperBillingId;
            this._billToCustomerId = i.BillToCustomerId;
            this._originTypeId = i.OriginTypeId;
            this._originId = i.OriginId;
            this._destinationTypeId = i.DestinationTypeId;
            this._destinationId = i.DestinationId;
            this._chargeCode = i.ChargeCode;
            this._paymentTermsId = i.PaymentTermsId;
            this._billOfLadingId = i.BillOfLadingId;
            this._dispatchId = i.DispatchId;
            this._invoiceSubtotalAmount = i.InvoiceSubtotalAmount;
            this._invoiceAdjustmentsAmount = i.InvoiceAdjustmentsAmount;
            this._invoiceTotalAmount = i.InvoiceTotalAmount;
            this._dateAdded = i.DateAdded;
            this._addedBy = i.AddedBy;
            this._dateUpdated = i.DateUpdated;
            this._updatedBy = i.UpdatedBy;
            this._rowUpdateVersion = i.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Invoice;
            }
        }

        public int InvoiceId
        {
            get
            {
                return this._invoiceId;
            }
            set
            {
                this._invoiceId = value;
                NotifyPropertyChanged("InvoiceId");
            }
        }

        public string InvoiceNumber
        {
            get
            {
                return this._invoiceNumber;
            }
            set
            {
                this._invoiceNumber = value;
                NotifyPropertyChanged("InvoiceNumber");
            }
        }

        public DateTime InvoiceDate
        {
            get
            {
                return this._invoiceDate;
            }
            set
            {
                this._invoiceDate = value;
                NotifyPropertyChanged("InvoiceDate");
            }
        }

        public int ShipperBillingId
        {
            get
            {
                return this._shipperBillingId;
            }
            set
            {
                this._shipperBillingId = value;
                NotifyPropertyChanged("ShipperBillingId");
            }
        }

        public int BillToCustomerId
        {
            get
            {
                return this._billToCustomerId;
            }
            set
            {
                this._billToCustomerId = value;
                NotifyPropertyChanged("BillToCustomerId");
            }
        }

        public int OriginTypeId
        {
            get
            {
                return this._originTypeId;
            }
            set
            {
                this._originTypeId = value;
                NotifyPropertyChanged("OriginTypeId");
            }
        }

        public int OriginId
        {
            get
            {
                return this._originId;
            }
            set
            {
                this._originId = value;
                NotifyPropertyChanged("OriginId");
            }
        }

        public int DestinationTypeId
        {
            get
            {
                return this._destinationTypeId;
            }
            set
            {
                this._destinationTypeId = value;
                NotifyPropertyChanged("DestinationTypeId");
            }
        }

        public int DestinationId
        {
            get
            {
                return this._destinationId;
            }
            set
            {
                this._destinationId = value;
                NotifyPropertyChanged("DestinationId");
            }
        }

        public string ChargeCode
        {
            get
            {
                return this._chargeCode;
            }
            set
            {
                this._chargeCode = value;
                NotifyPropertyChanged("ChargeCode");
            }
        }

        public int PaymentTermsId
        {
            get
            {
                return this._paymentTermsId;
            }
            set
            {
                this._paymentTermsId = value;
                NotifyPropertyChanged("PaymentTermsId");
            }
        }

        public int BillOfLadingId
        {
            get
            {
                return this._billOfLadingId;
            }
            set
            {
                this._billOfLadingId = value;
                NotifyPropertyChanged("BillOfLadingId");
            }
        }

        public int DispatchId
        {
            get
            {
                return this._dispatchId;
            }
            set
            {
                this._dispatchId = value;
                NotifyPropertyChanged("DispatchId");
            }
        }

        public decimal InvoiceSubtotalAmount
        {
            get
            {
                return this._invoiceSubtotalAmount;
            }
            set
            {
                this._invoiceSubtotalAmount = value;
                NotifyPropertyChanged("InvoiceSubtotalAmount");
            }
        }

        public decimal InvoiceAdjustmentsAmount
        {
            get
            {
                return this._invoiceAdjustmentsAmount;
            }
            set
            {
                this._invoiceAdjustmentsAmount = value;
                NotifyPropertyChanged("InvoiceAdjustmentsAmount");
            }
        }

        public decimal InvoiceTotalAmount
        {
            get
            {
                return this._invoiceTotalAmount;
            }
            set
            {
                this._invoiceTotalAmount = value;
                NotifyPropertyChanged("InvoiceTotalAmount");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Invoice i)
        {
            #region Compare Members

            if (this._invoiceId != i.InvoiceId)
            {
                return false;
            }

            if (this._invoiceNumber != i.InvoiceNumber)
            {
                return false;
            }

            if (this._invoiceDate != i.InvoiceDate)
            {
                return false;
            }

            if (this._shipperBillingId != i.ShipperBillingId)
            {
                return false;
            }

            if (this._billToCustomerId != i.BillToCustomerId)
            {
                return false;
            }

            if (this._originTypeId != i.OriginTypeId)
            {
                return false;
            }

            if (this._originId != i.OriginId)
            {
                return false;
            }

            if (this._destinationTypeId != i.DestinationTypeId)
            {
                return false;
            }

            if (this._destinationId != i.DestinationId)
            {
                return false;
            }

            if (this._chargeCode != i.ChargeCode)
            {
                return false;
            }

            if (this._paymentTermsId != i.PaymentTermsId)
            {
                return false;
            }

            if (this._billOfLadingId != i.BillOfLadingId)
            {
                return false;
            }

            if (this._dispatchId != i.DispatchId)
            {
                return false;
            }

            if (this._invoiceSubtotalAmount != i.InvoiceSubtotalAmount)
            {
                return false;
            }

            if (this._invoiceAdjustmentsAmount != i.InvoiceAdjustmentsAmount)
            {
                return false;
            }

            if (this._invoiceTotalAmount != i.InvoiceTotalAmount)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Invoice i = obj as Invoice;
            if ((System.Object)i == null)
            {
                return false;
            }

            if (!this.Equals(i))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Invoice a, Invoice b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.InvoiceId != b.InvoiceId)
            {
                return false;
            }

            if (a.InvoiceNumber != b.InvoiceNumber)
            {
                return false;
            }

            if (a.InvoiceDate != b.InvoiceDate)
            {
                return false;
            }

            if (a.ShipperBillingId != b.ShipperBillingId)
            {
                return false;
            }

            if (a.BillToCustomerId != b.BillToCustomerId)
            {
                return false;
            }

            if (a.OriginTypeId != b.OriginTypeId)
            {
                return false;
            }

            if (a.OriginId != b.OriginId)
            {
                return false;
            }

            if (a.DestinationTypeId != b.DestinationTypeId)
            {
                return false;
            }

            if (a.DestinationId != b.DestinationId)
            {
                return false;
            }

            if (a.ChargeCode != b.ChargeCode)
            {
                return false;
            }

            if (a.PaymentTermsId != b.PaymentTermsId)
            {
                return false;
            }

            if (a.BillOfLadingId != b.BillOfLadingId)
            {
                return false;
            }

            if (a.DispatchId != b.DispatchId)
            {
                return false;
            }

            if (a.InvoiceSubtotalAmount != b.InvoiceSubtotalAmount)
            {
                return false;
            }

            if (a.InvoiceAdjustmentsAmount != b.InvoiceAdjustmentsAmount)
            {
                return false;
            }

            if (a.InvoiceTotalAmount != b.InvoiceTotalAmount)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Invoice a, Invoice b)
        {
            return !(a == b);
        }

        #endregion

    }

}
