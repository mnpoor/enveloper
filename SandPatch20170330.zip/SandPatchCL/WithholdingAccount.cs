using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class WithholdingAccount : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _withholdingId;
        private string _withholdingAccountName;
        private string _withholdingSummaryAccountNumber;

        #endregion


        #region Constructor

        public WithholdingAccount()
        {
            this._withholdingId = 0;
            this._withholdingAccountName = string.Empty;
            this._withholdingSummaryAccountNumber = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public WithholdingAccount(WithholdingAccount w)
        {
            this._withholdingId = w.WithholdingId;
            this._withholdingAccountName = w.WithholdingAccountName;
            this._withholdingSummaryAccountNumber = w.WithholdingSummaryAccountNumber;
            this._dateAdded = w.DateAdded;
            this._addedBy = w.AddedBy;
            this._dateUpdated = w.DateUpdated;
            this._updatedBy = w.UpdatedBy;
            this._rowUpdateVersion = w.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.WithholdingAccount;
            }
        }

        public int WithholdingId
        {
            get
            {
                return this._withholdingId;
            }
            set
            {
                this._withholdingId = value;
                NotifyPropertyChanged("WithholdingId");
            }
        }

        public string WithholdingAccountName
        {
            get
            {
                return this._withholdingAccountName;
            }
            set
            {
                this._withholdingAccountName = value;
                NotifyPropertyChanged("WithholdingAccountName");
            }
        }

        public string WithholdingSummaryAccountNumber
        {
            get
            {
                return this._withholdingSummaryAccountNumber;
            }
            set
            {
                this._withholdingSummaryAccountNumber = value;
                NotifyPropertyChanged("WithholdingSummaryAccountNumber");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(WithholdingAccount w)
        {
            #region Compare Members

            if (this._withholdingId != w.WithholdingId)
            {
                return false;
            }

            if (this._withholdingAccountName != w.WithholdingAccountName)
            {
                return false;
            }

            if (this._withholdingSummaryAccountNumber != w.WithholdingSummaryAccountNumber)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            WithholdingAccount w = obj as WithholdingAccount;
            if ((System.Object)w == null)
            {
                return false;
            }

            if (!this.Equals(w))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(WithholdingAccount a, WithholdingAccount b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.WithholdingId != b.WithholdingId)
            {
                return false;
            }

            if (a.WithholdingAccountName != b.WithholdingAccountName)
            {
                return false;
            }

            if (a.WithholdingSummaryAccountNumber != b.WithholdingSummaryAccountNumber)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(WithholdingAccount a, WithholdingAccount b)
        {
            return !(a == b);
        }

        #endregion

    }

}
