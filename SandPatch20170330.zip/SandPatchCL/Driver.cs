using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Driver : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _driverId;
        private int _truckNumber;
        private int _carrierId;
        private string _driverName;
        private string _driverStreetAddress;
        private string _driverBoxAddress;
        private string _driverCity;
        private string _driverState;
        private string _driverPostalCode;
        private string _driverTelephoneNumber;
        private string _driverEmail;
        private int _driverStatusId;
        private DateTime _driverStartDate;
        private DateTime _driverSeveranceDate;
        private int _fuelCardStatusId;
        private int _licensePlateStatusId;
        private string _driverNotes;

        #endregion


        #region Constructor

        public Driver()
        {
            this._driverId = 0;
            this._truckNumber = 0;
            this._carrierId = 0;
            this._driverName = string.Empty;
            this._driverStreetAddress = string.Empty;
            this._driverBoxAddress = string.Empty;
            this._driverCity = string.Empty;
            this._driverState = string.Empty;
            this._driverPostalCode = string.Empty;
            this._driverTelephoneNumber = string.Empty;
            this._driverEmail = string.Empty;
            this._driverStatusId = 0;
            this._driverStartDate = new DateTime();
            this._driverSeveranceDate = new DateTime();
            this._fuelCardStatusId = 0;
            this._licensePlateStatusId = 0;
            this._driverNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Driver(Driver d)
        {
            this._driverId = d.DriverId;
            this._truckNumber = d.TruckNumber;
            this._carrierId = d.CarrierId;
            this._driverName = d.DriverName;
            this._driverStreetAddress = d.DriverStreetAddress;
            this._driverBoxAddress = d.DriverBoxAddress;
            this._driverCity = d.DriverCity;
            this._driverState = d.DriverState;
            this._driverPostalCode = d.DriverPostalCode;
            this._driverTelephoneNumber = d.DriverTelephoneNumber;
            this._driverEmail = d.DriverEmail;
            this._driverStatusId = d.DriverStatusId;
            this._driverStartDate = d.DriverStartDate;
            this._driverSeveranceDate = d.DriverSeveranceDate;
            this._fuelCardStatusId = d.FuelCardStatusId;
            this._licensePlateStatusId = d.LicensePlateStatusId;
            this._driverNotes = d.DriverNotes;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Driver;
            }
        }

        public int DriverId
        {
            get
            {
                return this._driverId;
            }
            set
            {
                this._driverId = value;
                NotifyPropertyChanged("DriverId");
            }
        }

        public int TruckNumber
        {
            get
            {
                return this._truckNumber;
            }
            set
            {
                this._truckNumber = value;
                NotifyPropertyChanged("TruckNumber");
            }
        }

        public int CarrierId
        {
            get
            {
                return this._carrierId;
            }
            set
            {
                this._carrierId = value;
                NotifyPropertyChanged("CarrierId");
            }
        }

        public string DriverName
        {
            get
            {
                return this._driverName;
            }
            set
            {
                this._driverName = value;
                NotifyPropertyChanged("DriverName");
            }
        }

        public string DriverStreetAddress
        {
            get
            {
                return this._driverStreetAddress;
            }
            set
            {
                this._driverStreetAddress = value;
                NotifyPropertyChanged("DriverStreetAddress");
            }
        }

        public string DriverBoxAddress
        {
            get
            {
                return this._driverBoxAddress;
            }
            set
            {
                this._driverBoxAddress = value;
                NotifyPropertyChanged("DriverBoxAddress");
            }
        }

        public string DriverCity
        {
            get
            {
                return this._driverCity;
            }
            set
            {
                this._driverCity = value;
                NotifyPropertyChanged("DriverCity");
            }
        }

        public string DriverState
        {
            get
            {
                return this._driverState;
            }
            set
            {
                this._driverState = value;
                NotifyPropertyChanged("DriverState");
            }
        }

        public string DriverPostalCode
        {
            get
            {
                return this._driverPostalCode;
            }
            set
            {
                this._driverPostalCode = value;
                NotifyPropertyChanged("DriverPostalCode");
            }
        }

        public string DriverTelephoneNumber
        {
            get
            {
                return this._driverTelephoneNumber;
            }
            set
            {
                this._driverTelephoneNumber = value;
                NotifyPropertyChanged("DriverTelephoneNumber");
            }
        }

        public string DriverEmail
        {
            get
            {
                return this._driverEmail;
            }
            set
            {
                this._driverEmail = value;
                NotifyPropertyChanged("DriverEmail");
            }
        }

        public int DriverStatusId
        {
            get
            {
                return this._driverStatusId;
            }
            set
            {
                this._driverStatusId = value;
                NotifyPropertyChanged("DriverStatusId");
            }
        }

        public DateTime DriverStartDate
        {
            get
            {
                return this._driverStartDate;
            }
            set
            {
                this._driverStartDate = value;
                NotifyPropertyChanged("DriverStartDate");
            }
        }

        public DateTime DriverSeveranceDate
        {
            get
            {
                return this._driverSeveranceDate;
            }
            set
            {
                this._driverSeveranceDate = value;
                NotifyPropertyChanged("DriverSeveranceDate");
            }
        }

        public int FuelCardStatusId
        {
            get
            {
                return this._fuelCardStatusId;
            }
            set
            {
                this._fuelCardStatusId = value;
                NotifyPropertyChanged("FuelCardStatusId");
            }
        }

        public int LicensePlateStatusId
        {
            get
            {
                return this._licensePlateStatusId;
            }
            set
            {
                this._licensePlateStatusId = value;
                NotifyPropertyChanged("LicensePlateStatusId");
            }
        }

        public string DriverNotes
        {
            get
            {
                return this._driverNotes;
            }
            set
            {
                this._driverNotes = value;
                NotifyPropertyChanged("DriverNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Driver d)
        {
            #region Compare Members

            if (this._driverId != d.DriverId)
            {
                return false;
            }

            if (this._truckNumber != d.TruckNumber)
            {
                return false;
            }

            if (this._carrierId != d.CarrierId)
            {
                return false;
            }

            if (this._driverName != d.DriverName)
            {
                return false;
            }

            if (this._driverStreetAddress != d.DriverStreetAddress)
            {
                return false;
            }

            if (this._driverBoxAddress != d.DriverBoxAddress)
            {
                return false;
            }

            if (this._driverCity != d.DriverCity)
            {
                return false;
            }

            if (this._driverState != d.DriverState)
            {
                return false;
            }

            if (this._driverPostalCode != d.DriverPostalCode)
            {
                return false;
            }

            if (this._driverTelephoneNumber != d.DriverTelephoneNumber)
            {
                return false;
            }

            if (this._driverEmail != d.DriverEmail)
            {
                return false;
            }

            if (this._driverStatusId != d.DriverStatusId)
            {
                return false;
            }

            if (this._driverStartDate != d.DriverStartDate)
            {
                return false;
            }

            if (this._driverSeveranceDate != d.DriverSeveranceDate)
            {
                return false;
            }

            if (this._fuelCardStatusId != d.FuelCardStatusId)
            {
                return false;
            }

            if (this._licensePlateStatusId != d.LicensePlateStatusId)
            {
                return false;
            }

            if (this._driverNotes != d.DriverNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Driver d = obj as Driver;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Driver a, Driver b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DriverId != b.DriverId)
            {
                return false;
            }

            if (a.TruckNumber != b.TruckNumber)
            {
                return false;
            }

            if (a.CarrierId != b.CarrierId)
            {
                return false;
            }

            if (a.DriverName != b.DriverName)
            {
                return false;
            }

            if (a.DriverStreetAddress != b.DriverStreetAddress)
            {
                return false;
            }

            if (a.DriverBoxAddress != b.DriverBoxAddress)
            {
                return false;
            }

            if (a.DriverCity != b.DriverCity)
            {
                return false;
            }

            if (a.DriverState != b.DriverState)
            {
                return false;
            }

            if (a.DriverPostalCode != b.DriverPostalCode)
            {
                return false;
            }

            if (a.DriverTelephoneNumber != b.DriverTelephoneNumber)
            {
                return false;
            }

            if (a.DriverEmail != b.DriverEmail)
            {
                return false;
            }

            if (a.DriverStatusId != b.DriverStatusId)
            {
                return false;
            }

            if (a.DriverStartDate != b.DriverStartDate)
            {
                return false;
            }

            if (a.DriverSeveranceDate != b.DriverSeveranceDate)
            {
                return false;
            }

            if (a.FuelCardStatusId != b.FuelCardStatusId)
            {
                return false;
            }

            if (a.LicensePlateStatusId != b.LicensePlateStatusId)
            {
                return false;
            }

            if (a.DriverNotes != b.DriverNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Driver a, Driver b)
        {
            return !(a == b);
        }

        #endregion

    }

}
