using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class PurchaseOrder : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _purchaseOrderId;
        private int _jobNumberId;
        private string _purchaseOrderNumber;
        private int _customerId;
        private DateTime _purchaseOrderDate;
        private int _loadingTerminalId;
        private int _freightId;
        private int _purchaseOrderStatusId;
        private int _milesOneWay;
        private int _jobSiteId;
        private decimal _totalOrderWeight;
        private decimal _shipmentWeight;
        private int _loadCount;
        private int _loadsAccepted;
        private decimal _weightDelivered;
        private decimal _weightRemaining;
        private DateTime _purchaseOrderCompletionDate;
        private decimal _shipmentWeightUndeliverable;
        private string _purchaseOrderComments;

        #endregion


        #region Constructor

        public PurchaseOrder()
        {
            this._purchaseOrderId = 0;
            this._jobNumberId = 0;
            this._purchaseOrderNumber = string.Empty;
            this._customerId = 0;
            this._purchaseOrderDate = new DateTime();
            this._loadingTerminalId = 0;
            this._freightId = 0;
            this._purchaseOrderStatusId = 0;
            this._milesOneWay = 0;
            this._jobSiteId = 0;
            this._totalOrderWeight = 0;
            this._shipmentWeight = 0;
            this._loadCount = 0;
            this._loadsAccepted = 0;
            this._weightDelivered = 0;
            this._weightRemaining = 0;
            this._purchaseOrderCompletionDate = new DateTime();
            this._shipmentWeightUndeliverable = 0;
            this._purchaseOrderComments = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public PurchaseOrder(PurchaseOrder p)
        {
            this._purchaseOrderId = p.PurchaseOrderId;
            this._jobNumberId = p.JobNumberId;
            this._purchaseOrderNumber = p.PurchaseOrderNumber;
            this._customerId = p.CustomerId;
            this._purchaseOrderDate = p.PurchaseOrderDate;
            this._loadingTerminalId = p.LoadingTerminalId;
            this._freightId = p.FreightId;
            this._purchaseOrderStatusId = p.PurchaseOrderStatusId;
            this._milesOneWay = p.MilesOneWay;
            this._jobSiteId = p.JobSiteId;
            this._totalOrderWeight = p.TotalOrderWeight;
            this._shipmentWeight = p.ShipmentWeight;
            this._loadCount = p.LoadCount;
            this._loadsAccepted = p.LoadsAccepted;
            this._weightDelivered = p.WeightDelivered;
            this._weightRemaining = p.WeightRemaining;
            this._purchaseOrderCompletionDate = p.PurchaseOrderCompletionDate;
            this._shipmentWeightUndeliverable = p.ShipmentWeightUndeliverable;
            this._purchaseOrderComments = p.PurchaseOrderComments;
            this._dateAdded = p.DateAdded;
            this._addedBy = p.AddedBy;
            this._dateUpdated = p.DateUpdated;
            this._updatedBy = p.UpdatedBy;
            this._rowUpdateVersion = p.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.PurchaseOrder;
            }
        }

        public int PurchaseOrderId
        {
            get
            {
                return this._purchaseOrderId;
            }
            set
            {
                this._purchaseOrderId = value;
                NotifyPropertyChanged("PurchaseOrderId");
            }
        }

        public int JobNumberId
        {
            get
            {
                return this._jobNumberId;
            }
            set
            {
                this._jobNumberId = value;
                NotifyPropertyChanged("JobNumberId");
            }
        }

        public string PurchaseOrderNumber
        {
            get
            {
                return this._purchaseOrderNumber;
            }
            set
            {
                this._purchaseOrderNumber = value;
                NotifyPropertyChanged("PurchaseOrderNumber");
            }
        }

        public int CustomerId
        {
            get
            {
                return this._customerId;
            }
            set
            {
                this._customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        public DateTime PurchaseOrderDate
        {
            get
            {
                return this._purchaseOrderDate;
            }
            set
            {
                this._purchaseOrderDate = value;
                NotifyPropertyChanged("PurchaseOrderDate");
            }
        }

        public int LoadingTerminalId
        {
            get
            {
                return this._loadingTerminalId;
            }
            set
            {
                this._loadingTerminalId = value;
                NotifyPropertyChanged("LoadingTerminalId");
            }
        }

        public int FreightId
        {
            get
            {
                return this._freightId;
            }
            set
            {
                this._freightId = value;
                NotifyPropertyChanged("FreightId");
            }
        }

        public int PurchaseOrderStatusId
        {
            get
            {
                return this._purchaseOrderStatusId;
            }
            set
            {
                this._purchaseOrderStatusId = value;
                NotifyPropertyChanged("PurchaseOrderStatusId");
            }
        }

        public int MilesOneWay
        {
            get
            {
                return this._milesOneWay;
            }
            set
            {
                this._milesOneWay = value;
                NotifyPropertyChanged("MilesOneWay");
            }
        }

        public int JobSiteId
        {
            get
            {
                return this._jobSiteId;
            }
            set
            {
                this._jobSiteId = value;
                NotifyPropertyChanged("JobSiteId");
            }
        }

        public decimal TotalOrderWeight
        {
            get
            {
                return this._totalOrderWeight;
            }
            set
            {
                this._totalOrderWeight = value;
                NotifyPropertyChanged("TotalOrderWeight");
            }
        }

        public decimal ShipmentWeight
        {
            get
            {
                return this._shipmentWeight;
            }
            set
            {
                this._shipmentWeight = value;
                NotifyPropertyChanged("ShipmentWeight");
            }
        }

        public int LoadCount
        {
            get
            {
                return this._loadCount;
            }
            set
            {
                this._loadCount = value;
                NotifyPropertyChanged("LoadCount");
            }
        }

        public int LoadsAccepted
        {
            get
            {
                return this._loadsAccepted;
            }
            set
            {
                this._loadsAccepted = value;
                NotifyPropertyChanged("LoadsAccepted");
            }
        }

        public decimal WeightDelivered
        {
            get
            {
                return this._weightDelivered;
            }
            set
            {
                this._weightDelivered = value;
                NotifyPropertyChanged("WeightDelivered");
            }
        }

        public decimal WeightRemaining
        {
            get
            {
                return this._weightRemaining;
            }
            set
            {
                this._weightRemaining = value;
                NotifyPropertyChanged("WeightRemaining");
            }
        }

        public DateTime PurchaseOrderCompletionDate
        {
            get
            {
                return this._purchaseOrderCompletionDate;
            }
            set
            {
                this._purchaseOrderCompletionDate = value;
                NotifyPropertyChanged("PurchaseOrderCompletionDate");
            }
        }

        public decimal ShipmentWeightUndeliverable
        {
            get
            {
                return this._shipmentWeightUndeliverable;
            }
            set
            {
                this._shipmentWeightUndeliverable = value;
                NotifyPropertyChanged("ShipmentWeightUndeliverable");
            }
        }

        public string PurchaseOrderComments
        {
            get
            {
                return this._purchaseOrderComments;
            }
            set
            {
                this._purchaseOrderComments = value;
                NotifyPropertyChanged("PurchaseOrderComments");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(PurchaseOrder p)
        {
            #region Compare Members

            if (this._purchaseOrderId != p.PurchaseOrderId)
            {
                return false;
            }

            if (this._jobNumberId != p.JobNumberId)
            {
                return false;
            }

            if (this._purchaseOrderNumber != p.PurchaseOrderNumber)
            {
                return false;
            }

            if (this._customerId != p.CustomerId)
            {
                return false;
            }

            if (this._purchaseOrderDate != p.PurchaseOrderDate)
            {
                return false;
            }

            if (this._loadingTerminalId != p.LoadingTerminalId)
            {
                return false;
            }

            if (this._freightId != p.FreightId)
            {
                return false;
            }

            if (this._purchaseOrderStatusId != p.PurchaseOrderStatusId)
            {
                return false;
            }

            if (this._milesOneWay != p.MilesOneWay)
            {
                return false;
            }

            if (this._jobSiteId != p.JobSiteId)
            {
                return false;
            }

            if (this._totalOrderWeight != p.TotalOrderWeight)
            {
                return false;
            }

            if (this._shipmentWeight != p.ShipmentWeight)
            {
                return false;
            }

            if (this._loadCount != p.LoadCount)
            {
                return false;
            }

            if (this._loadsAccepted != p.LoadsAccepted)
            {
                return false;
            }

            if (this._weightDelivered != p.WeightDelivered)
            {
                return false;
            }

            if (this._weightRemaining != p.WeightRemaining)
            {
                return false;
            }

            if (this._purchaseOrderCompletionDate != p.PurchaseOrderCompletionDate)
            {
                return false;
            }

            if (this._shipmentWeightUndeliverable != p.ShipmentWeightUndeliverable)
            {
                return false;
            }

            if (this._purchaseOrderComments != p.PurchaseOrderComments)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            PurchaseOrder p = obj as PurchaseOrder;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (!this.Equals(p))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(PurchaseOrder a, PurchaseOrder b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.PurchaseOrderId != b.PurchaseOrderId)
            {
                return false;
            }

            if (a.JobNumberId != b.JobNumberId)
            {
                return false;
            }

            if (a.PurchaseOrderNumber != b.PurchaseOrderNumber)
            {
                return false;
            }

            if (a.CustomerId != b.CustomerId)
            {
                return false;
            }

            if (a.PurchaseOrderDate != b.PurchaseOrderDate)
            {
                return false;
            }

            if (a.LoadingTerminalId != b.LoadingTerminalId)
            {
                return false;
            }

            if (a.FreightId != b.FreightId)
            {
                return false;
            }

            if (a.PurchaseOrderStatusId != b.PurchaseOrderStatusId)
            {
                return false;
            }

            if (a.MilesOneWay != b.MilesOneWay)
            {
                return false;
            }

            if (a.JobSiteId != b.JobSiteId)
            {
                return false;
            }

            if (a.TotalOrderWeight != b.TotalOrderWeight)
            {
                return false;
            }

            if (a.ShipmentWeight != b.ShipmentWeight)
            {
                return false;
            }

            if (a.LoadCount != b.LoadCount)
            {
                return false;
            }

            if (a.LoadsAccepted != b.LoadsAccepted)
            {
                return false;
            }

            if (a.WeightDelivered != b.WeightDelivered)
            {
                return false;
            }

            if (a.WeightRemaining != b.WeightRemaining)
            {
                return false;
            }

            if (a.PurchaseOrderCompletionDate != b.PurchaseOrderCompletionDate)
            {
                return false;
            }

            if (a.ShipmentWeightUndeliverable != b.ShipmentWeightUndeliverable)
            {
                return false;
            }

            if (a.PurchaseOrderComments != b.PurchaseOrderComments)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(PurchaseOrder a, PurchaseOrder b)
        {
            return !(a == b);
        }

        #endregion

    }

}
