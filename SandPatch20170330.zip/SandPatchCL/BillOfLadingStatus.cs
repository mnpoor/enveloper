using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class BillOfLadingStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _billOfLadingStatusId;
        private string _billOfLadingStatusDescription;

        #endregion


        #region Constructor

        public BillOfLadingStatus()
        {
            this._billOfLadingStatusId = 0;
            this._billOfLadingStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public BillOfLadingStatus(BillOfLadingStatus b)
        {
            this._billOfLadingStatusId = b.BillOfLadingStatusId;
            this._billOfLadingStatusDescription = b.BillOfLadingStatusDescription;
            this._dateAdded = b.DateAdded;
            this._addedBy = b.AddedBy;
            this._dateUpdated = b.DateUpdated;
            this._updatedBy = b.UpdatedBy;
            this._rowUpdateVersion = b.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.BillOfLadingStatus;
            }
        }

        public int BillOfLadingStatusId
        {
            get
            {
                return this._billOfLadingStatusId;
            }
            set
            {
                this._billOfLadingStatusId = value;
                NotifyPropertyChanged("BillOfLadingStatusId");
            }
        }

        public string BillOfLadingStatusDescription
        {
            get
            {
                return this._billOfLadingStatusDescription;
            }
            set
            {
                this._billOfLadingStatusDescription = value;
                NotifyPropertyChanged("BillOfLadingStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(BillOfLadingStatus b)
        {
            #region Compare Members

            if (this._billOfLadingStatusId != b.BillOfLadingStatusId)
            {
                return false;
            }

            if (this._billOfLadingStatusDescription != b.BillOfLadingStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            BillOfLadingStatus b = obj as BillOfLadingStatus;
            if ((System.Object)b == null)
            {
                return false;
            }

            if (!this.Equals(b))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(BillOfLadingStatus a, BillOfLadingStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.BillOfLadingStatusId != b.BillOfLadingStatusId)
            {
                return false;
            }

            if (a.BillOfLadingStatusDescription != b.BillOfLadingStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(BillOfLadingStatus a, BillOfLadingStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
