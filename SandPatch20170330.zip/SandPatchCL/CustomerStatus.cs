using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class CustomerStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _customerStatusId;
        private string _customerStatusDescription;

        #endregion


        #region Constructor

        public CustomerStatus()
        {
            this._customerStatusId = 0;
            this._customerStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public CustomerStatus(CustomerStatus c)
        {
            this._customerStatusId = c.CustomerStatusId;
            this._customerStatusDescription = c.CustomerStatusDescription;
            this._dateAdded = c.DateAdded;
            this._addedBy = c.AddedBy;
            this._dateUpdated = c.DateUpdated;
            this._updatedBy = c.UpdatedBy;
            this._rowUpdateVersion = c.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.CustomerStatus;
            }
        }

        public int CustomerStatusId
        {
            get
            {
                return this._customerStatusId;
            }
            set
            {
                this._customerStatusId = value;
                NotifyPropertyChanged("CustomerStatusId");
            }
        }

        public string CustomerStatusDescription
        {
            get
            {
                return this._customerStatusDescription;
            }
            set
            {
                this._customerStatusDescription = value;
                NotifyPropertyChanged("CustomerStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(CustomerStatus c)
        {
            #region Compare Members

            if (this._customerStatusId != c.CustomerStatusId)
            {
                return false;
            }

            if (this._customerStatusDescription != c.CustomerStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            CustomerStatus c = obj as CustomerStatus;
            if ((System.Object)c == null)
            {
                return false;
            }

            if (!this.Equals(c))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(CustomerStatus a, CustomerStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.CustomerStatusId != b.CustomerStatusId)
            {
                return false;
            }

            if (a.CustomerStatusDescription != b.CustomerStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(CustomerStatus a, CustomerStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
