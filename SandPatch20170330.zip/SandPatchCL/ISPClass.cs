using System;

namespace SandPatchCL
{
    public interface ISPClass
    {
        SPClassType ClassType
        {
            get;
        }

        string DateAdded
        {
            get;
            set;
        }

        string AddedBy
        {
            get;
            set;
        }

        string DateUpdated
        {
            get;
            set;
        }

        string UpdatedBy
        {
            get;
            set;
        }

        byte[] RowUpdateVersion
        {
            get;
            set;
        }

    }
}
