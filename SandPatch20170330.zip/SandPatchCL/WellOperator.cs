using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class WellOperator : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _wellOperatorId;
        private string _wellOperatorCompanyName;
        private string _wellOperatorStreetAddress;
        private string _wellOperatorBoxAddress;
        private string _wellOperatorCity;
        private string _wellOperatorState;
        private string _wellOperatorPostalCode;
        private int _wellOperatorStatusId;
        private string _wellOperatorPhoneNumber;
        private string _wellOperatorFaxNumber;
        private string _wellOperatorContactName;
        private string _wellOperatorContactEmail;
        private string _wellOperatorContactMobileNumber;
        private string _wellOperatorNotes;

        #endregion


        #region Constructor

        public WellOperator()
        {
            this._wellOperatorId = 0;
            this._wellOperatorCompanyName = string.Empty;
            this._wellOperatorStreetAddress = string.Empty;
            this._wellOperatorBoxAddress = string.Empty;
            this._wellOperatorCity = string.Empty;
            this._wellOperatorState = string.Empty;
            this._wellOperatorPostalCode = string.Empty;
            this._wellOperatorStatusId = 0;
            this._wellOperatorPhoneNumber = string.Empty;
            this._wellOperatorFaxNumber = string.Empty;
            this._wellOperatorContactName = string.Empty;
            this._wellOperatorContactEmail = string.Empty;
            this._wellOperatorContactMobileNumber = string.Empty;
            this._wellOperatorNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public WellOperator(WellOperator w)
        {
            this._wellOperatorId = w.WellOperatorId;
            this._wellOperatorCompanyName = w.WellOperatorCompanyName;
            this._wellOperatorStreetAddress = w.WellOperatorStreetAddress;
            this._wellOperatorBoxAddress = w.WellOperatorBoxAddress;
            this._wellOperatorCity = w.WellOperatorCity;
            this._wellOperatorState = w.WellOperatorState;
            this._wellOperatorPostalCode = w.WellOperatorPostalCode;
            this._wellOperatorStatusId = w.WellOperatorStatusId;
            this._wellOperatorPhoneNumber = w.WellOperatorPhoneNumber;
            this._wellOperatorFaxNumber = w.WellOperatorFaxNumber;
            this._wellOperatorContactName = w.WellOperatorContactName;
            this._wellOperatorContactEmail = w.WellOperatorContactEmail;
            this._wellOperatorContactMobileNumber = w.WellOperatorContactMobileNumber;
            this._wellOperatorNotes = w.WellOperatorNotes;
            this._dateAdded = w.DateAdded;
            this._addedBy = w.AddedBy;
            this._dateUpdated = w.DateUpdated;
            this._updatedBy = w.UpdatedBy;
            this._rowUpdateVersion = w.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.WellOperator;
            }
        }

        public int WellOperatorId
        {
            get
            {
                return this._wellOperatorId;
            }
            set
            {
                this._wellOperatorId = value;
                NotifyPropertyChanged("WellOperatorId");
            }
        }

        public string WellOperatorCompanyName
        {
            get
            {
                return this._wellOperatorCompanyName;
            }
            set
            {
                this._wellOperatorCompanyName = value;
                NotifyPropertyChanged("WellOperatorCompanyName");
            }
        }

        public string WellOperatorStreetAddress
        {
            get
            {
                return this._wellOperatorStreetAddress;
            }
            set
            {
                this._wellOperatorStreetAddress = value;
                NotifyPropertyChanged("WellOperatorStreetAddress");
            }
        }

        public string WellOperatorBoxAddress
        {
            get
            {
                return this._wellOperatorBoxAddress;
            }
            set
            {
                this._wellOperatorBoxAddress = value;
                NotifyPropertyChanged("WellOperatorBoxAddress");
            }
        }

        public string WellOperatorCity
        {
            get
            {
                return this._wellOperatorCity;
            }
            set
            {
                this._wellOperatorCity = value;
                NotifyPropertyChanged("WellOperatorCity");
            }
        }

        public string WellOperatorState
        {
            get
            {
                return this._wellOperatorState;
            }
            set
            {
                this._wellOperatorState = value;
                NotifyPropertyChanged("WellOperatorState");
            }
        }

        public string WellOperatorPostalCode
        {
            get
            {
                return this._wellOperatorPostalCode;
            }
            set
            {
                this._wellOperatorPostalCode = value;
                NotifyPropertyChanged("WellOperatorPostalCode");
            }
        }

        public int WellOperatorStatusId
        {
            get
            {
                return this._wellOperatorStatusId;
            }
            set
            {
                this._wellOperatorStatusId = value;
                NotifyPropertyChanged("WellOperatorStatusId");
            }
        }

        public string WellOperatorPhoneNumber
        {
            get
            {
                return this._wellOperatorPhoneNumber;
            }
            set
            {
                this._wellOperatorPhoneNumber = value;
                NotifyPropertyChanged("WellOperatorPhoneNumber");
            }
        }

        public string WellOperatorFaxNumber
        {
            get
            {
                return this._wellOperatorFaxNumber;
            }
            set
            {
                this._wellOperatorFaxNumber = value;
                NotifyPropertyChanged("WellOperatorFaxNumber");
            }
        }

        public string WellOperatorContactName
        {
            get
            {
                return this._wellOperatorContactName;
            }
            set
            {
                this._wellOperatorContactName = value;
                NotifyPropertyChanged("WellOperatorContactName");
            }
        }

        public string WellOperatorContactEmail
        {
            get
            {
                return this._wellOperatorContactEmail;
            }
            set
            {
                this._wellOperatorContactEmail = value;
                NotifyPropertyChanged("WellOperatorContactEmail");
            }
        }

        public string WellOperatorContactMobileNumber
        {
            get
            {
                return this._wellOperatorContactMobileNumber;
            }
            set
            {
                this._wellOperatorContactMobileNumber = value;
                NotifyPropertyChanged("WellOperatorContactMobileNumber");
            }
        }

        public string WellOperatorNotes
        {
            get
            {
                return this._wellOperatorNotes;
            }
            set
            {
                this._wellOperatorNotes = value;
                NotifyPropertyChanged("WellOperatorNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(WellOperator w)
        {
            #region Compare Members

            if (this._wellOperatorId != w.WellOperatorId)
            {
                return false;
            }

            if (this._wellOperatorCompanyName != w.WellOperatorCompanyName)
            {
                return false;
            }

            if (this._wellOperatorStreetAddress != w.WellOperatorStreetAddress)
            {
                return false;
            }

            if (this._wellOperatorBoxAddress != w.WellOperatorBoxAddress)
            {
                return false;
            }

            if (this._wellOperatorCity != w.WellOperatorCity)
            {
                return false;
            }

            if (this._wellOperatorState != w.WellOperatorState)
            {
                return false;
            }

            if (this._wellOperatorPostalCode != w.WellOperatorPostalCode)
            {
                return false;
            }

            if (this._wellOperatorStatusId != w.WellOperatorStatusId)
            {
                return false;
            }

            if (this._wellOperatorPhoneNumber != w.WellOperatorPhoneNumber)
            {
                return false;
            }

            if (this._wellOperatorFaxNumber != w.WellOperatorFaxNumber)
            {
                return false;
            }

            if (this._wellOperatorContactName != w.WellOperatorContactName)
            {
                return false;
            }

            if (this._wellOperatorContactEmail != w.WellOperatorContactEmail)
            {
                return false;
            }

            if (this._wellOperatorContactMobileNumber != w.WellOperatorContactMobileNumber)
            {
                return false;
            }

            if (this._wellOperatorNotes != w.WellOperatorNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            WellOperator w = obj as WellOperator;
            if ((System.Object)w == null)
            {
                return false;
            }

            if (!this.Equals(w))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(WellOperator a, WellOperator b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.WellOperatorId != b.WellOperatorId)
            {
                return false;
            }

            if (a.WellOperatorCompanyName != b.WellOperatorCompanyName)
            {
                return false;
            }

            if (a.WellOperatorStreetAddress != b.WellOperatorStreetAddress)
            {
                return false;
            }

            if (a.WellOperatorBoxAddress != b.WellOperatorBoxAddress)
            {
                return false;
            }

            if (a.WellOperatorCity != b.WellOperatorCity)
            {
                return false;
            }

            if (a.WellOperatorState != b.WellOperatorState)
            {
                return false;
            }

            if (a.WellOperatorPostalCode != b.WellOperatorPostalCode)
            {
                return false;
            }

            if (a.WellOperatorStatusId != b.WellOperatorStatusId)
            {
                return false;
            }

            if (a.WellOperatorPhoneNumber != b.WellOperatorPhoneNumber)
            {
                return false;
            }

            if (a.WellOperatorFaxNumber != b.WellOperatorFaxNumber)
            {
                return false;
            }

            if (a.WellOperatorContactName != b.WellOperatorContactName)
            {
                return false;
            }

            if (a.WellOperatorContactEmail != b.WellOperatorContactEmail)
            {
                return false;
            }

            if (a.WellOperatorContactMobileNumber != b.WellOperatorContactMobileNumber)
            {
                return false;
            }

            if (a.WellOperatorNotes != b.WellOperatorNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(WellOperator a, WellOperator b)
        {
            return !(a == b);
        }

        #endregion

    }

}
