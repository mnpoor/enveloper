using System;

namespace SandPatchCL
{
    public class SPEventArgs : EventArgs
    {
        private ISPClass _spClass;
        private SPObjectAction _spAction;
        private int _index;

        public SPEventArgs(ISPClass SPClass)
        {
            _spClass = SPClass;
        }

        public SPEventArgs(ISPClass SPClass, SPObjectAction SPAction)
        {
            _spClass = SPClass;
            _spAction = SPAction;
        }

        public SPEventArgs(ISPClass SPClass, int index)
        {
            _spClass = SPClass;
            _index = index;
        }

        public ISPClass SPClass
        {
            get
            {
                return _spClass;
            }
        }

        public SPObjectAction SPAction
        {
            get
            {
                return _spAction;
            }
        }

        public int Index
        {
            get
            {
                return _index;
            }
        }

    }
}
