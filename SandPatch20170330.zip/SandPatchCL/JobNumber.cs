using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class JobNumber : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _jobNumberId;
        private int _jobNumberAssignment;
        private int _customerId;
        private DateTime _jobNumberDate;
        private DateTime _startTime;
        private DateTime _endTime;
        private int _originTypeId;
        private int _originId;
        private int _destinationTypeId;
        private int _destinationId;
        private int _jobNumberStatusId;
        private string _jobNumberDescription;

        #endregion


        #region Constructor

        public JobNumber()
        {
            this._jobNumberId = 0;
            this._jobNumberAssignment = 0;
            this._customerId = 0;
            this._jobNumberDate = new DateTime();
            this._startTime = new DateTime();
            this._endTime = new DateTime();
            this._originTypeId = 0;
            this._originId = 0;
            this._destinationTypeId = 0;
            this._destinationId = 0;
            this._jobNumberStatusId = 0;
            this._jobNumberDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public JobNumber(JobNumber j)
        {
            this._jobNumberId = j.JobNumberId;
            this._jobNumberAssignment = j.JobNumberAssignment;
            this._customerId = j.CustomerId;
            this._jobNumberDate = j.JobNumberDate;
            this._startTime = j.StartTime;
            this._endTime = j.EndTime;
            this._originTypeId = j.OriginTypeId;
            this._originId = j.OriginId;
            this._destinationTypeId = j.DestinationTypeId;
            this._destinationId = j.DestinationId;
            this._jobNumberStatusId = j.JobNumberStatusId;
            this._jobNumberDescription = j.JobNumberDescription;
            this._dateAdded = j.DateAdded;
            this._addedBy = j.AddedBy;
            this._dateUpdated = j.DateUpdated;
            this._updatedBy = j.UpdatedBy;
            this._rowUpdateVersion = j.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.JobNumber;
            }
        }

        public int JobNumberId
        {
            get
            {
                return this._jobNumberId;
            }
            set
            {
                this._jobNumberId = value;
                NotifyPropertyChanged("JobNumberId");
            }
        }

        public int JobNumberAssignment
        {
            get
            {
                return this._jobNumberAssignment;
            }
            set
            {
                this._jobNumberAssignment = value;
                NotifyPropertyChanged("JobNumberAssignment");
            }
        }

        public int CustomerId
        {
            get
            {
                return this._customerId;
            }
            set
            {
                this._customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        public DateTime JobNumberDate
        {
            get
            {
                return this._jobNumberDate;
            }
            set
            {
                this._jobNumberDate = value;
                NotifyPropertyChanged("JobNumberDate");
            }
        }

        public DateTime StartTime
        {
            get
            {
                return this._startTime;
            }
            set
            {
                this._startTime = value;
                NotifyPropertyChanged("StartTime");
            }
        }

        public DateTime EndTime
        {
            get
            {
                return this._endTime;
            }
            set
            {
                this._endTime = value;
                NotifyPropertyChanged("EndTime");
            }
        }

        public int OriginTypeId
        {
            get
            {
                return this._originTypeId;
            }
            set
            {
                this._originTypeId = value;
                NotifyPropertyChanged("OriginType");
            }
        }

        public int OriginId
        {
            get
            {
                return this._originId;
            }
            set
            {
                this._originId = value;
                NotifyPropertyChanged("OriginId");
            }
        }

        public int DestinationTypeId
        {
            get
            {
                return this._destinationTypeId;
            }
            set
            {
                this._destinationTypeId = value;
                NotifyPropertyChanged("DestinationTypeId");
            }
        }

        public int DestinationId
        {
            get
            {
                return this._destinationId;
            }
            set
            {
                this._destinationId = value;
                NotifyPropertyChanged("DestinationId");
            }
        }

        public int JobNumberStatusId
        {
            get
            {
                return this._jobNumberStatusId;
            }
            set
            {
                this._jobNumberStatusId = value;
                NotifyPropertyChanged("JobNumberStatusId");
            }
        }

        public string JobNumberDescription
        {
            get
            {
                return this._jobNumberDescription;
            }
            set
            {
                this._jobNumberDescription = value;
                NotifyPropertyChanged("JobNumberDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(JobNumber j)
        {
            #region Compare Members

            if (this._jobNumberId != j.JobNumberId)
            {
                return false;
            }

            if (this._jobNumberAssignment != j.JobNumberAssignment)
            {
                return false;
            }

            if (this._customerId != j.CustomerId)
            {
                return false;
            }

            if (this._jobNumberDate != j.JobNumberDate)
            {
                return false;
            }

            if (this._startTime != j.StartTime)
            {
                return false;
            }

            if (this._endTime != j.EndTime)
            {
                return false;
            }

            if (this._originTypeId != j.OriginTypeId)
            {
                return false;
            }

            if (this._originId != j.OriginId)
            {
                return false;
            }

            if (this._destinationTypeId != j.DestinationTypeId)
            {
                return false;
            }

            if (this._destinationId != j.DestinationId)
            {
                return false;
            }

            if (this._jobNumberStatusId != j.JobNumberStatusId)
            {
                return false;
            }

            if (this._jobNumberDescription != j.JobNumberDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            JobNumber j = obj as JobNumber;
            if ((System.Object)j == null)
            {
                return false;
            }

            if (!this.Equals(j))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(JobNumber a, JobNumber b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.JobNumberId != b.JobNumberId)
            {
                return false;
            }

            if (a.JobNumberAssignment != b.JobNumberAssignment)
            {
                return false;
            }

            if (a.CustomerId != b.CustomerId)
            {
                return false;
            }

            if (a.JobNumberDate != b.JobNumberDate)
            {
                return false;
            }

            if (a.StartTime != b.StartTime)
            {
                return false;
            }

            if (a.EndTime != b.EndTime)
            {
                return false;
            }

            if (a.OriginTypeId != b.OriginTypeId)
            {
                return false;
            }

            if (a.OriginId != b.OriginId)
            {
                return false;
            }

            if (a.DestinationTypeId != b.DestinationTypeId)
            {
                return false;
            }

            if (a.DestinationId != b.DestinationId)
            {
                return false;
            }

            if (a.JobNumberStatusId != b.JobNumberStatusId)
            {
                return false;
            }

            if (a.JobNumberDescription != b.JobNumberDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(JobNumber a, JobNumber b)
        {
            return !(a == b);
        }

        #endregion

    }

}
