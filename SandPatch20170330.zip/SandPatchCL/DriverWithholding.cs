using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class DriverWithholding : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _driverWitholdingId;
        private int _carrierId;
        private int _driverId;
        private int _withholdingAccountId;
        private string _driverWitholdingLedgerAccountName;
        private string _driverWitholdingLedgerAccountNumber;
        private decimal _withholdingAmount;
        private decimal _withholdingPercentage;
        private int _licencePlateMonth;
        private DateTime _firstTransactionDate;
        private DateTime _lastTransactionDate;

        #endregion


        #region Constructor

        public DriverWithholding()
        {
            this._driverWitholdingId = 0;
            this._carrierId = 0;
            this._driverId = 0;
            this._withholdingAccountId = 0;
            this._driverWitholdingLedgerAccountName = string.Empty;
            this._driverWitholdingLedgerAccountNumber = string.Empty;
            this._withholdingAmount = 0;
            this._withholdingPercentage = 0;
            this._licencePlateMonth = 0;
            this._firstTransactionDate = new DateTime();
            this._lastTransactionDate = new DateTime();
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public DriverWithholding(DriverWithholding d)
        {
            this._driverWitholdingId = d.DriverWitholdingId;
            this._carrierId = d.CarrierId;
            this._driverId = d.DriverId;
            this._withholdingAccountId = d.WithholdingAccountId;
            this._driverWitholdingLedgerAccountName = d.DriverWitholdingLedgerAccountName;
            this._driverWitholdingLedgerAccountNumber = d.DriverWitholdingLedgerAccountNumber;
            this._withholdingAmount = d.WithholdingAmount;
            this._withholdingPercentage = d.WithholdingPercentage;
            this._licencePlateMonth = d.LicencePlateMonth;
            this._firstTransactionDate = d.FirstTransactionDate;
            this._lastTransactionDate = d.LastTransactionDate;
            this._dateAdded = d.DateAdded;
            this._addedBy = d.AddedBy;
            this._dateUpdated = d.DateUpdated;
            this._updatedBy = d.UpdatedBy;
            this._rowUpdateVersion = d.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.DriverWithholding;
            }
        }

        public int DriverWitholdingId
        {
            get
            {
                return this._driverWitholdingId;
            }
            set
            {
                this._driverWitholdingId = value;
                NotifyPropertyChanged("DriverWitholdingId");
            }
        }

        public int CarrierId
        {
            get
            {
                return this._carrierId;
            }
            set
            {
                this._carrierId = value;
                NotifyPropertyChanged("CarrierId");
            }
        }

        public int DriverId
        {
            get
            {
                return this._driverId;
            }
            set
            {
                this._driverId = value;
                NotifyPropertyChanged("DriverId");
            }
        }

        public int WithholdingAccountId
        {
            get
            {
                return this._withholdingAccountId;
            }
            set
            {
                this._withholdingAccountId = value;
                NotifyPropertyChanged("WithholdingAccountId");
            }
        }

        public string DriverWitholdingLedgerAccountName
        {
            get
            {
                return this._driverWitholdingLedgerAccountName;
            }
            set
            {
                this._driverWitholdingLedgerAccountName = value;
                NotifyPropertyChanged("DriverWitholdingLedgerAccountName");
            }
        }

        public string DriverWitholdingLedgerAccountNumber
        {
            get
            {
                return this._driverWitholdingLedgerAccountNumber;
            }
            set
            {
                this._driverWitholdingLedgerAccountNumber = value;
                NotifyPropertyChanged("DriverWitholdingLedgerAccountNumber");
            }
        }

        public decimal WithholdingAmount
        {
            get
            {
                return this._withholdingAmount;
            }
            set
            {
                this._withholdingAmount = value;
                NotifyPropertyChanged("WithholdingAmount");
            }
        }

        public decimal WithholdingPercentage
        {
            get
            {
                return this._withholdingPercentage;
            }
            set
            {
                this._withholdingPercentage = value;
                NotifyPropertyChanged("WithholdingPercentage");
            }
        }

        public int LicencePlateMonth
        {
            get
            {
                return this._licencePlateMonth;
            }
            set
            {
                this._licencePlateMonth = value;
                NotifyPropertyChanged("LicencePlateMonth");
            }
        }

        public DateTime FirstTransactionDate
        {
            get
            {
                return this._firstTransactionDate;
            }
            set
            {
                this._firstTransactionDate = value;
                NotifyPropertyChanged("FirstTransactionDate");
            }
        }

        public DateTime LastTransactionDate
        {
            get
            {
                return this._lastTransactionDate;
            }
            set
            {
                this._lastTransactionDate = value;
                NotifyPropertyChanged("LastTransactionDate");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(DriverWithholding d)
        {
            #region Compare Members

            if (this._driverWitholdingId != d.DriverWitholdingId)
            {
                return false;
            }

            if (this._carrierId != d.CarrierId)
            {
                return false;
            }

            if (this._driverId != d.DriverId)
            {
                return false;
            }

            if (this._withholdingAccountId != d.WithholdingAccountId)
            {
                return false;
            }

            if (this._driverWitholdingLedgerAccountName != d.DriverWitholdingLedgerAccountName)
            {
                return false;
            }

            if (this._driverWitholdingLedgerAccountNumber != d.DriverWitholdingLedgerAccountNumber)
            {
                return false;
            }

            if (this._withholdingAmount != d.WithholdingAmount)
            {
                return false;
            }

            if (this._withholdingPercentage != d.WithholdingPercentage)
            {
                return false;
            }

            if (this._licencePlateMonth != d.LicencePlateMonth)
            {
                return false;
            }

            if (this._firstTransactionDate != d.FirstTransactionDate)
            {
                return false;
            }

            if (this._lastTransactionDate != d.LastTransactionDate)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            DriverWithholding d = obj as DriverWithholding;
            if ((System.Object)d == null)
            {
                return false;
            }

            if (!this.Equals(d))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(DriverWithholding a, DriverWithholding b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.DriverWitholdingId != b.DriverWitholdingId)
            {
                return false;
            }

            if (a.CarrierId != b.CarrierId)
            {
                return false;
            }

            if (a.DriverId != b.DriverId)
            {
                return false;
            }

            if (a.WithholdingAccountId != b.WithholdingAccountId)
            {
                return false;
            }

            if (a.DriverWitholdingLedgerAccountName != b.DriverWitholdingLedgerAccountName)
            {
                return false;
            }

            if (a.DriverWitholdingLedgerAccountNumber != b.DriverWitholdingLedgerAccountNumber)
            {
                return false;
            }

            if (a.WithholdingAmount != b.WithholdingAmount)
            {
                return false;
            }

            if (a.WithholdingPercentage != b.WithholdingPercentage)
            {
                return false;
            }

            if (a.LicencePlateMonth != b.LicencePlateMonth)
            {
                return false;
            }

            if (a.FirstTransactionDate != b.FirstTransactionDate)
            {
                return false;
            }

            if (a.LastTransactionDate != b.LastTransactionDate)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(DriverWithholding a, DriverWithholding b)
        {
            return !(a == b);
        }

        #endregion

    }

}
