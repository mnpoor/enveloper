using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class PayScheduleStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _payScheduleStatusId;
        private string _payScheduleStatusDescription;

        #endregion


        #region Constructor

        public PayScheduleStatus()
        {
            this._payScheduleStatusId = 0;
            this._payScheduleStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public PayScheduleStatus(PayScheduleStatus p)
        {
            this._payScheduleStatusId = p.PayScheduleStatusId;
            this._payScheduleStatusDescription = p.PayScheduleStatusDescription;
            this._dateAdded = p.DateAdded;
            this._addedBy = p.AddedBy;
            this._dateUpdated = p.DateUpdated;
            this._updatedBy = p.UpdatedBy;
            this._rowUpdateVersion = p.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.PayScheduleStatus;
            }
        }

        public int PayScheduleStatusId
        {
            get
            {
                return this._payScheduleStatusId;
            }
            set
            {
                this._payScheduleStatusId = value;
                NotifyPropertyChanged("PayScheduleStatusId");
            }
        }

        public string PayScheduleStatusDescription
        {
            get
            {
                return this._payScheduleStatusDescription;
            }
            set
            {
                this._payScheduleStatusDescription = value;
                NotifyPropertyChanged("PayScheduleStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(PayScheduleStatus p)
        {
            #region Compare Members

            if (this._payScheduleStatusId != p.PayScheduleStatusId)
            {
                return false;
            }

            if (this._payScheduleStatusDescription != p.PayScheduleStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            PayScheduleStatus p = obj as PayScheduleStatus;
            if ((System.Object)p == null)
            {
                return false;
            }

            if (!this.Equals(p))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(PayScheduleStatus a, PayScheduleStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.PayScheduleStatusId != b.PayScheduleStatusId)
            {
                return false;
            }

            if (a.PayScheduleStatusDescription != b.PayScheduleStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(PayScheduleStatus a, PayScheduleStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
