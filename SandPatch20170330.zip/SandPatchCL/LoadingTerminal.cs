using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class LoadingTerminal : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _loadingTerminalId;
        private string _loadingTerminalName;
        private string _contactName;
        private string _streetAddress;
        private string _boxAddress;
        private string _city;
        private string _loadingTerminalState;
        private string _postalCode;
        private int _loadingTerminalStatusId;
        private string _phoneNumber;
        private string _faxNumber;
        private string _mobileNumber;
        private string _loadingTerminalWebURL;
        private string _contactEmailAddress;
        private string _loadingTerminalNotes;

        #endregion


        #region Constructor

        public LoadingTerminal()
        {
            this._loadingTerminalId = 0;
            this._loadingTerminalName = string.Empty;
            this._contactName = string.Empty;
            this._streetAddress = string.Empty;
            this._boxAddress = string.Empty;
            this._city = string.Empty;
            this._loadingTerminalState = string.Empty;
            this._postalCode = string.Empty;
            this._loadingTerminalStatusId = 0;
            this._phoneNumber = string.Empty;
            this._faxNumber = string.Empty;
            this._mobileNumber = string.Empty;
            this._loadingTerminalWebURL = string.Empty;
            this._contactEmailAddress = string.Empty;
            this._loadingTerminalNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public LoadingTerminal(LoadingTerminal l)
        {
            this._loadingTerminalId = l.LoadingTerminalId;
            this._loadingTerminalName = l.LoadingTerminalName;
            this._contactName = l.ContactName;
            this._streetAddress = l.StreetAddress;
            this._boxAddress = l.BoxAddress;
            this._city = l.City;
            this._loadingTerminalState = l.LoadingTerminalState;
            this._postalCode = l.PostalCode;
            this._loadingTerminalStatusId = l.LoadingTerminalStatusId;
            this._phoneNumber = l.PhoneNumber;
            this._faxNumber = l.FaxNumber;
            this._mobileNumber = l.MobileNumber;
            this._loadingTerminalWebURL = l.LoadingTerminalWebURL;
            this._contactEmailAddress = l.ContactEmailAddress;
            this._loadingTerminalNotes = l.LoadingTerminalNotes;
            this._dateAdded = l.DateAdded;
            this._addedBy = l.AddedBy;
            this._dateUpdated = l.DateUpdated;
            this._updatedBy = l.UpdatedBy;
            this._rowUpdateVersion = l.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.LoadingTerminal;
            }
        }

        public int LoadingTerminalId
        {
            get
            {
                return this._loadingTerminalId;
            }
            set
            {
                this._loadingTerminalId = value;
                NotifyPropertyChanged("LoadingTerminalId");
            }
        }

        public string LoadingTerminalName
        {
            get
            {
                return this._loadingTerminalName;
            }
            set
            {
                this._loadingTerminalName = value;
                NotifyPropertyChanged("LoadingTerminalName");
            }
        }

        public string ContactName
        {
            get
            {
                return this._contactName;
            }
            set
            {
                this._contactName = value;
                NotifyPropertyChanged("ContactName");
            }
        }

        public string StreetAddress
        {
            get
            {
                return this._streetAddress;
            }
            set
            {
                this._streetAddress = value;
                NotifyPropertyChanged("StreetAddress");
            }
        }

        public string BoxAddress
        {
            get
            {
                return this._boxAddress;
            }
            set
            {
                this._boxAddress = value;
                NotifyPropertyChanged("BoxAddress");
            }
        }

        public string City
        {
            get
            {
                return this._city;
            }
            set
            {
                this._city = value;
                NotifyPropertyChanged("City");
            }
        }

        public string LoadingTerminalState
        {
            get
            {
                return this._loadingTerminalState;
            }
            set
            {
                this._loadingTerminalState = value;
                NotifyPropertyChanged("LoadingTerminalState");
            }
        }

        public string PostalCode
        {
            get
            {
                return this._postalCode;
            }
            set
            {
                this._postalCode = value;
                NotifyPropertyChanged("PostalCode");
            }
        }

        public int LoadingTerminalStatusId
        {
            get
            {
                return this._loadingTerminalStatusId;
            }
            set
            {
                this._loadingTerminalStatusId = value;
                NotifyPropertyChanged("LoadingTerminalStatusId");
            }
        }

        public string PhoneNumber
        {
            get
            {
                return this._phoneNumber;
            }
            set
            {
                this._phoneNumber = value;
                NotifyPropertyChanged("PhoneNumber");
            }
        }

        public string FaxNumber
        {
            get
            {
                return this._faxNumber;
            }
            set
            {
                this._faxNumber = value;
                NotifyPropertyChanged("FaxNumber");
            }
        }

        public string MobileNumber
        {
            get
            {
                return this._mobileNumber;
            }
            set
            {
                this._mobileNumber = value;
                NotifyPropertyChanged("MobileNumber");
            }
        }

        public string LoadingTerminalWebURL
        {
            get
            {
                return this._loadingTerminalWebURL;
            }
            set
            {
                this._loadingTerminalWebURL = value;
                NotifyPropertyChanged("LoadingTerminalWebURL");
            }
        }

        public string ContactEmailAddress
        {
            get
            {
                return this._contactEmailAddress;
            }
            set
            {
                this._contactEmailAddress = value;
                NotifyPropertyChanged("ContactEmailAddress");
            }
        }

        public string LoadingTerminalNotes
        {
            get
            {
                return this._loadingTerminalNotes;
            }
            set
            {
                this._loadingTerminalNotes = value;
                NotifyPropertyChanged("LoadingTerminalNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(LoadingTerminal l)
        {
            #region Compare Members

            if (this._loadingTerminalId != l.LoadingTerminalId)
            {
                return false;
            }

            if (this._loadingTerminalName != l.LoadingTerminalName)
            {
                return false;
            }

            if (this._contactName != l.ContactName)
            {
                return false;
            }

            if (this._streetAddress != l.StreetAddress)
            {
                return false;
            }

            if (this._boxAddress != l.BoxAddress)
            {
                return false;
            }

            if (this._city != l.City)
            {
                return false;
            }

            if (this._loadingTerminalState != l.LoadingTerminalState)
            {
                return false;
            }

            if (this._postalCode != l.PostalCode)
            {
                return false;
            }

            if (this._loadingTerminalStatusId != l.LoadingTerminalStatusId)
            {
                return false;
            }

            if (this._phoneNumber != l.PhoneNumber)
            {
                return false;
            }

            if (this._faxNumber != l.FaxNumber)
            {
                return false;
            }

            if (this._mobileNumber != l.MobileNumber)
            {
                return false;
            }

            if (this._loadingTerminalWebURL != l.LoadingTerminalWebURL)
            {
                return false;
            }

            if (this._contactEmailAddress != l.ContactEmailAddress)
            {
                return false;
            }

            if (this._loadingTerminalNotes != l.LoadingTerminalNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            LoadingTerminal l = obj as LoadingTerminal;
            if ((System.Object)l == null)
            {
                return false;
            }

            if (!this.Equals(l))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(LoadingTerminal a, LoadingTerminal b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.LoadingTerminalId != b.LoadingTerminalId)
            {
                return false;
            }

            if (a.LoadingTerminalName != b.LoadingTerminalName)
            {
                return false;
            }

            if (a.ContactName != b.ContactName)
            {
                return false;
            }

            if (a.StreetAddress != b.StreetAddress)
            {
                return false;
            }

            if (a.BoxAddress != b.BoxAddress)
            {
                return false;
            }

            if (a.City != b.City)
            {
                return false;
            }

            if (a.LoadingTerminalState != b.LoadingTerminalState)
            {
                return false;
            }

            if (a.PostalCode != b.PostalCode)
            {
                return false;
            }

            if (a.LoadingTerminalStatusId != b.LoadingTerminalStatusId)
            {
                return false;
            }

            if (a.PhoneNumber != b.PhoneNumber)
            {
                return false;
            }

            if (a.FaxNumber != b.FaxNumber)
            {
                return false;
            }

            if (a.MobileNumber != b.MobileNumber)
            {
                return false;
            }

            if (a.LoadingTerminalWebURL != b.LoadingTerminalWebURL)
            {
                return false;
            }

            if (a.ContactEmailAddress != b.ContactEmailAddress)
            {
                return false;
            }

            if (a.LoadingTerminalNotes != b.LoadingTerminalNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(LoadingTerminal a, LoadingTerminal b)
        {
            return !(a == b);
        }

        #endregion

    }

}
