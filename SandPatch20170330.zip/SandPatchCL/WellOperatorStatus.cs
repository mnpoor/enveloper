using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class WellOperatorStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _wellOperatorStatusId;
        private string _wellOperatorStatusDescription;

        #endregion


        #region Constructor

        public WellOperatorStatus()
        {
            this._wellOperatorStatusId = 0;
            this._wellOperatorStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public WellOperatorStatus(WellOperatorStatus w)
        {
            this._wellOperatorStatusId = w.WellOperatorStatusId;
            this._wellOperatorStatusDescription = w.WellOperatorStatusDescription;
            this._dateAdded = w.DateAdded;
            this._addedBy = w.AddedBy;
            this._dateUpdated = w.DateUpdated;
            this._updatedBy = w.UpdatedBy;
            this._rowUpdateVersion = w.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.WellOperatorStatus;
            }
        }

        public int WellOperatorStatusId
        {
            get
            {
                return this._wellOperatorStatusId;
            }
            set
            {
                this._wellOperatorStatusId = value;
                NotifyPropertyChanged("WellOperatorStatusId");
            }
        }

        public string WellOperatorStatusDescription
        {
            get
            {
                return this._wellOperatorStatusDescription;
            }
            set
            {
                this._wellOperatorStatusDescription = value;
                NotifyPropertyChanged("WellOperatorStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(WellOperatorStatus w)
        {
            #region Compare Members

            if (this._wellOperatorStatusId != w.WellOperatorStatusId)
            {
                return false;
            }

            if (this._wellOperatorStatusDescription != w.WellOperatorStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            WellOperatorStatus w = obj as WellOperatorStatus;
            if ((System.Object)w == null)
            {
                return false;
            }

            if (!this.Equals(w))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(WellOperatorStatus a, WellOperatorStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.WellOperatorStatusId != b.WellOperatorStatusId)
            {
                return false;
            }

            if (a.WellOperatorStatusDescription != b.WellOperatorStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(WellOperatorStatus a, WellOperatorStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
