using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class LoadingTerminalStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _loadingTerminalStatusId;
        private string _loadingTerminalStatusDescription;

        #endregion


        #region Constructor

        public LoadingTerminalStatus()
        {
            this._loadingTerminalStatusId = 0;
            this._loadingTerminalStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public LoadingTerminalStatus(LoadingTerminalStatus l)
        {
            this._loadingTerminalStatusId = l.LoadingTerminalStatusId;
            this._loadingTerminalStatusDescription = l.LoadingTerminalStatusDescription;
            this._dateAdded = l.DateAdded;
            this._addedBy = l.AddedBy;
            this._dateUpdated = l.DateUpdated;
            this._updatedBy = l.UpdatedBy;
            this._rowUpdateVersion = l.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.LoadingTerminalStatus;
            }
        }

        public int LoadingTerminalStatusId
        {
            get
            {
                return this._loadingTerminalStatusId;
            }
            set
            {
                this._loadingTerminalStatusId = value;
                NotifyPropertyChanged("LoadingTerminalStatusId");
            }
        }

        public string LoadingTerminalStatusDescription
        {
            get
            {
                return this._loadingTerminalStatusDescription;
            }
            set
            {
                this._loadingTerminalStatusDescription = value;
                NotifyPropertyChanged("LoadingTerminalStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(LoadingTerminalStatus l)
        {
            #region Compare Members

            if (this._loadingTerminalStatusId != l.LoadingTerminalStatusId)
            {
                return false;
            }

            if (this._loadingTerminalStatusDescription != l.LoadingTerminalStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            LoadingTerminalStatus l = obj as LoadingTerminalStatus;
            if ((System.Object)l == null)
            {
                return false;
            }

            if (!this.Equals(l))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(LoadingTerminalStatus a, LoadingTerminalStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.LoadingTerminalStatusId != b.LoadingTerminalStatusId)
            {
                return false;
            }

            if (a.LoadingTerminalStatusDescription != b.LoadingTerminalStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(LoadingTerminalStatus a, LoadingTerminalStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
