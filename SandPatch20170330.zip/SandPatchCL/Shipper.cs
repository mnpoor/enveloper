using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Shipper : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _shipperId;
        private string _shipperCompanyName;
        private string _shipperStreetAddress;
        private string _shipperBoxAddress;
        private string _shipperCity;
        private string _shipperState;
        private string _shipperPostalCode;
        private int _shipperStatusId;
        private string _shipperPhoneNumber;
        private string _shipperFaxNumber;
        private string _shipperContactName;
        private string _shipperContactEmail;
        private string _shipperContactMobileNumber;
        private DateTime _shipperActivationDate;
        private DateTime _shipperSeveranceDate;
        private string _shipperNotes;

        #endregion


        #region Constructor

        public Shipper()
        {
            this._shipperId = 0;
            this._shipperCompanyName = string.Empty;
            this._shipperStreetAddress = string.Empty;
            this._shipperBoxAddress = string.Empty;
            this._shipperCity = string.Empty;
            this._shipperState = string.Empty;
            this._shipperPostalCode = string.Empty;
            this._shipperStatusId = 0;
            this._shipperPhoneNumber = string.Empty;
            this._shipperFaxNumber = string.Empty;
            this._shipperContactName = string.Empty;
            this._shipperContactEmail = string.Empty;
            this._shipperContactMobileNumber = string.Empty;
            this._shipperActivationDate = new DateTime();
            this._shipperSeveranceDate = new DateTime();
            this._shipperNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Shipper(Shipper s)
        {
            this._shipperId = s.ShipperId;
            this._shipperCompanyName = s.ShipperCompanyName;
            this._shipperStreetAddress = s.ShipperStreetAddress;
            this._shipperBoxAddress = s.ShipperBoxAddress;
            this._shipperCity = s.ShipperCity;
            this._shipperState = s.ShipperState;
            this._shipperPostalCode = s.ShipperPostalCode;
            this._shipperStatusId = s.ShipperStatusId;
            this._shipperPhoneNumber = s.ShipperPhoneNumber;
            this._shipperFaxNumber = s.ShipperFaxNumber;
            this._shipperContactName = s.ShipperContactName;
            this._shipperContactEmail = s.ShipperContactEmail;
            this._shipperContactMobileNumber = s.ShipperContactMobileNumber;
            this._shipperActivationDate = s.ShipperActivationDate;
            this._shipperSeveranceDate = s.ShipperSeveranceDate;
            this._shipperNotes = s.ShipperNotes;
            this._dateAdded = s.DateAdded;
            this._addedBy = s.AddedBy;
            this._dateUpdated = s.DateUpdated;
            this._updatedBy = s.UpdatedBy;
            this._rowUpdateVersion = s.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Shipper;
            }
        }

        public int ShipperId
        {
            get
            {
                return this._shipperId;
            }
            set
            {
                this._shipperId = value;
                NotifyPropertyChanged("ShipperId");
            }
        }

        public string ShipperCompanyName
        {
            get
            {
                return this._shipperCompanyName;
            }
            set
            {
                this._shipperCompanyName = value;
                NotifyPropertyChanged("ShipperCompanyName");
            }
        }

        public string ShipperStreetAddress
        {
            get
            {
                return this._shipperStreetAddress;
            }
            set
            {
                this._shipperStreetAddress = value;
                NotifyPropertyChanged("ShipperStreetAddress");
            }
        }

        public string ShipperBoxAddress
        {
            get
            {
                return this._shipperBoxAddress;
            }
            set
            {
                this._shipperBoxAddress = value;
                NotifyPropertyChanged("ShipperBoxAddress");
            }
        }

        public string ShipperCity
        {
            get
            {
                return this._shipperCity;
            }
            set
            {
                this._shipperCity = value;
                NotifyPropertyChanged("ShipperCity");
            }
        }

        public string ShipperState
        {
            get
            {
                return this._shipperState;
            }
            set
            {
                this._shipperState = value;
                NotifyPropertyChanged("ShipperState");
            }
        }

        public string ShipperPostalCode
        {
            get
            {
                return this._shipperPostalCode;
            }
            set
            {
                this._shipperPostalCode = value;
                NotifyPropertyChanged("ShipperPostalCode");
            }
        }

        public int ShipperStatusId
        {
            get
            {
                return this._shipperStatusId;
            }
            set
            {
                this._shipperStatusId = value;
                NotifyPropertyChanged("ShipperStatusId");
            }
        }

        public string ShipperPhoneNumber
        {
            get
            {
                return this._shipperPhoneNumber;
            }
            set
            {
                this._shipperPhoneNumber = value;
                NotifyPropertyChanged("ShipperPhoneNumber");
            }
        }

        public string ShipperFaxNumber
        {
            get
            {
                return this._shipperFaxNumber;
            }
            set
            {
                this._shipperFaxNumber = value;
                NotifyPropertyChanged("ShipperFaxNumber");
            }
        }

        public string ShipperContactName
        {
            get
            {
                return this._shipperContactName;
            }
            set
            {
                this._shipperContactName = value;
                NotifyPropertyChanged("ShipperContactName");
            }
        }

        public string ShipperContactEmail
        {
            get
            {
                return this._shipperContactEmail;
            }
            set
            {
                this._shipperContactEmail = value;
                NotifyPropertyChanged("ShipperContactEmail");
            }
        }

        public string ShipperContactMobileNumber
        {
            get
            {
                return this._shipperContactMobileNumber;
            }
            set
            {
                this._shipperContactMobileNumber = value;
                NotifyPropertyChanged("ShipperContactMobileNumber");
            }
        }

        public DateTime ShipperActivationDate
        {
            get
            {
                return this._shipperActivationDate;
            }
            set
            {
                this._shipperActivationDate = value;
                NotifyPropertyChanged("ShipperActivationDate");
            }
        }

        public DateTime ShipperSeveranceDate
        {
            get
            {
                return this._shipperSeveranceDate;
            }
            set
            {
                this._shipperSeveranceDate = value;
                NotifyPropertyChanged("ShipperSeveranceDate");
            }
        }

        public string ShipperNotes
        {
            get
            {
                return this._shipperNotes;
            }
            set
            {
                this._shipperNotes = value;
                NotifyPropertyChanged("ShipperNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Shipper s)
        {
            #region Compare Members

            if (this._shipperId != s.ShipperId)
            {
                return false;
            }

            if (this._shipperCompanyName != s.ShipperCompanyName)
            {
                return false;
            }

            if (this._shipperStreetAddress != s.ShipperStreetAddress)
            {
                return false;
            }

            if (this._shipperBoxAddress != s.ShipperBoxAddress)
            {
                return false;
            }

            if (this._shipperCity != s.ShipperCity)
            {
                return false;
            }

            if (this._shipperState != s.ShipperState)
            {
                return false;
            }

            if (this._shipperPostalCode != s.ShipperPostalCode)
            {
                return false;
            }

            if (this._shipperStatusId != s.ShipperStatusId)
            {
                return false;
            }

            if (this._shipperPhoneNumber != s.ShipperPhoneNumber)
            {
                return false;
            }

            if (this._shipperFaxNumber != s.ShipperFaxNumber)
            {
                return false;
            }

            if (this._shipperContactName != s.ShipperContactName)
            {
                return false;
            }

            if (this._shipperContactEmail != s.ShipperContactEmail)
            {
                return false;
            }

            if (this._shipperContactMobileNumber != s.ShipperContactMobileNumber)
            {
                return false;
            }

            if (this._shipperActivationDate != s.ShipperActivationDate)
            {
                return false;
            }

            if (this._shipperSeveranceDate != s.ShipperSeveranceDate)
            {
                return false;
            }

            if (this._shipperNotes != s.ShipperNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Shipper s = obj as Shipper;
            if ((System.Object)s == null)
            {
                return false;
            }

            if (!this.Equals(s))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Shipper a, Shipper b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.ShipperId != b.ShipperId)
            {
                return false;
            }

            if (a.ShipperCompanyName != b.ShipperCompanyName)
            {
                return false;
            }

            if (a.ShipperStreetAddress != b.ShipperStreetAddress)
            {
                return false;
            }

            if (a.ShipperBoxAddress != b.ShipperBoxAddress)
            {
                return false;
            }

            if (a.ShipperCity != b.ShipperCity)
            {
                return false;
            }

            if (a.ShipperState != b.ShipperState)
            {
                return false;
            }

            if (a.ShipperPostalCode != b.ShipperPostalCode)
            {
                return false;
            }

            if (a.ShipperStatusId != b.ShipperStatusId)
            {
                return false;
            }

            if (a.ShipperPhoneNumber != b.ShipperPhoneNumber)
            {
                return false;
            }

            if (a.ShipperFaxNumber != b.ShipperFaxNumber)
            {
                return false;
            }

            if (a.ShipperContactName != b.ShipperContactName)
            {
                return false;
            }

            if (a.ShipperContactEmail != b.ShipperContactEmail)
            {
                return false;
            }

            if (a.ShipperContactMobileNumber != b.ShipperContactMobileNumber)
            {
                return false;
            }

            if (a.ShipperActivationDate != b.ShipperActivationDate)
            {
                return false;
            }

            if (a.ShipperSeveranceDate != b.ShipperSeveranceDate)
            {
                return false;
            }

            if (a.ShipperNotes != b.ShipperNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Shipper a, Shipper b)
        {
            return !(a == b);
        }

        #endregion

    }

}
