using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace SandPatchCL
{
    public class ExcelRowArray : SPClassBase, ISPClass
    {

        #region Private Members

        private int _rowNumber;
        private DispatchRecordType _recordType;
        private DispatchRowType _rowType;
        private int _lastPageHeadingRowNumber;
        private int _lastAcquisitionRowNumber;
        private int _lastNoteGroupHeadingRowNumber;
        private int _arrayElementCount;
        private string[] _rowElements;

        #endregion


        #region Constructor

        public ExcelRowArray()
        {
            this._rowNumber = 0;
            this._recordType = DispatchRecordType.Unassigned;
            this._rowType = DispatchRowType.Unknown;
            this._lastPageHeadingRowNumber = 0;
            this._lastAcquisitionRowNumber = 0;
            this._lastNoteGroupHeadingRowNumber = 0;
            this._arrayElementCount = 1;
            this._rowElements = new string[] { string.Empty };
        }

        public ExcelRowArray(ExcelRowArray n)
        {
            this._rowNumber = n.RowNumber;
            this._recordType = n.RecordType;
            this._rowType = n.RowType;
            this._lastPageHeadingRowNumber = n.LastPageHeadingRowNumber;
            this._lastAcquisitionRowNumber = n.LastAcquisitionRowNumber;
            this._lastNoteGroupHeadingRowNumber = n.LastNoteGroupHeadingRowNumber;
            this._rowElements = n.RowElements;
        }

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.ExcelRowArray;
            }
        }

        public int RowNumber
        {
            get
            {
                return this._rowNumber;
            }
            set
            {
                this._rowNumber = value;
            }
        }

        public DispatchRecordType RecordType
        {
            get
            {
                return this._recordType;
            }
            set
            {
                this._recordType = value;
            }
        }

        public DispatchRowType RowType
        {
            get
            {
                return this._rowType;
            }
            set
            {
                this._rowType = value;
            }
        }

        public int LastPageHeadingRowNumber
        {
            get
            {
                return this._lastPageHeadingRowNumber;
            }
            set
            {
                this._lastPageHeadingRowNumber = value;
            }
        }

        public int LastAcquisitionRowNumber
        {
            get
            {
                return this._lastAcquisitionRowNumber;
            }
            set
            {
                this._lastAcquisitionRowNumber = value;
            }
        }

        public int LastNoteGroupHeadingRowNumber
        {
            get
            {
                return this._lastNoteGroupHeadingRowNumber;
            }
            set
            {
                this._lastNoteGroupHeadingRowNumber = value;
            }
        }

        public int ArrayElementCount
        {
            get
            {
                return this._arrayElementCount;
            }
            set
            {
                this._arrayElementCount = value;
            }
        }

        public string[] RowElements
        {
            get
            {
                return this._rowElements;
            }
            set
            {
                this._rowElements = value;
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(ExcelRowArray n)
        {

            #region Compare Members

            if (this._rowNumber != n.RowNumber)
            {
                return false;
            }

            if (this._recordType != n.RecordType)
            {
                return false;
            }

            if (this._rowType != n.RowType)
            {
                return false;
            }

            if (this._lastPageHeadingRowNumber != n.LastPageHeadingRowNumber)
            {
                return false;
            }

            if (this._lastNoteGroupHeadingRowNumber != n.LastNoteGroupHeadingRowNumber)
            {
                return false;
            }

            if (this._lastAcquisitionRowNumber != n.LastAcquisitionRowNumber)
            {
                return false;
            }

            if (this._arrayElementCount != n.ArrayElementCount)
            {
                return false;
            }

            if (this._rowElements != n.RowElements)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            ExcelRowArray n = obj as ExcelRowArray;
            if ((System.Object)n == null)
            {
                return false;
            }

            if (!this.Equals(n))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(ExcelRowArray a, ExcelRowArray b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.RowNumber != b.RowNumber)
            {
                return false;
            }

            if (a.RecordType != b.RecordType)
            {
                return false;
            }

            if (a.RowType != b.RowType)
            {
                return false;
            }

            if (a.LastPageHeadingRowNumber != b.LastPageHeadingRowNumber)
            {
                return false;
            }

            if (a.LastNoteGroupHeadingRowNumber != b.LastNoteGroupHeadingRowNumber)
            {
                return false;
            }

            if (a.LastAcquisitionRowNumber != b.LastAcquisitionRowNumber)
            {
                return false;
            }

            if (a.ArrayElementCount != b.ArrayElementCount)
            {
                return false;
            }

            if (a.RowElements != b.RowElements)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(ExcelRowArray a, ExcelRowArray b)
        {
            return !(a == b);
        }

        #endregion

    }
}
