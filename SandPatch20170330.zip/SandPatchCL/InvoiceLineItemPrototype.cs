using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class InvoiceLineItemPrototype : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _invoiceLineItemPrototypeId;
        private int _definitionDisplayOrder;
        private string _transactionDescription;
        private string _transactionDefaultText;
        private int _transactionValueSource;
        private string _unitsDescription;
        private short _recordQuantity;
        private short _recordUnits;
        private short _recordRate;
        private short _multiplyQuantityTimesRate;
        private short _recordAmount;

        #endregion


        #region Constructor

        public InvoiceLineItemPrototype()
        {
            this._invoiceLineItemPrototypeId = 0;
            this._definitionDisplayOrder = 0;
            this._transactionDescription = string.Empty;
            this._transactionDefaultText = string.Empty;
            this._transactionValueSource = 0;
            this._unitsDescription = string.Empty;
            this._recordQuantity = (short)0;
            this._recordUnits = (short)0;
            this._recordRate = (short)0;
            this._multiplyQuantityTimesRate = (short)0;
            this._recordAmount = (short)0;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public InvoiceLineItemPrototype(InvoiceLineItemPrototype i)
        {
            this._invoiceLineItemPrototypeId = i.InvoiceLineItemPrototypeId;
            this._definitionDisplayOrder = i.DefinitionDisplayOrder;
            this._transactionDescription = i.TransactionDescription;
            this._transactionDefaultText = i.TransactionDefaultText;
            this._transactionValueSource = i.TransactionValueSource;
            this._unitsDescription = i.UnitsDescription;
            this._recordQuantity = i.RecordQuantity;
            this._recordUnits = i.RecordUnits;
            this._recordRate = i.RecordRate;
            this._multiplyQuantityTimesRate = i.MultiplyQuantityTimesRate;
            this._recordAmount = i.RecordAmount;
            this._dateAdded = i.DateAdded;
            this._addedBy = i.AddedBy;
            this._dateUpdated = i.DateUpdated;
            this._updatedBy = i.UpdatedBy;
            this._rowUpdateVersion = i.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.InvoiceLineItemPrototype;
            }
        }

        public int InvoiceLineItemPrototypeId
        {
            get
            {
                return this._invoiceLineItemPrototypeId;
            }
            set
            {
                this._invoiceLineItemPrototypeId = value;
                NotifyPropertyChanged("InvoiceLineItemPrototypeId");
            }
        }

        public int DefinitionDisplayOrder
        {
            get
            {
                return this._definitionDisplayOrder;
            }
            set
            {
                this._definitionDisplayOrder = value;
                NotifyPropertyChanged("DefinitionDisplayOrder");
            }
        }

        public string TransactionDescription
        {
            get
            {
                return this._transactionDescription;
            }
            set
            {
                this._transactionDescription = value;
                NotifyPropertyChanged("TransactionDescription");
            }
        }

        public string TransactionDefaultText
        {
            get
            {
                return this._transactionDefaultText;
            }
            set
            {
                this._transactionDefaultText = value;
                NotifyPropertyChanged("TransactionDefaultText");
            }
        }

        public int TransactionValueSource
        {
            get
            {
                return this._transactionValueSource;
            }
            set
            {
                this._transactionValueSource = value;
                NotifyPropertyChanged("TransactionValueSource");
            }
        }

        public string UnitsDescription
        {
            get
            {
                return this._unitsDescription;
            }
            set
            {
                this._unitsDescription = value;
                NotifyPropertyChanged("UnitsDescription");
            }
        }

        public short RecordQuantity
        {
            get
            {
                return this._recordQuantity;
            }
            set
            {
                this._recordQuantity = value;
                NotifyPropertyChanged("RecordQuantity");
            }
        }

        public short RecordUnits
        {
            get
            {
                return this._recordUnits;
            }
            set
            {
                this._recordUnits = value;
                NotifyPropertyChanged("RecordUnits");
            }
        }

        public short RecordRate
        {
            get
            {
                return this._recordRate;
            }
            set
            {
                this._recordRate = value;
                NotifyPropertyChanged("RecordRate");
            }
        }

        public short MultiplyQuantityTimesRate
        {
            get
            {
                return this._multiplyQuantityTimesRate;
            }
            set
            {
                this._multiplyQuantityTimesRate = value;
                NotifyPropertyChanged("MultiplyQuantityTimesRate");
            }
        }

        public short RecordAmount
        {
            get
            {
                return this._recordAmount;
            }
            set
            {
                this._recordAmount = value;
                NotifyPropertyChanged("RecordAmount");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(InvoiceLineItemPrototype i)
        {
            #region Compare Members

            if (this._invoiceLineItemPrototypeId != i.InvoiceLineItemPrototypeId)
            {
                return false;
            }

            if (this._definitionDisplayOrder != i.DefinitionDisplayOrder)
            {
                return false;
            }

            if (this._transactionDescription != i.TransactionDescription)
            {
                return false;
            }

            if (this._transactionDefaultText != i.TransactionDefaultText)
            {
                return false;
            }

            if (this._transactionValueSource != i.TransactionValueSource)
            {
                return false;
            }

            if (this._unitsDescription != i.UnitsDescription)
            {
                return false;
            }

            if (this._recordQuantity != i.RecordQuantity)
            {
                return false;
            }

            if (this._recordUnits != i.RecordUnits)
            {
                return false;
            }

            if (this._recordRate != i.RecordRate)
            {
                return false;
            }

            if (this._multiplyQuantityTimesRate != i.MultiplyQuantityTimesRate)
            {
                return false;
            }

            if (this._recordAmount != i.RecordAmount)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            InvoiceLineItemPrototype i = obj as InvoiceLineItemPrototype;
            if ((System.Object)i == null)
            {
                return false;
            }

            if (!this.Equals(i))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(InvoiceLineItemPrototype a, InvoiceLineItemPrototype b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.InvoiceLineItemPrototypeId != b.InvoiceLineItemPrototypeId)
            {
                return false;
            }

            if (a.DefinitionDisplayOrder != b.DefinitionDisplayOrder)
            {
                return false;
            }

            if (a.TransactionDescription != b.TransactionDescription)
            {
                return false;
            }

            if (a.TransactionDefaultText != b.TransactionDefaultText)
            {
                return false;
            }

            if (a.TransactionValueSource != b.TransactionValueSource)
            {
                return false;
            }

            if (a.UnitsDescription != b.UnitsDescription)
            {
                return false;
            }

            if (a.RecordQuantity != b.RecordQuantity)
            {
                return false;
            }

            if (a.RecordUnits != b.RecordUnits)
            {
                return false;
            }

            if (a.RecordRate != b.RecordRate)
            {
                return false;
            }

            if (a.MultiplyQuantityTimesRate != b.MultiplyQuantityTimesRate)
            {
                return false;
            }

            if (a.RecordAmount != b.RecordAmount)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(InvoiceLineItemPrototype a, InvoiceLineItemPrototype b)
        {
            return !(a == b);
        }

        #endregion

    }

}
