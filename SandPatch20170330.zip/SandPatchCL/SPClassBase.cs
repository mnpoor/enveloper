using System;

namespace SandPatchCL
{
    /// <summary>
    /// Summary description for SPClassBase.
    /// </summary>
    public class SPClassBase
    {
        protected SPClassType _classType;

        protected string _dateAdded;
        protected string _addedBy;
        protected string _dateUpdated;
        protected string _updatedBy;
        protected byte[] _rowUpdateVersion;

        public SPClassBase()
        {
            _dateAdded = string.Empty;
            _addedBy = string.Empty;
            _dateUpdated = string.Empty;
            _updatedBy = string.Empty;
            _rowUpdateVersion = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
        }

        #region Public Methods

        public string DateAdded
        {
            get
            {
                return this._dateAdded;
            }
            set
            {
                this._dateAdded = value;
            }
        }

        public string AddedBy
        {
            get
            {
                return this._addedBy;
            }
            set
            {
                this._addedBy = value;
            }
        }

        public string DateUpdated
        {
            get
            {
                return this._dateUpdated;
            }
            set
            {
                this._dateUpdated = value;
            }
        }

        public string UpdatedBy
        {
            get
            {
                return this._updatedBy;
            }
            set
            {
                this._updatedBy = value;
            }
        }

        public byte[] RowUpdateVersion
        {
            get
            {
                return this._rowUpdateVersion;
            }
            set
            {
                this._rowUpdateVersion = value;
            }
        }

        public string UpdatedString
        {
            get
            {
                return string.Empty;
            }
        }


        #endregion

    }
}
