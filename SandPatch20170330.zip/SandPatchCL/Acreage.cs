using System;
using System.Collections.Generic;
using System.Text;

namespace SandPatchCL
{
    public class Acreage : SPClassBase, ISPClass
    {

        #region Private Members

        private int _acreageId;
        private int _stateId;
        private string _stateName;    // StateId, StateName, and CountyName are not part of the Acreage record structure, these get populated from a view
        private int _countyId;
        private string _countyName;
        private string _acreageLocation;
        private string _section;
        private string _township;
        private string _landRange;
        private string _abstract;
        private string _survey;
        private string _stateTaxMapNumber;
        private int _acreageStatusId;
        private string _acreageStatus;
        private string _acreageLandDescriptionDetail;
        private string _acreageNotes;

        #endregion


        #region Constructor

        public Acreage()
        {
            this._acreageId = 0;
            this._stateId = 0;
            this._stateName = string.Empty;
            this._countyId = 0;
            this._countyName = string.Empty;
            this._acreageLocation = string.Empty;
            this._section = string.Empty;
            this._township = string.Empty;
            this._landRange = string.Empty;
            this._abstract = string.Empty;
            this._survey = string.Empty;
            this._stateTaxMapNumber = string.Empty;
            this._acreageStatusId = 0;
            this._acreageStatus = string.Empty;
            this._acreageLandDescriptionDetail = string.Empty;
            this._acreageNotes = string.Empty;
        }

        public Acreage(Acreage a)
        {
            this._acreageId = a.AcreageId;
            this._stateId = a.StateId;
            this._stateName = a.StateName;
            this._countyId = a.CountyId;
            this._countyName = a.CountyName;
            this._acreageLocation = a.AcreageLocation;
            this._section = a.Section;
            this._township = a.Township;
            this._landRange = a.LandRange;
            this._abstract = a.Abstract;
            this._survey = a.Survey;
            this._stateTaxMapNumber = a.StateTaxMapNumber;
            this._acreageStatusId = a.AcreageStatusId;
            this._acreageStatus = a.AcreageStatus;
            this._acreageLandDescriptionDetail = a.AcreageLandDescriptionDetail;
            this._acreageNotes = a.AcreageNotes;
            this._dateAdded = a.DateAdded;
            this._addedBy = a.AddedBy;
            this._dateUpdated = a.DateUpdated;
            this._updatedBy = a.UpdatedBy;
        }

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Acreage;
            }
        }

        public int AcreageId
        {
            get
            {
                return this._acreageId;
            }
            set
            {
                this._acreageId = value;
            }
        }

        public int StateId
        {
            get
            {
                return this._stateId;
            }
            set
            {
                this._stateId = value;
            }
        }

        public string StateName
        {
            get
            {
                return this._stateName;
            }
            set
            {
                this._stateName = value;
            }
        }

        public int CountyId
        {
            get
            {
                return this._countyId;
            }
            set
            {
                this._countyId = value;
            }
        }

        public string CountyName
        {
            get
            {
                return this._countyName;
            }
            set
            {
                this._countyName = value;
            }
        }

        public string AcreageLocation
        {
            get
            {
                return this._acreageLocation;
            }
            set
            {
                this._acreageLocation = value;
            }
        }

        public string Section
        {
            get
            {
                return this._section;
            }
            set
            {
                this._section = value;
            }
        }

        public string Township
        {
            get
            {
                return this._township;
            }
            set
            {
                this._township = value;
            }
        }

        public string LandRange
        {
            get
            {
                return this._landRange;
            }
            set
            {
                this._landRange = value;
            }
        }

        public string Abstract
        {
            get
            {
                return this._abstract;
            }
            set
            {
                this._abstract = value;
            }
        }

        public string Survey
        {
            get
            {
                return this._survey;
            }
            set
            {
                this._survey = value;
            }
        }

        public string StateTaxMapNumber
        {
            get
            {
                return this._stateTaxMapNumber;
            }
            set
            {
                this._stateTaxMapNumber = value;
            }
        }

        public int AcreageStatusId
        {
            get
            {
                return this._acreageStatusId;
            }
            set
            {
                this._acreageStatusId = value;
            }
        }

        public string AcreageStatus
        {
            get
            {
                return this._acreageStatus;
            }
            set
            {
                this._acreageStatus = value;
            }
        }

        public string AcreageLandDescriptionDetail
        {
            get
            {
                return this._acreageLandDescriptionDetail;
            }
            set
            {
                this._acreageLandDescriptionDetail = value;
            }
        }

        public string AcreageNotes
        {
            get
            {
                return this._acreageNotes;
            }
            set
            {
                this._acreageNotes = value;
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Acreage m)
        {
            #region Compare Members

            if (this._acreageId != m.AcreageId)
            {
                return false;
            }

            if (this._countyId != m.CountyId)
            {
                return false;
            }

            if (this._acreageLocation != m.AcreageLocation)
            {
                return false;
            }

            if (this._section != m.Section)
            {
                return false;
            }

            if (this._township != m.Township)
            {
                return false;
            }

            if (this._landRange != m.LandRange)
            {
                return false;
            }

            if (this._abstract != m.Abstract)
            {
                return false;
            }

            if (this._survey != m.Survey)
            {
                return false;
            }

            if (this._stateTaxMapNumber != m.StateTaxMapNumber)
            {
                return false;
            }

            if (this._acreageStatusId != m.AcreageStatusId)
            {
                return false;
            }

            if (this._acreageStatus != m.AcreageStatus)
            {
                return false;
            }

            if (this._acreageLandDescriptionDetail != m.AcreageLandDescriptionDetail)
            {
                return false;
            }

            if (this._acreageNotes != m.AcreageNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Acreage m = obj as Acreage;
            if ((System.Object)m == null)
            {
                return false;
            }

            if (!this.Equals(m))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Acreage a, Acreage b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.AcreageId != b.AcreageId)
            {
                return false;
            }

            if (a.CountyId != b.CountyId)
            {
                return false;
            }

            if (a.AcreageLocation != b.AcreageLocation)
            {
                return false;
            }

            if (a.Section != b.Section)
            {
                return false;
            }

            if (a.Township != b.Township)
            {
                return false;
            }

            if (a.LandRange != b.LandRange)
            {
                return false;
            }

            if (a.Abstract != b.Abstract)
            {
                return false;
            }

            if (a.Survey != b.Survey)
            {
                return false;
            }

            if (a.StateTaxMapNumber != b.StateTaxMapNumber)
            {
                return false;
            }

            if (a.AcreageStatusId != b.AcreageStatusId)
            {
                return false;
            }

            if (a.AcreageStatus != b.AcreageStatus)
            {
                return false;
            }

            if (a.AcreageLandDescriptionDetail != b.AcreageLandDescriptionDetail)
            {
                return false;
            }

            if (a.AcreageNotes != b.AcreageNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Acreage a, Acreage b)
        {
            return !(a == b);
        }

        #endregion

    }
}
