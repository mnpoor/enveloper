using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class ShipperStatus : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _shipperStatusId;
        private string _shipperStatusDescription;

        #endregion


        #region Constructor

        public ShipperStatus()
        {
            this._shipperStatusId = 0;
            this._shipperStatusDescription = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public ShipperStatus(ShipperStatus s)
        {
            this._shipperStatusId = s.ShipperStatusId;
            this._shipperStatusDescription = s.ShipperStatusDescription;
            this._dateAdded = s.DateAdded;
            this._addedBy = s.AddedBy;
            this._dateUpdated = s.DateUpdated;
            this._updatedBy = s.UpdatedBy;
            this._rowUpdateVersion = s.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.ShipperStatus;
            }
        }

        public int ShipperStatusId
        {
            get
            {
                return this._shipperStatusId;
            }
            set
            {
                this._shipperStatusId = value;
                NotifyPropertyChanged("ShipperStatusId");
            }
        }

        public string ShipperStatusDescription
        {
            get
            {
                return this._shipperStatusDescription;
            }
            set
            {
                this._shipperStatusDescription = value;
                NotifyPropertyChanged("ShipperStatusDescription");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(ShipperStatus s)
        {
            #region Compare Members

            if (this._shipperStatusId != s.ShipperStatusId)
            {
                return false;
            }

            if (this._shipperStatusDescription != s.ShipperStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            ShipperStatus s = obj as ShipperStatus;
            if ((System.Object)s == null)
            {
                return false;
            }

            if (!this.Equals(s))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(ShipperStatus a, ShipperStatus b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.ShipperStatusId != b.ShipperStatusId)
            {
                return false;
            }

            if (a.ShipperStatusDescription != b.ShipperStatusDescription)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(ShipperStatus a, ShipperStatus b)
        {
            return !(a == b);
        }

        #endregion

    }

}
