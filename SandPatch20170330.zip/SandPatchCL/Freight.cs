using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class Freight : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _freightId;
        private string _freightName;
        private string _freightDescription;
        private string _freightUnitOfMeasure;
        private int _freightStatusId;
        private string _freightNotes;

        #endregion


        #region Constructor

        public Freight()
        {
            this._freightId = 0;
            this._freightName = string.Empty;
            this._freightDescription = string.Empty;
            this._freightUnitOfMeasure = string.Empty;
            this._freightStatusId = 0;
            this._freightNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public Freight(Freight f)
        {
            this._freightId = f.FreightId;
            this._freightName = f.FreightName;
            this._freightDescription = f.FreightDescription;
            this._freightUnitOfMeasure = f.FreightUnitOfMeasure;
            this._freightStatusId = f.FreightStatusId;
            this._freightNotes = f.FreightNotes;
            this._dateAdded = f.DateAdded;
            this._addedBy = f.AddedBy;
            this._dateUpdated = f.DateUpdated;
            this._updatedBy = f.UpdatedBy;
            this._rowUpdateVersion = f.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.Freight;
            }
        }

        public int FreightId
        {
            get
            {
                return this._freightId;
            }
            set
            {
                this._freightId = value;
                NotifyPropertyChanged("FreightId");
            }
        }

        public string FreightName
        {
            get
            {
                return this._freightName;
            }
            set
            {
                this._freightName = value;
                NotifyPropertyChanged("FreightName");
            }
        }

        public string FreightDescription
        {
            get
            {
                return this._freightDescription;
            }
            set
            {
                this._freightDescription = value;
                NotifyPropertyChanged("FreightDescription");
            }
        }

        public string FreightUnitOfMeasure
        {
            get
            {
                return this._freightUnitOfMeasure;
            }
            set
            {
                this._freightUnitOfMeasure = value;
                NotifyPropertyChanged("FreightUnitOfMeasure");
            }
        }

        public int FreightStatusId
        {
            get
            {
                return this._freightStatusId;
            }
            set
            {
                this._freightStatusId = value;
                NotifyPropertyChanged("FreightStatusId");
            }
        }

        public string FreightNotes
        {
            get
            {
                return this._freightNotes;
            }
            set
            {
                this._freightNotes = value;
                NotifyPropertyChanged("FreightNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(Freight f)
        {
            #region Compare Members

            if (this._freightId != f.FreightId)
            {
                return false;
            }

            if (this._freightName != f.FreightName)
            {
                return false;
            }

            if (this._freightDescription != f.FreightDescription)
            {
                return false;
            }

            if (this._freightUnitOfMeasure != f.FreightUnitOfMeasure)
            {
                return false;
            }

            if (this._freightStatusId != f.FreightStatusId)
            {
                return false;
            }

            if (this._freightNotes != f.FreightNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Freight f = obj as Freight;
            if ((System.Object)f == null)
            {
                return false;
            }

            if (!this.Equals(f))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(Freight a, Freight b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.FreightId != b.FreightId)
            {
                return false;
            }

            if (a.FreightName != b.FreightName)
            {
                return false;
            }

            if (a.FreightDescription != b.FreightDescription)
            {
                return false;
            }

            if (a.FreightUnitOfMeasure != b.FreightUnitOfMeasure)
            {
                return false;
            }

            if (a.FreightStatusId != b.FreightStatusId)
            {
                return false;
            }

            if (a.FreightNotes != b.FreightNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(Freight a, Freight b)
        {
            return !(a == b);
        }

        #endregion

    }

}
