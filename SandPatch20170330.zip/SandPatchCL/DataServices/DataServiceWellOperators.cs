using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceWellOperators
    {

        #region Private Members

        private const int FIELD_WELLOPERATORID                  = 0;
        private const int FIELD_WELLOPERATORCOMPANYNAME         = 1;
        private const int FIELD_WELLOPERATORSTREETADDRESS       = 2;
        private const int FIELD_WELLOPERATORBOXADDRESS          = 3;
        private const int FIELD_WELLOPERATORCITY                = 4;
        private const int FIELD_WELLOPERATORSTATE               = 5;
        private const int FIELD_WELLOPERATORPOSTALCODE          = 6;
        private const int FIELD_WELLOPERATORSTATUSID            = 7;
        private const int FIELD_WELLOPERATORPHONENUMBER         = 8;
        private const int FIELD_WELLOPERATORFAXNUMBER           = 9;
        private const int FIELD_WELLOPERATORCONTACTNAME         = 10;
        private const int FIELD_WELLOPERATORCONTACTEMAIL        = 11;
        private const int FIELD_WELLOPERATORCONTACTMOBILENUMBER = 12;
        private const int FIELD_WELLOPERATORNOTES               = 13;
        private const int FIELD_DATEADDED                       = 14;
        private const int FIELD_ADDEDBY                         = 15;
        private const int FIELD_DATEUPDATED                     = 16;
        private const int FIELD_UPDATEDBY                       = 17;
        private const int FIELD_ROWUPDATEVERSION                = 18;

        #endregion


        #region Constructor

        private DataServiceWellOperators() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static WellOperator WellOperatorSqlGetById(int wellOperatorId)
        {
            string sqlStatement = "GetWellOperatorById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WellOperatorId", (object)wellOperatorId));

            IDataReader dataReader;

            WellOperator w = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                w = WellOperatorGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return w;
        }

        public static Collection<WellOperator> WellOperatorSqlGetBySearchTerms(string WellOperatorCompanyName, string WellOperatorContactName, string WellOperatorCity)
        {
            string sqlStatement = "SelectWellOperatorsSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (WellOperatorCompanyName != string.Empty) command.Parameters.Add(new SqlParameter("@WellOperatorCompanyName", (object)WellOperatorCompanyName));
            if (WellOperatorContactName != string.Empty) command.Parameters.Add(new SqlParameter("@WellOperatorContactName", (object)WellOperatorContactName));
            if (WellOperatorCity != string.Empty) command.Parameters.Add(new SqlParameter("@WellOperatorCity", (object)WellOperatorCity));

            IDataReader dataReader;

            Collection<WellOperator> rowCollection = new Collection<WellOperator>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                WellOperator w = WellOperatorGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(w);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<WellOperator> WellOperatorSqlGetAll()
        {
            string sqlStatement = "GetAllWellOperators";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<WellOperator> rowCollection = new Collection<WellOperator>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                WellOperator w = WellOperatorGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(w);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref WellOperator w)
        {
            bool saved = false;

            if (w.WellOperatorId == 0)
            {
                saved = SqlSaveInsert(ref w);
            }
            else
            {
                saved = SqlSaveUpdate(ref w);
            }

            return saved;
        }

        public static bool SqlDelete(ref WellOperator w)
        {
            string sqlStatement = "delete from WellOperators where WellOperatorId = " + w.WellOperatorId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static WellOperator WellOperatorGetFromSqlDataReader(ref IDataReader dataReader)
        {
            WellOperator w = new WellOperator();

            w.WellOperatorId = dataReader.IsDBNull(FIELD_WELLOPERATORID) ? 0: dataReader.GetInt32(FIELD_WELLOPERATORID);
            w.WellOperatorCompanyName = dataReader.IsDBNull(FIELD_WELLOPERATORCOMPANYNAME) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORCOMPANYNAME);
            w.WellOperatorStreetAddress = dataReader.IsDBNull(FIELD_WELLOPERATORSTREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORSTREETADDRESS);
            w.WellOperatorBoxAddress = dataReader.IsDBNull(FIELD_WELLOPERATORBOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORBOXADDRESS);
            w.WellOperatorCity = dataReader.IsDBNull(FIELD_WELLOPERATORCITY) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORCITY);
            w.WellOperatorState = dataReader.IsDBNull(FIELD_WELLOPERATORSTATE) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORSTATE);
            w.WellOperatorPostalCode = dataReader.IsDBNull(FIELD_WELLOPERATORPOSTALCODE) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORPOSTALCODE);
            w.WellOperatorStatusId = dataReader.IsDBNull(FIELD_WELLOPERATORSTATUSID) ? 0: dataReader.GetInt32(FIELD_WELLOPERATORSTATUSID);
            w.WellOperatorPhoneNumber = dataReader.IsDBNull(FIELD_WELLOPERATORPHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORPHONENUMBER);
            w.WellOperatorFaxNumber = dataReader.IsDBNull(FIELD_WELLOPERATORFAXNUMBER) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORFAXNUMBER);
            w.WellOperatorContactName = dataReader.IsDBNull(FIELD_WELLOPERATORCONTACTNAME) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORCONTACTNAME);
            w.WellOperatorContactEmail = dataReader.IsDBNull(FIELD_WELLOPERATORCONTACTEMAIL) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORCONTACTEMAIL);
            w.WellOperatorContactMobileNumber = dataReader.IsDBNull(FIELD_WELLOPERATORCONTACTMOBILENUMBER) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORCONTACTMOBILENUMBER);
            w.WellOperatorNotes = dataReader.IsDBNull(FIELD_WELLOPERATORNOTES) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORNOTES);
            w.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            w.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            w.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            w.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) w.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, w.RowUpdateVersion, 0, 8);

            return w;
        }

        private static bool SqlSaveInsert(ref WellOperator w)
        {
            string sqlStatement = "WellOperatorInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WellOperatorCompanyName", (object)w.WellOperatorCompanyName));
            command.Parameters.Add(new SqlParameter("@WellOperatorStreetAddress", (object)w.WellOperatorStreetAddress));
            command.Parameters.Add(new SqlParameter("@WellOperatorBoxAddress", (object)w.WellOperatorBoxAddress));
            command.Parameters.Add(new SqlParameter("@WellOperatorCity", (object)w.WellOperatorCity));
            command.Parameters.Add(new SqlParameter("@WellOperatorState", (object)w.WellOperatorState));
            command.Parameters.Add(new SqlParameter("@WellOperatorPostalCode", (object)w.WellOperatorPostalCode));
            command.Parameters.Add(new SqlParameter("@WellOperatorStatusId", (object)w.WellOperatorStatusId));
            command.Parameters.Add(new SqlParameter("@WellOperatorPhoneNumber", (object)w.WellOperatorPhoneNumber));
            command.Parameters.Add(new SqlParameter("@WellOperatorFaxNumber", (object)w.WellOperatorFaxNumber));
            command.Parameters.Add(new SqlParameter("@WellOperatorContactName", (object)w.WellOperatorContactName));
            command.Parameters.Add(new SqlParameter("@WellOperatorContactEmail", (object)w.WellOperatorContactEmail));
            command.Parameters.Add(new SqlParameter("@WellOperatorContactMobileNumber", (object)w.WellOperatorContactMobileNumber));
            command.Parameters.Add(new SqlParameter("@WellOperatorNotes", (object)w.WellOperatorNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            w.WellOperatorId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return w.WellOperatorId != 0;
        }

        private static bool SqlSaveUpdate(ref WellOperator w)
        {
            string sqlStatement = "WellOperatorUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WellOperatorId", (object)w.WellOperatorId));
            command.Parameters.Add(new SqlParameter("@WellOperatorCompanyName", (object)w.WellOperatorCompanyName));
            command.Parameters.Add(new SqlParameter("@WellOperatorStreetAddress", (object)w.WellOperatorStreetAddress));
            command.Parameters.Add(new SqlParameter("@WellOperatorBoxAddress", (object)w.WellOperatorBoxAddress));
            command.Parameters.Add(new SqlParameter("@WellOperatorCity", (object)w.WellOperatorCity));
            command.Parameters.Add(new SqlParameter("@WellOperatorState", (object)w.WellOperatorState));
            command.Parameters.Add(new SqlParameter("@WellOperatorPostalCode", (object)w.WellOperatorPostalCode));
            command.Parameters.Add(new SqlParameter("@WellOperatorStatusId", (object)w.WellOperatorStatusId));
            command.Parameters.Add(new SqlParameter("@WellOperatorPhoneNumber", (object)w.WellOperatorPhoneNumber));
            command.Parameters.Add(new SqlParameter("@WellOperatorFaxNumber", (object)w.WellOperatorFaxNumber));
            command.Parameters.Add(new SqlParameter("@WellOperatorContactName", (object)w.WellOperatorContactName));
            command.Parameters.Add(new SqlParameter("@WellOperatorContactEmail", (object)w.WellOperatorContactEmail));
            command.Parameters.Add(new SqlParameter("@WellOperatorContactMobileNumber", (object)w.WellOperatorContactMobileNumber));
            command.Parameters.Add(new SqlParameter("@WellOperatorNotes", (object)w.WellOperatorNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
