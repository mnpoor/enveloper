using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceJobSites
    {

        #region Private Members

        private const int FIELD_JOBSITEID                  = 0;
        private const int FIELD_JOBSITENAME                = 1;
        private const int FIELD_WELLOPERATORID             = 2;
        private const int FIELD_JOBSITECONTACTNAME         = 3;
        private const int FIELD_STREETADDRESS              = 4;
        private const int FIELD_BOXADDRESS                 = 5;
        private const int FIELD_CITY                       = 6;
        private const int FIELD_JOBSITESTATE               = 7;
        private const int FIELD_POSTALCODE                 = 8;
        private const int FIELD_COUNTRYCODE                = 9;
        private const int FIELD_JOBSITESTATUSID            = 10;
        private const int FIELD_JOBSITEPHONENUMBER         = 11;
        private const int FIELD_JOBSITEFAXNUMBER           = 12;
        private const int FIELD_JOBSITECONTACTEMAIL        = 13;
        private const int FIELD_JOBSITECONTACTMOBILENUMBER = 14;
        private const int FIELD_JOBSITELATITUDE            = 15;
        private const int FIELD_JOBSITELONGITUDE           = 16;
        private const int FIELD_JOBSITEDRIVINGDIRECTIONS   = 17;
        private const int FIELD_JOBSITENOTES               = 18;
        private const int FIELD_DATEADDED                  = 19;
        private const int FIELD_ADDEDBY                    = 20;
        private const int FIELD_DATEUPDATED                = 21;
        private const int FIELD_UPDATEDBY                  = 22;
        private const int FIELD_ROWUPDATEVERSION           = 23;

        #endregion


        #region Constructor

        private DataServiceJobSites() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static JobSite JobSiteSqlGetById(int jobSiteId)
        {
            string sqlStatement = "GetJobSiteById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)jobSiteId));

            IDataReader dataReader;

            JobSite j = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                j = JobSiteGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return j;
        }

        public static Collection<JobSite> JobSiteSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectJobSitesSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@JobSiteName", (object)searchTerms[1]));

            IDataReader dataReader;

            Collection<JobSite> rowCollection = new Collection<JobSite>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                JobSite j = JobSiteGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(j);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<JobSite> JobSiteSqlGetAll()
        {
            string sqlStatement = "GetAllJobSites";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<JobSite> rowCollection = new Collection<JobSite>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                JobSite j = JobSiteGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(j);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref JobSite j)
        {
            bool saved = false;

            if (j.JobSiteId == 0)
            {
                saved = SqlSaveInsert(ref j);
            }
            else
            {
                saved = SqlSaveUpdate(ref j);
            }

            return saved;
        }

        public static bool SqlDelete(ref JobSite j)
        {
            string sqlStatement = "delete from JobSites where JobSiteId = " + j.JobSiteId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static JobSite JobSiteGetFromSqlDataReader(ref IDataReader dataReader)
        {
            JobSite j = new JobSite();

            j.JobSiteId = dataReader.IsDBNull(FIELD_JOBSITEID) ? 0: dataReader.GetInt32(FIELD_JOBSITEID);
            j.JobSiteName = dataReader.IsDBNull(FIELD_JOBSITENAME) ? string.Empty: dataReader.GetString(FIELD_JOBSITENAME);
            j.WellOperatorId = dataReader.IsDBNull(FIELD_WELLOPERATORID) ? 0: dataReader.GetInt32(FIELD_WELLOPERATORID);
            j.JobSiteContactName = dataReader.IsDBNull(FIELD_JOBSITECONTACTNAME) ? string.Empty: dataReader.GetString(FIELD_JOBSITECONTACTNAME);
            j.StreetAddress = dataReader.IsDBNull(FIELD_STREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_STREETADDRESS);
            j.BoxAddress = dataReader.IsDBNull(FIELD_BOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_BOXADDRESS);
            j.City = dataReader.IsDBNull(FIELD_CITY) ? string.Empty: dataReader.GetString(FIELD_CITY);
            j.JobSiteState = dataReader.IsDBNull(FIELD_JOBSITESTATE) ? string.Empty: dataReader.GetString(FIELD_JOBSITESTATE);
            j.PostalCode = dataReader.IsDBNull(FIELD_POSTALCODE) ? string.Empty: dataReader.GetString(FIELD_POSTALCODE);
            j.CountryCode = dataReader.IsDBNull(FIELD_COUNTRYCODE) ? string.Empty: dataReader.GetString(FIELD_COUNTRYCODE);
            j.JobSiteStatusId = dataReader.IsDBNull(FIELD_JOBSITESTATUSID) ? 0: dataReader.GetInt32(FIELD_JOBSITESTATUSID);
            j.JobSitePhoneNumber = dataReader.IsDBNull(FIELD_JOBSITEPHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_JOBSITEPHONENUMBER);
            j.JobSiteFaxNumber = dataReader.IsDBNull(FIELD_JOBSITEFAXNUMBER) ? string.Empty: dataReader.GetString(FIELD_JOBSITEFAXNUMBER);
            j.JobSiteContactEmail = dataReader.IsDBNull(FIELD_JOBSITECONTACTEMAIL) ? string.Empty: dataReader.GetString(FIELD_JOBSITECONTACTEMAIL);
            j.JobSiteContactMobileNumber = dataReader.IsDBNull(FIELD_JOBSITECONTACTMOBILENUMBER) ? string.Empty: dataReader.GetString(FIELD_JOBSITECONTACTMOBILENUMBER);
            j.JobSiteLatitude = dataReader.IsDBNull(FIELD_JOBSITELATITUDE) ? string.Empty: dataReader.GetString(FIELD_JOBSITELATITUDE);
            j.JobSiteLongitude = dataReader.IsDBNull(FIELD_JOBSITELONGITUDE) ? string.Empty: dataReader.GetString(FIELD_JOBSITELONGITUDE);
            j.JobSiteDrivingDirections = dataReader.IsDBNull(FIELD_JOBSITEDRIVINGDIRECTIONS) ? string.Empty: dataReader.GetString(FIELD_JOBSITEDRIVINGDIRECTIONS);
            j.JobSiteNotes = dataReader.IsDBNull(FIELD_JOBSITENOTES) ? string.Empty: dataReader.GetString(FIELD_JOBSITENOTES);
            j.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            j.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            j.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            j.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) j.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, j.RowUpdateVersion, 0, 8);

            return j;
        }

        private static bool SqlSaveInsert(ref JobSite j)
        {
            string sqlStatement = "JobSiteInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobSiteName", (object)j.JobSiteName));
            command.Parameters.Add(new SqlParameter("@WellOperatorId", (object)j.WellOperatorId));
            command.Parameters.Add(new SqlParameter("@JobSiteContactName", (object)j.JobSiteContactName));
            command.Parameters.Add(new SqlParameter("@StreetAddress", (object)j.StreetAddress));
            command.Parameters.Add(new SqlParameter("@BoxAddress", (object)j.BoxAddress));
            command.Parameters.Add(new SqlParameter("@City", (object)j.City));
            command.Parameters.Add(new SqlParameter("@JobSiteState", (object)j.JobSiteState));
            command.Parameters.Add(new SqlParameter("@PostalCode", (object)j.PostalCode));
            command.Parameters.Add(new SqlParameter("@CountryCode", (object)j.CountryCode));
            command.Parameters.Add(new SqlParameter("@JobSiteStatusId", (object)j.JobSiteStatusId));
            command.Parameters.Add(new SqlParameter("@JobSitePhoneNumber", (object)j.JobSitePhoneNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteFaxNumber", (object)j.JobSiteFaxNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteContactEmail", (object)j.JobSiteContactEmail));
            command.Parameters.Add(new SqlParameter("@JobSiteContactMobileNumber", (object)j.JobSiteContactMobileNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteLatitude", (object)j.JobSiteLatitude));
            command.Parameters.Add(new SqlParameter("@JobSiteLongitude", (object)j.JobSiteLongitude));
            command.Parameters.Add(new SqlParameter("@JobSiteDrivingDirections", (object)j.JobSiteDrivingDirections));
            command.Parameters.Add(new SqlParameter("@JobSiteNotes", (object)j.JobSiteNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            j.JobSiteId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return j.JobSiteId != 0;
        }

        private static bool SqlSaveUpdate(ref JobSite j)
        {
            string sqlStatement = "JobSiteUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)j.JobSiteId));
            command.Parameters.Add(new SqlParameter("@JobSiteName", (object)j.JobSiteName));
            command.Parameters.Add(new SqlParameter("@WellOperatorId", (object)j.WellOperatorId));
            command.Parameters.Add(new SqlParameter("@JobSiteContactName", (object)j.JobSiteContactName));
            command.Parameters.Add(new SqlParameter("@StreetAddress", (object)j.StreetAddress));
            command.Parameters.Add(new SqlParameter("@BoxAddress", (object)j.BoxAddress));
            command.Parameters.Add(new SqlParameter("@City", (object)j.City));
            command.Parameters.Add(new SqlParameter("@JobSiteState", (object)j.JobSiteState));
            command.Parameters.Add(new SqlParameter("@PostalCode", (object)j.PostalCode));
            command.Parameters.Add(new SqlParameter("@CountryCode", (object)j.CountryCode));
            command.Parameters.Add(new SqlParameter("@JobSiteStatusId", (object)j.JobSiteStatusId));
            command.Parameters.Add(new SqlParameter("@JobSitePhoneNumber", (object)j.JobSitePhoneNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteFaxNumber", (object)j.JobSiteFaxNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteContactEmail", (object)j.JobSiteContactEmail));
            command.Parameters.Add(new SqlParameter("@JobSiteContactMobileNumber", (object)j.JobSiteContactMobileNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteLatitude", (object)j.JobSiteLatitude));
            command.Parameters.Add(new SqlParameter("@JobSiteLongitude", (object)j.JobSiteLongitude));
            command.Parameters.Add(new SqlParameter("@JobSiteDrivingDirections", (object)j.JobSiteDrivingDirections));
            command.Parameters.Add(new SqlParameter("@JobSiteNotes", (object)j.JobSiteNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
