using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceFreightStatuses
    {

        #region Private Members

        private const int FIELD_FREIGHTSTATUSID          = 0;
        private const int FIELD_FREIGHTSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                = 2;
        private const int FIELD_ADDEDBY                  = 3;
        private const int FIELD_DATEUPDATED              = 4;
        private const int FIELD_UPDATEDBY                = 5;
        private const int FIELD_ROWUPDATEVERSION         = 6;

        #endregion


        #region Constructor

        private DataServiceFreightStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static FreightStatus FreightStatusSqlGetById(int freightStatusId)
        {
            string sqlStatement = "GetFreightStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FreightStatusId", (object)freightStatusId));

            IDataReader dataReader;

            FreightStatus f = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                f = FreightStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return f;
        }

        //public static Collection<FreightStatus> FreightStatusSqlGetBySearchTerms(string FreightStatusId, string FreightStatusDescription, )
        //{
        //    string sqlStatement = "SelectFreightStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (FreightStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@FreightStatusId", (object)FreightStatusId));
        //    if (FreightStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@FreightStatusDescription", (object)FreightStatusDescription));

        //    IDataReader dataReader;

        //    Collection<FreightStatus> rowCollection = new Collection<FreightStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        FreightStatus f = FreightStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(f);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<FreightStatus> FreightStatusSqlGetAll()
        {
            string sqlStatement = "GetAllFreightStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<FreightStatus> rowCollection = new Collection<FreightStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                FreightStatus f = FreightStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(f);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref FreightStatus f)
        {
            bool saved = false;

            if (f.FreightStatusId == 0)
            {
                saved = SqlSaveInsert(ref f);
            }
            else
            {
                saved = SqlSaveUpdate(ref f);
            }

            return saved;
        }

        public static bool SqlDelete(ref FreightStatus f)
        {
            string sqlStatement = "delete from FreightStatuses where FreightStatusId = " + f.FreightStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static FreightStatus FreightStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            FreightStatus f = new FreightStatus();

            f.FreightStatusId = dataReader.IsDBNull(FIELD_FREIGHTSTATUSID) ? 0: dataReader.GetInt32(FIELD_FREIGHTSTATUSID);
            f.FreightStatusDescription = dataReader.IsDBNull(FIELD_FREIGHTSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_FREIGHTSTATUSDESCRIPTION);
            f.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            f.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            f.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            f.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) f.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, f.RowUpdateVersion, 0, 8);

            return f;
        }

        private static bool SqlSaveInsert(ref FreightStatus f)
        {
            string sqlStatement = "FreightStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FreightStatusDescription", (object)f.FreightStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            f.FreightStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return f.FreightStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref FreightStatus f)
        {
            string sqlStatement = "FreightStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FreightStatusId", (object)f.FreightStatusId));
            command.Parameters.Add(new SqlParameter("@FreightStatusDescription", (object)f.FreightStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
