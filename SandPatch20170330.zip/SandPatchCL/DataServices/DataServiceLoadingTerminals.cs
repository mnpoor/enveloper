using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceLoadingTerminals
    {

        #region Private Members

        private const int FIELD_LOADINGTERMINALID       = 0;
        private const int FIELD_LOADINGTERMINALNAME     = 1;
        private const int FIELD_CONTACTNAME             = 2;
        private const int FIELD_STREETADDRESS           = 3;
        private const int FIELD_BOXADDRESS              = 4;
        private const int FIELD_CITY                    = 5;
        private const int FIELD_LOADINGTERMINALSTATE    = 6;
        private const int FIELD_POSTALCODE              = 7;
        private const int FIELD_LOADINGTERMINALSTATUSID = 8;
        private const int FIELD_PHONENUMBER             = 9;
        private const int FIELD_FAXNUMBER               = 10;
        private const int FIELD_MOBILENUMBER            = 11;
        private const int FIELD_LOADINGTERMINALWEBURL   = 12;
        private const int FIELD_CONTACTEMAILADDRESS     = 13;
        private const int FIELD_LOADINGTERMINALNOTES    = 14;
        private const int FIELD_DATEADDED               = 15;
        private const int FIELD_ADDEDBY                 = 16;
        private const int FIELD_DATEUPDATED             = 17;
        private const int FIELD_UPDATEDBY               = 18;
        private const int FIELD_ROWUPDATEVERSION        = 19;

        #endregion


        #region Constructor

        private DataServiceLoadingTerminals() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static LoadingTerminal LoadingTerminalSqlGetById(int loadingTerminalId)
        {
            string sqlStatement = "GetLoadingTerminalById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)loadingTerminalId));

            IDataReader dataReader;

            LoadingTerminal l = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                l = LoadingTerminalGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return l;
        }

        public static Collection<LoadingTerminal> LoadingTerminalSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectLoadingTerminalsSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@LoadingTerminalName", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@ContactName", (object)searchTerms[1]));
            if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@City", (object)searchTerms[2]));

            IDataReader dataReader;

            Collection<LoadingTerminal> rowCollection = new Collection<LoadingTerminal>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                LoadingTerminal l = LoadingTerminalGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(l);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<LoadingTerminal> LoadingTerminalSqlGetAll()
        {
            string sqlStatement = "GetAllLoadingTerminals";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<LoadingTerminal> rowCollection = new Collection<LoadingTerminal>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                LoadingTerminal l = LoadingTerminalGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(l);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref LoadingTerminal l)
        {
            bool saved = false;

            if (l.LoadingTerminalId == 0)
            {
                saved = SqlSaveInsert(ref l);
            }
            else
            {
                saved = SqlSaveUpdate(ref l);
            }

            return saved;
        }

        public static bool SqlDelete(ref LoadingTerminal l)
        {
            string sqlStatement = "delete from LoadingTerminals where LoadingTerminalId = " + l.LoadingTerminalId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static LoadingTerminal LoadingTerminalGetFromSqlDataReader(ref IDataReader dataReader)
        {
            LoadingTerminal l = new LoadingTerminal();

            l.LoadingTerminalId = dataReader.IsDBNull(FIELD_LOADINGTERMINALID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALID);
            l.LoadingTerminalName = dataReader.IsDBNull(FIELD_LOADINGTERMINALNAME) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALNAME);
            l.ContactName = dataReader.IsDBNull(FIELD_CONTACTNAME) ? string.Empty: dataReader.GetString(FIELD_CONTACTNAME);
            l.StreetAddress = dataReader.IsDBNull(FIELD_STREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_STREETADDRESS);
            l.BoxAddress = dataReader.IsDBNull(FIELD_BOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_BOXADDRESS);
            l.City = dataReader.IsDBNull(FIELD_CITY) ? string.Empty: dataReader.GetString(FIELD_CITY);
            l.LoadingTerminalState = dataReader.IsDBNull(FIELD_LOADINGTERMINALSTATE) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALSTATE);
            l.PostalCode = dataReader.IsDBNull(FIELD_POSTALCODE) ? string.Empty: dataReader.GetString(FIELD_POSTALCODE);
            l.LoadingTerminalStatusId = dataReader.IsDBNull(FIELD_LOADINGTERMINALSTATUSID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALSTATUSID);
            l.PhoneNumber = dataReader.IsDBNull(FIELD_PHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_PHONENUMBER);
            l.FaxNumber = dataReader.IsDBNull(FIELD_FAXNUMBER) ? string.Empty: dataReader.GetString(FIELD_FAXNUMBER);
            l.MobileNumber = dataReader.IsDBNull(FIELD_MOBILENUMBER) ? string.Empty: dataReader.GetString(FIELD_MOBILENUMBER);
            l.LoadingTerminalWebURL = dataReader.IsDBNull(FIELD_LOADINGTERMINALWEBURL) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALWEBURL);
            l.ContactEmailAddress = dataReader.IsDBNull(FIELD_CONTACTEMAILADDRESS) ? string.Empty: dataReader.GetString(FIELD_CONTACTEMAILADDRESS);
            l.LoadingTerminalNotes = dataReader.IsDBNull(FIELD_LOADINGTERMINALNOTES) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALNOTES);
            l.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            l.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            l.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            l.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) l.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, l.RowUpdateVersion, 0, 8);

            return l;
        }

        private static bool SqlSaveInsert(ref LoadingTerminal l)
        {
            string sqlStatement = "LoadingTerminalInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LoadingTerminalName", (object)l.LoadingTerminalName));
            command.Parameters.Add(new SqlParameter("@ContactName", (object)l.ContactName));
            command.Parameters.Add(new SqlParameter("@StreetAddress", (object)l.StreetAddress));
            command.Parameters.Add(new SqlParameter("@BoxAddress", (object)l.BoxAddress));
            command.Parameters.Add(new SqlParameter("@City", (object)l.City));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalState", (object)l.LoadingTerminalState));
            command.Parameters.Add(new SqlParameter("@PostalCode", (object)l.PostalCode));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusId", (object)l.LoadingTerminalStatusId));
            command.Parameters.Add(new SqlParameter("@PhoneNumber", (object)l.PhoneNumber));
            command.Parameters.Add(new SqlParameter("@FaxNumber", (object)l.FaxNumber));
            command.Parameters.Add(new SqlParameter("@MobileNumber", (object)l.MobileNumber));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalWebURL", (object)l.LoadingTerminalWebURL));
            command.Parameters.Add(new SqlParameter("@ContactEmailAddress", (object)l.ContactEmailAddress));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalNotes", (object)l.LoadingTerminalNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            l.LoadingTerminalId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return l.LoadingTerminalId != 0;
        }

        private static bool SqlSaveUpdate(ref LoadingTerminal l)
        {
            string sqlStatement = "LoadingTerminalUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)l.LoadingTerminalId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalName", (object)l.LoadingTerminalName));
            command.Parameters.Add(new SqlParameter("@ContactName", (object)l.ContactName));
            command.Parameters.Add(new SqlParameter("@StreetAddress", (object)l.StreetAddress));
            command.Parameters.Add(new SqlParameter("@BoxAddress", (object)l.BoxAddress));
            command.Parameters.Add(new SqlParameter("@City", (object)l.City));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalState", (object)l.LoadingTerminalState));
            command.Parameters.Add(new SqlParameter("@PostalCode", (object)l.PostalCode));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusId", (object)l.LoadingTerminalStatusId));
            command.Parameters.Add(new SqlParameter("@PhoneNumber", (object)l.PhoneNumber));
            command.Parameters.Add(new SqlParameter("@FaxNumber", (object)l.FaxNumber));
            command.Parameters.Add(new SqlParameter("@MobileNumber", (object)l.MobileNumber));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalWebURL", (object)l.LoadingTerminalWebURL));
            command.Parameters.Add(new SqlParameter("@ContactEmailAddress", (object)l.ContactEmailAddress));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalNotes", (object)l.LoadingTerminalNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
