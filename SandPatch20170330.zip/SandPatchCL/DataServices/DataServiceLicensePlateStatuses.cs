using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceLicensePlateStatuses
    {

        #region Private Members

        private const int FIELD_LICENSEPLATESTATUSID          = 0;
        private const int FIELD_LICENSEPLATESTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                     = 2;
        private const int FIELD_ADDEDBY                       = 3;
        private const int FIELD_DATEUPDATED                   = 4;
        private const int FIELD_UPDATEDBY                     = 5;
        private const int FIELD_ROWUPDATEVERSION              = 6;

        #endregion


        #region Constructor

        private DataServiceLicensePlateStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static LicensePlateStatus LicensePlateStatusSqlGetById(int licensePlateStatusId)
        {
            string sqlStatement = "GetLicensePlateStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LicensePlateStatusId", (object)licensePlateStatusId));

            IDataReader dataReader;

            LicensePlateStatus l = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                l = LicensePlateStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return l;
        }

        //public static Collection<LicensePlateStatus> LicensePlateStatusSqlGetBySearchTerms(string LicensePlateStatusId, string LicensePlateStatusDescription)
        //{
        //    string sqlStatement = "SelectLicensePlateStatuesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (LicensePlateStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@LicensePlateStatusId", (object)LicensePlateStatusId));
        //    if (LicensePlateStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@LicensePlateStatusDescription", (object)LicensePlateStatusDescription));

        //    IDataReader dataReader;

        //    Collection<LicensePlateStatus> rowCollection = new Collection<LicensePlateStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        LicensePlateStatus l = LicensePlateStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(l);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<LicensePlateStatus> LicensePlateStatusSqlGetAll()
        {
            string sqlStatement = "GetAllLicensePlateStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<LicensePlateStatus> rowCollection = new Collection<LicensePlateStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                LicensePlateStatus l = LicensePlateStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(l);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref LicensePlateStatus l)
        {
            bool saved = false;

            if (l.LicensePlateStatusId == 0)
            {
                saved = SqlSaveInsert(ref l);
            }
            else
            {
                saved = SqlSaveUpdate(ref l);
            }

            return saved;
        }

        public static bool SqlDelete(ref LicensePlateStatus l)
        {
            string sqlStatement = "delete from LicensePlateStatuses where LicensePlateStatusId = " + l.LicensePlateStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static LicensePlateStatus LicensePlateStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            LicensePlateStatus l = new LicensePlateStatus();

            l.LicensePlateStatusId = dataReader.IsDBNull(FIELD_LICENSEPLATESTATUSID) ? 0: dataReader.GetInt32(FIELD_LICENSEPLATESTATUSID);
            l.LicensePlateStatusDescription = dataReader.IsDBNull(FIELD_LICENSEPLATESTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_LICENSEPLATESTATUSDESCRIPTION);
            l.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            l.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            l.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            l.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) l.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, l.RowUpdateVersion, 0, 8);

            return l;
        }

        private static bool SqlSaveInsert(ref LicensePlateStatus l)
        {
            string sqlStatement = "LicensePlateStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LicensePlateStatusDescription", (object)l.LicensePlateStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            l.LicensePlateStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return l.LicensePlateStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref LicensePlateStatus l)
        {
            string sqlStatement = "LicensePlateStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LicensePlateStatusId", (object)l.LicensePlateStatusId));
            command.Parameters.Add(new SqlParameter("@LicensePlateStatusDescription", (object)l.LicensePlateStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
