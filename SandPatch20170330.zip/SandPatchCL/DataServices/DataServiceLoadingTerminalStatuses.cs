using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceLoadingTerminalStatuses
    {

        #region Private Members

        private const int FIELD_LOADINGTERMINALSTATUSID          = 0;
        private const int FIELD_LOADINGTERMINALSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                        = 2;
        private const int FIELD_ADDEDBY                          = 3;
        private const int FIELD_DATEUPDATED                      = 4;
        private const int FIELD_UPDATEDBY                        = 5;
        private const int FIELD_ROWUPDATEVERSION                 = 6;

        #endregion


        #region Constructor

        private DataServiceLoadingTerminalStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static LoadingTerminalStatus LoadingTerminalStatusSqlGetById(int loadingTerminalStatusId)
        {
            string sqlStatement = "GetLoadingTerminalStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusId", (object)loadingTerminalStatusId));

            IDataReader dataReader;

            LoadingTerminalStatus l = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                l = LoadingTerminalStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return l;
        }

        //public static Collection<LoadingTerminalStatus> LoadingTerminalStatusSqlGetBySearchTerms(string LoadingTerminalStatusId, string LoadingTerminalStatusDescription)
        //{
        //    string sqlStatement = "SelectLoadingTerminalStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (LoadingTerminalStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusId", (object)LoadingTerminalStatusId));
        //    if (LoadingTerminalStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusDescription", (object)LoadingTerminalStatusDescription));

        //    IDataReader dataReader;

        //    Collection<LoadingTerminalStatus> rowCollection = new Collection<LoadingTerminalStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        LoadingTerminalStatus l = LoadingTerminalStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(l);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<LoadingTerminalStatus> LoadingTerminalStatusSqlGetAll()
        {
            string sqlStatement = "GetAllLoadingTerminalStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<LoadingTerminalStatus> rowCollection = new Collection<LoadingTerminalStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                LoadingTerminalStatus l = LoadingTerminalStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(l);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref LoadingTerminalStatus l)
        {
            bool saved = false;

            if (l.LoadingTerminalStatusId == 0)
            {
                saved = SqlSaveInsert(ref l);
            }
            else
            {
                saved = SqlSaveUpdate(ref l);
            }

            return saved;
        }

        public static bool SqlDelete(ref LoadingTerminalStatus l)
        {
            string sqlStatement = "delete from LoadingTerminalStatuses where LoadingTerminalStatusId = " + l.LoadingTerminalStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static LoadingTerminalStatus LoadingTerminalStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            LoadingTerminalStatus l = new LoadingTerminalStatus();

            l.LoadingTerminalStatusId = dataReader.IsDBNull(FIELD_LOADINGTERMINALSTATUSID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALSTATUSID);
            l.LoadingTerminalStatusDescription = dataReader.IsDBNull(FIELD_LOADINGTERMINALSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALSTATUSDESCRIPTION);
            l.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            l.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            l.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            l.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) l.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, l.RowUpdateVersion, 0, 8);

            return l;
        }

        private static bool SqlSaveInsert(ref LoadingTerminalStatus l)
        {
            string sqlStatement = "LoadingTerminalStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusDescription", (object)l.LoadingTerminalStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            l.LoadingTerminalStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return l.LoadingTerminalStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref LoadingTerminalStatus l)
        {
            string sqlStatement = "LoadingTerminalStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusId", (object)l.LoadingTerminalStatusId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalStatusDescription", (object)l.LoadingTerminalStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
