using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceShippers
    {

        #region Private Members

        private const int FIELD_SHIPPERID                  = 0;
        private const int FIELD_SHIPPERCOMPANYNAME         = 1;
        private const int FIELD_SHIPPERSTREETADDRESS       = 2;
        private const int FIELD_SHIPPERBOXADDRESS          = 3;
        private const int FIELD_SHIPPERCITY                = 4;
        private const int FIELD_SHIPPERSTATE               = 5;
        private const int FIELD_SHIPPERPOSTALCODE          = 6;
        private const int FIELD_SHIPPERSTATUSID            = 7;
        private const int FIELD_SHIPPERPHONENUMBER         = 8;
        private const int FIELD_SHIPPERFAXNUMBER           = 9;
        private const int FIELD_SHIPPERCONTACTNAME         = 10;
        private const int FIELD_SHIPPERCONTACTEMAIL        = 11;
        private const int FIELD_SHIPPERCONTACTMOBILENUMBER = 12;
        private const int FIELD_SHIPPERACTIVATIONDATE      = 13;
        private const int FIELD_SHIPPERSEVERANCEDATE       = 14;
        private const int FIELD_SHIPPERNOTES               = 15;
        private const int FIELD_DATEADDED                  = 16;
        private const int FIELD_ADDEDBY                    = 17;
        private const int FIELD_DATEUPDATED                = 18;
        private const int FIELD_UPDATEDBY                  = 19;
        private const int FIELD_ROWUPDATEVERSION           = 20;

        #endregion


        #region Constructor

        private DataServiceShippers() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Shipper ShipperSqlGetById(int shipperId)
        {
            string sqlStatement = "GetShipperById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@ShipperId", (object)shipperId));

            IDataReader dataReader;

            Shipper s = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                s = ShipperGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return s;
        }

        public static Collection<Shipper> ShipperSqlGetBySearchTerms(string ShipperCompanyName, string ShipperContactName)
        {
            string sqlStatement = "SelectShippersSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (ShipperCompanyName != string.Empty) command.Parameters.Add(new SqlParameter("@ShipperCompanyName", (object)ShipperCompanyName));
            if (ShipperContactName != string.Empty) command.Parameters.Add(new SqlParameter("@ShipperContactName", (object)ShipperContactName));

            IDataReader dataReader;

            Collection<Shipper> rowCollection = new Collection<Shipper>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Shipper s = ShipperGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(s);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Shipper> ShipperSqlGetAll()
        {
            string sqlStatement = "GetAllShippers";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Shipper> rowCollection = new Collection<Shipper>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Shipper s = ShipperGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(s);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Shipper s)
        {
            bool saved = false;

            if (s.ShipperId == 0)
            {
                saved = SqlSaveInsert(ref s);
            }
            else
            {
                saved = SqlSaveUpdate(ref s);
            }

            return saved;
        }

        public static bool SqlDelete(ref Shipper s)
        {
            string sqlStatement = "delete from Shippers where ShipperId = " + s.ShipperId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Shipper ShipperGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Shipper s = new Shipper();

            s.ShipperId = dataReader.IsDBNull(FIELD_SHIPPERID) ? 0: dataReader.GetInt32(FIELD_SHIPPERID);
            s.ShipperCompanyName = dataReader.IsDBNull(FIELD_SHIPPERCOMPANYNAME) ? string.Empty: dataReader.GetString(FIELD_SHIPPERCOMPANYNAME);
            s.ShipperStreetAddress = dataReader.IsDBNull(FIELD_SHIPPERSTREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_SHIPPERSTREETADDRESS);
            s.ShipperBoxAddress = dataReader.IsDBNull(FIELD_SHIPPERBOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_SHIPPERBOXADDRESS);
            s.ShipperCity = dataReader.IsDBNull(FIELD_SHIPPERCITY) ? string.Empty: dataReader.GetString(FIELD_SHIPPERCITY);
            s.ShipperState = dataReader.IsDBNull(FIELD_SHIPPERSTATE) ? string.Empty: dataReader.GetString(FIELD_SHIPPERSTATE);
            s.ShipperPostalCode = dataReader.IsDBNull(FIELD_SHIPPERPOSTALCODE) ? string.Empty: dataReader.GetString(FIELD_SHIPPERPOSTALCODE);
            s.ShipperStatusId = dataReader.IsDBNull(FIELD_SHIPPERSTATUSID) ? 0: dataReader.GetInt32(FIELD_SHIPPERSTATUSID);
            s.ShipperPhoneNumber = dataReader.IsDBNull(FIELD_SHIPPERPHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_SHIPPERPHONENUMBER);
            s.ShipperFaxNumber = dataReader.IsDBNull(FIELD_SHIPPERFAXNUMBER) ? string.Empty: dataReader.GetString(FIELD_SHIPPERFAXNUMBER);
            s.ShipperContactName = dataReader.IsDBNull(FIELD_SHIPPERCONTACTNAME) ? string.Empty: dataReader.GetString(FIELD_SHIPPERCONTACTNAME);
            s.ShipperContactEmail = dataReader.IsDBNull(FIELD_SHIPPERCONTACTEMAIL) ? string.Empty: dataReader.GetString(FIELD_SHIPPERCONTACTEMAIL);
            s.ShipperContactMobileNumber = dataReader.IsDBNull(FIELD_SHIPPERCONTACTMOBILENUMBER) ? string.Empty: dataReader.GetString(FIELD_SHIPPERCONTACTMOBILENUMBER);
            s.ShipperActivationDate = dataReader.IsDBNull(FIELD_SHIPPERACTIVATIONDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_SHIPPERACTIVATIONDATE);
            s.ShipperSeveranceDate = dataReader.IsDBNull(FIELD_SHIPPERSEVERANCEDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_SHIPPERSEVERANCEDATE);
            s.ShipperNotes = dataReader.IsDBNull(FIELD_SHIPPERNOTES) ? string.Empty: dataReader.GetString(FIELD_SHIPPERNOTES);
            s.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            s.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            s.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            s.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) s.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, s.RowUpdateVersion, 0, 8);

            return s;
        }

        private static bool SqlSaveInsert(ref Shipper s)
        {
            string sqlStatement = "ShipperInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@ShipperCompanyName", (object)s.ShipperCompanyName));
            command.Parameters.Add(new SqlParameter("@ShipperStreetAddress", (object)s.ShipperStreetAddress));
            command.Parameters.Add(new SqlParameter("@ShipperBoxAddress", (object)s.ShipperBoxAddress));
            command.Parameters.Add(new SqlParameter("@ShipperCity", (object)s.ShipperCity));
            command.Parameters.Add(new SqlParameter("@ShipperState", (object)s.ShipperState));
            command.Parameters.Add(new SqlParameter("@ShipperPostalCode", (object)s.ShipperPostalCode));
            command.Parameters.Add(new SqlParameter("@ShipperStatusId", (object)s.ShipperStatusId));
            command.Parameters.Add(new SqlParameter("@ShipperPhoneNumber", (object)s.ShipperPhoneNumber));
            command.Parameters.Add(new SqlParameter("@ShipperFaxNumber", (object)s.ShipperFaxNumber));
            command.Parameters.Add(new SqlParameter("@ShipperContactName", (object)s.ShipperContactName));
            command.Parameters.Add(new SqlParameter("@ShipperContactEmail", (object)s.ShipperContactEmail));
            command.Parameters.Add(new SqlParameter("@ShipperContactMobileNumber", (object)s.ShipperContactMobileNumber));
            if (s.ShipperActivationDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ShipperActivationDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ShipperActivationDate", (object)s.ShipperActivationDate));
            }
            if (s.ShipperSeveranceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ShipperSeveranceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ShipperSeveranceDate", (object)s.ShipperSeveranceDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipperNotes", (object)s.ShipperNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            s.ShipperId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return s.ShipperId != 0;
        }

        private static bool SqlSaveUpdate(ref Shipper s)
        {
            string sqlStatement = "ShipperUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@ShipperId", (object)s.ShipperId));
            command.Parameters.Add(new SqlParameter("@ShipperCompanyName", (object)s.ShipperCompanyName));
            command.Parameters.Add(new SqlParameter("@ShipperStreetAddress", (object)s.ShipperStreetAddress));
            command.Parameters.Add(new SqlParameter("@ShipperBoxAddress", (object)s.ShipperBoxAddress));
            command.Parameters.Add(new SqlParameter("@ShipperCity", (object)s.ShipperCity));
            command.Parameters.Add(new SqlParameter("@ShipperState", (object)s.ShipperState));
            command.Parameters.Add(new SqlParameter("@ShipperPostalCode", (object)s.ShipperPostalCode));
            command.Parameters.Add(new SqlParameter("@ShipperStatusId", (object)s.ShipperStatusId));
            command.Parameters.Add(new SqlParameter("@ShipperPhoneNumber", (object)s.ShipperPhoneNumber));
            command.Parameters.Add(new SqlParameter("@ShipperFaxNumber", (object)s.ShipperFaxNumber));
            command.Parameters.Add(new SqlParameter("@ShipperContactName", (object)s.ShipperContactName));
            command.Parameters.Add(new SqlParameter("@ShipperContactEmail", (object)s.ShipperContactEmail));
            command.Parameters.Add(new SqlParameter("@ShipperContactMobileNumber", (object)s.ShipperContactMobileNumber));
            if (s.ShipperActivationDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ShipperActivationDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ShipperActivationDate", (object)s.ShipperActivationDate));
            }
            if (s.ShipperSeveranceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ShipperSeveranceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ShipperSeveranceDate", (object)s.ShipperSeveranceDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipperNotes", (object)s.ShipperNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
