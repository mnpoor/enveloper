using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceCustomerStatuses
    {

        #region Private Members

        private const int FIELD_CUSTOMERSTATUSID          = 0;
        private const int FIELD_CUSTOMERSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                 = 2;
        private const int FIELD_ADDEDBY                   = 3;
        private const int FIELD_DATEUPDATED               = 4;
        private const int FIELD_UPDATEDBY                 = 5;
        private const int FIELD_ROWUPDATEVERSION          = 6;

        #endregion


        #region Constructor

        private DataServiceCustomerStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static CustomerStatus CustomerStatusSqlGetById(int customerStatusId)
        {
            string sqlStatement = "GetCustomerStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerStatusId", (object)customerStatusId));

            IDataReader dataReader;

            CustomerStatus c = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                c = CustomerStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return c;
        }

        //public static Collection<CustomerStatus> CustomerStatusSqlGetBySearchTerms(string CustomerStatusId, string CustomerStatusDescription)
        //{
        //    string sqlStatement = "SelectCustomerStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (CustomerStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerStatusId", (object)CustomerStatusId));
        //    if (CustomerStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerStatusDescription", (object)CustomerStatusDescription));

        //    IDataReader dataReader;

        //    Collection<CustomerStatus> rowCollection = new Collection<CustomerStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        CustomerStatus c = CustomerStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(c);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<CustomerStatus> CustomerStatusSqlGetAll()
        {
            string sqlStatement = "GetAllCustomerStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<CustomerStatus> rowCollection = new Collection<CustomerStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                CustomerStatus c = CustomerStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(c);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref CustomerStatus c)
        {
            bool saved = false;

            if (c.CustomerStatusId == 0)
            {
                saved = SqlSaveInsert(ref c);
            }
            else
            {
                saved = SqlSaveUpdate(ref c);
            }

            return saved;
        }

        public static bool SqlDelete(ref CustomerStatus c)
        {
            string sqlStatement = "delete from CustomerStatuses where CustomerStatusId = " + c.CustomerStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static CustomerStatus CustomerStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            CustomerStatus c = new CustomerStatus();

            c.CustomerStatusId = dataReader.IsDBNull(FIELD_CUSTOMERSTATUSID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERSTATUSID);
            c.CustomerStatusDescription = dataReader.IsDBNull(FIELD_CUSTOMERSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_CUSTOMERSTATUSDESCRIPTION);
            c.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            c.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            c.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            c.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) c.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, c.RowUpdateVersion, 0, 8);

            return c;
        }

        private static bool SqlSaveInsert(ref CustomerStatus c)
        {
            string sqlStatement = "CustomerStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerStatusDescription", (object)c.CustomerStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            c.CustomerStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return c.CustomerStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref CustomerStatus c)
        {
            string sqlStatement = "CustomerStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerStatusId", (object)c.CustomerStatusId));
            command.Parameters.Add(new SqlParameter("@CustomerStatusDescription", (object)c.CustomerStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
