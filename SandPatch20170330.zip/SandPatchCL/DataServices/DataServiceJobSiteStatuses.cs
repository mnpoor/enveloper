using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceJobSiteStatuses
    {

        #region Private Members

        private const int FIELD_JOBSITESTATUSID          = 0;
        private const int FIELD_JOBSITESTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                = 2;
        private const int FIELD_ADDEDBY                  = 3;
        private const int FIELD_DATEUPDATED              = 4;
        private const int FIELD_UPDATEDBY                = 5;
        private const int FIELD_ROWUPDATEVERSION         = 6;

        #endregion


        #region Constructor

        private DataServiceJobSiteStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static JobSiteStatus JobSiteStatusSqlGetById(int jobSiteStatusId)
        {
            string sqlStatement = "GetJobSiteStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobSiteStatusId", (object)jobSiteStatusId));

            IDataReader dataReader;

            JobSiteStatus j = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                j = JobSiteStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return j;
        }

        //public static Collection<JobSiteStatus> JobSiteStatusSqlGetBySearchTerms(string JobSiteStatusId, string JobSiteStatusDescription)
        //{
        //    string sqlStatement = "SelectJobSiteStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (JobSiteStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@JobSiteStatusId", (object)JobSiteStatusId));
        //    if (JobSiteStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@JobSiteStatusDescription", (object)JobSiteStatusDescription));

        //    IDataReader dataReader;

        //    Collection<JobSiteStatus> rowCollection = new Collection<JobSiteStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        JobSiteStatus j = JobSiteStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(j);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<JobSiteStatus> JobSiteStatusSqlGetAll()
        {
            string sqlStatement = "GetAllJobSiteStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<JobSiteStatus> rowCollection = new Collection<JobSiteStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                JobSiteStatus j = JobSiteStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(j);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref JobSiteStatus j)
        {
            bool saved = false;

            if (j.JobSiteStatusId == 0)
            {
                saved = SqlSaveInsert(ref j);
            }
            else
            {
                saved = SqlSaveUpdate(ref j);
            }

            return saved;
        }

        public static bool SqlDelete(ref JobSiteStatus j)
        {
            string sqlStatement = "delete from JobSiteStatuses where JobSiteStatusId = " + j.JobSiteStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static JobSiteStatus JobSiteStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            JobSiteStatus j = new JobSiteStatus();

            j.JobSiteStatusId = dataReader.IsDBNull(FIELD_JOBSITESTATUSID) ? 0: dataReader.GetInt32(FIELD_JOBSITESTATUSID);
            j.JobSiteStatusDescription = dataReader.IsDBNull(FIELD_JOBSITESTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_JOBSITESTATUSDESCRIPTION);
            j.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            j.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            j.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            j.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) j.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, j.RowUpdateVersion, 0, 8);

            return j;
        }

        private static bool SqlSaveInsert(ref JobSiteStatus j)
        {
            string sqlStatement = "JobSiteStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobSiteStatusDescription", (object)j.JobSiteStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            j.JobSiteStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return j.JobSiteStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref JobSiteStatus j)
        {
            string sqlStatement = "JobSiteStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobSiteStatusId", (object)j.JobSiteStatusId));
            command.Parameters.Add(new SqlParameter("@JobSiteStatusDescription", (object)j.JobSiteStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
