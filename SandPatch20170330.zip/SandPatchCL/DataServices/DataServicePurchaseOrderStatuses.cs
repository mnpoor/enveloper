using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServicePurchaseOrderStatuses
    {

        #region Private Members

        private const int FIELD_PURCHASEORDERSTATUSID          = 0;
        private const int FIELD_PURCHASEORDERSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                      = 2;
        private const int FIELD_ADDEDBY                        = 3;
        private const int FIELD_DATEUPDATED                    = 4;
        private const int FIELD_UPDATEDBY                      = 5;
        private const int FIELD_ROWUPDATEVERSION               = 6;

        #endregion


        #region Constructor

        private DataServicePurchaseOrderStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static PurchaseOrderStatus PurchaseOrderStatusSqlGetById(int purchaseOrderStatusId)
        {
            string sqlStatement = "GetPurchaseOrderStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusId", (object)purchaseOrderStatusId));

            IDataReader dataReader;

            PurchaseOrderStatus p = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                p = PurchaseOrderStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return p;
        }

        //public static Collection<PurchaseOrderStatus> PurchaseOrderStatusSqlGetBySearchTerms(string PurchaseOrderStatusId, string PurchaseOrderStatusDescription, )
        //{
        //    string sqlStatement = "SelectPurchaseOrderStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (PurchaseOrderStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusId", (object)PurchaseOrderStatusId));
        //    if (PurchaseOrderStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusDescription", (object)PurchaseOrderStatusDescription));

        //    IDataReader dataReader;

        //    Collection<PurchaseOrderStatus> rowCollection = new Collection<PurchaseOrderStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        PurchaseOrderStatus p = PurchaseOrderStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(p);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<PurchaseOrderStatus> PurchaseOrderStatusSqlGetAll()
        {
            string sqlStatement = "GetAllPurchaseOrderStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<PurchaseOrderStatus> rowCollection = new Collection<PurchaseOrderStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PurchaseOrderStatus p = PurchaseOrderStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref PurchaseOrderStatus p)
        {
            bool saved = false;

            if (p.PurchaseOrderStatusId == 0)
            {
                saved = SqlSaveInsert(ref p);
            }
            else
            {
                saved = SqlSaveUpdate(ref p);
            }

            return saved;
        }

        public static bool SqlDelete(ref PurchaseOrderStatus p)
        {
            string sqlStatement = "delete from PurchaseOrderStatuses where PurchaseOrderStatusId = " + p.PurchaseOrderStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static PurchaseOrderStatus PurchaseOrderStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            PurchaseOrderStatus p = new PurchaseOrderStatus();

            p.PurchaseOrderStatusId = dataReader.IsDBNull(FIELD_PURCHASEORDERSTATUSID) ? 0: dataReader.GetInt32(FIELD_PURCHASEORDERSTATUSID);
            p.PurchaseOrderStatusDescription = dataReader.IsDBNull(FIELD_PURCHASEORDERSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_PURCHASEORDERSTATUSDESCRIPTION);
            p.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            p.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            p.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            p.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) p.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, p.RowUpdateVersion, 0, 8);

            return p;
        }

        private static bool SqlSaveInsert(ref PurchaseOrderStatus p)
        {
            string sqlStatement = "PurchaseOrderStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusDescription", (object)p.PurchaseOrderStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            p.PurchaseOrderStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return p.PurchaseOrderStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref PurchaseOrderStatus p)
        {
            string sqlStatement = "PurchaseOrderStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusId", (object)p.PurchaseOrderStatusId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusDescription", (object)p.PurchaseOrderStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
