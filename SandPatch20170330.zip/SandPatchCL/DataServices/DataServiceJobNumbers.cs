using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceJobNumbers
    {

        #region Private Members

        private const int FIELD_JOBNUMBERID            = 0;
        private const int FIELD_JOBNUMBERASSIGNMENT    = 1;
        private const int FIELD_CUSTOMERID             = 2;
        private const int FIELD_JOBNUMBERDATE          = 3;
        private const int FIELD_STARTTIME              = 4;
        private const int FIELD_ENDTIME                = 5;
        private const int FIELD_ORIGINTYPEID           = 6;
        private const int FIELD_ORIGINID               = 7;
        private const int FIELD_DESTINATIONTYPEID      = 8;
        private const int FIELD_DESTINATIONID          = 9;
        private const int FIELD_JOBNUMBERSTATUSID      = 10;
        private const int FIELD_JOBNUMBERDESCRIPTION   = 11;
        private const int FIELD_DATEADDED              = 12;
        private const int FIELD_ADDEDBY                = 13;
        private const int FIELD_DATEUPDATED            = 14;
        private const int FIELD_UPDATEDBY              = 15;
        private const int FIELD_ROWUPDATEVERSION       = 16;

        #endregion


        #region Constructor

        private DataServiceJobNumbers() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static JobNumber JobNumberSqlGetById(int jobNumberId)
        {
            string sqlStatement = "GetJobNumberById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)jobNumberId));

            IDataReader dataReader;

            JobNumber j = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                j = JobNumberGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return j;
        }

        public static Collection<JobNumber> JobNumberSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectJobNumbersSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberDateFrom", (object)searchTerms[1]));
            if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberDateTo", (object)searchTerms[2]));

            IDataReader dataReader;

            Collection<JobNumber> rowCollection = new Collection<JobNumber>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                JobNumber j = JobNumberGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(j);
            }

            command.Connection.Close();

            return rowCollection;
        }

        //public static Collection<JobNumber> JobNumberSqlGetBySearchTerms(string jobNumberAssignment, string jobNumberDateFrom, string jobNumberDateTo)
        //{
        //    string sqlStatement = "SelectJobNumbersSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (jobNumberAssignment != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumberAssignment));
        //    if (jobNumberDateFrom != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberDateFrom", (object)jobNumberDateFrom));
        //    if (jobNumberDateTo != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberDateTo", (object)jobNumberDateTo));

        //    IDataReader dataReader;

        //    Collection<JobNumber> rowCollection = new Collection<JobNumber>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        JobNumber j = JobNumberGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(j);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<JobNumber> JobNumberSqlGetAll()
        {
            string sqlStatement = "GetAllJobNumbers";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<JobNumber> rowCollection = new Collection<JobNumber>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                JobNumber j = JobNumberGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(j);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref JobNumber j)
        {
            bool saved = false;

            if (j.JobNumberId == 0)
            {
                saved = SqlSaveInsert(ref j);
            }
            else
            {
                saved = SqlSaveUpdate(ref j);
            }

            return saved;
        }

        public static bool SqlDelete(ref JobNumber j)
        {
            string sqlStatement = "delete from JobNumbers where JobNumberId = " + j.JobNumberId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static JobNumber JobNumberGetFromSqlDataReader(ref IDataReader dataReader)
        {
            JobNumber j = new JobNumber();

            j.JobNumberId = dataReader.IsDBNull(FIELD_JOBNUMBERID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERID);
            j.JobNumberAssignment = dataReader.IsDBNull(FIELD_JOBNUMBERASSIGNMENT) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERASSIGNMENT);
            j.CustomerId = dataReader.IsDBNull(FIELD_CUSTOMERID) ? 0 : dataReader.GetInt32(FIELD_CUSTOMERID);
            j.JobNumberDate = dataReader.IsDBNull(FIELD_JOBNUMBERDATE) ? new DateTime() : dataReader.GetDateTime(FIELD_JOBNUMBERDATE);
            j.StartTime = dataReader.IsDBNull(FIELD_STARTTIME) ? new DateTime(): dataReader.GetDateTime(FIELD_STARTTIME);
            j.EndTime = dataReader.IsDBNull(FIELD_ENDTIME) ? new DateTime(): dataReader.GetDateTime(FIELD_ENDTIME);
            j.OriginTypeId = dataReader.IsDBNull(FIELD_ORIGINTYPEID) ? 0: dataReader.GetInt32(FIELD_ORIGINTYPEID);
            j.OriginId = dataReader.IsDBNull(FIELD_ORIGINID) ? 0: dataReader.GetInt32(FIELD_ORIGINID);
            j.DestinationTypeId = dataReader.IsDBNull(FIELD_DESTINATIONTYPEID) ? 0: dataReader.GetInt32(FIELD_DESTINATIONTYPEID);
            j.DestinationId = dataReader.IsDBNull(FIELD_DESTINATIONID) ? 0: dataReader.GetInt32(FIELD_DESTINATIONID);
            j.JobNumberStatusId = dataReader.IsDBNull(FIELD_JOBNUMBERSTATUSID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERSTATUSID);
            j.JobNumberDescription = dataReader.IsDBNull(FIELD_JOBNUMBERDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_JOBNUMBERDESCRIPTION);
            j.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            j.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            j.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            j.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) j.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, j.RowUpdateVersion, 0, 8);

            return j;
        }

        private static bool SqlSaveInsert(ref JobNumber j)
        {
            string sqlStatement = "JobNumberInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)j.JobNumberAssignment));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)j.CustomerId));
            if (j.JobNumberDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobNumberDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobNumberDate", (object)j.JobNumberDate));
            }
            if (j.StartTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@StartTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@StartTime", (object)j.StartTime));
            }
            if (j.EndTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@EndTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@EndTime", (object)j.EndTime));
            }
            command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)j.OriginTypeId));
            command.Parameters.Add(new SqlParameter("@OriginId", (object)j.OriginId));
            command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)j.DestinationTypeId));
            command.Parameters.Add(new SqlParameter("@DestinationId", (object)j.DestinationId));
            command.Parameters.Add(new SqlParameter("@JobNumberStatusId", (object)j.JobNumberStatusId));
            command.Parameters.Add(new SqlParameter("@JobNumberDescription", (object)j.JobNumberDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            j.JobNumberId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return j.JobNumberId != 0;
        }

        private static bool SqlSaveUpdate(ref JobNumber j)
        {
            string sqlStatement = "JobNumberUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)j.JobNumberId));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)j.CustomerId));
            command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)j.JobNumberAssignment));
            if (j.JobNumberDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobNumberDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobNumberDate", (object)j.JobNumberDate));
            }
            if (j.StartTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@StartTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@StartTime", (object)j.StartTime));
            }
            if (j.EndTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@EndTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@EndTime", (object)j.EndTime));
            }
            command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)j.OriginTypeId));
            command.Parameters.Add(new SqlParameter("@OriginId", (object)j.OriginId));
            command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)j.DestinationTypeId));
            command.Parameters.Add(new SqlParameter("@DestinationId", (object)j.DestinationId));
            command.Parameters.Add(new SqlParameter("@JobNumberStatusId", (object)j.JobNumberStatusId));
            command.Parameters.Add(new SqlParameter("@JobNumberDescription", (object)j.JobNumberDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }

}
