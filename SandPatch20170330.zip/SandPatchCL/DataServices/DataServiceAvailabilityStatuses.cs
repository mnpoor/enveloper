using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceAvailabilityStatuses
    {

        #region Private Members

        private const int FIELD_AVAILABILITYSTATUSID          = 0;
        private const int FIELD_AVAILABILITYSTATUSDESCRIPTION = 1;
        private const int FIELD_AVAILABILITYCOLORCODE         = 2;
        private const int FIELD_DATEADDED                     = 3;
        private const int FIELD_ADDEDBY                       = 4;
        private const int FIELD_DATEUPDATED                   = 5;
        private const int FIELD_UPDATEDBY                     = 6;
        private const int FIELD_ROWUPDATEVERSION              = 7;

        #endregion


        #region Constructor

        private DataServiceAvailabilityStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static AvailabilityStatus AvailabilityStatusSqlGetById(int availabilityStatusId)
        {
            string sqlStatement = "GetAvailabilityStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@AvailabilityStatusId", (object)availabilityStatusId));

            IDataReader dataReader;

            AvailabilityStatus a = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                a = AvailabilityStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return a;
        }

        //public static Collection<AvailabilityStatus> AvailabilityStatusSqlGetBySearchTerms(string AvailabilityStatusId, string AvailabilityStatusDescription, string AvailabilityColorCode)
        //{
        //    string sqlStatement = "SelectAvailabilityStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (AvailabilityStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@AvailabilityStatusId", (object)AvailabilityStatusId));
        //    if (AvailabilityStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@AvailabilityStatusDescription", (object)AvailabilityStatusDescription));
        //    if (AvailabilityColorCode != string.Empty) command.Parameters.Add(new SqlParameter("@AvailabilityColorCode", (object)AvailabilityColorCode));

        //    IDataReader dataReader;

        //    Collection<AvailabilityStatus> rowCollection = new Collection<AvailabilityStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        AvailabilityStatus a = AvailabilityStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(a);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<AvailabilityStatus> AvailabilityStatusSqlGetAll()
        {
            string sqlStatement = "GetAllAvailabilityStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<AvailabilityStatus> rowCollection = new Collection<AvailabilityStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                AvailabilityStatus a = AvailabilityStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(a);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref AvailabilityStatus a)
        {
            bool saved = false;

            if (a.AvailabilityStatusId == 0)
            {
                saved = SqlSaveInsert(ref a);
            }
            else
            {
                saved = SqlSaveUpdate(ref a);
            }

            return saved;
        }

        public static bool SqlDelete(ref AvailabilityStatus a)
        {
            string sqlStatement = "delete from AvailabilityStatuses where AvailabilityStatusId = " + a.AvailabilityStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static AvailabilityStatus AvailabilityStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            AvailabilityStatus a = new AvailabilityStatus();

            a.AvailabilityStatusId = dataReader.IsDBNull(FIELD_AVAILABILITYSTATUSID) ? 0: dataReader.GetInt32(FIELD_AVAILABILITYSTATUSID);
            a.AvailabilityStatusDescription = dataReader.IsDBNull(FIELD_AVAILABILITYSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_AVAILABILITYSTATUSDESCRIPTION);
            a.AvailabilityColorCode = dataReader.IsDBNull(FIELD_AVAILABILITYCOLORCODE) ? string.Empty: dataReader.GetString(FIELD_AVAILABILITYCOLORCODE);
            a.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            a.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            a.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            a.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) a.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, a.RowUpdateVersion, 0, 8);

            return a;
        }

        private static bool SqlSaveInsert(ref AvailabilityStatus a)
        {
            string sqlStatement = "AvailabilityStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@AvailabilityStatusDescription", (object)a.AvailabilityStatusDescription));
            command.Parameters.Add(new SqlParameter("@AvailabilityColorCode", (object)a.AvailabilityColorCode));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            a.AvailabilityStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return a.AvailabilityStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref AvailabilityStatus a)
        {
            string sqlStatement = "AvailabilityStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@AvailabilityStatusId", (object)a.AvailabilityStatusId));
            command.Parameters.Add(new SqlParameter("@AvailabilityStatusDescription", (object)a.AvailabilityStatusDescription));
            command.Parameters.Add(new SqlParameter("@AvailabilityColorCode", (object)a.AvailabilityColorCode));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
