using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceRawImports
    {

        #region Private Members

        private const int FIELD_RAWIMPORTID                        = 0;
        private const int FIELD_CUSTOMERID                         = 1;
        private const int FIELD_TRUCKNUMBER                        = 2;
        private const int FIELD_DISPATCHACCEPTANCENUMBER           = 3;
        private const int FIELD_DISPATCHACCEPTANCEDATE             = 4;
        private const int FIELD_SANDTYPE                           = 5;
        private const int FIELD_PURCHASEORDERNUMBER                = 6;
        private const int FIELD_LOADINGTERMINALAPPOINTMENTDATETIME = 7;
        private const int FIELD_ACTUALLOADINGTERMINALARRIVALTIME   = 8;
        private const int FIELD_ACTUALLOADINGTERMINALDEPARTURETIME = 9;
        private const int FIELD_BILLOFLADING                       = 10;
        private const int FIELD_SHIPMENTWEIGHT                     = 11;
        private const int FIELD_TICKETNUMBER                       = 12;
        private const int FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME = 13;
        private const int FIELD_JOBSITEACTUALARRIVALTIME           = 14;
        private const int FIELD_JOBSITEACTUALDEPARTURETIME         = 15;
        private const int FIELD_DATEADDED                          = 16;
        private const int FIELD_ADDEDBY                            = 17;
        private const int FIELD_DATEUPDATED                        = 18;
        private const int FIELD_UPDATEDBY                          = 19;
        private const int FIELD_ROWUPDATEVERSION                   = 20;

        #endregion


        #region Constructor

        private DataServiceRawImports() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static RawImport RawImportSqlGetById(int rawImportId)
        {
            string sqlStatement = "GetRawImportById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@RawImportId", (object)rawImportId));

            IDataReader dataReader;

            RawImport r = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                r = RawImportGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return r;
        }

        public static Collection<RawImport> RawImportSqlGetAll()
        {
            string sqlStatement = "GetAllRawImports";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<RawImport> rowCollection = new Collection<RawImport>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                RawImport r = RawImportGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(r);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref RawImport r)
        {
            bool saved = false;

            if (r.RawImportId == 0)
            {
                saved = SqlSaveInsert(ref r);
            }
            else
            {
                saved = SqlSaveUpdate(ref r);
            }

            return saved;
        }

        public static bool SqlDelete(ref RawImport r)
        {
            string sqlStatement = "delete from RawImports where RawImportId = " + r.RawImportId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static RawImport RawImportGetFromSqlDataReader(ref IDataReader dataReader)
        {
            RawImport r = new RawImport();

            r.RawImportId = dataReader.IsDBNull(FIELD_RAWIMPORTID) ? 0: dataReader.GetInt32(FIELD_RAWIMPORTID);
            r.CustomerId = dataReader.IsDBNull(FIELD_CUSTOMERID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERID);
            r.TruckNumber = dataReader.IsDBNull(FIELD_TRUCKNUMBER) ? string.Empty: dataReader.GetString(FIELD_TRUCKNUMBER);
            r.DispatchAcceptanceNumber = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCENUMBER) ? string.Empty: dataReader.GetString(FIELD_DISPATCHACCEPTANCENUMBER);
            r.DispatchAcceptanceDate = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCEDATE) ? string.Empty: dataReader.GetString(FIELD_DISPATCHACCEPTANCEDATE);
            r.SandType = dataReader.IsDBNull(FIELD_SANDTYPE) ? string.Empty: dataReader.GetString(FIELD_SANDTYPE);
            r.PurchaseOrderNumber = dataReader.IsDBNull(FIELD_PURCHASEORDERNUMBER) ? string.Empty: dataReader.GetString(FIELD_PURCHASEORDERNUMBER);
            r.LoadingTerminalAppointmentDateTime = dataReader.IsDBNull(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME);
            r.ActualLoadingTerminalArrivalTime = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALARRIVALTIME) ? string.Empty: dataReader.GetString(FIELD_ACTUALLOADINGTERMINALARRIVALTIME);
            r.ActualLoadingTerminalDepartureTime = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME) ? string.Empty: dataReader.GetString(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME);
            r.BillOfLading = dataReader.IsDBNull(FIELD_BILLOFLADING) ? string.Empty: dataReader.GetString(FIELD_BILLOFLADING);
            r.ShipmentWeight = dataReader.IsDBNull(FIELD_SHIPMENTWEIGHT) ? string.Empty: dataReader.GetString(FIELD_SHIPMENTWEIGHT);
            r.TicketNumber = dataReader.IsDBNull(FIELD_TICKETNUMBER) ? string.Empty: dataReader.GetString(FIELD_TICKETNUMBER);
            r.JobSiteDeliveryAppointmentDateTime = dataReader.IsDBNull(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME) ? string.Empty: dataReader.GetString(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME);
            r.JobSiteActualArrivalTime = dataReader.IsDBNull(FIELD_JOBSITEACTUALARRIVALTIME) ? string.Empty: dataReader.GetString(FIELD_JOBSITEACTUALARRIVALTIME);
            r.JobSiteActualDepartureTime = dataReader.IsDBNull(FIELD_JOBSITEACTUALDEPARTURETIME) ? string.Empty: dataReader.GetString(FIELD_JOBSITEACTUALDEPARTURETIME);
            r.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            r.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            r.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            r.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) r.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, r.RowUpdateVersion, 0, 8);

            return r;
        }

        private static bool SqlSaveInsert(ref RawImport r)
        {
            string sqlStatement = "RawImportInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerId", (object)r.CustomerId));
            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)r.TruckNumber));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)r.DispatchAcceptanceNumber));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceDate", (object)r.DispatchAcceptanceDate));
            command.Parameters.Add(new SqlParameter("@SandType", (object)r.SandType));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)r.PurchaseOrderNumber));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)r.LoadingTerminalAppointmentDateTime));
            command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)r.ActualLoadingTerminalArrivalTime));
            command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)r.ActualLoadingTerminalDepartureTime));
            command.Parameters.Add(new SqlParameter("@BillOfLading", (object)r.BillOfLading));
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)r.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@TicketNumber", (object)r.TicketNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)r.JobSiteDeliveryAppointmentDateTime));
            command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)r.JobSiteActualArrivalTime));
            command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)r.JobSiteActualDepartureTime));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            r.RawImportId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return r.RawImportId != 0;
        }

        private static bool SqlSaveUpdate(ref RawImport r)
        {
            string sqlStatement = "RawImportUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@RawImportId", (object)r.RawImportId));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)r.CustomerId));
            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)r.TruckNumber));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)r.DispatchAcceptanceNumber));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceDate", (object)r.DispatchAcceptanceDate));
            command.Parameters.Add(new SqlParameter("@SandType", (object)r.SandType));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)r.PurchaseOrderNumber));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)r.LoadingTerminalAppointmentDateTime));
            command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)r.ActualLoadingTerminalArrivalTime));
            command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)r.ActualLoadingTerminalDepartureTime));
            command.Parameters.Add(new SqlParameter("@BillOfLading", (object)r.BillOfLading));
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)r.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@TicketNumber", (object)r.TicketNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)r.JobSiteDeliveryAppointmentDateTime));
            command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)r.JobSiteActualArrivalTime));
            command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)r.JobSiteActualDepartureTime));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
