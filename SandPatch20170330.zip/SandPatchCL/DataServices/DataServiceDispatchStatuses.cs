using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDispatchStatuses
    {

        #region Private Members

        private const int FIELD_DISPATCHSTATUSID                = 0;
        private const int FIELD_DISPATCHSTATUSDESCRIPTION       = 1;
        private const int FIELD_DISPATCHINCLUDEINOPENDISPATCHES = 2;
        private const int FIELD_DATEADDED                       = 3;
        private const int FIELD_ADDEDBY                         = 4;
        private const int FIELD_DATEUPDATED                     = 5;
        private const int FIELD_UPDATEDBY                       = 6;
        private const int FIELD_ROWUPDATEVERSION                = 7;

        #endregion


        #region Constructor

        private DataServiceDispatchStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static DispatchStatus DispatchStatusSqlGetById(int dispatchStatusId)
        {
            string sqlStatement = "GetDispatchStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)dispatchStatusId));

            IDataReader dataReader;

            DispatchStatus d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DispatchStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        //public static Collection<DispatchStatus> DispatchStatusSqlGetBySearchTerms(string DispatchStatusId, string DispatchStatusDescription, string DispatchIncludeInOpenDispatches)
        //{
        //    string sqlStatement = "SelectDispatchStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (DispatchStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)DispatchStatusId));
        //    if (DispatchStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@DispatchStatusDescription", (object)DispatchStatusDescription));
        //    if (DispatchIncludeInOpenDispatches != string.Empty) command.Parameters.Add(new SqlParameter("@DispatchIncludeInOpenDispatches", (object)DispatchIncludeInOpenDispatches));

        //    IDataReader dataReader;

        //    Collection<DispatchStatus> rowCollection = new Collection<DispatchStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        DispatchStatus d = DispatchStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(d);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<DispatchStatus> DispatchStatusSqlGetAll()
        {
            string sqlStatement = "GetAllDispatchStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<DispatchStatus> rowCollection = new Collection<DispatchStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DispatchStatus d = DispatchStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref DispatchStatus d)
        {
            bool saved = false;

            if (d.DispatchStatusId == 0)
            {
                saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        public static bool SqlDelete(ref DispatchStatus d)
        {
            string sqlStatement = "delete from DispatchStatuses where DispatchStatusId = " + d.DispatchStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static DispatchStatus DispatchStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            DispatchStatus d = new DispatchStatus();

            d.DispatchStatusId = dataReader.IsDBNull(FIELD_DISPATCHSTATUSID) ? 0: dataReader.GetInt32(FIELD_DISPATCHSTATUSID);
            d.DispatchStatusDescription = dataReader.IsDBNull(FIELD_DISPATCHSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_DISPATCHSTATUSDESCRIPTION);
            d.DispatchIncludeInOpenDispatches = dataReader.IsDBNull(FIELD_DISPATCHINCLUDEINOPENDISPATCHES) ? (short)0: dataReader.GetInt16(FIELD_DISPATCHINCLUDEINOPENDISPATCHES);
            d.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            d.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            d.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            d.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, d.RowUpdateVersion, 0, 8);

            return d;
        }

        private static bool SqlSaveInsert(ref DispatchStatus d)
        {
            string sqlStatement = "DispatchStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchStatusDescription", (object)d.DispatchStatusDescription));
            command.Parameters.Add(new SqlParameter("@DispatchIncludeInOpenDispatches", (object)d.DispatchIncludeInOpenDispatches));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            d.DispatchStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return d.DispatchStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref DispatchStatus d)
        {
            string sqlStatement = "DispatchStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)d.DispatchStatusId));
            command.Parameters.Add(new SqlParameter("@DispatchStatusDescription", (object)d.DispatchStatusDescription));
            command.Parameters.Add(new SqlParameter("@DispatchIncludeInOpenDispatches", (object)d.DispatchIncludeInOpenDispatches));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
