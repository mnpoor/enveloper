using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServicePayScheduleStatuses
    {

        #region Private Members

        private const int FIELD_PAYSCHEDULESTATUSID          = 0;
        private const int FIELD_PAYSCHEDULESTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                    = 2;
        private const int FIELD_ADDEDBY                      = 3;
        private const int FIELD_DATEUPDATED                  = 4;
        private const int FIELD_UPDATEDBY                    = 5;
        private const int FIELD_ROWUPDATEVERSION             = 6;

        #endregion


        #region Constructor

        private DataServicePayScheduleStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static PayScheduleStatus PayScheduleStatusSqlGetById(int payScheduleStatusId)
        {
            string sqlStatement = "GetPayScheduleStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PayScheduleStatusId", (object)payScheduleStatusId));

            IDataReader dataReader;

            PayScheduleStatus p = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                p = PayScheduleStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return p;
        }

        //public static Collection<PayScheduleStatus> PayScheduleStatusSqlGetBySearchTerms(string PayScheduleStatusId, string PayScheduleStatusDescription, )
        //{
        //    string sqlStatement = "SelectPayScheduleStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (PayScheduleStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@PayScheduleStatusId", (object)PayScheduleStatusId));
        //    if (PayScheduleStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@PayScheduleStatusDescription", (object)PayScheduleStatusDescription));

        //    IDataReader dataReader;

        //    Collection<PayScheduleStatus> rowCollection = new Collection<PayScheduleStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        PayScheduleStatus p = PayScheduleStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(p);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<PayScheduleStatus> PayScheduleStatusSqlGetAll()
        {
            string sqlStatement = "GetAllPayScheduleStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<PayScheduleStatus> rowCollection = new Collection<PayScheduleStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PayScheduleStatus p = PayScheduleStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref PayScheduleStatus p)
        {
            bool saved = false;

            if (p.PayScheduleStatusId == 0)
            {
                saved = SqlSaveInsert(ref p);
            }
            else
            {
                saved = SqlSaveUpdate(ref p);
            }

            return saved;
        }

        public static bool SqlDelete(ref PayScheduleStatus p)
        {
            string sqlStatement = "delete from PayScheduleStatuses where PayScheduleStatusId = " + p.PayScheduleStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static PayScheduleStatus PayScheduleStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            PayScheduleStatus p = new PayScheduleStatus();

            p.PayScheduleStatusId = dataReader.IsDBNull(FIELD_PAYSCHEDULESTATUSID) ? 0: dataReader.GetInt32(FIELD_PAYSCHEDULESTATUSID);
            p.PayScheduleStatusDescription = dataReader.IsDBNull(FIELD_PAYSCHEDULESTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_PAYSCHEDULESTATUSDESCRIPTION);
            p.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            p.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            p.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            p.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) p.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, p.RowUpdateVersion, 0, 8);

            return p;
        }

        private static bool SqlSaveInsert(ref PayScheduleStatus p)
        {
            string sqlStatement = "PayScheduleStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PayScheduleStatusDescription", (object)p.PayScheduleStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            p.PayScheduleStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return p.PayScheduleStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref PayScheduleStatus p)
        {
            string sqlStatement = "PayScheduleStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PayScheduleStatusId", (object)p.PayScheduleStatusId));
            command.Parameters.Add(new SqlParameter("@PayScheduleStatusDescription", (object)p.PayScheduleStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
