using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDriverWithholdings
    {

        #region Private Members

        private const int FIELD_DRIVERWITHOLDINGID                  = 0;
        private const int FIELD_CARRIERID                           = 1;
        private const int FIELD_DRIVERID                            = 2;
        private const int FIELD_WITHHOLDINGACCOUNTID                = 3;
        private const int FIELD_DRIVERWITHOLDINGLEDGERACCOUNTNAME   = 4;
        private const int FIELD_DRIVERWITHOLDINGLEDGERACCOUNTNUMBER = 5;
        private const int FIELD_WITHHOLDINGAMOUNT                   = 6;
        private const int FIELD_WITHHOLDINGPERCENTAGE               = 7;
        private const int FIELD_LICENCEPLATEMONTH                   = 8;
        private const int FIELD_FIRSTTRANSACTIONDATE                = 9;
        private const int FIELD_LASTTRANSACTIONDATE                 = 10;
        private const int FIELD_DATEADDED                           = 11;
        private const int FIELD_ADDEDBY                             = 12;
        private const int FIELD_DATEUPDATED                         = 13;
        private const int FIELD_UPDATEDBY                           = 14;
        private const int FIELD_ROWUPDATEVERSION                    = 15;

        #endregion


        #region Constructor

        private DataServiceDriverWithholdings() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static DriverWithholding DriverWithholdingSqlGetById(int driverWitholdingId)
        {
            string sqlStatement = "GetDriverWithholdingById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverWitholdingId", (object)driverWitholdingId));

            IDataReader dataReader;

            DriverWithholding d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DriverWithholdingGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        public static Collection<DriverWithholding> DriverWithholdingSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectDriverWithholdingsSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@DriverWitholdingId", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierId", (object)searchTerms[1]));
            if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@DriverId", (object)searchTerms[2]));

            IDataReader dataReader;

            Collection<DriverWithholding> rowCollection = new Collection<DriverWithholding>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DriverWithholding d = DriverWithholdingGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<DriverWithholding> DriverWithholdingSqlGetAll()
        {
            string sqlStatement = "GetAllDriverWithholdings";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<DriverWithholding> rowCollection = new Collection<DriverWithholding>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DriverWithholding d = DriverWithholdingGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref DriverWithholding d)
        {
            bool saved = false;

            if (d.DriverWitholdingId == 0)
            {
                saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        public static bool SqlDelete(ref DriverWithholding d)
        {
            string sqlStatement = "delete from DriverWithholdings where DriverWitholdingId = " + d.DriverWitholdingId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static DriverWithholding DriverWithholdingGetFromSqlDataReader(ref IDataReader dataReader)
        {
            DriverWithholding d = new DriverWithholding();

            d.DriverWitholdingId = dataReader.IsDBNull(FIELD_DRIVERWITHOLDINGID) ? 0: dataReader.GetInt32(FIELD_DRIVERWITHOLDINGID);
            d.CarrierId = dataReader.IsDBNull(FIELD_CARRIERID) ? 0: dataReader.GetInt32(FIELD_CARRIERID);
            d.DriverId = dataReader.IsDBNull(FIELD_DRIVERID) ? 0: dataReader.GetInt32(FIELD_DRIVERID);
            d.WithholdingAccountId = dataReader.IsDBNull(FIELD_WITHHOLDINGACCOUNTID) ? 0: dataReader.GetInt32(FIELD_WITHHOLDINGACCOUNTID);
            d.DriverWitholdingLedgerAccountName = dataReader.IsDBNull(FIELD_DRIVERWITHOLDINGLEDGERACCOUNTNAME) ? string.Empty: dataReader.GetString(FIELD_DRIVERWITHOLDINGLEDGERACCOUNTNAME);
            d.DriverWitholdingLedgerAccountNumber = dataReader.IsDBNull(FIELD_DRIVERWITHOLDINGLEDGERACCOUNTNUMBER) ? string.Empty: dataReader.GetString(FIELD_DRIVERWITHOLDINGLEDGERACCOUNTNUMBER);
            d.WithholdingAmount = dataReader.IsDBNull(FIELD_WITHHOLDINGAMOUNT) ? 0: dataReader.GetDecimal(FIELD_WITHHOLDINGAMOUNT);
            d.WithholdingPercentage = dataReader.IsDBNull(FIELD_WITHHOLDINGPERCENTAGE) ? 0: dataReader.GetDecimal(FIELD_WITHHOLDINGPERCENTAGE);
            d.LicencePlateMonth = dataReader.IsDBNull(FIELD_LICENCEPLATEMONTH) ? 0: dataReader.GetInt32(FIELD_LICENCEPLATEMONTH);
            d.FirstTransactionDate = dataReader.IsDBNull(FIELD_FIRSTTRANSACTIONDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_FIRSTTRANSACTIONDATE);
            d.LastTransactionDate = dataReader.IsDBNull(FIELD_LASTTRANSACTIONDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_LASTTRANSACTIONDATE);
            d.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            d.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            d.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            d.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, d.RowUpdateVersion, 0, 8);

            return d;
        }

        private static bool SqlSaveInsert(ref DriverWithholding d)
        {
            string sqlStatement = "DriverWithholdingInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierId", (object)d.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
            command.Parameters.Add(new SqlParameter("@WithholdingAccountId", (object)d.WithholdingAccountId));
            command.Parameters.Add(new SqlParameter("@DriverWitholdingLedgerAccountName", (object)d.DriverWitholdingLedgerAccountName));
            command.Parameters.Add(new SqlParameter("@DriverWitholdingLedgerAccountNumber", (object)d.DriverWitholdingLedgerAccountNumber));
            command.Parameters.Add(new SqlParameter("@WithholdingAmount", (object)d.WithholdingAmount));
            command.Parameters.Add(new SqlParameter("@WithholdingPercentage", (object)d.WithholdingPercentage));
            command.Parameters.Add(new SqlParameter("@LicencePlateMonth", (object)d.LicencePlateMonth));
            if (d.FirstTransactionDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@FirstTransactionDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@FirstTransactionDate", (object)d.FirstTransactionDate));
            }
            if (d.LastTransactionDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@LastTransactionDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@LastTransactionDate", (object)d.LastTransactionDate));
            }
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            d.DriverWitholdingId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return d.DriverWitholdingId != 0;
        }

        private static bool SqlSaveUpdate(ref DriverWithholding d)
        {
            string sqlStatement = "DriverWithholdingUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverWitholdingId", (object)d.DriverWitholdingId));
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)d.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
            command.Parameters.Add(new SqlParameter("@WithholdingAccountId", (object)d.WithholdingAccountId));
            command.Parameters.Add(new SqlParameter("@DriverWitholdingLedgerAccountName", (object)d.DriverWitholdingLedgerAccountName));
            command.Parameters.Add(new SqlParameter("@DriverWitholdingLedgerAccountNumber", (object)d.DriverWitholdingLedgerAccountNumber));
            command.Parameters.Add(new SqlParameter("@WithholdingAmount", (object)d.WithholdingAmount));
            command.Parameters.Add(new SqlParameter("@WithholdingPercentage", (object)d.WithholdingPercentage));
            command.Parameters.Add(new SqlParameter("@LicencePlateMonth", (object)d.LicencePlateMonth));
            if (d.FirstTransactionDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@FirstTransactionDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@FirstTransactionDate", (object)d.FirstTransactionDate));
            }
            if (d.LastTransactionDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@LastTransactionDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@LastTransactionDate", (object)d.LastTransactionDate));
            }

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
