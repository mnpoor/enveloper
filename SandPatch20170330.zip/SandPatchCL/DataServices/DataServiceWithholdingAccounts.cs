using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceWithholdingAccounts
    {

        #region Private Members

        private const int FIELD_WITHHOLDINGID                   = 0;
        private const int FIELD_WITHHOLDINGACCOUNTNAME          = 1;
        private const int FIELD_WITHHOLDINGSUMMARYACCOUNTNUMBER = 2;
        private const int FIELD_DATEADDED                       = 3;
        private const int FIELD_ADDEDBY                         = 4;
        private const int FIELD_DATEUPDATED                     = 5;
        private const int FIELD_UPDATEDBY                       = 6;
        private const int FIELD_ROWUPDATEVERSION                = 7;

        #endregion


        #region Constructor

        private DataServiceWithholdingAccounts() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static WithholdingAccount WithholdingAccountSqlGetById(int withholdingId)
        {
            string sqlStatement = "GetWithholdingAccountById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WithholdingId", (object)withholdingId));

            IDataReader dataReader;

            WithholdingAccount w = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                w = WithholdingAccountGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return w;
        }

        //public static Collection<WithholdingAccount> WithholdingAccountSqlGetBySearchTerms(string[] searchTerms)
        //{
        //    string sqlStatement = "SelectWithholdingAccountsSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@WithholdingAccountName", (object)searchTerms[0]));
        //    if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@WithholdingSummaryAccountNumber", (object)searchTerms[1]));

        //    IDataReader dataReader;

        //    Collection<WithholdingAccount> rowCollection = new Collection<WithholdingAccount>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        WithholdingAccount w = WithholdingAccountGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(w);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<WithholdingAccount> WithholdingAccountSqlGetAll()
        {
            string sqlStatement = "GetAllWithholdingAccounts";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<WithholdingAccount> rowCollection = new Collection<WithholdingAccount>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                WithholdingAccount w = WithholdingAccountGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(w);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref WithholdingAccount w)
        {
            bool saved = false;

            if (w.WithholdingId == 0)
            {
                saved = SqlSaveInsert(ref w);
            }
            else
            {
                saved = SqlSaveUpdate(ref w);
            }

            return saved;
        }

        public static bool SqlDelete(ref WithholdingAccount w)
        {
            string sqlStatement = "delete from WithholdingAccounts where WithholdingId = " + w.WithholdingId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static WithholdingAccount WithholdingAccountGetFromSqlDataReader(ref IDataReader dataReader)
        {
            WithholdingAccount w = new WithholdingAccount();

            w.WithholdingId = dataReader.IsDBNull(FIELD_WITHHOLDINGID) ? 0: dataReader.GetInt32(FIELD_WITHHOLDINGID);
            w.WithholdingAccountName = dataReader.IsDBNull(FIELD_WITHHOLDINGACCOUNTNAME) ? string.Empty: dataReader.GetString(FIELD_WITHHOLDINGACCOUNTNAME);
            w.WithholdingSummaryAccountNumber = dataReader.IsDBNull(FIELD_WITHHOLDINGSUMMARYACCOUNTNUMBER) ? string.Empty: dataReader.GetString(FIELD_WITHHOLDINGSUMMARYACCOUNTNUMBER);
            w.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            w.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            w.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            w.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) w.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, w.RowUpdateVersion, 0, 8);

            return w;
        }

        private static bool SqlSaveInsert(ref WithholdingAccount w)
        {
            string sqlStatement = "WithholdingAccountInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WithholdingAccountName", (object)w.WithholdingAccountName));
            command.Parameters.Add(new SqlParameter("@WithholdingSummaryAccountNumber", (object)w.WithholdingSummaryAccountNumber));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            w.WithholdingId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return w.WithholdingId != 0;
        }

        private static bool SqlSaveUpdate(ref WithholdingAccount w)
        {
            string sqlStatement = "WithholdingAccountUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WithholdingId", (object)w.WithholdingId));
            command.Parameters.Add(new SqlParameter("@WithholdingAccountName", (object)w.WithholdingAccountName));
            command.Parameters.Add(new SqlParameter("@WithholdingSummaryAccountNumber", (object)w.WithholdingSummaryAccountNumber));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
