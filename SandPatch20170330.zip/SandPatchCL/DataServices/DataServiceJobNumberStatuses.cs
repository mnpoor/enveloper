using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceJobNumberStatuses
    {

        #region Private Members

        private const int FIELD_JOBNUMBERSTATUSID          = 0;
        private const int FIELD_JOBNUMBERSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                  = 2;
        private const int FIELD_ADDEDBY                    = 3;
        private const int FIELD_DATEUPDATED                = 4;
        private const int FIELD_UPDATEDBY                  = 5;
        private const int FIELD_ROWUPDATEVERSION           = 6;

        #endregion


        #region Constructor

        private DataServiceJobNumberStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static JobNumberStatus JobNumberStatusSqlGetById(int jobNumberStatusId)
        {
            string sqlStatement = "GetJobNumberStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberStatusId", (object)jobNumberStatusId));

            IDataReader dataReader;

            JobNumberStatus j = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                j = JobNumberStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return j;
        }

        //public static Collection<JobNumberStatus> JobNumberStatusSqlGetBySearchTerms(string JobNumberStatusId, string JobNumberStatusDescription, )
        //{
        //    string sqlStatement = "SelectJobNumberStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (JobNumberStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberStatusId", (object)JobNumberStatusId));
        //    if (JobNumberStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberStatusDescription", (object)JobNumberStatusDescription));

        //    IDataReader dataReader;

        //    Collection<JobNumberStatus> rowCollection = new Collection<JobNumberStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        JobNumberStatus j = JobNumberStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(j);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<JobNumberStatus> JobNumberStatusSqlGetAll()
        {
            string sqlStatement = "GetAllJobNumberStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<JobNumberStatus> rowCollection = new Collection<JobNumberStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                JobNumberStatus j = JobNumberStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(j);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref JobNumberStatus j)
        {
            bool saved = false;

            if (j.JobNumberStatusId == 0)
            {
                saved = SqlSaveInsert(ref j);
            }
            else
            {
                saved = SqlSaveUpdate(ref j);
            }

            return saved;
        }

        public static bool SqlDelete(ref JobNumberStatus j)
        {
            string sqlStatement = "delete from JobNumberStatuses where JobNumberStatusId = " + j.JobNumberStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static JobNumberStatus JobNumberStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            JobNumberStatus j = new JobNumberStatus();

            j.JobNumberStatusId = dataReader.IsDBNull(FIELD_JOBNUMBERSTATUSID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERSTATUSID);
            j.JobNumberStatusDescription = dataReader.IsDBNull(FIELD_JOBNUMBERSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_JOBNUMBERSTATUSDESCRIPTION);
            j.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            j.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            j.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            j.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) j.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, j.RowUpdateVersion, 0, 8);

            return j;
        }

        private static bool SqlSaveInsert(ref JobNumberStatus j)
        {
            string sqlStatement = "JobNumberStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberStatusDescription", (object)j.JobNumberStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            j.JobNumberStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return j.JobNumberStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref JobNumberStatus j)
        {
            string sqlStatement = "JobNumberStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberStatusId", (object)j.JobNumberStatusId));
            command.Parameters.Add(new SqlParameter("@JobNumberStatusDescription", (object)j.JobNumberStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
