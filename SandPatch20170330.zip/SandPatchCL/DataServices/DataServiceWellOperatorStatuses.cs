using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceWellOperatorStatuses
    {

        #region Private Members

        private const int FIELD_WELLOPERATORSTATUSID          = 0;
        private const int FIELD_WELLOPERATORSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                     = 2;
        private const int FIELD_ADDEDBY                       = 3;
        private const int FIELD_DATEUPDATED                   = 4;
        private const int FIELD_UPDATEDBY                     = 5;
        private const int FIELD_ROWUPDATEVERSION              = 6;

        #endregion


        #region Constructor

        private DataServiceWellOperatorStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static WellOperatorStatus WellOperatorStatusSqlGetById(int wellOperatorStatusId)
        {
            string sqlStatement = "GetWellOperatorStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WellOperatorStatusId", (object)wellOperatorStatusId));

            IDataReader dataReader;

            WellOperatorStatus w = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                w = WellOperatorStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return w;
        }

        //public static Collection<WellOperatorStatus> WellOperatorStatusSqlGetBySearchTerms(string WellOperatorStatusId, string WellOperatorStatusDescription)
        //{
        //    string sqlStatement = "SelectWellOperatorStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (WellOperatorStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@WellOperatorStatusId", (object)WellOperatorStatusId));
        //    if (WellOperatorStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@WellOperatorStatusDescription", (object)WellOperatorStatusDescription));

        //    IDataReader dataReader;

        //    Collection<WellOperatorStatus> rowCollection = new Collection<WellOperatorStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        WellOperatorStatus w = WellOperatorStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(w);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<WellOperatorStatus> WellOperatorStatusSqlGetAll()
        {
            string sqlStatement = "GetAllWellOperatorStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<WellOperatorStatus> rowCollection = new Collection<WellOperatorStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                WellOperatorStatus w = WellOperatorStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(w);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref WellOperatorStatus w)
        {
            bool saved = false;

            if (w.WellOperatorStatusId == 0)
            {
                saved = SqlSaveInsert(ref w);
            }
            else
            {
                saved = SqlSaveUpdate(ref w);
            }

            return saved;
        }

        public static bool SqlDelete(ref WellOperatorStatus w)
        {
            string sqlStatement = "delete from WellOperatorStatuses where WellOperatorStatusId = " + w.WellOperatorStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static WellOperatorStatus WellOperatorStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            WellOperatorStatus w = new WellOperatorStatus();

            w.WellOperatorStatusId = dataReader.IsDBNull(FIELD_WELLOPERATORSTATUSID) ? 0: dataReader.GetInt32(FIELD_WELLOPERATORSTATUSID);
            w.WellOperatorStatusDescription = dataReader.IsDBNull(FIELD_WELLOPERATORSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_WELLOPERATORSTATUSDESCRIPTION);
            w.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            w.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            w.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            w.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) w.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, w.RowUpdateVersion, 0, 8);

            return w;
        }

        private static bool SqlSaveInsert(ref WellOperatorStatus w)
        {
            string sqlStatement = "WellOperatorStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WellOperatorStatusDescription", (object)w.WellOperatorStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            w.WellOperatorStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return w.WellOperatorStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref WellOperatorStatus w)
        {
            string sqlStatement = "WellOperatorStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@WellOperatorStatusId", (object)w.WellOperatorStatusId));
            command.Parameters.Add(new SqlParameter("@WellOperatorStatusDescription", (object)w.WellOperatorStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
