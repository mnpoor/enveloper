using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDriverStatuses
    {

        #region Private Members

        private const int FIELD_DRIVERSTATUSID          = 0;
        private const int FIELD_DRIVERSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED               = 2;
        private const int FIELD_ADDEDBY                 = 3;
        private const int FIELD_DATEUPDATED             = 4;
        private const int FIELD_UPDATEDBY               = 5;
        private const int FIELD_ROWUPDATEVERSION        = 6;

        #endregion


        #region Constructor

        private DataServiceDriverStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static DriverStatus DriverStatusSqlGetById(int driverStatusId)
        {
            string sqlStatement = "GetDriverStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverStatusId", (object)driverStatusId));

            IDataReader dataReader;

            DriverStatus d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DriverStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        public static Collection<DriverStatus> DriverStatusSqlGetBySearchTerms(string DriverStatusId, string DriverStatusDescription)
        {
            string sqlStatement = "SelectDriverStatusesSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (DriverStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@DriverStatusId", (object)DriverStatusId));
            if (DriverStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@DriverStatusDescription", (object)DriverStatusDescription));

            IDataReader dataReader;

            Collection<DriverStatus> rowCollection = new Collection<DriverStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DriverStatus d = DriverStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<DriverStatus> DriverStatusSqlGetAll()
        {
            string sqlStatement = "GetAllDriverStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<DriverStatus> rowCollection = new Collection<DriverStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DriverStatus d = DriverStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref DriverStatus d)
        {
            bool saved = false;

            if (d.DriverStatusId == 0)
            {
                saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        public static bool SqlDelete(ref DriverStatus d)
        {
            string sqlStatement = "delete from DriverStatuses where DriverStatusId = " + d.DriverStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static DriverStatus DriverStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            DriverStatus d = new DriverStatus();

            d.DriverStatusId = dataReader.IsDBNull(FIELD_DRIVERSTATUSID) ? 0: dataReader.GetInt32(FIELD_DRIVERSTATUSID);
            d.DriverStatusDescription = dataReader.IsDBNull(FIELD_DRIVERSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_DRIVERSTATUSDESCRIPTION);
            d.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            d.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            d.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            d.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, d.RowUpdateVersion, 0, 8);

            return d;
        }

        private static bool SqlSaveInsert(ref DriverStatus d)
        {
            string sqlStatement = "DriverStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverStatusDescription", (object)d.DriverStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            d.DriverStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return d.DriverStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref DriverStatus d)
        {
            string sqlStatement = "DriverStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverStatusId", (object)d.DriverStatusId));
            command.Parameters.Add(new SqlParameter("@DriverStatusDescription", (object)d.DriverStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
