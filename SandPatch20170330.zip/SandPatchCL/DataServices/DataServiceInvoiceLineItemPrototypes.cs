using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceInvoiceLineItemPrototypes
    {

        #region Private Members

        private const int FIELD_INVOICELINEITEMPROTOTYPEID = 0;
        private const int FIELD_DEFINITIONDISPLAYORDER     = 1;
        private const int FIELD_TRANSACTIONDESCRIPTION     = 2;
        private const int FIELD_TRANSACTIONDEFAULTTEXT     = 3;
        private const int FIELD_TRANSACTIONVALUESOURCE     = 4;
        private const int FIELD_UNITSDESCRIPTION           = 5;
        private const int FIELD_RECORDQUANTITY             = 6;
        private const int FIELD_RECORDUNITS                = 7;
        private const int FIELD_RECORDRATE                 = 8;
        private const int FIELD_MULTIPLYQUANTITYTIMESRATE  = 9;
        private const int FIELD_RECORDAMOUNT               = 10;
        private const int FIELD_DATEADDED                  = 11;
        private const int FIELD_ADDEDBY                    = 12;
        private const int FIELD_DATEUPDATED                = 13;
        private const int FIELD_UPDATEDBY                  = 14;
        private const int FIELD_ROWUPDATEVERSION           = 15;

        #endregion


        #region Constructor

        private DataServiceInvoiceLineItemPrototypes() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static InvoiceLineItemPrototype InvoiceLineItemPrototypeSqlGetById(int invoiceLineItemPrototypeId)
        {
            string sqlStatement = "GetInvoiceLineItemPrototypeById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@InvoiceLineItemPrototypeId", (object)invoiceLineItemPrototypeId));

            IDataReader dataReader;

            InvoiceLineItemPrototype i = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                i = InvoiceLineItemPrototypeGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return i;
        }

        //public static Collection<InvoiceLineItemPrototype> InvoiceLineItemPrototypeSqlGetBySearchTerms(string[] searchTerms)
        //{
        //    string sqlStatement = "SelectInvoiceLineItemPrototypesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@InvoiceLineItemPrototypeId", (object)searchTerms[0]));
        //    if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@DefinitionDisplayOrder", (object)searchTerms[1]));
        //    if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@TransactionDescription", (object)searchTerms[2]));

        //    IDataReader dataReader;

        //    Collection<InvoiceLineItemPrototype> rowCollection = new Collection<InvoiceLineItemPrototype>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        InvoiceLineItemPrototype i = InvoiceLineItemPrototypeGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(i);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<InvoiceLineItemPrototype> InvoiceLineItemPrototypeSqlGetAll()
        {
            string sqlStatement = "GetAllInvoiceLineItemPrototypes";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<InvoiceLineItemPrototype> rowCollection = new Collection<InvoiceLineItemPrototype>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                InvoiceLineItemPrototype i = InvoiceLineItemPrototypeGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(i);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref InvoiceLineItemPrototype i)
        {
            bool saved = false;

            if (i.InvoiceLineItemPrototypeId == 0)
            {
                saved = SqlSaveInsert(ref i);
            }
            else
            {
                saved = SqlSaveUpdate(ref i);
            }

            return saved;
        }

        public static bool SqlDelete(ref InvoiceLineItemPrototype i)
        {
            string sqlStatement = "delete from InvoiceLineItemPrototypes where InvoiceLineItemPrototypeId = " + i.InvoiceLineItemPrototypeId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static InvoiceLineItemPrototype InvoiceLineItemPrototypeGetFromSqlDataReader(ref IDataReader dataReader)
        {
            InvoiceLineItemPrototype i = new InvoiceLineItemPrototype();

            i.InvoiceLineItemPrototypeId = dataReader.IsDBNull(FIELD_INVOICELINEITEMPROTOTYPEID) ? 0: dataReader.GetInt32(FIELD_INVOICELINEITEMPROTOTYPEID);
            i.DefinitionDisplayOrder = dataReader.IsDBNull(FIELD_DEFINITIONDISPLAYORDER) ? 0: dataReader.GetInt32(FIELD_DEFINITIONDISPLAYORDER);
            i.TransactionDescription = dataReader.IsDBNull(FIELD_TRANSACTIONDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_TRANSACTIONDESCRIPTION);
            i.TransactionDefaultText = dataReader.IsDBNull(FIELD_TRANSACTIONDEFAULTTEXT) ? string.Empty: dataReader.GetString(FIELD_TRANSACTIONDEFAULTTEXT);
            i.TransactionValueSource = dataReader.IsDBNull(FIELD_TRANSACTIONVALUESOURCE) ? 0: dataReader.GetInt32(FIELD_TRANSACTIONVALUESOURCE);
            i.UnitsDescription = dataReader.IsDBNull(FIELD_UNITSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_UNITSDESCRIPTION);
            i.RecordQuantity = dataReader.IsDBNull(FIELD_RECORDQUANTITY) ? (short)0: dataReader.GetInt16(FIELD_RECORDQUANTITY);
            i.RecordUnits = dataReader.IsDBNull(FIELD_RECORDUNITS) ? (short)0: dataReader.GetInt16(FIELD_RECORDUNITS);
            i.RecordRate = dataReader.IsDBNull(FIELD_RECORDRATE) ? (short)0: dataReader.GetInt16(FIELD_RECORDRATE);
            i.MultiplyQuantityTimesRate = dataReader.IsDBNull(FIELD_MULTIPLYQUANTITYTIMESRATE) ? (short)0: dataReader.GetInt16(FIELD_MULTIPLYQUANTITYTIMESRATE);
            i.RecordAmount = dataReader.IsDBNull(FIELD_RECORDAMOUNT) ? (short)0: dataReader.GetInt16(FIELD_RECORDAMOUNT);
            i.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            i.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            i.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            i.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) i.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, i.RowUpdateVersion, 0, 8);

            return i;
        }

        private static bool SqlSaveInsert(ref InvoiceLineItemPrototype i)
        {
            string sqlStatement = "InvoiceLineItemPrototypeInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DefinitionDisplayOrder", (object)i.DefinitionDisplayOrder));
            command.Parameters.Add(new SqlParameter("@TransactionDescription", (object)i.TransactionDescription));
            command.Parameters.Add(new SqlParameter("@TransactionDefaultText", (object)i.TransactionDefaultText));
            command.Parameters.Add(new SqlParameter("@TransactionValueSource", (object)i.TransactionValueSource));
            command.Parameters.Add(new SqlParameter("@UnitsDescription", (object)i.UnitsDescription));
            command.Parameters.Add(new SqlParameter("@RecordQuantity", (object)i.RecordQuantity));
            command.Parameters.Add(new SqlParameter("@RecordUnits", (object)i.RecordUnits));
            command.Parameters.Add(new SqlParameter("@RecordRate", (object)i.RecordRate));
            command.Parameters.Add(new SqlParameter("@MultiplyQuantityTimesRate", (object)i.MultiplyQuantityTimesRate));
            command.Parameters.Add(new SqlParameter("@RecordAmount", (object)i.RecordAmount));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            i.InvoiceLineItemPrototypeId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return i.InvoiceLineItemPrototypeId != 0;
        }

        private static bool SqlSaveUpdate(ref InvoiceLineItemPrototype i)
        {
            string sqlStatement = "InvoiceLineItemPrototypeUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@InvoiceLineItemPrototypeId", (object)i.InvoiceLineItemPrototypeId));
            command.Parameters.Add(new SqlParameter("@DefinitionDisplayOrder", (object)i.DefinitionDisplayOrder));
            command.Parameters.Add(new SqlParameter("@TransactionDescription", (object)i.TransactionDescription));
            command.Parameters.Add(new SqlParameter("@TransactionDefaultText", (object)i.TransactionDefaultText));
            command.Parameters.Add(new SqlParameter("@TransactionValueSource", (object)i.TransactionValueSource));
            command.Parameters.Add(new SqlParameter("@UnitsDescription", (object)i.UnitsDescription));
            command.Parameters.Add(new SqlParameter("@RecordQuantity", (object)i.RecordQuantity));
            command.Parameters.Add(new SqlParameter("@RecordUnits", (object)i.RecordUnits));
            command.Parameters.Add(new SqlParameter("@RecordRate", (object)i.RecordRate));
            command.Parameters.Add(new SqlParameter("@MultiplyQuantityTimesRate", (object)i.MultiplyQuantityTimesRate));
            command.Parameters.Add(new SqlParameter("@RecordAmount", (object)i.RecordAmount));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }

}
