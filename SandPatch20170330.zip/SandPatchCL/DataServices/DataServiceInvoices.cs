using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceInvoices
    {

        #region Private Members

        private const int FIELD_INVOICEID                = 0;
        private const int FIELD_INVOICENUMBER            = 1;
        private const int FIELD_INVOICEDATE              = 2;
        private const int FIELD_SHIPPERBILLINGID         = 3;
        private const int FIELD_BILLTOCUSTOMERID         = 4;
        private const int FIELD_ORIGINTYPEID             = 5;
        private const int FIELD_ORIGINID                 = 6;
        private const int FIELD_DESTINATIONTYPEID        = 7;
        private const int FIELD_DESTINATIONID            = 8;
        private const int FIELD_CHARGECODE               = 9;
        private const int FIELD_PAYMENTTERMSID           = 10;
        private const int FIELD_BILLOFLADINGID           = 11;
        private const int FIELD_DISPATCHID               = 12;
        private const int FIELD_INVOICESUBTOTALAMOUNT    = 13;
        private const int FIELD_INVOICEADJUSTMENTSAMOUNT = 14;
        private const int FIELD_INVOICETOTALAMOUNT       = 15;
        private const int FIELD_DATEADDED                = 16;
        private const int FIELD_ADDEDBY                  = 17;
        private const int FIELD_DATEUPDATED              = 18;
        private const int FIELD_UPDATEDBY                = 19;
        private const int FIELD_ROWUPDATEVERSION         = 20;

        #endregion


        #region Constructor

        private DataServiceInvoices() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Invoice InvoiceSqlGetById(int invoiceId)
        {
            string sqlStatement = "GetInvoiceById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@InvoiceId", (object)invoiceId));

            IDataReader dataReader;

            Invoice i = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                i = InvoiceGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return i;
        }

        public static Collection<Invoice> InvoiceSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectInvoicesSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@InvoiceNumber", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@InvoiceDate", (object)searchTerms[1]));

            IDataReader dataReader;

            Collection<Invoice> rowCollection = new Collection<Invoice>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Invoice i = InvoiceGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(i);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Invoice> InvoiceSqlGetAll()
        {
            string sqlStatement = "GetAllInvoices";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Invoice> rowCollection = new Collection<Invoice>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Invoice i = InvoiceGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(i);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Invoice i)
        {
            bool saved = false;

            if (i.InvoiceId == 0)
            {
                saved = SqlSaveInsert(ref i);
            }
            else
            {
                saved = SqlSaveUpdate(ref i);
            }

            return saved;
        }

        public static bool SqlDelete(ref Invoice i)
        {
            string sqlStatement = "delete from Invoices where InvoiceId = " + i.InvoiceId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Invoice InvoiceGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Invoice i = new Invoice();

            i.InvoiceId = dataReader.IsDBNull(FIELD_INVOICEID) ? 0: dataReader.GetInt32(FIELD_INVOICEID);
            i.InvoiceNumber = dataReader.IsDBNull(FIELD_INVOICENUMBER) ? string.Empty: dataReader.GetString(FIELD_INVOICENUMBER);
            i.InvoiceDate = dataReader.IsDBNull(FIELD_INVOICEDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_INVOICEDATE);
            i.ShipperBillingId = dataReader.IsDBNull(FIELD_SHIPPERBILLINGID) ? 0: dataReader.GetInt32(FIELD_SHIPPERBILLINGID);
            i.BillToCustomerId = dataReader.IsDBNull(FIELD_BILLTOCUSTOMERID) ? 0: dataReader.GetInt32(FIELD_BILLTOCUSTOMERID);
            i.OriginTypeId = dataReader.IsDBNull(FIELD_ORIGINTYPEID) ? 0: dataReader.GetInt32(FIELD_ORIGINTYPEID);
            i.OriginId = dataReader.IsDBNull(FIELD_ORIGINID) ? 0: dataReader.GetInt32(FIELD_ORIGINID);
            i.DestinationTypeId = dataReader.IsDBNull(FIELD_DESTINATIONTYPEID) ? 0: dataReader.GetInt32(FIELD_DESTINATIONTYPEID);
            i.DestinationId = dataReader.IsDBNull(FIELD_DESTINATIONID) ? 0: dataReader.GetInt32(FIELD_DESTINATIONID);
            i.ChargeCode = dataReader.IsDBNull(FIELD_CHARGECODE) ? string.Empty: dataReader.GetString(FIELD_CHARGECODE);
            i.PaymentTermsId = dataReader.IsDBNull(FIELD_PAYMENTTERMSID) ? 0: dataReader.GetInt32(FIELD_PAYMENTTERMSID);
            i.BillOfLadingId = dataReader.IsDBNull(FIELD_BILLOFLADINGID) ? 0: dataReader.GetInt32(FIELD_BILLOFLADINGID);
            i.DispatchId = dataReader.IsDBNull(FIELD_DISPATCHID) ? 0: dataReader.GetInt32(FIELD_DISPATCHID);
            i.InvoiceSubtotalAmount = dataReader.IsDBNull(FIELD_INVOICESUBTOTALAMOUNT) ? 0: dataReader.GetDecimal(FIELD_INVOICESUBTOTALAMOUNT);
            i.InvoiceAdjustmentsAmount = dataReader.IsDBNull(FIELD_INVOICEADJUSTMENTSAMOUNT) ? 0: dataReader.GetDecimal(FIELD_INVOICEADJUSTMENTSAMOUNT);
            i.InvoiceTotalAmount = dataReader.IsDBNull(FIELD_INVOICETOTALAMOUNT) ? 0: dataReader.GetDecimal(FIELD_INVOICETOTALAMOUNT);
            i.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            i.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            i.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            i.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) i.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, i.RowUpdateVersion, 0, 8);

            return i;
        }

        private static bool SqlSaveInsert(ref Invoice i)
        {
            string sqlStatement = "InvoiceInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@InvoiceNumber", (object)i.InvoiceNumber));
            if (i.InvoiceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@InvoiceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@InvoiceDate", (object)i.InvoiceDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipperBillingId", (object)i.ShipperBillingId));
            command.Parameters.Add(new SqlParameter("@BillToCustomerId", (object)i.BillToCustomerId));
            command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)i.OriginTypeId));
            command.Parameters.Add(new SqlParameter("@OriginId", (object)i.OriginId));
            command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)i.DestinationTypeId));
            command.Parameters.Add(new SqlParameter("@DestinationId", (object)i.DestinationId));
            command.Parameters.Add(new SqlParameter("@ChargeCode", (object)i.ChargeCode));
            command.Parameters.Add(new SqlParameter("@PaymentTermsId", (object)i.PaymentTermsId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)i.BillOfLadingId));
            command.Parameters.Add(new SqlParameter("@DispatchId", (object)i.DispatchId));
            command.Parameters.Add(new SqlParameter("@InvoiceSubtotalAmount", (object)i.InvoiceSubtotalAmount));
            command.Parameters.Add(new SqlParameter("@InvoiceAdjustmentsAmount", (object)i.InvoiceAdjustmentsAmount));
            command.Parameters.Add(new SqlParameter("@InvoiceTotalAmount", (object)i.InvoiceTotalAmount));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            i.InvoiceId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return i.InvoiceId != 0;
        }

        private static bool SqlSaveUpdate(ref Invoice i)
        {
            string sqlStatement = "InvoiceUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@InvoiceId", (object)i.InvoiceId));
            command.Parameters.Add(new SqlParameter("@InvoiceNumber", (object)i.InvoiceNumber));
            if (i.InvoiceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@InvoiceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@InvoiceDate", (object)i.InvoiceDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipperBillingId", (object)i.ShipperBillingId));
            command.Parameters.Add(new SqlParameter("@BillToCustomerId", (object)i.BillToCustomerId));
            command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)i.OriginTypeId));
            command.Parameters.Add(new SqlParameter("@OriginId", (object)i.OriginId));
            command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)i.DestinationTypeId));
            command.Parameters.Add(new SqlParameter("@DestinationId", (object)i.DestinationId));
            command.Parameters.Add(new SqlParameter("@ChargeCode", (object)i.ChargeCode));
            command.Parameters.Add(new SqlParameter("@PaymentTermsId", (object)i.PaymentTermsId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)i.BillOfLadingId));
            command.Parameters.Add(new SqlParameter("@DispatchId", (object)i.DispatchId));
            command.Parameters.Add(new SqlParameter("@InvoiceSubtotalAmount", (object)i.InvoiceSubtotalAmount));
            command.Parameters.Add(new SqlParameter("@InvoiceAdjustmentsAmount", (object)i.InvoiceAdjustmentsAmount));
            command.Parameters.Add(new SqlParameter("@InvoiceTotalAmount", (object)i.InvoiceTotalAmount));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
