using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServicePaySchedules
    {

        #region Private Members

        private const int FIELD_PAYSCHEDULEID              = 0;
        private const int FIELD_PAYPERIODSTARTDATE         = 1;
        private const int FIELD_PAYPERIODENDDATE           = 2;
        private const int FIELD_TRIPPACKETSARRIVALDEADLINE = 3;
        private const int FIELD_PAYDATE                    = 4;
        private const int FIELD_PAYSCHEDULENOTES           = 5;
        private const int FIELD_DATEADDED                  = 6;
        private const int FIELD_ADDEDBY                    = 7;
        private const int FIELD_DATEUPDATED                = 8;
        private const int FIELD_UPDATEDBY                  = 9;
        private const int FIELD_ROWUPDATEVERSION           = 10;

        #endregion


        #region Constructor

        private DataServicePaySchedules() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static PaySchedule PayScheduleSqlGetById(int payScheduleId)
        {
            string sqlStatement = "GetPayScheduleById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PayScheduleId", (object)payScheduleId));

            IDataReader dataReader;

            PaySchedule p = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                p = PayScheduleGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return p;
        }

        public static Collection<PaySchedule> PayScheduleSqlGetBySearchTerms(string PayPeriodStartDate, string PayPeriodEndDate, string PayDate)
        {
            string sqlStatement = "SelectPaySchedulesSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (PayPeriodStartDate != string.Empty) command.Parameters.Add(new SqlParameter("@PayPeriodStartDate", (object)PayPeriodStartDate));
            if (PayPeriodEndDate != string.Empty) command.Parameters.Add(new SqlParameter("@PayPeriodEndDate", (object)PayPeriodEndDate));
            if (PayDate != string.Empty) command.Parameters.Add(new SqlParameter("@PayDate", (object)PayDate));

            IDataReader dataReader;

            Collection<PaySchedule> rowCollection = new Collection<PaySchedule>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PaySchedule p = PayScheduleGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<PaySchedule> PayScheduleSqlGetAll()
        {
            string sqlStatement = "GetAllPaySchedules";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<PaySchedule> rowCollection = new Collection<PaySchedule>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PaySchedule p = PayScheduleGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref PaySchedule p)
        {
            bool saved = false;

            if (p.PayScheduleId == 0)
            {
                saved = SqlSaveInsert(ref p);
            }
            else
            {
                saved = SqlSaveUpdate(ref p);
            }

            return saved;
        }

        public static bool SqlDelete(ref PaySchedule p)
        {
            string sqlStatement = "delete from PaySchedules where PayScheduleId = " + p.PayScheduleId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static PaySchedule PayScheduleGetFromSqlDataReader(ref IDataReader dataReader)
        {
            PaySchedule p = new PaySchedule();

            p.PayScheduleId = dataReader.IsDBNull(FIELD_PAYSCHEDULEID) ? 0: dataReader.GetInt32(FIELD_PAYSCHEDULEID);
            p.PayPeriodStartDate = dataReader.IsDBNull(FIELD_PAYPERIODSTARTDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_PAYPERIODSTARTDATE);
            p.PayPeriodEndDate = dataReader.IsDBNull(FIELD_PAYPERIODENDDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_PAYPERIODENDDATE);
            p.TripPacketsArrivalDeadline = dataReader.IsDBNull(FIELD_TRIPPACKETSARRIVALDEADLINE) ? new DateTime(): dataReader.GetDateTime(FIELD_TRIPPACKETSARRIVALDEADLINE);
            p.PayDate = dataReader.IsDBNull(FIELD_PAYDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_PAYDATE);
            p.PayScheduleNotes = dataReader.IsDBNull(FIELD_PAYSCHEDULENOTES) ? string.Empty: dataReader.GetString(FIELD_PAYSCHEDULENOTES);
            p.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            p.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            p.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            p.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) p.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, p.RowUpdateVersion, 0, 8);

            return p;
        }

        private static bool SqlSaveInsert(ref PaySchedule p)
        {
            string sqlStatement = "PayScheduleInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (p.PayPeriodStartDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodStartDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodStartDate", (object)p.PayPeriodStartDate));
            }
            if (p.PayPeriodEndDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodEndDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodEndDate", (object)p.PayPeriodEndDate));
            }
            if (p.TripPacketsArrivalDeadline == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@TripPacketsArrivalDeadline", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@TripPacketsArrivalDeadline", (object)p.TripPacketsArrivalDeadline));
            }
            if (p.PayDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PayDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PayDate", (object)p.PayDate));
            }
            command.Parameters.Add(new SqlParameter("@PayScheduleNotes", (object)p.PayScheduleNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            p.PayScheduleId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return p.PayScheduleId != 0;
        }

        private static bool SqlSaveUpdate(ref PaySchedule p)
        {
            string sqlStatement = "PayScheduleUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PayScheduleId", (object)p.PayScheduleId));
            if (p.PayPeriodStartDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodStartDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodStartDate", (object)p.PayPeriodStartDate));
            }
            if (p.PayPeriodEndDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodEndDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PayPeriodEndDate", (object)p.PayPeriodEndDate));
            }
            if (p.TripPacketsArrivalDeadline == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@TripPacketsArrivalDeadline", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@TripPacketsArrivalDeadline", (object)p.TripPacketsArrivalDeadline));
            }
            if (p.PayDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PayDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PayDate", (object)p.PayDate));
            }
            command.Parameters.Add(new SqlParameter("@PayScheduleNotes", (object)p.PayScheduleNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
