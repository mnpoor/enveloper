using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceCarriers
    {

        #region Private Members

        private const int FIELD_CARRIERID                  = 0;
        private const int FIELD_CARRIERCOMPANYNAME         = 1;
        private const int FIELD_CARRIERSTREETADDRESS       = 2;
        private const int FIELD_CARRIERBOXADDRESS          = 3;
        private const int FIELD_CARRIERCITY                = 4;
        private const int FIELD_CARRIERSTATE               = 5;
        private const int FIELD_CARRIERPOSTALCODE          = 6;
        private const int FIELD_CARRIERSTATUSID            = 7;
        private const int FIELD_CARRIERPHONENUMBER         = 8;
        private const int FIELD_CARRIERFAXNUMBER           = 9;
        private const int FIELD_CARRIERCONTACTNAME         = 10;
        private const int FIELD_CARRIERCONTACTEMAIL        = 11;
        private const int FIELD_CARRIERCONTACTMOBILENUMBER = 12;
        private const int FIELD_CARRIERACTIVATIONDATE      = 13;
        private const int FIELD_CARRIERSEVERANCEDATE       = 14;
        private const int FIELD_CARRIERNOTES               = 15;
        private const int FIELD_DATEADDED                  = 16;
        private const int FIELD_ADDEDBY                    = 17;
        private const int FIELD_DATEUPDATED                = 18;
        private const int FIELD_UPDATEDBY                  = 19;
        private const int FIELD_ROWUPDATEVERSION           = 20;

        #endregion


        #region Constructor

        private DataServiceCarriers() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Carrier CarrierSqlGetById(int carrierId)
        {
            string sqlStatement = "GetCarrierById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierId", (object)carrierId));

            IDataReader dataReader;

            Carrier c = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                c = CarrierGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return c;
        }

        public static Collection<Carrier> CarrierSqlGetBySearchTerms(string CarrierCompanyName, string CarrierContactName, string CarrierCity)
        {
            string sqlStatement = "SelectCarriersSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (CarrierCompanyName != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierCompanyName", (object)CarrierCompanyName));
            if (CarrierContactName != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierContactName", (object)CarrierContactName));
            if (CarrierCity != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierCity", (object)CarrierCity));

            IDataReader dataReader;

            Collection<Carrier> rowCollection = new Collection<Carrier>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Carrier c = CarrierGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(c);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Carrier> CarrierSqlGetAll()
        {
            string sqlStatement = "GetAllCarriers";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Carrier> rowCollection = new Collection<Carrier>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Carrier c = CarrierGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(c);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Carrier c)
        {
            bool saved = false;

            if (c.CarrierId == 0)
            {
                saved = SqlSaveInsert(ref c);
            }
            else
            {
                saved = SqlSaveUpdate(ref c);
            }

            return saved;
        }

        public static bool SqlDelete(ref Carrier c)
        {
            string sqlStatement = "delete from Carriers where CarrierId = " + c.CarrierId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Carrier CarrierGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Carrier c = new Carrier();

            c.CarrierId = dataReader.IsDBNull(FIELD_CARRIERID) ? 0: dataReader.GetInt32(FIELD_CARRIERID);
            c.CarrierCompanyName = dataReader.IsDBNull(FIELD_CARRIERCOMPANYNAME) ? string.Empty: dataReader.GetString(FIELD_CARRIERCOMPANYNAME);
            c.CarrierStreetAddress = dataReader.IsDBNull(FIELD_CARRIERSTREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_CARRIERSTREETADDRESS);
            c.CarrierBoxAddress = dataReader.IsDBNull(FIELD_CARRIERBOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_CARRIERBOXADDRESS);
            c.CarrierCity = dataReader.IsDBNull(FIELD_CARRIERCITY) ? string.Empty: dataReader.GetString(FIELD_CARRIERCITY);
            c.CarrierState = dataReader.IsDBNull(FIELD_CARRIERSTATE) ? string.Empty: dataReader.GetString(FIELD_CARRIERSTATE);
            c.CarrierPostalCode = dataReader.IsDBNull(FIELD_CARRIERPOSTALCODE) ? string.Empty: dataReader.GetString(FIELD_CARRIERPOSTALCODE);
            c.CarrierStatusId = dataReader.IsDBNull(FIELD_CARRIERSTATUSID) ? 0: dataReader.GetInt32(FIELD_CARRIERSTATUSID);
            c.CarrierPhoneNumber = dataReader.IsDBNull(FIELD_CARRIERPHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_CARRIERPHONENUMBER);
            c.CarrierFaxNumber = dataReader.IsDBNull(FIELD_CARRIERFAXNUMBER) ? string.Empty: dataReader.GetString(FIELD_CARRIERFAXNUMBER);
            c.CarrierContactName = dataReader.IsDBNull(FIELD_CARRIERCONTACTNAME) ? string.Empty: dataReader.GetString(FIELD_CARRIERCONTACTNAME);
            c.CarrierContactEmail = dataReader.IsDBNull(FIELD_CARRIERCONTACTEMAIL) ? string.Empty: dataReader.GetString(FIELD_CARRIERCONTACTEMAIL);
            c.CarrierContactMobileNumber = dataReader.IsDBNull(FIELD_CARRIERCONTACTMOBILENUMBER) ? string.Empty: dataReader.GetString(FIELD_CARRIERCONTACTMOBILENUMBER);
            c.CarrierActivationDate = dataReader.IsDBNull(FIELD_CARRIERACTIVATIONDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_CARRIERACTIVATIONDATE);
            c.CarrierSeveranceDate = dataReader.IsDBNull(FIELD_CARRIERSEVERANCEDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_CARRIERSEVERANCEDATE);
            c.CarrierNotes = dataReader.IsDBNull(FIELD_CARRIERNOTES) ? string.Empty: dataReader.GetString(FIELD_CARRIERNOTES);
            c.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            c.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            c.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            c.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) c.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, c.RowUpdateVersion, 0, 8);

            return c;
        }

        private static bool SqlSaveInsert(ref Carrier c)
        {
            string sqlStatement = "CarrierInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierCompanyName", (object)c.CarrierCompanyName));
            command.Parameters.Add(new SqlParameter("@CarrierStreetAddress", (object)c.CarrierStreetAddress));
            command.Parameters.Add(new SqlParameter("@CarrierBoxAddress", (object)c.CarrierBoxAddress));
            command.Parameters.Add(new SqlParameter("@CarrierCity", (object)c.CarrierCity));
            command.Parameters.Add(new SqlParameter("@CarrierState", (object)c.CarrierState));
            command.Parameters.Add(new SqlParameter("@CarrierPostalCode", (object)c.CarrierPostalCode));
            command.Parameters.Add(new SqlParameter("@CarrierStatusId", (object)c.CarrierStatusId));
            command.Parameters.Add(new SqlParameter("@CarrierPhoneNumber", (object)c.CarrierPhoneNumber));
            command.Parameters.Add(new SqlParameter("@CarrierFaxNumber", (object)c.CarrierFaxNumber));
            command.Parameters.Add(new SqlParameter("@CarrierContactName", (object)c.CarrierContactName));
            command.Parameters.Add(new SqlParameter("@CarrierContactEmail", (object)c.CarrierContactEmail));
            command.Parameters.Add(new SqlParameter("@CarrierContactMobileNumber", (object)c.CarrierContactMobileNumber));
            if (c.CarrierActivationDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@CarrierActivationDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@CarrierActivationDate", (object)c.CarrierActivationDate));
            }
            if (c.CarrierSeveranceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@CarrierSeveranceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@CarrierSeveranceDate", (object)c.CarrierSeveranceDate));
            }
            command.Parameters.Add(new SqlParameter("@CarrierNotes", (object)c.CarrierNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            c.CarrierId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return c.CarrierId != 0;
        }

        private static bool SqlSaveUpdate(ref Carrier c)
        {
            string sqlStatement = "CarrierUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierId", (object)c.CarrierId));
            command.Parameters.Add(new SqlParameter("@CarrierCompanyName", (object)c.CarrierCompanyName));
            command.Parameters.Add(new SqlParameter("@CarrierStreetAddress", (object)c.CarrierStreetAddress));
            command.Parameters.Add(new SqlParameter("@CarrierBoxAddress", (object)c.CarrierBoxAddress));
            command.Parameters.Add(new SqlParameter("@CarrierCity", (object)c.CarrierCity));
            command.Parameters.Add(new SqlParameter("@CarrierState", (object)c.CarrierState));
            command.Parameters.Add(new SqlParameter("@CarrierPostalCode", (object)c.CarrierPostalCode));
            command.Parameters.Add(new SqlParameter("@CarrierStatusId", (object)c.CarrierStatusId));
            command.Parameters.Add(new SqlParameter("@CarrierPhoneNumber", (object)c.CarrierPhoneNumber));
            command.Parameters.Add(new SqlParameter("@CarrierFaxNumber", (object)c.CarrierFaxNumber));
            command.Parameters.Add(new SqlParameter("@CarrierContactName", (object)c.CarrierContactName));
            command.Parameters.Add(new SqlParameter("@CarrierContactEmail", (object)c.CarrierContactEmail));
            command.Parameters.Add(new SqlParameter("@CarrierContactMobileNumber", (object)c.CarrierContactMobileNumber));
            if (c.CarrierActivationDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@CarrierActivationDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@CarrierActivationDate", (object)c.CarrierActivationDate));
            }
            if (c.CarrierSeveranceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@CarrierSeveranceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@CarrierSeveranceDate", (object)c.CarrierSeveranceDate));
            }
            command.Parameters.Add(new SqlParameter("@CarrierNotes", (object)c.CarrierNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
