using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceShipperStatuses
    {

        #region Private Members

        private const int FIELD_SHIPPERSTATUSID          = 0;
        private const int FIELD_SHIPPERSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                = 2;
        private const int FIELD_ADDEDBY                  = 3;
        private const int FIELD_DATEUPDATED              = 4;
        private const int FIELD_UPDATEDBY                = 5;
        private const int FIELD_ROWUPDATEVERSION         = 6;

        #endregion


        #region Constructor

        private DataServiceShipperStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static ShipperStatus ShipperStatusSqlGetById(int shipperStatusId)
        {
            string sqlStatement = "GetShipperStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@ShipperStatusId", (object)shipperStatusId));

            IDataReader dataReader;

            ShipperStatus s = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                s = ShipperStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return s;
        }

        //public static Collection<ShipperStatus> ShipperStatusSqlGetBySearchTerms(string ShipperStatusId, string ShipperStatusDescription)
        //{
        //    string sqlStatement = "SelectShipperStatuesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (ShipperStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@ShipperStatusId", (object)ShipperStatusId));
        //    if (ShipperStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@ShipperStatusDescription", (object)ShipperStatusDescription));

        //    IDataReader dataReader;

        //    Collection<ShipperStatus> rowCollection = new Collection<ShipperStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        ShipperStatus s = ShipperStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(s);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<ShipperStatus> ShipperStatusSqlGetAll()
        {
            string sqlStatement = "GetAllShipperStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<ShipperStatus> rowCollection = new Collection<ShipperStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                ShipperStatus s = ShipperStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(s);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref ShipperStatus s)
        {
            bool saved = false;

            if (s.ShipperStatusId == 0)
            {
                saved = SqlSaveInsert(ref s);
            }
            else
            {
                saved = SqlSaveUpdate(ref s);
            }

            return saved;
        }

        public static bool SqlDelete(ref ShipperStatus s)
        {
            string sqlStatement = "delete from ShipperStatuses where ShipperStatusId = " + s.ShipperStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static ShipperStatus ShipperStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            ShipperStatus s = new ShipperStatus();

            s.ShipperStatusId = dataReader.IsDBNull(FIELD_SHIPPERSTATUSID) ? 0: dataReader.GetInt32(FIELD_SHIPPERSTATUSID);
            s.ShipperStatusDescription = dataReader.IsDBNull(FIELD_SHIPPERSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_SHIPPERSTATUSDESCRIPTION);
            s.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            s.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            s.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            s.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) s.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, s.RowUpdateVersion, 0, 8);

            return s;
        }

        private static bool SqlSaveInsert(ref ShipperStatus s)
        {
            string sqlStatement = "ShipperStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@ShipperStatusDescription", (object)s.ShipperStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            s.ShipperStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return s.ShipperStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref ShipperStatus s)
        {
            string sqlStatement = "ShipperStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@ShipperStatusId", (object)s.ShipperStatusId));
            command.Parameters.Add(new SqlParameter("@ShipperStatusDescription", (object)s.ShipperStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }

}
