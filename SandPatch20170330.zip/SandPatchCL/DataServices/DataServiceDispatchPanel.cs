using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDispatchPanel
    {

        #region Private Members
        
        private const int FIELD_DISPATCHPANELID                    = 0;
        private const int FIELD_PANELCOLUMN                        = 1;
        private const int FIELD_PANELROW                           = 2;
        private const int FIELD_DISPATCHID                         = 3;
        private const int FIELD_DRIVERID                           = 4;
        private const int FIELD_TRUCKNUMBER                        = 5;
        private const int FIELD_ACTIVEDISPATCHES                   = 6;
        private const int FIELD_DRIVERNAME                         = 7;
        private const int FIELD_AVAILABILITYSTATUSID               = 8;
        private const int FIELD_AVAILABILITYSTATUSDESCRIPTION      = 9;
        private const int FIELD_AVAILABILITYCOLORCODE              = 10;
        private const int FIELD_JOBNUMBERID                        = 11;
        private const int FIELD_JOBNUMBERASSIGNMENT                = 12;
        private const int FIELD_DISPATCHACCEPTANCENUMBER           = 13;
        private const int FIELD_DISPATCHSTATUSID                   = 14;
        private const int FIELD_DISPATCHSTATUSDESCRIPTION          = 15;
        private const int FIELD_LOADINGTERMINALID                  = 16;
        private const int FIELD_LOADINGTERMINALNAME                = 17;
        private const int FIELD_LOADINGTERMINALAPPOINTMENTDATETIME = 18;
        private const int FIELD_ACTUALLOADINGTERMINALARRIVALTIME   = 19;
        private const int FIELD_ACTUALLOADINGTERMINALDEPARTURETIME = 20;
        private const int FIELD_JOBSITEID                          = 21;
        private const int FIELD_JOBSITENAME                        = 22;
        private const int FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME = 23;
        private const int FIELD_JOBSITEACTUALARRIVALTIME           = 24;
        private const int FIELD_JOBSITEACTUALDEPARTURETIME         = 25;
        private const int FIELD_DATEADDED                          = 26;
        private const int FIELD_ADDEDBY                            = 27;
        private const int FIELD_DATEUPDATED                        = 28;
        private const int FIELD_UPDATEDBY                          = 29;
        private const int FIELD_ROWUPDATEVERSION                   = 30;
        
        #endregion


        #region Constructor

        private DataServiceDispatchPanel() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static DispatchPanel DispatchPanelSqlGetById(int dispatchPanelId)
        {
            string sqlStatement = "GetDispatchPanelById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchPanelId", (object)dispatchPanelId));

            IDataReader dataReader;

            DispatchPanel d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DispatchPanelGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }
        //GetDispatchPanelByRowAndColumn
        public static DispatchPanel DispatchPanelSqlGetByTruckNumber(int truckNumber)
        {
            string sqlStatement = "GetDispatchPanelByTruckNumber";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)truckNumber));

            IDataReader dataReader;

            DispatchPanel d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DispatchPanelGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        public static DispatchPanel DispatchPanelSqlGetByRowAndColumn(int panelColumn, int panelRow)
        {
            string sqlStatement = "GetDispatchPanelByRowAndColumn";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PanelColumn", (object)panelColumn));
            command.Parameters.Add(new SqlParameter("@PanelRow", (object)panelRow));

            IDataReader dataReader;

            DispatchPanel d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DispatchPanelGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        //public static Collection<DispatchPanel> DispatchPanelSqlGetBySearchTerms(string DispatchPanelId, string PanelColumn, string PanelRow)
        //{
        //    string sqlStatement = "SelectDispatchPanelsSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (DispatchPanelId != string.Empty) command.Parameters.Add(new SqlParameter("@DispatchPanelId", (object)DispatchPanelId));
        //    if (PanelColumn != string.Empty) command.Parameters.Add(new SqlParameter("@PanelColumn", (object)PanelColumn));
        //    if (PanelRow != string.Empty) command.Parameters.Add(new SqlParameter("@PanelRow", (object)PanelRow));

        //    IDataReader dataReader;

        //    Collection<DispatchPanel> rowCollection = new Collection<DispatchPanel>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        DispatchPanel d = DispatchPanelGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(d);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static void DispatchPanelSqlGenerate()
        {
            string sqlStatement = "GenerateDispatchPanel";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.ExecuteNonQuery();

            command.Connection.Close();
        }

        public static void DispatchPanelSqlSynchronize()
        {
            string sqlStatement = "SynchronizeDriverAvailability";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;
            command.ExecuteNonQuery();

            command.Connection.Close();
        }

        public static Collection<DispatchPanel> DispatchPanelSqlGetAll()
        {
            string sqlStatement = "GetAllDispatchPanels";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<DispatchPanel> rowCollection = new Collection<DispatchPanel>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DispatchPanel d = DispatchPanelGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref DispatchPanel d)
        {
            bool saved = false;

            if (d.DispatchPanelId == 0)
            {
                //saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        //public static bool SqlDelete(ref DispatchPanel d)
        //{
        //    string sqlStatement = "delete from DispatchPanels where DispatchPanelId = " + d.DispatchPanelId.ToString();

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.Text;

        //    int recordsAffected = command.ExecuteNonQuery();

        //    command.Connection.Close();

        //    return (recordsAffected == 1);
        //}


        #endregion


        #region SQL Server Private Methods

        private static DispatchPanel DispatchPanelGetFromSqlDataReader(ref IDataReader dataReader)
        {
            DispatchPanel d = new DispatchPanel();

            d.DispatchPanelId = dataReader.IsDBNull(FIELD_DISPATCHPANELID) ? 0: dataReader.GetInt32(FIELD_DISPATCHPANELID);
            d.PanelColumn = dataReader.IsDBNull(FIELD_PANELCOLUMN) ? 0: dataReader.GetInt32(FIELD_PANELCOLUMN);
            d.PanelRow = dataReader.IsDBNull(FIELD_PANELROW) ? 0: dataReader.GetInt32(FIELD_PANELROW);
            d.DispatchId = dataReader.IsDBNull(FIELD_DISPATCHID) ? 0: dataReader.GetInt32(FIELD_DISPATCHID);
            d.DriverId = dataReader.IsDBNull(FIELD_DRIVERID) ? 0: dataReader.GetInt32(FIELD_DRIVERID);
            d.TruckNumber = dataReader.IsDBNull(FIELD_TRUCKNUMBER) ? 0: dataReader.GetInt32(FIELD_TRUCKNUMBER);
            d.ActiveDispatches = dataReader.IsDBNull(FIELD_ACTIVEDISPATCHES) ? 0 : dataReader.GetInt32(FIELD_ACTIVEDISPATCHES);
            d.DriverName = dataReader.IsDBNull(FIELD_DRIVERNAME) ? string.Empty : dataReader.GetString(FIELD_DRIVERNAME);
            d.AvailabilityStatusId = dataReader.IsDBNull(FIELD_AVAILABILITYSTATUSID) ? 0: dataReader.GetInt32(FIELD_AVAILABILITYSTATUSID);
            d.AvailabilityStatusDescription = dataReader.IsDBNull(FIELD_AVAILABILITYSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_AVAILABILITYSTATUSDESCRIPTION);
            d.AvailabilityColorCode = dataReader.IsDBNull(FIELD_AVAILABILITYCOLORCODE) ? string.Empty: dataReader.GetString(FIELD_AVAILABILITYCOLORCODE);
            d.JobNumberId = dataReader.IsDBNull(FIELD_JOBNUMBERID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERID);
            d.JobNumberAssignment = dataReader.IsDBNull(FIELD_JOBNUMBERASSIGNMENT) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERASSIGNMENT);
            d.DispatchAcceptanceNumber = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCENUMBER) ? string.Empty: dataReader.GetString(FIELD_DISPATCHACCEPTANCENUMBER);
            d.DispatchStatusId = dataReader.IsDBNull(FIELD_DISPATCHSTATUSID) ? 0: dataReader.GetInt32(FIELD_DISPATCHSTATUSID);
            d.DispatchStatusDescription = dataReader.IsDBNull(FIELD_DISPATCHSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_DISPATCHSTATUSDESCRIPTION);
            d.LoadingTerminalId = dataReader.IsDBNull(FIELD_LOADINGTERMINALID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALID);
            d.LoadingTerminalName = dataReader.IsDBNull(FIELD_LOADINGTERMINALNAME) ? string.Empty: dataReader.GetString(FIELD_LOADINGTERMINALNAME);
            d.LoadingTerminalAppointmentDateTime = dataReader.IsDBNull(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME);
            d.ActualLoadingTerminalArrivalTime = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALARRIVALTIME) ? new DateTime(): dataReader.GetDateTime(FIELD_ACTUALLOADINGTERMINALARRIVALTIME);
            d.ActualLoadingTerminalDepartureTime = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME);
            d.JobSiteId = dataReader.IsDBNull(FIELD_JOBSITEID) ? 0: dataReader.GetInt32(FIELD_JOBSITEID);
            d.JobSiteName = dataReader.IsDBNull(FIELD_JOBSITENAME) ? string.Empty: dataReader.GetString(FIELD_JOBSITENAME);
            d.JobSiteDeliveryAppointmentDateTime = dataReader.IsDBNull(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME);
            d.JobSiteActualArrivalTime = dataReader.IsDBNull(FIELD_JOBSITEACTUALARRIVALTIME) ? new DateTime(): dataReader.GetDateTime(FIELD_JOBSITEACTUALARRIVALTIME);
            d.JobSiteActualDepartureTime = dataReader.IsDBNull(FIELD_JOBSITEACTUALDEPARTURETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_JOBSITEACTUALDEPARTURETIME);
            d.DateAdded = string.Empty;
            d.AddedBy = string.Empty;
            d.DateUpdated = string.Empty;
            d.UpdatedBy = string.Empty;
            d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};

            return d;
        }

        //private static bool SqlSaveInsert(ref DispatchPanel d)
        //{
        //    string sqlStatement = "DispatchPanelsInsert";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    command.Parameters.Add(new SqlParameter("@DispatchPanelId", (object)d.DispatchPanelId));
        //    command.Parameters.Add(new SqlParameter("@PanelColumn", (object)d.PanelColumn));
        //    command.Parameters.Add(new SqlParameter("@PanelRow", (object)d.PanelRow));
        //    command.Parameters.Add(new SqlParameter("@DispatchId", (object)d.DispatchId));
        //    command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
        //    command.Parameters.Add(new SqlParameter("@TruckNumber", (object)d.TruckNumber));
        //    command.Parameters.Add(new SqlParameter("@ActiveDispatches", (object)d.ActiveDispatches));
        //    command.Parameters.Add(new SqlParameter("@DriverName", (object)d.DriverName));
        //    command.Parameters.Add(new SqlParameter("@AvailabilityStatusId", (object)d.AvailabilityStatusId));
        //    command.Parameters.Add(new SqlParameter("@AvailabilityStatusDescription", (object)d.AvailabilityStatusDescription));
        //    command.Parameters.Add(new SqlParameter("@AvailabilityColorCode", (object)d.AvailabilityColorCode));
        //    command.Parameters.Add(new SqlParameter("@JobNumberId", (object)d.JobNumberId));
        //    command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)d.JobNumberAssignment));
        //    command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)d.DispatchAcceptanceNumber));
        //    command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)d.DispatchStatusId));
        //    command.Parameters.Add(new SqlParameter("@DispatchStatusDescription", (object)d.DispatchStatusDescription));
        //    command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)d.LoadingTerminalId));
        //    command.Parameters.Add(new SqlParameter("@LoadingTerminalName", (object)d.LoadingTerminalName));
        //    if (d.LoadingTerminalAppointmentDateTime == new DateTime())
        //    {
        //        command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)System.DBNull.Value));
        //    }
        //    else
        //    {
        //        command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)d.LoadingTerminalAppointmentDateTime));
        //    }
        //    if (d.ActualLoadingTerminalArrivalTime == new DateTime())
        //    {
        //        command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)System.DBNull.Value));
        //    }
        //    else
        //    {
        //        command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)d.ActualLoadingTerminalArrivalTime));
        //    }
        //    if (d.ActualLoadingTerminalDepartureTime == new DateTime())
        //    {
        //        command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)System.DBNull.Value));
        //    }
        //    else
        //    {
        //        command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)d.ActualLoadingTerminalDepartureTime));
        //    }
        //    command.Parameters.Add(new SqlParameter("@JobSiteId", (object)d.JobSiteId));
        //    command.Parameters.Add(new SqlParameter("@JobSiteName", (object)d.JobSiteName));
        //    if (d.JobSiteDeliveryAppointmentDateTime == new DateTime())
        //    {
        //        command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)System.DBNull.Value));
        //    }
        //    else
        //    {
        //        command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)d.JobSiteDeliveryAppointmentDateTime));
        //    }
        //    if (d.JobSiteActualArrivalTime == new DateTime())
        //    {
        //        command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)System.DBNull.Value));
        //    }
        //    else
        //    {
        //        command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)d.JobSiteActualArrivalTime));
        //    }
        //    if (d.JobSiteActualDepartureTime == new DateTime())
        //    {
        //        command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)System.DBNull.Value));
        //    }
        //    else
        //    {
        //        command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)d.JobSiteActualDepartureTime));
        //    }
        //    command.Parameters.Add("@PK_New", SqlDbType.Int);
        //    command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

        //    int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

        //    d.DispatchPanelId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

        //    command.Connection.Close();

        //    return d.DispatchPanelId != 0;
        //}

        private static bool SqlSaveUpdate(ref DispatchPanel d)
        {
            string sqlStatement = "DispatchPanelUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchPanelId", (object)d.DispatchPanelId));
            command.Parameters.Add(new SqlParameter("@PanelColumn", (object)d.PanelColumn));
            command.Parameters.Add(new SqlParameter("@PanelRow", (object)d.PanelRow));
            command.Parameters.Add(new SqlParameter("@DispatchId", (object)d.DispatchId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)d.TruckNumber));
            command.Parameters.Add(new SqlParameter("@ActiveDispatches", (object)d.ActiveDispatches));
            command.Parameters.Add(new SqlParameter("@DriverName", (object)d.DriverName));
            command.Parameters.Add(new SqlParameter("@AvailabilityStatusId", (object)d.AvailabilityStatusId));
            command.Parameters.Add(new SqlParameter("@AvailabilityStatusDescription", (object)d.AvailabilityStatusDescription));
            command.Parameters.Add(new SqlParameter("@AvailabilityColorCode", (object)d.AvailabilityColorCode));
            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)d.JobNumberId));
            command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)d.JobNumberAssignment));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)d.DispatchAcceptanceNumber));
            command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)d.DispatchStatusId));
            command.Parameters.Add(new SqlParameter("@DispatchStatusDescription", (object)d.DispatchStatusDescription));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)d.LoadingTerminalId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalName", (object)d.LoadingTerminalName));
            if (d.LoadingTerminalAppointmentDateTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)d.LoadingTerminalAppointmentDateTime));
            }
            if (d.ActualLoadingTerminalArrivalTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)d.ActualLoadingTerminalArrivalTime));
            }
            if (d.ActualLoadingTerminalDepartureTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)d.ActualLoadingTerminalDepartureTime));
            }
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)d.JobSiteId));
            command.Parameters.Add(new SqlParameter("@JobSiteName", (object)d.JobSiteName));
            if (d.JobSiteDeliveryAppointmentDateTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)d.JobSiteDeliveryAppointmentDateTime));
            }
            if (d.JobSiteActualArrivalTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)d.JobSiteActualArrivalTime));
            }
            if (d.JobSiteActualDepartureTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)d.JobSiteActualDepartureTime));
            }

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }

}
