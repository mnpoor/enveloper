using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceOriginTypes
    {

        #region Private Members

        private const int FIELD_ORIGINTYPEID           = 0;
        private const int FIELD_ORIGINTYPEDESCRIPTION  = 1;
        private const int FIELD_DATEADDED              = 2;
        private const int FIELD_ADDEDBY                = 3;
        private const int FIELD_DATEUPDATED            = 4;
        private const int FIELD_UPDATEDBY              = 5;
        private const int FIELD_ROWUPDATEVERSION       = 6;

        #endregion


        #region Constructor

        private DataServiceOriginTypes() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static OriginType OriginTypeSqlGetById(int originTypeId)
        {
            string sqlStatement = "GetOriginTypeById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)originTypeId));

            IDataReader dataReader;

            OriginType o = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                o = OriginTypeGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return o;
        }

        //public static Collection<OriginType> OriginTypeSqlGetBySearchTerms(string OriginTypeId, string OriginTypeDescription, )
        //{
        //    string sqlStatement = "SelectOriginTypesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (OriginTypeId != string.Empty) command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)OriginTypeId));
        //    if (OriginTypeDescription != string.Empty) command.Parameters.Add(new SqlParameter("@OriginTypeDescription", (object)OriginTypeDescription));

        //    IDataReader dataReader;

        //    Collection<OriginType> rowCollection = new Collection<OriginType>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        OriginType o = OriginTypeGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(o);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<OriginType> OriginTypeSqlGetAll()
        {
            string sqlStatement = "GetAllOriginTypes";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<OriginType> rowCollection = new Collection<OriginType>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                OriginType o = OriginTypeGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(o);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref OriginType o)
        {
            bool saved = false;

            if (o.OriginTypeId == 0)
            {
                saved = SqlSaveInsert(ref o);
            }
            else
            {
                saved = SqlSaveUpdate(ref o);
            }

            return saved;
        }

        public static bool SqlDelete(ref OriginType o)
        {
            string sqlStatement = "delete from OriginTypes where OriginTypeId = " + o.OriginTypeId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static OriginType OriginTypeGetFromSqlDataReader(ref IDataReader dataReader)
        {
            OriginType o = new OriginType();

            o.OriginTypeId = dataReader.IsDBNull(FIELD_ORIGINTYPEID) ? 0: dataReader.GetInt32(FIELD_ORIGINTYPEID);
            o.OriginTypeDescription = dataReader.IsDBNull(FIELD_ORIGINTYPEDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_ORIGINTYPEDESCRIPTION);
            o.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            o.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            o.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            o.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) o.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, o.RowUpdateVersion, 0, 8);

            return o;
        }

        private static bool SqlSaveInsert(ref OriginType o)
        {
            string sqlStatement = "OriginTypeInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@OriginTypeDescription", (object)o.OriginTypeDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            o.OriginTypeId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return o.OriginTypeId != 0;
        }

        private static bool SqlSaveUpdate(ref OriginType o)
        {
            string sqlStatement = "OriginTypeUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@OriginTypeId", (object)o.OriginTypeId));
            command.Parameters.Add(new SqlParameter("@OriginTypeDescription", (object)o.OriginTypeDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
