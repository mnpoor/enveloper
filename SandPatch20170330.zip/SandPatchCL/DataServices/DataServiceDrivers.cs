using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDrivers
    {

        #region Private Members

        private const int FIELD_DRIVERID               = 0;
        private const int FIELD_TRUCKNUMBER            = 1;
        private const int FIELD_CARRIERID              = 2;
        private const int FIELD_DRIVERNAME             = 3;
        private const int FIELD_DRIVERSTREETADDRESS    = 4;
        private const int FIELD_DRIVERBOXADDRESS       = 5;
        private const int FIELD_DRIVERCITY             = 6;
        private const int FIELD_DRIVERSTATE            = 7;
        private const int FIELD_DRIVERPOSTALCODE       = 8;
        private const int FIELD_DRIVERTELEPHONENUMBER  = 9;
        private const int FIELD_DRIVEREMAIL            = 10;
        private const int FIELD_DRIVERSTATUSID         = 11;
        private const int FIELD_DRIVERSTARTDATE        = 12;
        private const int FIELD_DRIVERSEVERANCEDATE    = 13;
        private const int FIELD_FUELCARDSTATUSID       = 14;
        private const int FIELD_LICENSEPLATESTATUSID   = 15;
        private const int FIELD_DRIVERNOTES            = 16;
        private const int FIELD_DATEADDED              = 17;
        private const int FIELD_ADDEDBY                = 18;
        private const int FIELD_DATEUPDATED            = 19;
        private const int FIELD_UPDATEDBY              = 20;
        private const int FIELD_ROWUPDATEVERSION       = 21;

        #endregion


        #region Constructor

        private DataServiceDrivers() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Driver DriverSqlGetById(int driverId)
        {
            string sqlStatement = "GetDriverById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverId", (object)driverId));

            IDataReader dataReader;

            Driver d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DriverGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        public static Collection<Driver> DriverSqlGetByPage(int pageNumber, int rowCount)
        {
            string sqlStatement = "GetDriversByPage";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PageNumber", (object)pageNumber));
            command.Parameters.Add(new SqlParameter("@RowCount", (object)rowCount));

            IDataReader dataReader;

            Collection<Driver> rowCollection = new Collection<Driver>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Driver d = DriverGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Driver> DriverSqlGetBySearchTerms(int pageNumber, int rowCount, string truckNumber, string carrierCompanyName, string carrierContactName, string driverName)
        {
            string sqlStatement = "SelectDriversSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (truckNumber != string.Empty) {
                int truckNumberInt = Convert.ToInt32(truckNumber); 
                command.Parameters.Add(new SqlParameter("@TruckNumber", (object)truckNumberInt));
            }
            if (pageNumber > 0) command.Parameters.Add(new SqlParameter("@PageNumber", (object)pageNumber));
            if (rowCount > 0) command.Parameters.Add(new SqlParameter("@RowCount", (object)rowCount));
            if (carrierCompanyName != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierCompanyName", (object)carrierCompanyName));
            if (carrierContactName != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierContactName", (object)carrierContactName));
            if (driverName != string.Empty) command.Parameters.Add(new SqlParameter("@DriverName", (object)driverName));

            IDataReader dataReader;

            Collection<Driver> rowCollection = new Collection<Driver>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Driver d = DriverGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Driver> DriverSqlGetAll()
        {
            string sqlStatement = "GetAllDrivers";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Driver> rowCollection = new Collection<Driver>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Driver d = DriverGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Driver d)
        {
            bool saved = false;

            if (d.DriverId == 0)
            {
                saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        public static bool SqlDelete(ref Driver d)
        {
            string sqlStatement = "delete from Drivers where DriverId = " + d.DriverId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Driver DriverGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Driver d = new Driver();

            d.DriverId = dataReader.IsDBNull(FIELD_DRIVERID) ? 0: dataReader.GetInt32(FIELD_DRIVERID);
            d.TruckNumber = dataReader.IsDBNull(FIELD_TRUCKNUMBER) ? 0: dataReader.GetInt32(FIELD_TRUCKNUMBER);
            d.CarrierId = dataReader.IsDBNull(FIELD_CARRIERID) ? 0: dataReader.GetInt32(FIELD_CARRIERID);
            d.DriverName = dataReader.IsDBNull(FIELD_DRIVERNAME) ? string.Empty: dataReader.GetString(FIELD_DRIVERNAME);
            d.DriverStreetAddress = dataReader.IsDBNull(FIELD_DRIVERSTREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_DRIVERSTREETADDRESS);
            d.DriverBoxAddress = dataReader.IsDBNull(FIELD_DRIVERBOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_DRIVERBOXADDRESS);
            d.DriverCity = dataReader.IsDBNull(FIELD_DRIVERCITY) ? string.Empty: dataReader.GetString(FIELD_DRIVERCITY);
            d.DriverState = dataReader.IsDBNull(FIELD_DRIVERSTATE) ? string.Empty: dataReader.GetString(FIELD_DRIVERSTATE);
            d.DriverPostalCode = dataReader.IsDBNull(FIELD_DRIVERPOSTALCODE) ? string.Empty: dataReader.GetString(FIELD_DRIVERPOSTALCODE);
            d.DriverTelephoneNumber = dataReader.IsDBNull(FIELD_DRIVERTELEPHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_DRIVERTELEPHONENUMBER);
            d.DriverEmail = dataReader.IsDBNull(FIELD_DRIVEREMAIL) ? string.Empty: dataReader.GetString(FIELD_DRIVEREMAIL);
            d.DriverStatusId = dataReader.IsDBNull(FIELD_DRIVERSTATUSID) ? 0: dataReader.GetInt32(FIELD_DRIVERSTATUSID);
            d.DriverStartDate = dataReader.IsDBNull(FIELD_DRIVERSTARTDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_DRIVERSTARTDATE);
            d.DriverSeveranceDate = dataReader.IsDBNull(FIELD_DRIVERSEVERANCEDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_DRIVERSEVERANCEDATE);
            d.FuelCardStatusId = dataReader.IsDBNull(FIELD_FUELCARDSTATUSID) ? 0: dataReader.GetInt32(FIELD_FUELCARDSTATUSID);
            d.LicensePlateStatusId = dataReader.IsDBNull(FIELD_LICENSEPLATESTATUSID) ? 0: dataReader.GetInt32(FIELD_LICENSEPLATESTATUSID);
            d.DriverNotes = dataReader.IsDBNull(FIELD_DRIVERNOTES) ? string.Empty: dataReader.GetString(FIELD_DRIVERNOTES);
            d.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            d.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            d.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            d.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, d.RowUpdateVersion, 0, 8);

            return d;
        }

        private static bool SqlSaveInsert(ref Driver d)
        {
            string sqlStatement = "DriverInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)d.TruckNumber));
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)d.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverName", (object)d.DriverName));
            command.Parameters.Add(new SqlParameter("@DriverStreetAddress", (object)d.DriverStreetAddress));
            command.Parameters.Add(new SqlParameter("@DriverBoxAddress", (object)d.DriverBoxAddress));
            command.Parameters.Add(new SqlParameter("@DriverCity", (object)d.DriverCity));
            command.Parameters.Add(new SqlParameter("@DriverState", (object)d.DriverState));
            command.Parameters.Add(new SqlParameter("@DriverPostalCode", (object)d.DriverPostalCode));
            command.Parameters.Add(new SqlParameter("@DriverTelephoneNumber", (object)d.DriverTelephoneNumber));
            command.Parameters.Add(new SqlParameter("@DriverEmail", (object)d.DriverEmail));
            command.Parameters.Add(new SqlParameter("@DriverStatusId", (object)d.DriverStatusId));
            if (d.DriverStartDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@DriverStartDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@DriverStartDate", (object)d.DriverStartDate));
            }
            if (d.DriverSeveranceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@DriverSeveranceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@DriverSeveranceDate", (object)d.DriverSeveranceDate));
            }
            command.Parameters.Add(new SqlParameter("@FuelCardStatusId", (object)d.FuelCardStatusId));
            command.Parameters.Add(new SqlParameter("@LicensePlateStatusId", (object)d.LicensePlateStatusId));
            command.Parameters.Add(new SqlParameter("@DriverNotes", (object)d.DriverNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            d.DriverId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return d.DriverId != 0;
        }

        private static bool SqlSaveUpdate(ref Driver d)
        {
            string sqlStatement = "DriverUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)d.TruckNumber));
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)d.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverName", (object)d.DriverName));
            command.Parameters.Add(new SqlParameter("@DriverStreetAddress", (object)d.DriverStreetAddress));
            command.Parameters.Add(new SqlParameter("@DriverBoxAddress", (object)d.DriverBoxAddress));
            command.Parameters.Add(new SqlParameter("@DriverCity", (object)d.DriverCity));
            command.Parameters.Add(new SqlParameter("@DriverState", (object)d.DriverState));
            command.Parameters.Add(new SqlParameter("@DriverPostalCode", (object)d.DriverPostalCode));
            command.Parameters.Add(new SqlParameter("@DriverTelephoneNumber", (object)d.DriverTelephoneNumber));
            command.Parameters.Add(new SqlParameter("@DriverEmail", (object)d.DriverEmail));
            command.Parameters.Add(new SqlParameter("@DriverStatusId", (object)d.DriverStatusId));
            if (d.DriverStartDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@DriverStartDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@DriverStartDate", (object)d.DriverStartDate));
            }
            if (d.DriverSeveranceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@DriverSeveranceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@DriverSeveranceDate", (object)d.DriverSeveranceDate));
            }
            command.Parameters.Add(new SqlParameter("@FuelCardStatusId", (object)d.FuelCardStatusId));
            command.Parameters.Add(new SqlParameter("@LicensePlateStatusId", (object)d.LicensePlateStatusId));
            command.Parameters.Add(new SqlParameter("@DriverNotes", (object)d.DriverNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
