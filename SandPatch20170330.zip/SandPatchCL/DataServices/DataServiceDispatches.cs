using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDispatches
    {

        #region Private Members

        private const int FIELD_DISPATCHID                         = 0;
        private const int FIELD_CUSTOMERID                         = 1;
        private const int FIELD_JOBNUMBERID                        = 2;
        private const int FIELD_PURCHASEORDERID                    = 3;
        private const int FIELD_DISPATCHACCEPTANCENUMBER           = 4;
        private const int FIELD_DISPATCHACCEPTANCEDATE             = 5;
        private const int FIELD_CARRIERID                          = 6;
        private const int FIELD_DRIVERID                           = 7;
        private const int FIELD_DISPATCHSTATUSID                   = 8;
        private const int FIELD_FREIGHTID                          = 9;
        private const int FIELD_LOADINGTERMINALID                  = 10;
        private const int FIELD_LOADINGTERMINALAPPOINTMENTDATETIME = 11;
        private const int FIELD_ACTUALLOADINGTERMINALARRIVALTIME   = 12;
        private const int FIELD_ACTUALLOADINGTERMINALDEPARTURETIME = 13;
        private const int FIELD_BILLOFLADINGID                     = 14;
        private const int FIELD_BILLOFLADINGNUMBER                 = 15;
        private const int FIELD_SHIPMENTWEIGHT                     = 16;
        private const int FIELD_TICKETNUMBER                       = 17;
        private const int FIELD_JOBSITEID                          = 18;
        private const int FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME = 19;
        private const int FIELD_JOBSITEACTUALARRIVALTIME           = 20;
        private const int FIELD_JOBSITEACTUALDEPARTURETIME         = 21;
        private const int FIELD_DISPATCHMILES                      = 22;
        private const int FIELD_DISPATCHTOTALHOURS                 = 23;
        private const int FIELD_DISPATCHCOMMENTS                   = 24;
        private const int FIELD_DATEADDED                          = 25;
        private const int FIELD_ADDEDBY                            = 26;
        private const int FIELD_DATEUPDATED                        = 27;
        private const int FIELD_UPDATEDBY                          = 28;
        private const int FIELD_ROWUPDATEVERSION                   = 29;

        #endregion


        #region Constructor

        private DataServiceDispatches() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Dispatch DispatchSqlGetById(int dispatchId)
        {
            string sqlStatement = "GetDispatchById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchId", (object)dispatchId));

            IDataReader dataReader;

            Dispatch d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DispatchGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        public static Collection<Dispatch> DispatchSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectDispatchesSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty)
            { 
                try
                {
                    int truckNumberInt = Convert.ToInt32(searchTerms[1]);
                    command.Parameters.Add(new SqlParameter("@TruckNumber", (object)truckNumberInt));
                }
                catch
                {
                    // no parameter added - do nothing
                }
            }
            if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@ActiveDispatchesOnly", (object)searchTerms[2]));
            if (searchTerms[3] != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)searchTerms[3]));
            if (searchTerms[4] != string.Empty)
            {
                try
                {
                    int jobNumberInt = Convert.ToInt32(searchTerms[4]);
                    command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumberInt));
                }
                catch
                {
                    // no parameter added - do nothing
                }
            }
            if (searchTerms[5] != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)searchTerms[5]));
            if (searchTerms[6] != string.Empty)
            {
                try
                {
                    DateTime acceptanceDateFromDate = Convert.ToDateTime(searchTerms[6]);
                    command.Parameters.Add(new SqlParameter("@AcceptanceDateFrom", (object)acceptanceDateFromDate));
                }
                catch
                {
                    // no parameter added - do nothing
                }
            }
            if (searchTerms[7] != string.Empty)
            {
                try
                {
                    DateTime acceptanceDateToDate = Convert.ToDateTime(searchTerms[7]);
                    command.Parameters.Add(new SqlParameter("@AcceptanceDateTo", (object)acceptanceDateToDate));
                }
                catch
                {
                    // no parameter added - do nothing
                }
            }
            if (searchTerms[8] != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)searchTerms[8]));

            IDataReader dataReader;

            Collection<Dispatch> rowCollection = new Collection<Dispatch>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Dispatch d = DispatchGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Dispatch> DispatchSqlGetAll()
        {
            string sqlStatement = "GetAllDispatches";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Dispatch> rowCollection = new Collection<Dispatch>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Dispatch d = DispatchGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Dispatch d)
        {
            bool saved = false;

            if (d.DispatchId == 0)
            {
                saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        public static bool SqlDelete(ref Dispatch d)
        {
            string sqlStatement = "delete from Dispatches where DispatchId = " + d.DispatchId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Dispatch DispatchGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Dispatch d = new Dispatch();

            d.DispatchId = dataReader.IsDBNull(FIELD_DISPATCHID) ? 0: dataReader.GetInt32(FIELD_DISPATCHID);
            d.CustomerId = dataReader.IsDBNull(FIELD_CUSTOMERID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERID);
            d.JobNumberId = dataReader.IsDBNull(FIELD_JOBNUMBERID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERID);
            d.PurchaseOrderId = dataReader.IsDBNull(FIELD_PURCHASEORDERID) ? 0: dataReader.GetInt32(FIELD_PURCHASEORDERID);
            d.DispatchAcceptanceNumber = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCENUMBER) ? string.Empty: dataReader.GetString(FIELD_DISPATCHACCEPTANCENUMBER);
            d.DispatchAcceptanceDate = dataReader.IsDBNull(FIELD_DISPATCHACCEPTANCEDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_DISPATCHACCEPTANCEDATE);
            d.CarrierId = dataReader.IsDBNull(FIELD_CARRIERID) ? 0: dataReader.GetInt32(FIELD_CARRIERID);
            d.DriverId = dataReader.IsDBNull(FIELD_DRIVERID) ? 0: dataReader.GetInt32(FIELD_DRIVERID);
            d.DispatchStatusId = dataReader.IsDBNull(FIELD_DISPATCHSTATUSID) ? 0: dataReader.GetInt32(FIELD_DISPATCHSTATUSID);
            d.FreightId = dataReader.IsDBNull(FIELD_FREIGHTID) ? 0: dataReader.GetInt32(FIELD_FREIGHTID);
            d.LoadingTerminalId = dataReader.IsDBNull(FIELD_LOADINGTERMINALID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALID);
            d.LoadingTerminalAppointmentDateTime = dataReader.IsDBNull(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_LOADINGTERMINALAPPOINTMENTDATETIME);
            d.ActualLoadingTerminalArrivalTime = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALARRIVALTIME) ? new DateTime(): dataReader.GetDateTime(FIELD_ACTUALLOADINGTERMINALARRIVALTIME);
            d.ActualLoadingTerminalDepartureTime = dataReader.IsDBNull(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_ACTUALLOADINGTERMINALDEPARTURETIME);
            d.BillOfLadingId = dataReader.IsDBNull(FIELD_BILLOFLADINGID) ? 0: dataReader.GetInt32(FIELD_BILLOFLADINGID);
            d.BillOfLadingNumber = dataReader.IsDBNull(FIELD_BILLOFLADINGNUMBER) ? string.Empty : dataReader.GetString(FIELD_BILLOFLADINGNUMBER);
            d.ShipmentWeight = dataReader.IsDBNull(FIELD_SHIPMENTWEIGHT) ? 0 : dataReader.GetDecimal(FIELD_SHIPMENTWEIGHT);
            d.TicketNumber = dataReader.IsDBNull(FIELD_TICKETNUMBER) ? string.Empty: dataReader.GetString(FIELD_TICKETNUMBER);
            d.JobSiteId = dataReader.IsDBNull(FIELD_JOBSITEID) ? 0: dataReader.GetInt32(FIELD_JOBSITEID);
            d.JobSiteDeliveryAppointmentDateTime = dataReader.IsDBNull(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_JOBSITEDELIVERYAPPOINTMENTDATETIME);
            d.JobSiteActualArrivalTime = dataReader.IsDBNull(FIELD_JOBSITEACTUALARRIVALTIME) ? new DateTime(): dataReader.GetDateTime(FIELD_JOBSITEACTUALARRIVALTIME);
            d.JobSiteActualDepartureTime = dataReader.IsDBNull(FIELD_JOBSITEACTUALDEPARTURETIME) ? new DateTime(): dataReader.GetDateTime(FIELD_JOBSITEACTUALDEPARTURETIME);
            d.DispatchMiles = dataReader.IsDBNull(FIELD_DISPATCHMILES) ? 0: dataReader.GetInt32(FIELD_DISPATCHMILES);
            d.DispatchTotalHours = dataReader.IsDBNull(FIELD_DISPATCHTOTALHOURS) ? 0: dataReader.GetInt32(FIELD_DISPATCHTOTALHOURS);
            d.DispatchComments = dataReader.IsDBNull(FIELD_DISPATCHCOMMENTS) ? string.Empty: dataReader.GetString(FIELD_DISPATCHCOMMENTS);
            d.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            d.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            d.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            d.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, d.RowUpdateVersion, 0, 8);

            return d;
        }

        private static bool SqlSaveInsert(ref Dispatch d)
        {
            string sqlStatement = "DispatchInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerId", (object)d.CustomerId));
            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)d.JobNumberId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderId", (object)d.PurchaseOrderId));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)d.DispatchAcceptanceNumber));
            if (d.DispatchAcceptanceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@DispatchAcceptanceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@DispatchAcceptanceDate", (object)d.DispatchAcceptanceDate));
            }
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)d.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
            command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)d.DispatchStatusId));
            command.Parameters.Add(new SqlParameter("@FreightId", (object)d.FreightId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)d.LoadingTerminalId));
            if (d.LoadingTerminalAppointmentDateTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)d.LoadingTerminalAppointmentDateTime));
            }
            if (d.ActualLoadingTerminalArrivalTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)d.ActualLoadingTerminalArrivalTime));
            }
            if (d.ActualLoadingTerminalDepartureTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)d.ActualLoadingTerminalDepartureTime));
            }
            command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)d.BillOfLadingId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)d.BillOfLadingNumber));
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)d.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@TicketNumber", (object)d.TicketNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)d.JobSiteId));
            if (d.JobSiteDeliveryAppointmentDateTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)d.JobSiteDeliveryAppointmentDateTime));
            }
            if (d.JobSiteActualArrivalTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)d.JobSiteActualArrivalTime));
            }
            if (d.JobSiteActualDepartureTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)d.JobSiteActualDepartureTime));
            }
            command.Parameters.Add(new SqlParameter("@DispatchMiles", (object)d.DispatchMiles));
            command.Parameters.Add(new SqlParameter("@DispatchTotalHours", (object)d.DispatchTotalHours));
            command.Parameters.Add(new SqlParameter("@DispatchComments", (object)d.DispatchComments));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            d.DispatchId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return d.DispatchId != 0;
        }

        private static bool SqlSaveUpdate(ref Dispatch d)
        {
            string sqlStatement = "DispatchUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DispatchId", (object)d.DispatchId));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)d.CustomerId));
            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)d.JobNumberId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderId", (object)d.PurchaseOrderId));
            command.Parameters.Add(new SqlParameter("@DispatchAcceptanceNumber", (object)d.DispatchAcceptanceNumber));
            if (d.DispatchAcceptanceDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@DispatchAcceptanceDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@DispatchAcceptanceDate", (object)d.DispatchAcceptanceDate));
            }
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)d.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)d.DriverId));
            command.Parameters.Add(new SqlParameter("@DispatchStatusId", (object)d.DispatchStatusId));
            command.Parameters.Add(new SqlParameter("@FreightId", (object)d.FreightId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)d.LoadingTerminalId));
            if (d.LoadingTerminalAppointmentDateTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@LoadingTerminalAppointmentDateTime", (object)d.LoadingTerminalAppointmentDateTime));
            }
            if (d.ActualLoadingTerminalArrivalTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalArrivalTime", (object)d.ActualLoadingTerminalArrivalTime));
            }
            if (d.ActualLoadingTerminalDepartureTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ActualLoadingTerminalDepartureTime", (object)d.ActualLoadingTerminalDepartureTime));
            }
            command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)d.BillOfLadingId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)d.BillOfLadingNumber));
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)d.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@TicketNumber", (object)d.TicketNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)d.JobSiteId));
            if (d.JobSiteDeliveryAppointmentDateTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteDeliveryAppointmentDateTime", (object)d.JobSiteDeliveryAppointmentDateTime));
            }
            if (d.JobSiteActualArrivalTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualArrivalTime", (object)d.JobSiteActualArrivalTime));
            }
            if (d.JobSiteActualDepartureTime == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@JobSiteActualDepartureTime", (object)d.JobSiteActualDepartureTime));
            }
            command.Parameters.Add(new SqlParameter("@DispatchMiles", (object)d.DispatchMiles));
            command.Parameters.Add(new SqlParameter("@DispatchTotalHours", (object)d.DispatchTotalHours));
            command.Parameters.Add(new SqlParameter("@DispatchComments", (object)d.DispatchComments));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
