using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServicePurchaseOrders
    {

        #region Private Members

        private const int FIELD_PURCHASEORDERID             = 0;
        private const int FIELD_JOBNUMBERID                 = 1;
        private const int FIELD_PURCHASEORDERNUMBER         = 2;
        private const int FIELD_CUSTOMERID                  = 3;
        private const int FIELD_PURCHASEORDERDATE           = 4;
        private const int FIELD_LOADINGTERMINALID           = 5;
        private const int FIELD_FREIGHTID                   = 6;
        private const int FIELD_PURCHASEORDERSTATUSID       = 7;
        private const int FIELD_MILESONEWAY                 = 8;
        private const int FIELD_JOBSITEID                   = 9;
        private const int FIELD_TOTALORDERWEIGHT            = 10;
        private const int FIELD_SHIPMENTWEIGHT              = 11;
        private const int FIELD_LOADCOUNT                   = 12;
        private const int FIELD_LOADSACCEPTED               = 13;
        private const int FIELD_WEIGHTDELIVERED             = 14;
        private const int FIELD_WEIGHTREMAINING             = 15;
        private const int FIELD_PURCHASEORDERCOMPLETIONDATE = 16;
        private const int FIELD_SHIPMENTWEIGHTUNDELIVERABLE = 17;
        private const int FIELD_PURCHASEORDERCOMMENTS       = 18;
        private const int FIELD_DATEADDED                   = 19;
        private const int FIELD_ADDEDBY                     = 20;
        private const int FIELD_DATEUPDATED                 = 21;
        private const int FIELD_UPDATEDBY                   = 22;
        private const int FIELD_ROWUPDATEVERSION            = 23;

        #endregion


        #region Constructor

        private DataServicePurchaseOrders() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static PurchaseOrder PurchaseOrderSqlGetById(int purchaseOrderId)
        {
            string sqlStatement = "GetPurchaseOrderById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PurchaseOrderId", (object)purchaseOrderId));

            IDataReader dataReader;

            PurchaseOrder p = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                p = PurchaseOrderGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return p;
        }

        public static Collection<PurchaseOrder> PurchaseOrderSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectPurchaseOrdersSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)searchTerms[0]));
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)searchTerms[1]));
            if (searchTerms[2] != string.Empty)
            {
                try
                {
                    int jobNumberAssignment = Convert.ToInt32(searchTerms[2]);
                    command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumberAssignment));
                }
                catch
                {
                    // do nothing.
                }
            }
            if (searchTerms[3] != string.Empty) command.Parameters.Add(new SqlParameter("@FreightName", (object)searchTerms[3]));
            if (searchTerms[4] != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderDateFrom", (object)searchTerms[4]));
            if (searchTerms[5] != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderDateTo", (object)searchTerms[5]));

            IDataReader dataReader;

            Collection<PurchaseOrder> rowCollection = new Collection<PurchaseOrder>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PurchaseOrder p = PurchaseOrderGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        //public static Collection<PurchaseOrder> PurchaseOrderSqlGetBySearchTerms(string purchaseOrderNumber, string customerName, string jobNumber, string freightName, string purchaseOrderDateFrom, string purchaseOrderDateTo)
        //{
        //    string sqlStatement = "SelectPurchaseOrdersSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (purchaseOrderNumber != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)purchaseOrderNumber));
        //    if (customerName != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)customerName));
        //    if (jobNumber != string.Empty)
        //    {
        //        try
        //        {
        //            int jobNumberAssignment = Convert.ToInt32(jobNumber);
        //            command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumber));
        //        }
        //        catch
        //        {
        //            // do nothing.
        //        }
        //    }
        //    if (freightName != string.Empty) command.Parameters.Add(new SqlParameter("@FreightName", (object)freightName));
        //    if (purchaseOrderDateFrom != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderDateFrom", (object)purchaseOrderDateFrom));
        //    if (purchaseOrderDateTo != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderDateTo", (object)purchaseOrderDateTo));

        //    IDataReader dataReader;

        //    Collection<PurchaseOrder> rowCollection = new Collection<PurchaseOrder>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        PurchaseOrder p = PurchaseOrderGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(p);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<PurchaseOrder> PurchaseOrderSqlGetAll()
        {
            string sqlStatement = "GetAllPurchaseOrders";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<PurchaseOrder> rowCollection = new Collection<PurchaseOrder>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PurchaseOrder p = PurchaseOrderGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref PurchaseOrder p)
        {
            bool saved = false;

            if (p.PurchaseOrderId == 0)
            {
                saved = SqlSaveInsert(ref p);
            }
            else
            {
                saved = SqlSaveUpdate(ref p);
            }

            return saved;
        }

        public static bool SqlDelete(ref PurchaseOrder p)
        {
            string sqlStatement = "delete from PurchaseOrders where PurchaseOrderId = " + p.PurchaseOrderId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static PurchaseOrder PurchaseOrderGetFromSqlDataReader(ref IDataReader dataReader)
        {
            PurchaseOrder p = new PurchaseOrder();

            p.PurchaseOrderId = dataReader.IsDBNull(FIELD_PURCHASEORDERID) ? 0: dataReader.GetInt32(FIELD_PURCHASEORDERID);
            p.JobNumberId = dataReader.IsDBNull(FIELD_JOBNUMBERID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERID);
            p.PurchaseOrderNumber = dataReader.IsDBNull(FIELD_PURCHASEORDERNUMBER) ? string.Empty: dataReader.GetString(FIELD_PURCHASEORDERNUMBER);
            p.CustomerId = dataReader.IsDBNull(FIELD_CUSTOMERID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERID);
            p.PurchaseOrderDate = dataReader.IsDBNull(FIELD_PURCHASEORDERDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_PURCHASEORDERDATE);
            p.LoadingTerminalId = dataReader.IsDBNull(FIELD_LOADINGTERMINALID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALID);
            p.FreightId = dataReader.IsDBNull(FIELD_FREIGHTID) ? 0: dataReader.GetInt32(FIELD_FREIGHTID);
            p.PurchaseOrderStatusId = dataReader.IsDBNull(FIELD_PURCHASEORDERSTATUSID) ? 0: dataReader.GetInt32(FIELD_PURCHASEORDERSTATUSID);
            p.MilesOneWay = dataReader.IsDBNull(FIELD_MILESONEWAY) ? 0: dataReader.GetInt32(FIELD_MILESONEWAY);
            p.JobSiteId = dataReader.IsDBNull(FIELD_JOBSITEID) ? 0: dataReader.GetInt32(FIELD_JOBSITEID);
            p.TotalOrderWeight = dataReader.IsDBNull(FIELD_TOTALORDERWEIGHT) ? 0: dataReader.GetDecimal(FIELD_TOTALORDERWEIGHT);
            p.ShipmentWeight = dataReader.IsDBNull(FIELD_SHIPMENTWEIGHT) ? 0: dataReader.GetDecimal(FIELD_SHIPMENTWEIGHT);
            p.LoadCount = dataReader.IsDBNull(FIELD_LOADCOUNT) ? 0: dataReader.GetInt32(FIELD_LOADCOUNT);
            p.LoadsAccepted = dataReader.IsDBNull(FIELD_LOADSACCEPTED) ? 0: dataReader.GetInt32(FIELD_LOADSACCEPTED);
            p.WeightDelivered = dataReader.IsDBNull(FIELD_WEIGHTDELIVERED) ? 0: dataReader.GetDecimal(FIELD_WEIGHTDELIVERED);
            p.WeightRemaining = dataReader.IsDBNull(FIELD_WEIGHTREMAINING) ? 0: dataReader.GetDecimal(FIELD_WEIGHTREMAINING);
            p.PurchaseOrderCompletionDate = dataReader.IsDBNull(FIELD_PURCHASEORDERCOMPLETIONDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_PURCHASEORDERCOMPLETIONDATE);
            p.ShipmentWeightUndeliverable = dataReader.IsDBNull(FIELD_SHIPMENTWEIGHTUNDELIVERABLE) ? 0: dataReader.GetDecimal(FIELD_SHIPMENTWEIGHTUNDELIVERABLE);
            p.PurchaseOrderComments = dataReader.IsDBNull(FIELD_PURCHASEORDERCOMMENTS) ? string.Empty: dataReader.GetString(FIELD_PURCHASEORDERCOMMENTS);
            p.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            p.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            p.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            p.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) p.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, p.RowUpdateVersion, 0, 8);

            return p;
        }

        private static bool SqlSaveInsert(ref PurchaseOrder p)
        {
            string sqlStatement = "PurchaseOrderInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)p.JobNumberId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)p.PurchaseOrderNumber));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)p.CustomerId));
            if (p.PurchaseOrderDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderDate", (object)p.PurchaseOrderDate));
            }
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)p.LoadingTerminalId));
            command.Parameters.Add(new SqlParameter("@FreightId", (object)p.FreightId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusId", (object)p.PurchaseOrderStatusId));
            command.Parameters.Add(new SqlParameter("@MilesOneWay", (object)p.MilesOneWay));
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)p.JobSiteId));
            command.Parameters.Add(new SqlParameter("@TotalOrderWeight", (object)p.TotalOrderWeight));
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)p.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@LoadCount", (object)p.LoadCount));
            command.Parameters.Add(new SqlParameter("@LoadsAccepted", (object)p.LoadsAccepted));
            command.Parameters.Add(new SqlParameter("@WeightDelivered", (object)p.WeightDelivered));
            command.Parameters.Add(new SqlParameter("@WeightRemaining", (object)p.WeightRemaining));
            if (p.PurchaseOrderCompletionDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderCompletionDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderCompletionDate", (object)p.PurchaseOrderCompletionDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipmentWeightUndeliverable", (object)p.ShipmentWeightUndeliverable));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderComments", (object)p.PurchaseOrderComments));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            p.PurchaseOrderId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return p.PurchaseOrderId != 0;
        }

        private static bool SqlSaveUpdate(ref PurchaseOrder p)
        {
            string sqlStatement = "PurchaseOrderUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PurchaseOrderId", (object)p.PurchaseOrderId));
            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)p.JobNumberId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)p.PurchaseOrderNumber));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)p.CustomerId));
            if (p.PurchaseOrderDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderDate", (object)p.PurchaseOrderDate));
            }
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)p.LoadingTerminalId));
            command.Parameters.Add(new SqlParameter("@FreightId", (object)p.FreightId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderStatusId", (object)p.PurchaseOrderStatusId));
            command.Parameters.Add(new SqlParameter("@MilesOneWay", (object)p.MilesOneWay));
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)p.JobSiteId));
            command.Parameters.Add(new SqlParameter("@TotalOrderWeight", (object)p.TotalOrderWeight));
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)p.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@LoadCount", (object)p.LoadCount));
            command.Parameters.Add(new SqlParameter("@LoadsAccepted", (object)p.LoadsAccepted));
            command.Parameters.Add(new SqlParameter("@WeightDelivered", (object)p.WeightDelivered));
            command.Parameters.Add(new SqlParameter("@WeightRemaining", (object)p.WeightRemaining));
            if (p.PurchaseOrderCompletionDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderCompletionDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@PurchaseOrderCompletionDate", (object)p.PurchaseOrderCompletionDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipmentWeightUndeliverable", (object)p.ShipmentWeightUndeliverable));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderComments", (object)p.PurchaseOrderComments));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
