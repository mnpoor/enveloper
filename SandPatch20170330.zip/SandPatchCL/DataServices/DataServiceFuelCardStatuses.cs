using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceFuelCardStatuses
    {

        #region Private Members

        private const int FIELD_FUELCARDSTATUSID          = 0;
        private const int FIELD_FUELCARDSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                 = 2;
        private const int FIELD_ADDEDBY                   = 3;
        private const int FIELD_DATEUPDATED               = 4;
        private const int FIELD_UPDATEDBY                 = 5;
        private const int FIELD_ROWUPDATEVERSION          = 6;

        #endregion


        #region Constructor

        private DataServiceFuelCardStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static FuelCardStatus FuelCardStatusSqlGetById(int fuelCardStatusId)
        {
            string sqlStatement = "GetFuelCardStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FuelCardStatusId", (object)fuelCardStatusId));

            IDataReader dataReader;

            FuelCardStatus f = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                f = FuelCardStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return f;
        }

        //public static Collection<FuelCardStatus> FuelCardStatusSqlGetBySearchTerms(string FuelCardStatusId, string FuelCardStatusDescription)
        //{
        //    string sqlStatement = "SelectFuelCardStatuesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (FuelCardStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@FuelCardStatusId", (object)FuelCardStatusId));
        //    if (FuelCardStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@FuelCardStatusDescription", (object)FuelCardStatusDescription));

        //    IDataReader dataReader;

        //    Collection<FuelCardStatus> rowCollection = new Collection<FuelCardStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        FuelCardStatus f = FuelCardStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(f);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<FuelCardStatus> FuelCardStatusSqlGetAll()
        {
            string sqlStatement = "GetAllFuelCardStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<FuelCardStatus> rowCollection = new Collection<FuelCardStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                FuelCardStatus f = FuelCardStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(f);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref FuelCardStatus f)
        {
            bool saved = false;

            if (f.FuelCardStatusId == 0)
            {
                saved = SqlSaveInsert(ref f);
            }
            else
            {
                saved = SqlSaveUpdate(ref f);
            }

            return saved;
        }

        public static bool SqlDelete(ref FuelCardStatus f)
        {
            string sqlStatement = "delete from FuelCardStatuses where FuelCardStatusId = " + f.FuelCardStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static FuelCardStatus FuelCardStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            FuelCardStatus f = new FuelCardStatus();

            f.FuelCardStatusId = dataReader.IsDBNull(FIELD_FUELCARDSTATUSID) ? 0: dataReader.GetInt32(FIELD_FUELCARDSTATUSID);
            f.FuelCardStatusDescription = dataReader.IsDBNull(FIELD_FUELCARDSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_FUELCARDSTATUSDESCRIPTION);
            f.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            f.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            f.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            f.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) f.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, f.RowUpdateVersion, 0, 8);

            return f;
        }

        private static bool SqlSaveInsert(ref FuelCardStatus f)
        {
            string sqlStatement = "FuelCardStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FuelCardStatusDescription", (object)f.FuelCardStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            f.FuelCardStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return f.FuelCardStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref FuelCardStatus f)
        {
            string sqlStatement = "FuelCardStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FuelCardStatusId", (object)f.FuelCardStatusId));
            command.Parameters.Add(new SqlParameter("@FuelCardStatusDescription", (object)f.FuelCardStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }

}
