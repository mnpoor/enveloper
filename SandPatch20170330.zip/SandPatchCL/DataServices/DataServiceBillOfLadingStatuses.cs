using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceBillOfLadingStatuses
    {

        #region Private Members

        private const int FIELD_BILLOFLADINGSTATUSID          = 0;
        private const int FIELD_BILLOFLADINGSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                     = 2;
        private const int FIELD_ADDEDBY                       = 3;
        private const int FIELD_DATEUPDATED                   = 4;
        private const int FIELD_UPDATEDBY                     = 5;
        private const int FIELD_ROWUPDATEVERSION              = 6;

        #endregion


        #region Constructor

        private DataServiceBillOfLadingStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static BillOfLadingStatus BillOfLadingStatusSqlGetById(int billOfLadingStatusId)
        {
            string sqlStatement = "GetBillOfLadingStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@BillOfLadingStatusId", (object)billOfLadingStatusId));

            IDataReader dataReader;

            BillOfLadingStatus b = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                b = BillOfLadingStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return b;
        }

        //public static Collection<BillOfLadingStatus> BillOfLadingStatusSqlGetBySearchTerms(string BillOfLadingStatusId, string BillOfLadingStatusDescription, )
        //{
        //    string sqlStatement = "SelectBillOfLadingStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (BillOfLadingStatusId != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingStatusId", (object)BillOfLadingStatusId));
        //    if (BillOfLadingStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingStatusDescription", (object)BillOfLadingStatusDescription));

        //    IDataReader dataReader;

        //    Collection<BillOfLadingStatus> rowCollection = new Collection<BillOfLadingStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        BillOfLadingStatus b = BillOfLadingStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(b);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<BillOfLadingStatus> BillOfLadingStatusSqlGetAll()
        {
            string sqlStatement = "GetAllBillOfLadingStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<BillOfLadingStatus> rowCollection = new Collection<BillOfLadingStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                BillOfLadingStatus b = BillOfLadingStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(b);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref BillOfLadingStatus b)
        {
            bool saved = false;

            if (b.BillOfLadingStatusId == 0)
            {
                saved = SqlSaveInsert(ref b);
            }
            else
            {
                saved = SqlSaveUpdate(ref b);
            }

            return saved;
        }

        public static bool SqlDelete(ref BillOfLadingStatus b)
        {
            string sqlStatement = "delete from BillOfLadingStatuses where BillOfLadingStatusId = " + b.BillOfLadingStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static BillOfLadingStatus BillOfLadingStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            BillOfLadingStatus b = new BillOfLadingStatus();

            b.BillOfLadingStatusId = dataReader.IsDBNull(FIELD_BILLOFLADINGSTATUSID) ? 0: dataReader.GetInt32(FIELD_BILLOFLADINGSTATUSID);
            b.BillOfLadingStatusDescription = dataReader.IsDBNull(FIELD_BILLOFLADINGSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_BILLOFLADINGSTATUSDESCRIPTION);
            b.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            b.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            b.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            b.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) b.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, b.RowUpdateVersion, 0, 8);

            return b;
        }

        private static bool SqlSaveInsert(ref BillOfLadingStatus b)
        {
            string sqlStatement = "BillOfLadingStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@BillOfLadingStatusDescription", (object)b.BillOfLadingStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            b.BillOfLadingStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return b.BillOfLadingStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref BillOfLadingStatus b)
        {
            string sqlStatement = "BillOfLadingStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@BillOfLadingStatusId", (object)b.BillOfLadingStatusId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingStatusDescription", (object)b.BillOfLadingStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
