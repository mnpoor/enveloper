using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceCarrierStatuses
    {

        #region Private Members

        private const int FIELD_CARRIERSTATUSID          = 0;
        private const int FIELD_CARRIERSTATUSDESCRIPTION = 1;
        private const int FIELD_DATEADDED                = 2;
        private const int FIELD_ADDEDBY                  = 3;
        private const int FIELD_DATEUPDATED              = 4;
        private const int FIELD_UPDATEDBY                = 5;
        private const int FIELD_ROWUPDATEVERSION         = 6;

        #endregion


        #region Constructor

        private DataServiceCarrierStatuses() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static CarrierStatus CarrierStatusSqlGetById(int carrierStatusId)
        {
            string sqlStatement = "GetCarrierStatusById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierStatusId", (object)carrierStatusId));

            IDataReader dataReader;

            CarrierStatus c = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                c = CarrierStatusGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return c;
        }

        //public static Collection<CarrierStatus> CarrierStatusSqlGetBySearchTerms(string CarrierStatusId, string CarrierStatusDescription)
        //{
        //    string sqlStatement = "SelectCarrierStatusesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (CarrierStatusDescription != string.Empty) command.Parameters.Add(new SqlParameter("@CarrierStatusDescription", (object)CarrierStatusDescription));

        //    IDataReader dataReader;

        //    Collection<CarrierStatus> rowCollection = new Collection<CarrierStatus>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        CarrierStatus c = CarrierStatusGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(c);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<CarrierStatus> CarrierStatusSqlGetAll()
        {
            string sqlStatement = "GetAllCarrierStatuses";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<CarrierStatus> rowCollection = new Collection<CarrierStatus>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                CarrierStatus c = CarrierStatusGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(c);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref CarrierStatus c)
        {
            bool saved = false;

            if (c.CarrierStatusId == 0)
            {
                saved = SqlSaveInsert(ref c);
            }
            else
            {
                saved = SqlSaveUpdate(ref c);
            }

            return saved;
        }

        public static bool SqlDelete(ref CarrierStatus c)
        {
            string sqlStatement = "delete from CarrierStatuses where CarrierStatusId = " + c.CarrierStatusId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static CarrierStatus CarrierStatusGetFromSqlDataReader(ref IDataReader dataReader)
        {
            CarrierStatus c = new CarrierStatus();

            c.CarrierStatusId = dataReader.IsDBNull(FIELD_CARRIERSTATUSID) ? 0: dataReader.GetInt32(FIELD_CARRIERSTATUSID);
            c.CarrierStatusDescription = dataReader.IsDBNull(FIELD_CARRIERSTATUSDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_CARRIERSTATUSDESCRIPTION);
            c.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            c.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            c.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            c.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) c.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, c.RowUpdateVersion, 0, 8);

            return c;
        }

        private static bool SqlSaveInsert(ref CarrierStatus c)
        {
            string sqlStatement = "CarrierStatusInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierStatusDescription", (object)c.CarrierStatusDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            c.CarrierStatusId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return c.CarrierStatusId != 0;
        }

        private static bool SqlSaveUpdate(ref CarrierStatus c)
        {
            string sqlStatement = "CarrierStatusUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CarrierStatusId", (object)c.CarrierStatusId));
            command.Parameters.Add(new SqlParameter("@CarrierStatusDescription", (object)c.CarrierStatusDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }

}
