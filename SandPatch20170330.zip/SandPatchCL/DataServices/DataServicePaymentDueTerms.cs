using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServicePaymentDueTerms
    {

        #region Private Members

        private const int FIELD_PAYMENTDUETERMID          = 0;
        private const int FIELD_PAYMENTDUETERMDESCRIPTION = 1;
        private const int FIELD_DATEADDED                 = 2;
        private const int FIELD_ADDEDBY                   = 3;
        private const int FIELD_DATEUPDATED               = 4;
        private const int FIELD_UPDATEDBY                 = 5;
        private const int FIELD_ROWUPDATEVERSION          = 6;

        #endregion


        #region Constructor

        private DataServicePaymentDueTerms() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static PaymentDueTerm PaymentDueTermSqlGetById(int paymentDueTermId)
        {
            string sqlStatement = "GetPaymentDueTermById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PaymentDueTermId", (object)paymentDueTermId));

            IDataReader dataReader;

            PaymentDueTerm p = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                p = PaymentDueTermGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return p;
        }

        //public static Collection<PaymentDueTerm> PaymentDueTermSqlGetBySearchTerms(string[] searchTerms)
        //{
        //    string sqlStatement = "SelectPaymentDueTermsSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@PaymentDueTermId", (object)searchTerms[0]));
        //    if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@PaymentDueTermDescription", (object)searchTerms[1]));

        //    IDataReader dataReader;

        //    Collection<PaymentDueTerm> rowCollection = new Collection<PaymentDueTerm>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        PaymentDueTerm p = PaymentDueTermGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(p);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<PaymentDueTerm> PaymentDueTermSqlGetAll()
        {
            string sqlStatement = "GetAllPaymentDueTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<PaymentDueTerm> rowCollection = new Collection<PaymentDueTerm>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                PaymentDueTerm p = PaymentDueTermGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(p);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref PaymentDueTerm p)
        {
            bool saved = false;

            if (p.PaymentDueTermId == 0)
            {
                saved = SqlSaveInsert(ref p);
            }
            else
            {
                saved = SqlSaveUpdate(ref p);
            }

            return saved;
        }

        public static bool SqlDelete(ref PaymentDueTerm p)
        {
            string sqlStatement = "delete from PaymentDueTerms where PaymentDueTermId = " + p.PaymentDueTermId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static PaymentDueTerm PaymentDueTermGetFromSqlDataReader(ref IDataReader dataReader)
        {
            PaymentDueTerm p = new PaymentDueTerm();

            p.PaymentDueTermId = dataReader.IsDBNull(FIELD_PAYMENTDUETERMID) ? 0: dataReader.GetInt32(FIELD_PAYMENTDUETERMID);
            p.PaymentDueTermDescription = dataReader.IsDBNull(FIELD_PAYMENTDUETERMDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_PAYMENTDUETERMDESCRIPTION);
            p.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            p.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            p.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            p.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) p.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, p.RowUpdateVersion, 0, 8);

            return p;
        }

        private static bool SqlSaveInsert(ref PaymentDueTerm p)
        {
            string sqlStatement = "PaymentDueTermInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PaymentDueTermDescription", (object)p.PaymentDueTermDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            p.PaymentDueTermId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return p.PaymentDueTermId != 0;
        }

        private static bool SqlSaveUpdate(ref PaymentDueTerm p)
        {
            string sqlStatement = "PaymentDueTermUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@PaymentDueTermId", (object)p.PaymentDueTermId));
            command.Parameters.Add(new SqlParameter("@PaymentDueTermDescription", (object)p.PaymentDueTermDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
