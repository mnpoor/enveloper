using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceCustomers
    {

        #region Private Members

        private const int FIELD_CUSTOMERID             = 0;
        private const int FIELD_CUSTOMERNAME           = 1;
        private const int FIELD_CONTACTNAME            = 2;
        private const int FIELD_STREETADDRESS          = 3;
        private const int FIELD_BOXADDRESS             = 4;
        private const int FIELD_CITY                   = 5;
        private const int FIELD_CUSTOMERSTATE          = 6;
        private const int FIELD_POSTALCODE             = 7;
        private const int FIELD_CUSTOMERSTATUSID       = 8;
        private const int FIELD_PHONENUMBER            = 9;
        private const int FIELD_FAXNUMBER              = 10;
        private const int FIELD_MOBILENUMBER           = 11;
        private const int FIELD_CUSTOMERWEBURL         = 12;
        private const int FIELD_CONTACTEMAILADDRESS    = 13;
        private const int FIELD_CUSTOMERNOTES          = 14;
        private const int FIELD_DATEADDED              = 15;
        private const int FIELD_ADDEDBY                = 16;
        private const int FIELD_DATEUPDATED            = 17;
        private const int FIELD_UPDATEDBY              = 18;
        private const int FIELD_ROWUPDATEVERSION       = 19;

        #endregion


        #region Constructor

        private DataServiceCustomers() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Customer CustomerSqlGetById(int customerId)
        {
            string sqlStatement = "GetCustomerById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerId", (object)customerId));

            IDataReader dataReader;

            Customer c = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                c = CustomerGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return c;
        }

        public static Collection<Customer> CustomerSqlGetBySearchTerms(string customerName, string contactName)
        {
            string sqlStatement = "SelectCustomersSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (customerName != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)customerName));
            if (contactName != string.Empty) command.Parameters.Add(new SqlParameter("@ContactName", (object)contactName));

            IDataReader dataReader;

            Collection<Customer> rowCollection = new Collection<Customer>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Customer c = CustomerGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(c);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Customer> CustomerSqlGetAll()
        {
            string sqlStatement = "GetAllCustomers";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Customer> rowCollection = new Collection<Customer>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Customer c = CustomerGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(c);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Customer c)
        {
            bool saved = false;

            if (c.CustomerId == 0)
            {
                saved = SqlSaveInsert(ref c);
            }
            else
            {
                saved = SqlSaveUpdate(ref c);
            }

            return saved;
        }

        public static bool SqlDelete(ref Customer c)
        {
            string sqlStatement = "delete from Customers where CustomerId = " + c.CustomerId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Customer CustomerGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Customer c = new Customer();

            c.CustomerId = dataReader.IsDBNull(FIELD_CUSTOMERID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERID);
            c.CustomerName = dataReader.IsDBNull(FIELD_CUSTOMERNAME) ? string.Empty: dataReader.GetString(FIELD_CUSTOMERNAME);
            c.ContactName = dataReader.IsDBNull(FIELD_CONTACTNAME) ? string.Empty: dataReader.GetString(FIELD_CONTACTNAME);
            c.StreetAddress = dataReader.IsDBNull(FIELD_STREETADDRESS) ? string.Empty: dataReader.GetString(FIELD_STREETADDRESS);
            c.BoxAddress = dataReader.IsDBNull(FIELD_BOXADDRESS) ? string.Empty: dataReader.GetString(FIELD_BOXADDRESS);
            c.City = dataReader.IsDBNull(FIELD_CITY) ? string.Empty: dataReader.GetString(FIELD_CITY);
            c.CustomerState = dataReader.IsDBNull(FIELD_CUSTOMERSTATE) ? string.Empty: dataReader.GetString(FIELD_CUSTOMERSTATE);
            c.PostalCode = dataReader.IsDBNull(FIELD_POSTALCODE) ? string.Empty: dataReader.GetString(FIELD_POSTALCODE);
            c.CustomerStatusId = dataReader.IsDBNull(FIELD_CUSTOMERSTATUSID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERSTATUSID);
            c.PhoneNumber = dataReader.IsDBNull(FIELD_PHONENUMBER) ? string.Empty: dataReader.GetString(FIELD_PHONENUMBER);
            c.FaxNumber = dataReader.IsDBNull(FIELD_FAXNUMBER) ? string.Empty: dataReader.GetString(FIELD_FAXNUMBER);
            c.MobileNumber = dataReader.IsDBNull(FIELD_MOBILENUMBER) ? string.Empty: dataReader.GetString(FIELD_MOBILENUMBER);
            c.CustomerWebURL = dataReader.IsDBNull(FIELD_CUSTOMERWEBURL) ? string.Empty: dataReader.GetString(FIELD_CUSTOMERWEBURL);
            c.ContactEmailAddress = dataReader.IsDBNull(FIELD_CONTACTEMAILADDRESS) ? string.Empty: dataReader.GetString(FIELD_CONTACTEMAILADDRESS);
            c.CustomerNotes = dataReader.IsDBNull(FIELD_CUSTOMERNOTES) ? string.Empty: dataReader.GetString(FIELD_CUSTOMERNOTES);
            c.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            c.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            c.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            c.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) c.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, c.RowUpdateVersion, 0, 8);

            return c;
        }

        private static bool SqlSaveInsert(ref Customer c)
        {
            string sqlStatement = "CustomerInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerName", (object)c.CustomerName));
            command.Parameters.Add(new SqlParameter("@ContactName", (object)c.ContactName));
            command.Parameters.Add(new SqlParameter("@StreetAddress", (object)c.StreetAddress));
            command.Parameters.Add(new SqlParameter("@BoxAddress", (object)c.BoxAddress));
            command.Parameters.Add(new SqlParameter("@City", (object)c.City));
            command.Parameters.Add(new SqlParameter("@CustomerState", (object)c.CustomerState));
            command.Parameters.Add(new SqlParameter("@PostalCode", (object)c.PostalCode));
            command.Parameters.Add(new SqlParameter("@CustomerStatusId", (object)c.CustomerStatusId));
            command.Parameters.Add(new SqlParameter("@PhoneNumber", (object)c.PhoneNumber));
            command.Parameters.Add(new SqlParameter("@FaxNumber", (object)c.FaxNumber));
            command.Parameters.Add(new SqlParameter("@MobileNumber", (object)c.MobileNumber));
            command.Parameters.Add(new SqlParameter("@CustomerWebURL", (object)c.CustomerWebURL));
            command.Parameters.Add(new SqlParameter("@ContactEmailAddress", (object)c.ContactEmailAddress));
            command.Parameters.Add(new SqlParameter("@CustomerNotes", (object)c.CustomerNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            c.CustomerId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return c.CustomerId != 0;
        }

        private static bool SqlSaveUpdate(ref Customer c)
        {
            string sqlStatement = "CustomerUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerId", (object)c.CustomerId));
            command.Parameters.Add(new SqlParameter("@CustomerName", (object)c.CustomerName));
            command.Parameters.Add(new SqlParameter("@ContactName", (object)c.ContactName));
            command.Parameters.Add(new SqlParameter("@StreetAddress", (object)c.StreetAddress));
            command.Parameters.Add(new SqlParameter("@BoxAddress", (object)c.BoxAddress));
            command.Parameters.Add(new SqlParameter("@City", (object)c.City));
            command.Parameters.Add(new SqlParameter("@CustomerState", (object)c.CustomerState));
            command.Parameters.Add(new SqlParameter("@PostalCode", (object)c.PostalCode));
            command.Parameters.Add(new SqlParameter("@CustomerStatusId", (object)c.CustomerStatusId));
            command.Parameters.Add(new SqlParameter("@PhoneNumber", (object)c.PhoneNumber));
            command.Parameters.Add(new SqlParameter("@FaxNumber", (object)c.FaxNumber));
            command.Parameters.Add(new SqlParameter("@MobileNumber", (object)c.MobileNumber));
            command.Parameters.Add(new SqlParameter("@CustomerWebURL", (object)c.CustomerWebURL));
            command.Parameters.Add(new SqlParameter("@ContactEmailAddress", (object)c.ContactEmailAddress));
            command.Parameters.Add(new SqlParameter("@CustomerNotes", (object)c.CustomerNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
