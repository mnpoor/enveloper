using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SandPatchCL.DataServices
{
    public class DataServiceBase
    {
        public static void SetSQLServerConnectionString(string sqlServerConnectionString)
        {
            //Properties.Settings.Default.SQLServerConnectionString = sqlServerConnectionString;
            //Properties.Settings.Default.Save();
        }

        public static string GetSQLServerConnectionString()
        {
            if (Environment.MachineName == "SCE-SQL-VS")
                return Properties.Settings.Default.ProductionDatabaseConnectionString;
            else
                return Properties.Settings.Default.SQLServerConnectionString;
        }

        public static SqlConnection GetSQLConnection()
        {
            SqlConnection sConnection = new SqlConnection(GetSQLServerConnectionString());
            sConnection.Open();
            return sConnection;
        }
    }
}
