using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceBillsOfLading
    {

        #region Private Members

        private const int FIELD_BILLOFLADINGID         = 0;
        private const int FIELD_CUSTOMERID             = 1;
        private const int FIELD_JOBNUMBERID            = 2;
        private const int FIELD_PURCHASEORDERID        = 3;
        private const int FIELD_BILLOFLADINGNUMBER     = 4;
        private const int FIELD_CARRIERID              = 5;
        private const int FIELD_DRIVERID               = 6;
        private const int FIELD_LOADINGTERMINALID      = 7;
        private const int FIELD_FREIGHTID              = 8;
        private const int FIELD_TICKETNUMBER           = 9;
        private const int FIELD_JOBSITEID              = 10;
        private const int FIELD_BILLOFLADINGSTATUSID   = 11;
        private const int FIELD_SHIPMENTDATE           = 12;
        private const int FIELD_SHIPMENTWEIGHT         = 13;
        private const int FIELD_BILLOFLADINGCOMMENTS   = 14;
        private const int FIELD_DATEADDED              = 15;
        private const int FIELD_ADDEDBY                = 16;
        private const int FIELD_DATEUPDATED            = 17;
        private const int FIELD_UPDATEDBY              = 18;
        private const int FIELD_ROWUPDATEVERSION       = 19;

        #endregion


        #region Constructor

        private DataServiceBillsOfLading() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static BillOfLading BillOfLadingSqlGetById(int billOfLadingId)
        {
            string sqlStatement = "GetBillOfLadingById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)billOfLadingId));

            IDataReader dataReader;

            BillOfLading b = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                b = BillOfLadingGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return b;
        }

        public static BillOfLading BillOfLadingSqlGetByBOLNumber(string billOfLadingNumber)
        {
            string sqlStatement = "GetBillOfLadingByBOLNumber";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)billOfLadingNumber));

            IDataReader dataReader;

            BillOfLading b = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                b = BillOfLadingGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return b;
        }

        public static Collection<BillOfLading> BillOfLadingSqlGetBySearchTerms(string[] searchTerms)
        {
            string sqlStatement = "SelectBillsOfLadingSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (searchTerms[0] != string.Empty)
            {
                try
                {
                    int truckNumberAssignment = Convert.ToInt32(searchTerms[0]);
                    command.Parameters.Add(new SqlParameter("@TruckNumber", (object)truckNumberAssignment));
                }
                catch
                {
                    // do nothing.
                }
            }
            if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)searchTerms[1]));
            if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)searchTerms[2]));
            if (searchTerms[3] != string.Empty)
            {
                try
                {
                    int jobNumberAssignment = Convert.ToInt32(searchTerms[3]);
                    command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumberAssignment));
                }
                catch
                {
                    // do nothing.
                }
            }
            if (searchTerms[4] != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)searchTerms[4]));
            if (searchTerms[5] != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingFromDate", (object)searchTerms[5]));
            if (searchTerms[6] != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingToDate", (object)searchTerms[6]));
            //if (searchTerms[0] != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)searchTerms[0]));
            //if (searchTerms[1] != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerId", (object)searchTerms[1]));
            //if (searchTerms[2] != string.Empty) command.Parameters.Add(new SqlParameter("@JobNumberId", (object)searchTerms[2]));

            IDataReader dataReader;

            Collection<BillOfLading> rowCollection = new Collection<BillOfLading>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                BillOfLading b = BillOfLadingGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(b);
            }

            command.Connection.Close();

            return rowCollection;
        }

        //public static Collection<BillOfLading> BillOfLadingSqlGetBySearchTerms(string truckNumber, string billOfLadingNumber, string customerName, string jobNumber, string purchaseOrderNumber, string billOfLadingFromDate, string billOfLadingToDate)
        //{
        //    string sqlStatement = "SelectBillsOfLadingSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (truckNumber != string.Empty)
        //    {
        //        try
        //        {
        //            int truckNumberAssignment = Convert.ToInt32(truckNumber);
        //            command.Parameters.Add(new SqlParameter("@TruckNumber", (object)truckNumberAssignment));
        //        }
        //        catch
        //        {
        //            // do nothing.
        //        }
        //    }
        //    if (billOfLadingNumber != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)billOfLadingNumber));
        //    if (customerName != string.Empty) command.Parameters.Add(new SqlParameter("@CustomerName", (object)customerName));
        //    if (jobNumber != string.Empty)
        //    {
        //        try
        //        {
        //            int jobNumberAssignment = Convert.ToInt32(jobNumber);
        //            command.Parameters.Add(new SqlParameter("@JobNumberAssignment", (object)jobNumber));
        //        }
        //        catch
        //        {
        //            // do nothing.
        //        }
        //    }
        //    if (purchaseOrderNumber != string.Empty) command.Parameters.Add(new SqlParameter("@PurchaseOrderNumber", (object)purchaseOrderNumber));
        //    if (billOfLadingFromDate != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingFromDate", (object)billOfLadingFromDate));
        //    if (billOfLadingToDate != string.Empty) command.Parameters.Add(new SqlParameter("@BillOfLadingToDate", (object)billOfLadingToDate));

        //    IDataReader dataReader;

        //    Collection<BillOfLading> rowCollection = new Collection<BillOfLading>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        BillOfLading b = BillOfLadingGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(b);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<BillOfLading> BillOfLadingSqlGetAll()
        {
            string sqlStatement = "GetAllBillsOfLading";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<BillOfLading> rowCollection = new Collection<BillOfLading>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                BillOfLading b = BillOfLadingGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(b);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static void SynchronizeBOLToDispatch(ref BillOfLading billOfLading, ref Dispatch dispatch)
        {
            if (billOfLading == null) return;
            if (billOfLading.CustomerId != dispatch.CustomerId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.JobSiteId != dispatch.JobNumberId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.PurchaseOrderId != dispatch.PurchaseOrderId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.CarrierId != dispatch.CarrierId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.DriverId != dispatch.DriverId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.LoadingTerminalId != dispatch.LoadingTerminalId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.FreightId != dispatch.FreightId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }            
            if (billOfLading.TicketNumber != dispatch.TicketNumber) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.JobSiteId != dispatch.JobSiteId) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.ShipmentDate != dispatch.ActualLoadingTerminalDepartureTime.Date) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            if (billOfLading.ShipmentWeight != dispatch.ShipmentWeight) { UpdateBOLFromDispatch(ref billOfLading, ref dispatch); return; }
            // if everything is equal update to the BOL is not necessary;
        }

        private static void UpdateBOLFromDispatch(ref BillOfLading billOfLading, ref Dispatch dispatch)
        {
            billOfLading.CustomerId = dispatch.CustomerId;
            billOfLading.JobNumberId = dispatch.JobNumberId;
            billOfLading.PurchaseOrderId = dispatch.PurchaseOrderId;
            billOfLading.CarrierId = dispatch.CarrierId;
            billOfLading.DriverId = dispatch.DriverId;
            billOfLading.LoadingTerminalId = dispatch.LoadingTerminalId;
            billOfLading.FreightId = dispatch.FreightId;
            billOfLading.TicketNumber = dispatch.TicketNumber;
            billOfLading.JobSiteId = dispatch.JobSiteId;
            billOfLading.ShipmentDate = dispatch.ActualLoadingTerminalDepartureTime.Date;
            billOfLading.ShipmentWeight = dispatch.ShipmentWeight;
            if (billOfLading.BillOfLadingStatusId < 3) // change status to appropriate level if it's less than 'delivered'. If there's a weight, then status should be 2
            {
                if (billOfLading.ShipmentWeight > 0) billOfLading.BillOfLadingStatusId = 2; // means it's been weighed
                if (dispatch.JobSiteActualDepartureTime != new DateTime()) billOfLading.BillOfLadingStatusId = 3; // it's been delivered
            }
            SqlSave(ref billOfLading);
        }

        public static bool SqlSave(ref BillOfLading b)
        {
            bool saved = false;

            if (b.BillOfLadingId == 0)
            {
                saved = SqlSaveInsert(ref b);
            }
            else
            {
                saved = SqlSaveUpdate(ref b);
            }

            return saved;
        }

        public static bool SqlDelete(ref BillOfLading b)
        {
            string sqlStatement = "delete from BillOfLadings where BillOfLadingId = " + b.BillOfLadingId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static BillOfLading BillOfLadingGetFromSqlDataReader(ref IDataReader dataReader)
        {
            BillOfLading b = new BillOfLading();

            b.BillOfLadingId = dataReader.IsDBNull(FIELD_BILLOFLADINGID) ? 0: dataReader.GetInt32(FIELD_BILLOFLADINGID);
            b.CustomerId = dataReader.IsDBNull(FIELD_CUSTOMERID) ? 0: dataReader.GetInt32(FIELD_CUSTOMERID);
            b.JobNumberId = dataReader.IsDBNull(FIELD_JOBNUMBERID) ? 0: dataReader.GetInt32(FIELD_JOBNUMBERID);
            b.PurchaseOrderId = dataReader.IsDBNull(FIELD_PURCHASEORDERID) ? 0: dataReader.GetInt32(FIELD_PURCHASEORDERID);
            b.BillOfLadingNumber = dataReader.IsDBNull(FIELD_BILLOFLADINGNUMBER) ? string.Empty: dataReader.GetString(FIELD_BILLOFLADINGNUMBER);
            b.CarrierId = dataReader.IsDBNull(FIELD_CARRIERID) ? 0: dataReader.GetInt32(FIELD_CARRIERID);
            b.DriverId = dataReader.IsDBNull(FIELD_DRIVERID) ? 0: dataReader.GetInt32(FIELD_DRIVERID);
            b.LoadingTerminalId = dataReader.IsDBNull(FIELD_LOADINGTERMINALID) ? 0: dataReader.GetInt32(FIELD_LOADINGTERMINALID);
            b.FreightId = dataReader.IsDBNull(FIELD_FREIGHTID) ? 0: dataReader.GetInt32(FIELD_FREIGHTID);
            b.TicketNumber = dataReader.IsDBNull(FIELD_TICKETNUMBER) ? string.Empty : dataReader.GetString(FIELD_TICKETNUMBER);
            b.JobSiteId = dataReader.IsDBNull(FIELD_JOBSITEID) ? 0: dataReader.GetInt32(FIELD_JOBSITEID);
            b.BillOfLadingStatusId = dataReader.IsDBNull(FIELD_BILLOFLADINGSTATUSID) ? 0: dataReader.GetInt32(FIELD_BILLOFLADINGSTATUSID);
            b.ShipmentDate = dataReader.IsDBNull(FIELD_SHIPMENTDATE) ? new DateTime(): dataReader.GetDateTime(FIELD_SHIPMENTDATE);
            b.ShipmentWeight = dataReader.IsDBNull(FIELD_SHIPMENTWEIGHT) ? 0: dataReader.GetDecimal(FIELD_SHIPMENTWEIGHT);
            b.BillOfLadingComments = dataReader.IsDBNull(FIELD_BILLOFLADINGCOMMENTS) ? string.Empty: dataReader.GetString(FIELD_BILLOFLADINGCOMMENTS);
            b.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            b.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            b.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            b.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) b.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, b.RowUpdateVersion, 0, 8);

            return b;
        }

        private static bool SqlSaveInsert(ref BillOfLading b)
        {
            string sqlStatement = "BillOfLadingInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@CustomerId", (object)b.CustomerId));
            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)b.JobNumberId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderId", (object)b.PurchaseOrderId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)b.BillOfLadingNumber));
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)b.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)b.DriverId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)b.LoadingTerminalId));
            command.Parameters.Add(new SqlParameter("@FreightId", (object)b.FreightId));
            command.Parameters.Add(new SqlParameter("@TicketNumber", (object)b.TicketNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)b.JobSiteId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingStatusId", (object)b.BillOfLadingStatusId));
            if (b.ShipmentDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ShipmentDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ShipmentDate", (object)b.ShipmentDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)b.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@BillOfLadingComments", (object)b.BillOfLadingComments));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            b.BillOfLadingId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return b.BillOfLadingId != 0;
        }

        private static bool SqlSaveUpdate(ref BillOfLading b)
        {
            string sqlStatement = "BillOfLadingUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@BillOfLadingId", (object)b.BillOfLadingId));
            command.Parameters.Add(new SqlParameter("@CustomerId", (object)b.CustomerId));
            command.Parameters.Add(new SqlParameter("@JobNumberId", (object)b.JobNumberId));
            command.Parameters.Add(new SqlParameter("@PurchaseOrderId", (object)b.PurchaseOrderId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingNumber", (object)b.BillOfLadingNumber));
            command.Parameters.Add(new SqlParameter("@CarrierId", (object)b.CarrierId));
            command.Parameters.Add(new SqlParameter("@DriverId", (object)b.DriverId));
            command.Parameters.Add(new SqlParameter("@LoadingTerminalId", (object)b.LoadingTerminalId));
            command.Parameters.Add(new SqlParameter("@FreightId", (object)b.FreightId));
            command.Parameters.Add(new SqlParameter("@TicketNumber", (object)b.TicketNumber));
            command.Parameters.Add(new SqlParameter("@JobSiteId", (object)b.JobSiteId));
            command.Parameters.Add(new SqlParameter("@BillOfLadingStatusId", (object)b.BillOfLadingStatusId));
            if (b.ShipmentDate == new DateTime())
            {
                command.Parameters.Add(new SqlParameter("@ShipmentDate", (object)System.DBNull.Value));
            }
            else
            {
                command.Parameters.Add(new SqlParameter("@ShipmentDate", (object)b.ShipmentDate));
            }
            command.Parameters.Add(new SqlParameter("@ShipmentWeight", (object)b.ShipmentWeight));
            command.Parameters.Add(new SqlParameter("@BillOfLadingComments", (object)b.BillOfLadingComments));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
