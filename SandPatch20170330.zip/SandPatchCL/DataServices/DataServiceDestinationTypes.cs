using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceDestinationTypes
    {

        #region Private Members

        private const int FIELD_DESTINATIONTYPEID          = 0;
        private const int FIELD_DESTINATIONTYPEDESCRIPTION = 1;
        private const int FIELD_DATEADDED                  = 2;
        private const int FIELD_ADDEDBY                    = 3;
        private const int FIELD_DATEUPDATED                = 4;
        private const int FIELD_UPDATEDBY                  = 5;
        private const int FIELD_ROWUPDATEVERSION           = 6;

        #endregion


        #region Constructor

        private DataServiceDestinationTypes() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static DestinationType DestinationTypeSqlGetById(int destinationTypeId)
        {
            string sqlStatement = "GetDestinationTypeById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)destinationTypeId));

            IDataReader dataReader;

            DestinationType d = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                d = DestinationTypeGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return d;
        }

        //public static Collection<DestinationType> DestinationTypeSqlGetBySearchTerms(string DestinationTypeId, string DestinationTypeDescription, )
        //{
        //    string sqlStatement = "SelectDestinationTypesSearchTerms";

        //    SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
        //    command.CommandType = CommandType.StoredProcedure;

        //    if (DestinationTypeId != string.Empty) command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)DestinationTypeId));
        //    if (DestinationTypeDescription != string.Empty) command.Parameters.Add(new SqlParameter("@DestinationTypeDescription", (object)DestinationTypeDescription));

        //    IDataReader dataReader;

        //    Collection<DestinationType> rowCollection = new Collection<DestinationType>();

        //    dataReader = command.ExecuteReader();

        //    while (dataReader.Read())
        //    {
        //        DestinationType d = DestinationTypeGetFromSqlDataReader(ref dataReader);
        //        rowCollection.Add(d);
        //    }

        //    command.Connection.Close();

        //    return rowCollection;
        //}

        public static Collection<DestinationType> DestinationTypeSqlGetAll()
        {
            string sqlStatement = "GetAllDestinationTypes";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<DestinationType> rowCollection = new Collection<DestinationType>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                DestinationType d = DestinationTypeGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(d);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref DestinationType d)
        {
            bool saved = false;

            if (d.DestinationTypeId == 0)
            {
                saved = SqlSaveInsert(ref d);
            }
            else
            {
                saved = SqlSaveUpdate(ref d);
            }

            return saved;
        }

        public static bool SqlDelete(ref DestinationType d)
        {
            string sqlStatement = "delete from DestinationTypes where DestinationTypeId = " + d.DestinationTypeId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static DestinationType DestinationTypeGetFromSqlDataReader(ref IDataReader dataReader)
        {
            DestinationType d = new DestinationType();

            d.DestinationTypeId = dataReader.IsDBNull(FIELD_DESTINATIONTYPEID) ? 0: dataReader.GetInt32(FIELD_DESTINATIONTYPEID);
            d.DestinationTypeDescription = dataReader.IsDBNull(FIELD_DESTINATIONTYPEDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_DESTINATIONTYPEDESCRIPTION);
            d.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            d.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            d.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            d.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) d.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, d.RowUpdateVersion, 0, 8);

            return d;
        }

        private static bool SqlSaveInsert(ref DestinationType d)
        {
            string sqlStatement = "DestinationTypeInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DestinationTypeDescription", (object)d.DestinationTypeDescription));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            d.DestinationTypeId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return d.DestinationTypeId != 0;
        }

        private static bool SqlSaveUpdate(ref DestinationType d)
        {
            string sqlStatement = "DestinationTypeUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@DestinationTypeId", (object)d.DestinationTypeId));
            command.Parameters.Add(new SqlParameter("@DestinationTypeDescription", (object)d.DestinationTypeDescription));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
