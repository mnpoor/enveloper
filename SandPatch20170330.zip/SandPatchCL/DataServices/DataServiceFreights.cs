using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;

namespace SandPatchCL.DataServices
{
    public class DataServiceFreights
    {

        #region Private Members

        private const int FIELD_FREIGHTID              = 0;
        private const int FIELD_FREIGHTNAME            = 1;
        private const int FIELD_FREIGHTDESCRIPTION     = 2;
        private const int FIELD_FREIGHTUNITOFMEASURE   = 3;
        private const int FIELD_FREIGHTSTATUSID        = 4;
        private const int FIELD_FREIGHTNOTES           = 5;
        private const int FIELD_DATEADDED              = 6;
        private const int FIELD_ADDEDBY                = 7;
        private const int FIELD_DATEUPDATED            = 8;
        private const int FIELD_UPDATEDBY              = 9;
        private const int FIELD_ROWUPDATEVERSION       = 10;

        #endregion


        #region Constructor

        private DataServiceFreights() { }

        #endregion


        #region Public Properties (None)

        #endregion


        #region Public SQL Server Methods

        public static Freight FreightSqlGetById(int freightId)
        {
            string sqlStatement = "GetFreightById";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FreightId", (object)freightId));

            IDataReader dataReader;

            Freight f = null;

            dataReader = command.ExecuteReader();

            if (dataReader.Read())
            {
                f = FreightGetFromSqlDataReader(ref dataReader);
            }

            command.Connection.Close();

            return f;
        }

        public static Collection<Freight> FreightSqlGetBySearchTerms(string FreightName, string FreightDescription)
        {
            string sqlStatement = "SelectFreightsSearchTerms";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            if (FreightName != string.Empty) command.Parameters.Add(new SqlParameter("@FreightName", (object)FreightName));
            if (FreightDescription != string.Empty) command.Parameters.Add(new SqlParameter("@FreightDescription", (object)FreightDescription));

            IDataReader dataReader;

            Collection<Freight> rowCollection = new Collection<Freight>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Freight f = FreightGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(f);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static Collection<Freight> FreightSqlGetAll()
        {
            string sqlStatement = "GetAllFreights";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            IDataReader dataReader;

            Collection<Freight> rowCollection = new Collection<Freight>();

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                Freight f = FreightGetFromSqlDataReader(ref dataReader);
                rowCollection.Add(f);
            }

            command.Connection.Close();

            return rowCollection;
        }

        public static bool SqlSave(ref Freight f)
        {
            bool saved = false;

            if (f.FreightId == 0)
            {
                saved = SqlSaveInsert(ref f);
            }
            else
            {
                saved = SqlSaveUpdate(ref f);
            }

            return saved;
        }

        public static bool SqlDelete(ref Freight f)
        {
            string sqlStatement = "delete from Freights where FreightId = " + f.FreightId.ToString();

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.Text;

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return (recordsAffected == 1);
        }


        #endregion


        #region SQL Server Private Methods

        private static Freight FreightGetFromSqlDataReader(ref IDataReader dataReader)
        {
            Freight f = new Freight();

            f.FreightId = dataReader.IsDBNull(FIELD_FREIGHTID) ? 0: dataReader.GetInt32(FIELD_FREIGHTID);
            f.FreightName = dataReader.IsDBNull(FIELD_FREIGHTNAME) ? string.Empty: dataReader.GetString(FIELD_FREIGHTNAME);
            f.FreightDescription = dataReader.IsDBNull(FIELD_FREIGHTDESCRIPTION) ? string.Empty: dataReader.GetString(FIELD_FREIGHTDESCRIPTION);
            f.FreightUnitOfMeasure = dataReader.IsDBNull(FIELD_FREIGHTUNITOFMEASURE) ? string.Empty: dataReader.GetString(FIELD_FREIGHTUNITOFMEASURE);
            f.FreightStatusId = dataReader.IsDBNull(FIELD_FREIGHTSTATUSID) ? 0: dataReader.GetInt32(FIELD_FREIGHTSTATUSID);
            f.FreightNotes = dataReader.IsDBNull(FIELD_FREIGHTNOTES) ? string.Empty: dataReader.GetString(FIELD_FREIGHTNOTES);
            f.DateAdded = dataReader.IsDBNull(FIELD_DATEADDED) ? string.Empty: dataReader.GetString(FIELD_DATEADDED);
            f.AddedBy = dataReader.IsDBNull(FIELD_ADDEDBY) ? string.Empty: dataReader.GetString(FIELD_ADDEDBY);
            f.DateUpdated = dataReader.IsDBNull(FIELD_DATEUPDATED) ? string.Empty: dataReader.GetString(FIELD_DATEUPDATED);
            f.UpdatedBy = dataReader.IsDBNull(FIELD_UPDATEDBY) ? string.Empty: dataReader.GetString(FIELD_UPDATEDBY);
            if (dataReader.IsDBNull(FIELD_ROWUPDATEVERSION)) f.RowUpdateVersion = new byte[] {0, 0, 0, 0, 0, 0, 0, 0};
                else dataReader.GetBytes(FIELD_ROWUPDATEVERSION, 0, f.RowUpdateVersion, 0, 8);

            return f;
        }

        private static bool SqlSaveInsert(ref Freight f)
        {
            string sqlStatement = "FreightInsert";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FreightName", (object)f.FreightName));
            command.Parameters.Add(new SqlParameter("@FreightDescription", (object)f.FreightDescription));
            command.Parameters.Add(new SqlParameter("@FreightUnitOfMeasure", (object)f.FreightUnitOfMeasure));
            command.Parameters.Add(new SqlParameter("@FreightStatusId", (object)f.FreightStatusId));
            command.Parameters.Add(new SqlParameter("@FreightNotes", (object)f.FreightNotes));
            command.Parameters.Add("@PK_New", SqlDbType.Int);
            command.Parameters["@PK_New"].Direction = ParameterDirection.Output;

            int recordsAffected = Convert.ToInt32(command.ExecuteNonQuery());

            f.FreightId = Convert.ToInt32(command.Parameters["@PK_New"].Value);

            command.Connection.Close();

            return f.FreightId != 0;
        }

        private static bool SqlSaveUpdate(ref Freight f)
        {
            string sqlStatement = "FreightUpdate";

            SqlCommand command = new SqlCommand(sqlStatement, DataServiceBase.GetSQLConnection());
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FreightId", (object)f.FreightId));
            command.Parameters.Add(new SqlParameter("@FreightName", (object)f.FreightName));
            command.Parameters.Add(new SqlParameter("@FreightDescription", (object)f.FreightDescription));
            command.Parameters.Add(new SqlParameter("@FreightUnitOfMeasure", (object)f.FreightUnitOfMeasure));
            command.Parameters.Add(new SqlParameter("@FreightStatusId", (object)f.FreightStatusId));
            command.Parameters.Add(new SqlParameter("@FreightNotes", (object)f.FreightNotes));

            int recordsAffected = command.ExecuteNonQuery();

            command.Connection.Close();

            return recordsAffected == 1;
        }

        #endregion

    }
}
