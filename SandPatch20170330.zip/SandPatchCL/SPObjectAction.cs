using System;
using System.Collections.Generic;
using System.Text;

namespace SandPatchCL
{
    public enum SPObjectAction
    {
        add,
        cancel,
        clear,
        clearSearch,
        click,
        dataGridItemSelected,
        delete,
        dispatchImport,
        listItemSelected,
        pause,
        previewPrint,
        refresh,
        saveToTable,
        search,
        update
    }
}
