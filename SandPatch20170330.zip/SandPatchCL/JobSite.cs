using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SandPatchCL
{
    public class JobSite : SPClassBase, ISPClass
    {

        public event PropertyChangedEventHandler PropertyChanged;

        #region Private Members

        private int _jobSiteId;
        private string _jobSiteName;
        private int _wellOperatorId;
        private string _jobSiteContactName;
        private string _streetAddress;
        private string _boxAddress;
        private string _city;
        private string _jobSiteState;
        private string _postalCode;
        private string _countryCode;
        private int _jobSiteStatusId;
        private string _jobSitePhoneNumber;
        private string _jobSiteFaxNumber;
        private string _jobSiteContactEmail;
        private string _jobSiteContactMobileNumber;
        private string _jobSiteLatitude;
        private string _jobSiteLongitude;
        private string _jobSiteDrivingDirections;
        private string _jobSiteNotes;

        #endregion


        #region Constructor

        public JobSite()
        {
            this._jobSiteId = 0;
            this._jobSiteName = string.Empty;
            this._wellOperatorId = 0;
            this._jobSiteContactName = string.Empty;
            this._streetAddress = string.Empty;
            this._boxAddress = string.Empty;
            this._city = string.Empty;
            this._jobSiteState = string.Empty;
            this._postalCode = string.Empty;
            this._countryCode = string.Empty;
            this._jobSiteStatusId = 0;
            this._jobSitePhoneNumber = string.Empty;
            this._jobSiteFaxNumber = string.Empty;
            this._jobSiteContactEmail = string.Empty;
            this._jobSiteContactMobileNumber = string.Empty;
            this._jobSiteLatitude = string.Empty;
            this._jobSiteLongitude = string.Empty;
            this._jobSiteDrivingDirections = string.Empty;
            this._jobSiteNotes = string.Empty;
        }

        //public Lease(bool use, string name)
        //{
        //    _use = use;
        //    Name = name;
        //}

        public JobSite(JobSite j)
        {
            this._jobSiteId = j.JobSiteId;
            this._jobSiteName = j.JobSiteName;
            this._wellOperatorId = j.WellOperatorId;
            this._jobSiteContactName = j.JobSiteContactName;
            this._streetAddress = j.StreetAddress;
            this._boxAddress = j.BoxAddress;
            this._city = j.City;
            this._jobSiteState = j.JobSiteState;
            this._postalCode = j.PostalCode;
            this._countryCode = j.CountryCode;
            this._jobSiteStatusId = j.JobSiteStatusId;
            this._jobSitePhoneNumber = j.JobSitePhoneNumber;
            this._jobSiteFaxNumber = j.JobSiteFaxNumber;
            this._jobSiteContactEmail = j.JobSiteContactEmail;
            this._jobSiteContactMobileNumber = j.JobSiteContactMobileNumber;
            this._jobSiteLatitude = j.JobSiteLatitude;
            this._jobSiteLongitude = j.JobSiteLongitude;
            this._jobSiteDrivingDirections = j.JobSiteDrivingDirections;
            this._jobSiteNotes = j.JobSiteNotes;
            this._dateAdded = j.DateAdded;
            this._addedBy = j.AddedBy;
            this._dateUpdated = j.DateUpdated;
            this._updatedBy = j.UpdatedBy;
            this._rowUpdateVersion = j.RowUpdateVersion;
        }

        #endregion

        #region iNotifyPropertyChanged Interface

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged(String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        //public bool Use
        //{
        //    get
        //    {
        //        return _use;
        //    }
        //    set
        //    {
        //        if (_use != value && this.PropertyChanged != null)
        //        {
        //            _use = value;
        //            this.PropertyChanged(this, new PropertyChangedEventArgs("Use"));
        //        }
        //        else
        //            _use = value;
        //    }
        //}

        #endregion


        #region Public Properties

        public SPClassType ClassType
        {
            get
            {
                return SPClassType.JobSite;
            }
        }

        public int JobSiteId
        {
            get
            {
                return this._jobSiteId;
            }
            set
            {
                this._jobSiteId = value;
                NotifyPropertyChanged("JobSiteId");
            }
        }

        public string JobSiteName
        {
            get
            {
                return this._jobSiteName;
            }
            set
            {
                this._jobSiteName = value;
                NotifyPropertyChanged("JobSiteName");
            }
        }

        public int WellOperatorId
        {
            get
            {
                return this._wellOperatorId;
            }
            set
            {
                this._wellOperatorId = value;
                NotifyPropertyChanged("WellOperatorId");
            }
        }

        public string JobSiteContactName
        {
            get
            {
                return this._jobSiteContactName;
            }
            set
            {
                this._jobSiteContactName = value;
                NotifyPropertyChanged("JobSiteContactName");
            }
        }

        public string StreetAddress
        {
            get
            {
                return this._streetAddress;
            }
            set
            {
                this._streetAddress = value;
                NotifyPropertyChanged("StreetAddress");
            }
        }

        public string BoxAddress
        {
            get
            {
                return this._boxAddress;
            }
            set
            {
                this._boxAddress = value;
                NotifyPropertyChanged("BoxAddress");
            }
        }

        public string City
        {
            get
            {
                return this._city;
            }
            set
            {
                this._city = value;
                NotifyPropertyChanged("City");
            }
        }

        public string JobSiteState
        {
            get
            {
                return this._jobSiteState;
            }
            set
            {
                this._jobSiteState = value;
                NotifyPropertyChanged("JobSiteState");
            }
        }

        public string PostalCode
        {
            get
            {
                return this._postalCode;
            }
            set
            {
                this._postalCode = value;
                NotifyPropertyChanged("PostalCode");
            }
        }

        public string CountryCode
        {
            get
            {
                return this._countryCode;
            }
            set
            {
                this._countryCode = value;
                NotifyPropertyChanged("CountryCode");
            }
        }

        public int JobSiteStatusId
        {
            get
            {
                return this._jobSiteStatusId;
            }
            set
            {
                this._jobSiteStatusId = value;
                NotifyPropertyChanged("JobSiteStatusId");
            }
        }

        public string JobSitePhoneNumber
        {
            get
            {
                return this._jobSitePhoneNumber;
            }
            set
            {
                this._jobSitePhoneNumber = value;
                NotifyPropertyChanged("JobSitePhoneNumber");
            }
        }

        public string JobSiteFaxNumber
        {
            get
            {
                return this._jobSiteFaxNumber;
            }
            set
            {
                this._jobSiteFaxNumber = value;
                NotifyPropertyChanged("JobSiteFaxNumber");
            }
        }

        public string JobSiteContactEmail
        {
            get
            {
                return this._jobSiteContactEmail;
            }
            set
            {
                this._jobSiteContactEmail = value;
                NotifyPropertyChanged("JobSiteContactEmail");
            }
        }

        public string JobSiteContactMobileNumber
        {
            get
            {
                return this._jobSiteContactMobileNumber;
            }
            set
            {
                this._jobSiteContactMobileNumber = value;
                NotifyPropertyChanged("JobSiteContactMobileNumber");
            }
        }

        public string JobSiteLatitude
        {
            get
            {
                return this._jobSiteLatitude;
            }
            set
            {
                this._jobSiteLatitude = value;
                NotifyPropertyChanged("JobSiteLatitude");
            }
        }

        public string JobSiteLongitude
        {
            get
            {
                return this._jobSiteLongitude;
            }
            set
            {
                this._jobSiteLongitude = value;
                NotifyPropertyChanged("JobSiteLongitude");
            }
        }

        public string JobSiteDrivingDirections
        {
            get
            {
                return this._jobSiteDrivingDirections;
            }
            set
            {
                this._jobSiteDrivingDirections = value;
                NotifyPropertyChanged("JobSiteDrivingDirections");
            }
        }

        public string JobSiteNotes
        {
            get
            {
                return this._jobSiteNotes;
            }
            set
            {
                this._jobSiteNotes = value;
                NotifyPropertyChanged("JobSiteNotes");
            }
        }

        #endregion


        #region Public Methods

        public bool Equals(JobSite j)
        {
            #region Compare Members

            if (this._jobSiteId != j.JobSiteId)
            {
                return false;
            }

            if (this._jobSiteName != j.JobSiteName)
            {
                return false;
            }

            if (this._wellOperatorId != j.WellOperatorId)
            {
                return false;
            }

            if (this._jobSiteContactName != j.JobSiteContactName)
            {
                return false;
            }

            if (this._streetAddress != j.StreetAddress)
            {
                return false;
            }

            if (this._boxAddress != j.BoxAddress)
            {
                return false;
            }

            if (this._city != j.City)
            {
                return false;
            }

            if (this._jobSiteState != j.JobSiteState)
            {
                return false;
            }

            if (this._postalCode != j.PostalCode)
            {
                return false;
            }

            if (this._countryCode != j.CountryCode)
            {
                return false;
            }

            if (this._jobSiteStatusId != j.JobSiteStatusId)
            {
                return false;
            }

            if (this._jobSitePhoneNumber != j.JobSitePhoneNumber)
            {
                return false;
            }

            if (this._jobSiteFaxNumber != j.JobSiteFaxNumber)
            {
                return false;
            }

            if (this._jobSiteContactEmail != j.JobSiteContactEmail)
            {
                return false;
            }

            if (this._jobSiteContactMobileNumber != j.JobSiteContactMobileNumber)
            {
                return false;
            }

            if (this._jobSiteLatitude != j.JobSiteLatitude)
            {
                return false;
            }

            if (this._jobSiteLongitude != j.JobSiteLongitude)
            {
                return false;
            }

            if (this._jobSiteDrivingDirections != j.JobSiteDrivingDirections)
            {
                return false;
            }

            if (this._jobSiteNotes != j.JobSiteNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            JobSite j = obj as JobSite;
            if ((System.Object)j == null)
            {
                return false;
            }

            if (!this.Equals(j))
            {
                return false;
            }

            return true;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        static public bool operator ==(JobSite a, JobSite b)
        {
            if (System.Object.ReferenceEquals(a, b))
            {
                return true;
            }

            if ((object)a == null || ((object)b == null))
            {
                return false;
            }

            #region Compare Members

            if (a.JobSiteId != b.JobSiteId)
            {
                return false;
            }

            if (a.JobSiteName != b.JobSiteName)
            {
                return false;
            }

            if (a.WellOperatorId != b.WellOperatorId)
            {
                return false;
            }

            if (a.JobSiteContactName != b.JobSiteContactName)
            {
                return false;
            }

            if (a.StreetAddress != b.StreetAddress)
            {
                return false;
            }

            if (a.BoxAddress != b.BoxAddress)
            {
                return false;
            }

            if (a.City != b.City)
            {
                return false;
            }

            if (a.JobSiteState != b.JobSiteState)
            {
                return false;
            }

            if (a.PostalCode != b.PostalCode)
            {
                return false;
            }

            if (a.CountryCode != b.CountryCode)
            {
                return false;
            }

            if (a.JobSiteStatusId != b.JobSiteStatusId)
            {
                return false;
            }

            if (a.JobSitePhoneNumber != b.JobSitePhoneNumber)
            {
                return false;
            }

            if (a.JobSiteFaxNumber != b.JobSiteFaxNumber)
            {
                return false;
            }

            if (a.JobSiteContactEmail != b.JobSiteContactEmail)
            {
                return false;
            }

            if (a.JobSiteContactMobileNumber != b.JobSiteContactMobileNumber)
            {
                return false;
            }

            if (a.JobSiteLatitude != b.JobSiteLatitude)
            {
                return false;
            }

            if (a.JobSiteLongitude != b.JobSiteLongitude)
            {
                return false;
            }

            if (a.JobSiteDrivingDirections != b.JobSiteDrivingDirections)
            {
                return false;
            }

            if (a.JobSiteNotes != b.JobSiteNotes)
            {
                return false;
            }

            #endregion

            return true;
        }

        static public bool operator !=(JobSite a, JobSite b)
        {
            return !(a == b);
        }

        #endregion

    }

}
